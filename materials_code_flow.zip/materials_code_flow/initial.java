//materials.ws
requestMaterialsLoginBS	
	
Get materials access and role details, APPLICATION_JSON
Response requestMaterialsLogin
	sm_ssoid
	portal_id
	String strSSO = MaterialsServiceUtil.getSMSSOId(request); ----return normaizedUserId ----ERROR_8301
		strUserId = request.getHeader(SM_SSOID);
	String portalId = MaterialsServiceUtil.getPortalId(request); ----return normaizedPortalId   ----ERROR_8302
		strPortalId = request.getHeader(PORTAL_ID);
	import static com.geaviation.materials.ws.util.Constants
	Object loginResponse = materialsLoginInterceptor.requestMaterialsLogin(strSSO, portalId);
		isGEAEUser = true;
		isGEAEUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
			String userType = getUserType(sso, portalId);
				User userBO = getUserDetails(sso, portalId,"user/");
					return userBO;
				List<Property> userProperty = userBO.getUserProperty();
				userType = property.getPropValue();
				return userType;
			return flag;
		return materialsLoginApp.requestMaterialsLogin(strSSO, portalId);
			String icao = materialsAppUtil.getIcaoCode(sso, portalId);
				icao = getUserIcaoCode(sso, portalId, "user/orgid/");
					return userString;
				return icao;
			List<Object> loginDetailLst = getLoginAllData(sso,portalId,icao);
				materialsLoginResponse = requestMaterialsLoginBS(sso,portalId,icao);
					String icaoCode = icao;
					MaterialsAppUtil.isNotNullandEmpty(sso) ------ERROR_8301
					MaterialsAppUtil.isNotNullandEmpty(portalId)  ------ERROR_8302
					MaterialsAppUtil.isNotNullandEmpty(icaoCode)
						materialsAppUtil.startLogging(task, watch);
						String defaultOrgId = materialsAppUtil.getDefaultOrg(sso, portalId);
							defaultOrg = getUserAttributes(strSso, portalId, ATTR_USER_ORG, "user/prop/");
								return propValue;
							return defaultOrg;
						materialsAppUtil.endLogging(task, watch);
						materialsAppUtil.startLogging(task, watch);
						String opUid =  materialsLoginDAO.getPortalOUDS(portalId.toUpperCase());
							Map<String,String> portalOuIdMap = new HashMap<String,String>();
							portalOuIdMap = materialsDataUtil.getPortalConfigAsMap(portalToOperatingUnitIdConfig);
							return portalOuIdMap.get(portalId);
						materialsAppUtil.endLogging(task, watch);
						materialsUserAccess =  materialsLoginDAO.isHavingAccessDS(sso, icaoCode, opUid);
							MaterialsUserAccess userAccess = null;
							String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_CHECK_LOGIN);
				return list;
			return loginResponse;
		return obj;
	loginResponse
	return response




requestMaterialsLoginAttivioBS
requestRepairsLoginAttivioBS
requestRepairsLogin
getCartBS
saveCartBS
deleteCartBS
getCartCountBS
deleteCartLineBS
addLineItemBS
getLineDetailBS
deleteOrderLineBS
updateShipmentDetailsBS
downloadDisputeDocBS
uploadOrderTemplateBS
createDisputeOrderBS
getOrders
getHeaderDetailBS
getOrderAuditHistoryBS
getOrderTemplateBS
updateOrderBS
getLineStatusHistoryBS
getPricingCatalogBS
getPricingCatalogDocBS
purchasePOBS
getPoQuotations
getShiptoMarkforAddressBS
insertWishList
getWishListDetails
deleteWishListBS
wishLstToSaveLst
addBulkPartDtls
getBulkSearchPartDtlBS
getCustAdminDetailsBS
getItemAvailPricDtlBS
getItemAvailPricPartDtlBS
getItemConfigHistoryBS
getKitStructureBS
getRepUsedItemConfigHistory
getCommercialAgreementBS
getCommercialAgreementPartBS
getRatingPlugBS
createRatingPlugFormBS
getRatingPlugFormBS
getInvoiceDocumentBS
listRFQBS
getRFQDetailBS
getRFQBS
createRFQBS
getcsvFile
getMaterialsDocumentBS
getPDFFile
getRepairCatalogBS
getRepairCatalogListBS
getGlobEnqCustIdListBS
getOrderDetailsBS










