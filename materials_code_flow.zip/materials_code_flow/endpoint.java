


materials.ws



CONFIG




IMPL

	MaterialsServicesImpl
	
		requestMaterialsLoginBS	
		requestMaterialsLoginAttivioBS
		requestRepairsLoginAttivioBS
		requestRepairsLogin
		getCartBS
		saveCartBS
		deleteCartBS
		getCartCountBS
		deleteCartLineBS
		addLineItemBS
		getLineDetailBS
		deleteOrderLineBS
		updateShipmentDetailsBS
		downloadDisputeDocBS
		uploadOrderTemplateBS
		createDisputeOrderBS
		getOrders
		getHeaderDetailBS
		getOrderAuditHistoryBS
		getOrderTemplateBS
		updateOrderBS
		getLineStatusHistoryBS
		getPricingCatalogBS
		getPricingCatalogDocBS
		purchasePOBS
		getPoQuotations
		getShiptoMarkforAddressBS
		insertWishList
		getWishListDetails
		deleteWishListBS
		wishLstToSaveLst
		addBulkPartDtls
		getBulkSearchPartDtlBS
		getCustAdminDetailsBS
		getItemAvailPricDtlBS
		getItemAvailPricPartDtlBS
		getItemConfigHistoryBS
		getKitStructureBS
		getRepUsedItemConfigHistory
		getCommercialAgreementBS
		getCommercialAgreementPartBS
		getRatingPlugBS
		createRatingPlugFormBS
		getRatingPlugFormBS
		getInvoiceDocumentBS
		listRFQBS
		getRFQDetailBS
		getRFQBS
		createRFQBS
		getcsvFile
		getMaterialsDocumentBS
		getPDFFile
		getRepairCatalogBS
		getRepairCatalogListBS
		getGlobEnqCustIdListBS
		getOrderDetailsBS



UTIL
	
	Constants
	MaterialsServiceUtil



MaterialsServicesSBApp















