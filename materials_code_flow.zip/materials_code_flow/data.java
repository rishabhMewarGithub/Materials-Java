


materials.data

API

	MaterialsCartDAOImpl
		
		import static com.geaviation.materials.data.impl.util.MaterialsDataUtil.getAsString;
	
		import com.geaviation.dss.service.common.exception.TechnicalException;
		import java.util.List;
		import com.geaviation.materials.entity.CartDO;
		import com.geaviation.materials.entity.CustomerBO;
		import com.geaviation.materials.entity.DeleteCartLineBO;
		import com.geaviation.materials.entity.ItemDetailHeaderInputDO;
		import com.geaviation.materials.entity.PurchasePODO;
		import com.geaviation.materials.entity.SaveCartDetailsOutputDO;
		import com.geaviation.materials.entity.SaveCartInputDO;
		import com.geaviation.materials.entity.SaveCartOrderLineInputDO;
		
		/////////////
		
		import java.sql.Array;
		import java.sql.CallableStatement;
		import java.sql.Connection;
		import java.sql.SQLException;
		import java.sql.Struct;
		import java.sql.Types;
		import java.util.ArrayList;
		import java.util.Arrays;
		
		import javax.sql.DataSource;
		import org.apache.commons.logging.Log;
		import org.apache.commons.logging.LogFactory;
		import org.springframework.beans.factory.annotation.Autowired;
		import org.springframework.beans.factory.annotation.Value;
		import org.springframework.context.annotation.Configuration;
		import org.springframework.stereotype.Component;

		import com.geaviation.materials.data.api.IMaterialsCartDAO;
		import com.geaviation.materials.data.impl.util.MaterialsDataConstants;
		import com.geaviation.materials.data.impl.util.MaterialsDataUtil;
		import com.geaviation.materials.data.impl.util.MaterialsQueryLoader;
		
		import com.geaviation.materials.entity.CartHDRInfoDO;
		import com.geaviation.materials.entity.CartMessageDO;
		import com.geaviation.materials.entity.LineMessageDO;
		import com.geaviation.materials.entity.PartDO;
		import com.geaviation.materials.entity.SaveCartLineMessageOutputDO;
		import com.geaviation.materials.entity.SaveCartMessageOutputDO;

		import oracle.jdbc.OracleConnection;
		import oracle.jdbc.OracleTypes;
		import oracle.sql.ARRAY;
		import oracle.sql.ArrayDescriptor;
		
		@Override
		public CartDO getCartDS(String strSSO, String icaoCode, List<CustomerBO> customerBOList,String role, String operatingUnitId,String portalId) throws TechnicalException
			return cartDO;
		/** * If sso or portalId input is null then it throws MaterialsException.
			* Returns Cart details as SaveCartDetailsOutputDO JSON object for the given SaveCartRequest JSON. 
			* The SaveCartDetailsOutputDO contains the following fields  :
				* cartHeaderId				denotes the cartHeaderId that is saved.
				* statusMessage				denotes the message from the procedure.
				* orderLineMessageBOList	denotes list of SaveCartOrderLineMessageBO		
			* @return SaveCartResponse				SaveCartResponse object
			* @throws TechnicalException	*/
		@Override
		public SaveCartDetailsOutputDO saveCartDS(String sso, String role,	String icao, String[] custIdArray, String operatingUnitId, List<SaveCartInputDO> saveCartInputDOList,
						List<SaveCartOrderLineInputDO> saveCartOrderLineInputDOList, List<Boolean> esnValidFlagList, List<String> priorityList) throws TechnicalException
			return saveCartDetailsOutputDO;
		@Override
		public String deleteCartDS(String strSSO,String  icaoCode, String[] custIdList, String role, String operatingUnitId) throws TechnicalException	
			return message;
		@Override
		public String[]  getCartCountDS(String strSSO,String  icaoCode, String[] custIdList, String role, String operatingUnitId) throws TechnicalException
			return cartCountValues;
		@Override
		public DeleteCartLineBO deleteCartLineDS(String strSSO,String icaoCode,String[] custIdList ,String role,String operatingUnitId,String cartHeaderId,String cartLineId)throws TechnicalException	
			return deleteCartLineBO;
		@Override
		public String   addLineItemDS(String strSSO,String icaoCode,String[] custIdList,String role,String operatingUnitid,String inventoryItemId,String selectedCustomerId,
										String selectedSupplierCode,String quantity,String pricingListId, String quoteHeaderId)  throws TechnicalException
			return message;
		@Override
		public PurchasePODO purchasePODS(String strSSO,String role,String icaoCode,String[] custIdList ,String operatingUnitId,String cartHeaderId,List<ItemDetailHeaderInputDO> lstDetailHeaderInputDOs)throws TechnicalException	
			return purchasePODO;
		private String[] getCustIds(List<CustomerBO> customerBOList)
			return custIds;
		private CartDO populateCartHDRLineDetailsValues(Array array,CartDO cartDO)	
			return cartDO;
		private CartDO populateCartHDRDetailsValues(Array array,CartDO cartDO,String portalId)
			return cartDO;
		private SaveCartDetailsOutputDO populateSaveCartDetails(Array array, SaveCartDetailsOutputDO saveCartDetailsOutputDO)
			return saveCartDetailsOutputDO;
		private SaveCartDetailsOutputDO populateSaveCartLineDetails(Array array, SaveCartDetailsOutputDO saveCartDetailsOutputDO, List<Boolean> esnValidFlagList,List<String> priorityList)
			return saveCartDetailsOutputDO;
		private void getItemIdCustomerId (CallableStatement callStatement, String inventoryItemId, String selectedCustomerId) throws SQLException 
		private void getQuantityPriceListIdHeaderId (CallableStatement callStatement, String quantity, String pricingListId, String quoteHeaderId) throws SQLException	
		private PurchasePODO populateCartMessagesDetailsValues(Array array, PurchasePODO purchasePODO)	
			return purchasePODO;
		private PurchasePODO populateCartLineDetailsValues(Array array, PurchasePODO purchasePODO)	
			return purchasePODO;
			
		
	
	MaterialsDAOImpl
	
		
		import java.sql.Date;
		import java.util.List;
		import java.util.Map;
		import org.bson.types.ObjectId;
		import com.geaviation.dss.service.common.exception.TechnicalException;
		import com.geaviation.materials.entity.BulkPartDetailsBO;
		import com.geaviation.materials.entity.CustGlobEnqDetails;
		import com.geaviation.materials.entity.CustomerAdminDetailsBO;
		import com.geaviation.materials.entity.CustomerBO;
		import com.geaviation.materials.entity.LineDetailDO;
		import com.geaviation.materials.entity.OrderStatusBO;
		import com.geaviation.materials.entity.OrderTemplateStatusBO;
		import com.geaviation.materials.entity.PartsInputDO2;
		import com.geaviation.materials.entity.Platform;
		import com.geaviation.materials.entity.PricingCatalogDO;
		import com.geaviation.materials.entity.PricingCatalogDates;
		import com.geaviation.materials.entity.PriorityBO;
		import com.mongodb.client.gridfs.model.GridFSFile;
		
		///////////
		
		import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.CF34;
		import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.CF348S;
		import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.CF34GA;
		import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.CT7;
		import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.CT7GA;
		import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.EMPTY_STRING;
		import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.GEAE;
		import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.PORTAL_CWC;
		import static com.geaviation.materials.data.impl.util.MaterialsDataUtil.getAsString;

		import java.sql.Array;
		import java.sql.CallableStatement;
		import java.sql.Connection;
		import java.sql.PreparedStatement;
		import java.sql.ResultSet;
		import java.sql.SQLException;
		import java.sql.Struct;
		import java.sql.Timestamp;
		import java.text.SimpleDateFormat;
		import java.util.ArrayList;
		import java.util.Arrays;
		import java.util.HashMap;
		import java.util.StringTokenizer;

		import javax.sql.DataSource;

		import org.apache.commons.logging.Log;
		import org.apache.commons.logging.LogFactory;
		import org.bson.Document;
		import org.springframework.beans.factory.annotation.Autowired;
		import org.springframework.beans.factory.annotation.Qualifier;
		import org.springframework.beans.factory.annotation.Value;
		import org.springframework.context.annotation.Configuration;
		import org.springframework.stereotype.Component;
		import org.springframework.util.StopWatch;

		import com.geaviation.materials.data.api.IMaterialsDAO;
		import com.geaviation.materials.data.impl.util.MaterialsDataConstants;
		import com.geaviation.materials.data.impl.util.MaterialsDataUtil;
		import com.geaviation.materials.data.impl.util.MaterialsQueryLoader;

		import com.geaviation.materials.entity.CustAdmin;
		import com.geaviation.materials.entity.CustGTAListBO;
		import com.geaviation.materials.entity.DeliverAddress;
		import com.geaviation.materials.entity.LineInfoDO;
		import com.geaviation.materials.entity.MappingAddress;
		import com.geaviation.materials.entity.ShipAddress;
		import com.mongodb.BasicDBObject;
		import com.mongodb.MongoClient;
		import com.mongodb.client.MongoCollection;
		import com.mongodb.client.MongoCursor;
		import com.mongodb.client.MongoDatabase;
		import com.mongodb.client.gridfs.GridFSBucket;
		import com.mongodb.client.gridfs.GridFSBuckets;
		import com.mongodb.client.gridfs.GridFSDownloadStream;
		import com.mongodb.client.model.Projections;

		import oracle.jdbc.OracleConnection;
		import oracle.jdbc.OracleTypes;
		import oracle.sql.ARRAY;
		import oracle.sql.ArrayDescriptor;

		@Override
		public List<PriorityBO> getPriorityDS(String strSSO,String portalId)throws TechnicalException
			return priorityList;
		@Override
		/** * Returns CustAdminDetailsDO details as CustAdminDetailsDO object for the given user.
			* The returned CustAdminDetailsDO object will have CustAdminDetails details object..
			* @return OrderDO		        OrderDO objects	*/
		public CustomerAdminDetailsBO getCustDetailDS(String sso, String icaoCode, String[] custIdList, String role, String operatingUnitId, String headerId) throws TechnicalException
			return custAdminDetailsDO;
		@Override
		public LineDetailDO getLineDetailDS(String strSSO, String icaoCode,	String[] custIdList, String role, String operatingUnitId, String msNumber, String deliveryId, String orderHeaderId, String invoiceHeaderId)
			return lineDetailDO;
		@Override
		public Platform getAllPricingCatalogDS(String portalId, String icaoCode, String icaoCodeAvialGTA)throws TechnicalException
			return platform;
		@Override
		public Platform getPricingCatalogDS(String strSSO, String portalId, String icaoCd, String[] custIds, String role, String opUid, String icaoCodeGTA, String icaoCodeAvialGTA) throws TechnicalException
			return platform;
		@Override
		public Map<String, PricingCatalogDates> getGEAEEffectiveDateDS(List<String> lstPlatform) throws TechnicalException
			return mapEffectiveDates;
		@Override
		public Map<String, PricingCatalogDates> getEffectiveDateDS(List<String> lstPlatform) throws TechnicalException
			return mapEffectiveDates;
		@Override
		public PricingCatalogDO getPDFExcelCatalogDS(String platform, String docType, Date effDate)throws TechnicalException
			return pricingCatalogDO;
		@Override
		public PricingCatalogDO getAllPDFExcelCatalogDS(String platform, String docType, Date effDate)throws TechnicalException
			return pricingCatalogDO;
		@Override
		public List<OrderTemplateStatusBO> addBulkPrtDtlsDS(String strSSO, String icaoCode,	String[] custIdList, String role, String operatingUnitId, List<PartsInputDO2> partsInputDOList,  
																OrderStatusBO orderStatusBO, Map<String, String> statusMsgmap, List<OrderTemplateStatusBO> orderList)
			return orderList;
			return orderTemplateStatusList;
		@Override
		public List<BulkPartDetailsBO> getBulkSearchPartDtlDS(String strSSO, String icaoCd, List<CustomerBO> custIdList, String role, String opUid, String[] partNumber)
			return bulkPartLst;
		@Override
		public GridFSFile getFile(String filename)
			return bucket.find(new Document("_id", id)).first();
		@Override
		public CustGlobEnqDetails getGlobEnqCustIdListDS(String strSSO, String opUid, String icaoCode, String role)throws TechnicalException
			return custGlobEnqDetails;
		@Override
		public GridFSFile getFaaMsDoc(String folder, String filename)
			return bucket.find(new Document("_id", id)).first();
		@Override
		/** @return map of filename and createUpdateDate*/
		public Map<Object, Object> getFileList(String portalId)
			return fileMap;
		private List<LineInfoDO> populateLineDetail(Array array)
			return lineInfoDOList;
		public String[] splitString(final String input, final String delimitter)
			return result;
		private String getStrFromDate(Date dt)
			return fmtedDt;
			return "";
		private String generateQsForIn(int numQs)
			return items;
		private Platform populatePlatformValues(String portalId, Array array, String icaoCd, String icaoCodeGTA, String icaoCodeAvialGTA)	
			return platform;
		private ArrayList<String> populatePlatformWithGTA(String portalId, ArrayList<String> lstPlatform, String icaoCd, String icaoCodeGTA, String icaoCodeAvialGTA)
			return lstPlatform;
		private List<OrderTemplateStatusBO> populateOrderStatustDetails(Array orderInfoArray, OrderStatusBO orderStatusBO, Map<String, String> statusMsgmap, 
																			List<OrderTemplateStatusBO> orderList)
			return orderList;
		private List<BulkPartDetailsBO> populateBulkPartDetails(Array itemDetailsArray)
			return bulkList;
		public byte[] getFileDataFully(ObjectId id, String bucketName)
			return rtn;
		private List<CustomerBO> populateGlobEnqCustValues(Array array)
			return list;
		
	
	

	MaterialsItemDAOImpl
	
	
		import java.util.List;
		import com.geaviation.dss.service.common.exception.TechnicalException;
		import com.geaviation.materials.entity.CustomerBO;
		import com.geaviation.materials.entity.ItemConfigHistoryBO;
		import com.geaviation.materials.entity.KitStructureBO;
		import com.geaviation.materials.entity.PartDetailsBO;
		
		//////
		
		import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.EMPTY_STRING;
		import static com.geaviation.materials.data.impl.util.MaterialsDataUtil.getAsString;
		import static com.geaviation.materials.data.impl.util.MaterialsDataUtil.isCollectionNotEmpty;
		import static com.geaviation.materials.data.impl.util.MaterialsDataUtil.isNotNullandEmpty;

		import java.sql.Array;
		import java.sql.CallableStatement;
		import java.sql.Connection;
		import java.sql.Struct;
		import java.text.ParseException;
		import java.text.SimpleDateFormat;
		import java.util.ArrayList;
		import java.util.HashMap;
		import java.util.Map;

		import javax.sql.DataSource;

		import org.apache.commons.logging.Log;
		import org.apache.commons.logging.LogFactory;
		import org.springframework.beans.factory.annotation.Autowired;
		import org.springframework.beans.factory.annotation.Qualifier;
		import org.springframework.beans.factory.annotation.Value;
		import org.springframework.stereotype.Component;

		import com.geaviation.materials.data.api.IMaterialsItemDAO;
		import com.geaviation.materials.data.impl.util.MaterialsDataConstants;
		import com.geaviation.materials.data.impl.util.MaterialsDataUtil;
		import com.geaviation.materials.data.impl.util.MaterialsQueryLoader;
		import com.geaviation.materials.entity.ApplicableCustBO;
		import com.geaviation.materials.entity.ApplicableProductLineBO;
		import com.geaviation.materials.entity.AvailabilityListBO;
		import com.geaviation.materials.entity.AvailableDiscounts;
		import com.geaviation.materials.entity.CommercialAgreementListBO;
		import com.geaviation.materials.entity.ConfigHistory;
		import com.geaviation.materials.entity.KitComponentDetailsBO;
		import com.geaviation.materials.entity.KitPricingListBO;
		import com.geaviation.materials.entity.PriceListBO;
		import com.geaviation.materials.entity.PricingListBO;
		import com.geaviation.materials.entity.QuotationBO;

		import oracle.jdbc.OracleConnection;
		import oracle.jdbc.OracleTypes;
		import oracle.sql.ARRAY;
		import oracle.sql.ArrayDescriptor;
		
		@Overide
		public PartDetailsBO getItemAvailPricDtlDS(String strSSO,String icaoCode,List<CustomerBO> custId,String role,String operatingUnitId,String invontoryItemId);
			return partDetailsBO;
		@Overide
		public PartDetailsBO getItemAvailPricPartDtlDS(String strSSO,String icaoCode,List<CustomerBO> custId,String role,String operatingUnitId,String partNumber);
			return partDetailsBO;
		@Overide
		public ItemConfigHistoryBO getItemConfigHistoryDS(String strSSO,String icaoCode,List<CustomerBO> customerBOList,String role,String operatingUnitId,String invontoryItemId,String partNumber);
			return configHistoryBO;
		@Overide
		public KitStructureBO getKitStructureDS(String sso, String icaoCode, String[] custIdList, String role, String operatingUnitId, String inventoryItemId)throws TechnicalException;
			return kitStructureBO;	
		@Overide
		public ItemConfigHistoryBO getRepUsedItemConfigHistory(String strSSO, String icaoCode, String role, String operatingUnitId, String partNumber) throws TechnicalException;
			return configHistoryBO;
		private List<ConfigHistory> populateConfigHistoryDetails(Array array)
			return lstconfigHistoryBO;
		private KitStructureBO populateKitStructureDetails(Array kitDetailsArray, Array kitComponentDtlsArray, KitStructureBO kitStructureBO)
			return kitStructureBO;
		private List<KitPricingListBO> getkitPricingListDetails(String[] pricingDtlsArray)
			return kitPricingList;
		public List<ApplicableProductLineBO> populateApplicableEngineBOValues(Array array)
			return applicableEngineBOObj;	
		PartDetailsBO populateItemDetailsValues(Array array,PartDetailsBO partDetailsBO)
			return partDetailsBO;
		List<AvailabilityListBO> populateAvlDetailsValues(Array array)
			return avlObj;	
		private Boolean getBooleanFrmString(String strFlag)
			return flag;
		List<ApplicableCustBO> populateapplicableCustDetailsValues(Array array)
			return applicableCustObj;	
		List<PricingListBO> populatePricingDetailsValues(Array array)
			return pricingObj;	
		List<QuotationBO> populateQuotationValues()
			return listQuotationBO;
		public List<AvailableDiscounts> populateDiscountDetailsValues(Array array)
			return availableDiscountsObj;	
		private String formatStrDate(String strDate)
			return toStrDate;
		List<CommercialAgreementListBO> populateCommercialAgreementValues()
			return commercialAgreementListBOs;
		
		
		
	
	MaterialsShipmentDAOImpl
	MaterialsWishListDAOImpl
	
	
	
	
	


	MaterialsLoginDaoImpl
		
		
		import com.geaviation.dss.service.common.exception.TechnicalException;
		import com.geaviation.materials.entity.MaterialsUserAccess;
		import com.geaviation.materials.entity.MaterialsUserBO;
		
		//////////
		
		import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.EMPTY_STRING;
		import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.YES;

		import java.sql.Array;
		import java.sql.CallableStatement;
		import java.sql.Connection;
		import java.sql.Struct;
		import java.util.ArrayList;
		import java.util.HashMap;
		import java.util.List;
		import java.util.Map;

		import javax.sql.DataSource;

		import org.apache.commons.logging.Log;
		import org.apache.commons.logging.LogFactory;
		import org.springframework.beans.factory.annotation.Autowired;
		import org.springframework.beans.factory.annotation.Qualifier;
		import org.springframework.beans.factory.annotation.Value;
		import org.springframework.stereotype.Component;
		import org.springframework.util.StopWatch;

		import com.geaviation.materials.data.api.IMaterialsLoginDAO;
		import com.geaviation.materials.data.impl.util.MaterialsDataConstants;
		import com.geaviation.materials.data.impl.util.MaterialsDataUtil;
		import com.geaviation.materials.data.impl.util.MaterialsQueryLoader;
		import com.geaviation.materials.entity.CustomerBO;

		import oracle.jdbc.OracleConnection;
		import oracle.jdbc.OracleTypes;
		
		
		/**Returns Operating Unit Id for the given Portal Id*/
		@Override
		public String getPortalOUDS(String portalId) throws TechnicalException;
			return portalOuIdMap.get(portalId);
		/**Returns user access details as MaterialsUserAccess object for the given user.
		 * The returned MaterialsUserAccess object will have success and message fields.*/
		@Override
		public MaterialsUserAccess isHavingAccessDS(String strSSO, String icaoCd, String opUid)throws TechnicalException;
			return userAccess;
		/** Returns login details as MaterialsUserBO object for the given user.
			* The returned MaterialsUserBO object will have user role and Customer object
			* The MaterialsUserBO contains the following fields  
			*  	role
			*  	CustomerBO
			* @return MaterialsUserBO		MaterialsUserBO object	*/
		@Override
		public MaterialsUserBO requestLoginDS(String strSSO, String icaoCd, String opUid, String impersonator) throws TechnicalException;
			return userBO;
		/** * Returns repair login details as MaterialsUserBO object for the given user.
			* The returned MaterialsUserBO object will have user role and Customer object
			* The MaterialsUserBO contains the following fields  
			*  role
			*  CustomerBO
			* @return MaterialsUserBO		MaterialsUserBO object*/
		@Override
		public MaterialsUserBO requestLoginRepairsDS(String sso, String icao,String opUid, String impersonator)throws TechnicalException;
			return userBO;
		private List<CustomerBO> populateCustValues(Array array)
			return list;
		public static boolean isMapNotEmpty
			return (map != null && !map.isEmpty());
		
		
		
		
	MaterialsOrdersDAOImpl
	
		
		import java.util.List;
		import java.util.Map;
		import com.geaviation.dss.service.common.exception.TechnicalException;
		import com.geaviation.materials.entity.DeleteOrderLineBO;
		import com.geaviation.materials.entity.InvoiceDocDO;
		import com.geaviation.materials.entity.LineDetailDO;
		import com.geaviation.materials.entity.MaterialsDocumentDetails;
		import com.geaviation.materials.entity.MaterialsOrderRequest;
		import com.geaviation.materials.entity.OrderAuditDetailsDO;
		import com.geaviation.materials.entity.OrderCFMListResponse;
		import com.geaviation.materials.entity.OrderDO;
		import com.geaviation.materials.entity.OrderHeaderDetails;
		import com.geaviation.materials.entity.OrderListResponse;
		import com.geaviation.materials.entity.OrderStatusBO;
		import com.geaviation.materials.entity.OrderTemplateStatusBO;
		import com.geaviation.materials.entity.PartsInputDO1;
		import com.geaviation.materials.entity.PriorityBO;
		import com.geaviation.materials.entity.UpdateOrderDetailsOutputDO;
		import com.geaviation.materials.entity.UpdateOrderInputDO;
		
		////////////
		
		import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.EMPTY_STRING;

		import java.sql.Array;
		import java.sql.Blob;
		import java.sql.CallableStatement;
		import java.sql.Connection;
		import java.sql.PreparedStatement;
		import java.sql.ResultSet;
		import java.sql.SQLException;
		import java.sql.Struct;
		import java.sql.Timestamp;
		import java.util.ArrayList;
		import java.util.Arrays;
		import java.util.HashMap;

		import javax.sql.DataSource;

		import org.apache.commons.logging.Log;
		import org.apache.commons.logging.LogFactory;
		import org.springframework.beans.factory.annotation.Autowired;
		import org.springframework.beans.factory.annotation.Qualifier;
		import org.springframework.beans.factory.annotation.Value;
		import org.springframework.stereotype.Component;

		import com.geaviation.materials.data.api.IMaterialsOrdersDAO;
		import com.geaviation.materials.data.impl.util.MaterialsDataConstants;
		import com.geaviation.materials.data.impl.util.MaterialsDataUtil;
		import com.geaviation.materials.data.impl.util.MaterialsQueryLoader;
		import com.geaviation.materials.entity.LineInfoDO;
		import com.geaviation.materials.entity.MaterialsOrders;
		import com.geaviation.materials.entity.MaterialsOrdersCFM;
		import com.geaviation.materials.entity.OrderAuditDO;
		import com.geaviation.materials.entity.UpdateOrderOutputDO;

		import oracle.jdbc.OracleConnection;
		import oracle.jdbc.OracleTypes;
		import oracle.sql.ARRAY;
		import oracle.sql.ArrayDescriptor;

		@Override
		public OrderHeaderDetails getHeaderDetailDS(String sso,String icaoCode,String[] custId ,String role,String operatingUnitId, String msNumber,String deliveryId, String orderHeaderId, String invoiceHeaderId)throws TechnicalException;
			return orderHeaderDetails;	
		@Override
		public MaterialsDocumentDetails getMaterialsDocumentDS(String msNumber,String docType,String shipmentDate)throws TechnicalException;
			return materialsDocURL;
		@Override
		public byte[] getInvoiceDocDS(String sso,String invoiceId)throws TechnicalException;
			return bytes;
		@Override
		public List<PriorityBO> getPriorityDS(String strSSO,String portalId)throws TechnicalException ;
			return priorityList;
		@Override
		public OrderAuditDetailsDO getOrderAuditDS(String strSSO, String icaoCode,	String[] custIdList, String role, String operatingUnitId,String headerId) throws TechnicalException;
			return orderAuditDetailsDO;
		@Override
		public UpdateOrderDetailsOutputDO updateOrderDS(String sso, String role,String icao, String[] custIdArray, String operatingUnitId, List<UpdateOrderInputDO> updateOrderInputDOList, List<Boolean> esnValidFlagList, List<String> priorityList) throws TechnicalException;
				return updateOrderDetailsOutputDO;
		@Override
		public DeleteOrderLineBO deleteOrderLineDS(String sso,String icaoCode,String[] custIdList ,String role,String operatingUnitId,String headerId,String lineId)throws TechnicalException;
		@Override
		public String getCAMEmailDS(String sso,String icao,String[] custIds, String role,String opUid);
			return result;
		@Override
		public List<OrderTemplateStatusBO> uploadOrderTemplateDS(String strSSO, String icaoCode,	String[] custIdList, String role, String operatingUnitId,
																	List<PartsInputDO1> partsInputDO1List, OrderStatusBO orderStatusBO, Map<String, String> statusMsgmap, 
																	List<OrderTemplateStatusBO> orderList, List<Boolean> esnValidFlag, List<String> priorityList);
		@Override
		public OrderCFMListResponse materialsOrderCFMListDS(MaterialsOrderRequest materialsOrderRequest,String portalId) throws TechnicalException;
			return materialsOrdersListResponse;
		@Override
		public OrderListResponse materialsOrderListDS(MaterialsOrderRequest materialsOrderRequest,String portalId) throws TechnicalException;
						InvoiceDocDO getInvoiceDocDS(String strSSO, String icaoCode, String[] custIdList, String role, String operatingUnitId, String invoiceId) throws TechnicalException;
			return materialsOrdersListResponse;
		@Override
		boolean isMSDocRequestExist(String docnumber, String docTypeCd,String emailId) throws TechnicalException;
			return results;
		@Override
		public int requestEmailMaterialsDocDS(String docType,String docnumber,String docversion,String userId,String userEmail)throws TechnicalException;
			
		@Override
		public LineDetailDO getLineDetailDS(String strSSO, String icaoCode,	String[] custIdList, String role, String operatingUnitId, String msNumber, String deliveryId, String orderHeaderId, String invoiceHeaderId);
		@Override
		public OrderDO getOrderDetailsDS(String sso,String icaoCode ,String custId,String role,String operatingUnitId ,String headerId )throws TechnicalException;
		public DeleteOrderLineBO deleteOrderLineDS(String strSSO,String icaoCode,String[] custIdList ,String role, String operatingUnitId,String headerId,String lineId)throws TechnicalException
			return deleteOrderLineBO;
		private boolean isNotNullandEmpty(final String strData)
			return isValid;
		public List<OrderTemplateStatusBO> uploadOrderTemplateDS(String strSSO, String icaoCode,	String[] custIdList, String role, String operatingUnitId,
			List<PartsInputDO1> partsInputDOList,  OrderStatusBO orderStatusBO, Map<String, String> statusMsgmap, 
			List<OrderTemplateStatusBO> orderList, List<Boolean> esnValidFlag, List<String> priorityList)
			return orderList;
			return orderTemplateStatusList;
		private List<OrderTemplateStatusBO> populateOrderStatustDetailsCFM(Array orderInfoArray, OrderStatusBO orderStatusBO, 
			Map<String, String> statusMsgmap, List<OrderTemplateStatusBO> orderList, List<Boolean> esnValidFlag,
			List<String> priorityList)
				return orderList;
		private List<OrderAuditDO> populateOrderAuditHistory(Array array)
			return orderAuditlist;
		private UpdateOrderDetailsOutputDO populateUpdateOrderDetails(Array array,
			UpdateOrderDetailsOutputDO updateOrderDetailsOutputDO, List<Boolean> esnValidFlagList,
			List<String> priorityList)
			return updateOrderDetailsOutputDO;
		private List<MaterialsOrdersCFM> populateMataerialsOrderListCFM(Array array, String portalId)
			return materialsOrdersList;
		private List<MaterialsOrders> populateMataerialsOrderList(Array array, String portalId)
			return materialsOrdersList;
		
		
		
	
		
	IMaterialsShipmentDAO
	
		import com.geaviation.dss.service.common.exception.TechnicalException;
		import com.geaviation.materials.entity.CustLoginDetails;
		import com.geaviation.materials.entity.DisputeOrderInput;
		import com.geaviation.materials.entity.DisputeOrderStatusBO;
		import com.geaviation.materials.entity.ReturnLabelDO;

		public ReturnLabelDO getReturnLabelDetailDS(String sso, String orderHeaderId, CustLoginDetails custLoginDetails) throws TechnicalException;
		public DisputeOrderStatusBO createDisputeOrderDS(DisputeOrderInput disputeOrderInput);
		
		
		
		
	IMaterialsWishListDAO
	
		import com.geaviation.dss.service.common.exception.TechnicalException;
		import com.geaviation.materials.entity.DeleteWishListBO;
		import com.geaviation.materials.entity.InsertWishListResponse;
		import com.geaviation.materials.entity.WishListDetailsBO;
	
		public InsertWishListResponse insertWishListDS(String partNumber, String strSSO, String portalId,String operatingUnitId) throws TechnicalException;
		public List<WishListDetailsBO> getWishListDetailsDS(String strSSO, String portalId,String operatingUnitId,String[] custIdArray,String role) throws TechnicalException;
		public List<DeleteWishListBO> deleteWishListDS(String strSSO, String portalId,String[] partNumberArray,String icaoCode) throws TechnicalException;
	
	
	
	
UTIL


	MaterialsDataConstants
		public static final String ESN_STATUS_MSG_UPDATE = "The user entered value for the ESN can not be validated and it was updated to null";
		public static final String EMPTY_STRING = "";
		public static final String MATERIALS_QUERY = "query";
		etc etc..............
		
		
		
	MaterialsDataUtil
	
		import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.EMPTY_STRING;

		import java.io.IOException;
		import java.io.InputStream;

		import java.sql.Array;
		import java.sql.Connection;
		import java.sql.ResultSet;
		import java.sql.SQLException;
		import java.sql.Statement;
		import java.sql.Struct;

		import java.text.DateFormat;
		import java.text.ParseException;
		import java.text.SimpleDateFormat;

		import java.util.ArrayList;
		import java.util.Arrays;
		import java.util.Collection;
		import java.util.Date;
		import java.util.HashMap;
		import java.util.List;
		import java.util.Map;
		import java.util.StringTokenizer;

		import org.apache.commons.logging.Log;
		import org.apache.commons.logging.LogFactory;
		import org.owasp.encoder.Encode;
		import org.springframework.stereotype.Component;
		import org.springframework.util.StopWatch;

		import com.geaviation.dss.service.common.exception.TechnicalException;

		import com.geaviation.materials.entity.ColumnBO;
		import com.geaviation.materials.entity.ColumnGroupBO;
		import com.geaviation.materials.entity.CommercialAgreementList;
		import com.geaviation.materials.entity.LineMapping;
		import com.geaviation.materials.entity.MYGEAGroupBO;
		import com.geaviation.materials.entity.OrderHeaderDetails;
		import com.geaviation.materials.entity.OrderHeaderInfoBO;
	
		private static final Log log = LogFactory.getLog(MaterialsDataUtil.class);
		final static String SIMPLEDATEFORMAT = "yyyy-MM-dd";

		getPortalConfigAsMap
		getPortalRequestedDaysToAdd
		convertDate
		FormatedDate
		convertDateToYYMMMDD
		isNullOrEmpty
		isNotNullandEmpty
		getAsString
		getAsInteger
		isCollectionNotEmpty
		getCartHdrDetails
		getHeaderInfo
		getColumnGroupList
		getGEAEGroupList
		getColIds
		getColList
		populateCommercialAgreementValuesForHdrDtl
		releaseResources
		encodeForJava
		getAsJavaObject
		getObjectList
		getBytesFromStream
		startLogging
		endLogging
		getFormattedDate
		splitString
		
		
		
		
	MaterialsQueryLoader
	
		import java.util.ResourceBundle;
		import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.MATERIALS_QUERY;
		private static ResourceBundle rbQueryProps = ResourceBundle.getBundle(MATERIALS_QUERY);
		
		
		
		
		
		
IMPLEMENTATION


	
			
			
			
			
	
			
			
	
	
		
		
		
	
	
	
	
	
	
	
	
	
	
	
	
