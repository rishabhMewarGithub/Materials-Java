


materials.app

API


	IMaterialsCartApp
	
		import java.util.List;
		import com.geaviation.materials.entity.CartCountBS;
		import com.geaviation.materials.entity.DeleteCartLineBO;
		import com.geaviation.materials.entity.PurchasePOBO;
		import com.geaviation.materials.entity.SaveCartRequestDetails;
		import com.geaviation.materials.entity.SaveCartResponseDetails;
		import com.geaviation.materials.entity.StatusBO;
		import com.geaviation.materials.entity.TotalPurchaseOrderBO;
		import com.geaviation.materials.exception.MaterialsException;

		public TotalPurchaseOrderBO getCartBS(String strSSO, String portalId) throws MaterialsException;
		/** * Returns Cart details as SaveCartResponse JSON object for the given SaveCartRequest JSON.
			* If strSSO or portalId input is null then it throws MaterialsException.
			* The SaveCartResponse contains the following fields  
				*  cartHeaderId				denotes the cartHeaderId that is saved.
				*  statusMessage			denotes the message from the procedure.
				*  orderLineMessageBOList	denotes list of SaveCartOrderLineMessageBO		
			* @return SaveCartResponse		SaveCartResponse object*/
		public List<SaveCartResponseDetails> saveCartBS(List<SaveCartRequestDetails> saveCartRequestList, String strSSO, String portalId) throws MaterialsException;
		public StatusBO  deleteCartBS(String strSSO, String portalId) throws MaterialsException;
		public CartCountBS getCartCountBS(String strSSO, String portalId) throws MaterialsException;
		public DeleteCartLineBO deleteCartLineBS(String strSSO, String portalId,String cartHeaderId, String cartLineId) throws MaterialsException;
		public StatusBO  addLineItemBS(String strSSO,String portalId,String inventoryItemId, String selectedCustomerId,
										String selectedSupplierCode, String quantity, String pricingListId, String quoteHeaderId) throws MaterialsException;
		public List<PurchasePOBO> purchasePOBS(String strSSO, String portalId, String cartHeaderId, String orderType) throws MaterialsException;
		public List<PurchasePOBO> purchasePassportEnginePOsInteceptor(String strSSO, String portalId, String cartHeaderId, String orderType) throws MaterialsException;
		
		
		
		
	IMaterialsApp
	
		import java.util.List;
		import javax.ws.rs.core.MultivaluedMap;
		import javax.ws.rs.core.Response;
		import com.geaviation.materials.entity.BulkAddPartBO;
		import com.geaviation.materials.entity.BulkPartDetailsBO;
		import com.geaviation.materials.entity.CustGlobEnqDetails;
		import com.geaviation.materials.entity.CustomerAdminDetailsBO;
		import com.geaviation.materials.entity.LineDetailBO;
		import com.geaviation.materials.entity.MaterialsSortField;
		import com.geaviation.materials.entity.OrderStatusBO;
		import com.geaviation.materials.entity.PricingCatalogBO;
		import com.geaviation.materials.entity.RepairCatalog;
		import com.geaviation.materials.entity.ShiptoMarkforAddress;
		import com.geaviation.materials.exception.MaterialsException;
		
		public ShiptoMarkforAddress getShiptoMarkforAddressBS(String strSSO, String portalId,String customerId)throws MaterialsException;
		public Integer fetchResultSize();
		public CustomerAdminDetailsBO getCustAdminDetailsBS(String userId, String portalId,String custId) throws MaterialsException;
		public LineDetailBO getLineDetailBS(String strSSO, String portalId,	String msNumber, String deliveryId, String orderHeaderId,
												String invoiceHeaderId, List<MaterialsSortField> sortFields,Integer start, Integer limit) throws MaterialsException;
		public String  getErrorCode(String message, String strSSO, String portalId,String partNumber) throws MaterialsException;
		public Response getPricingCatalogDocBS(String platform, String doctype,String strSSO,String portalId,String effDate) ;
		public PricingCatalogBO getPricingCatalog(MultivaluedMap<String, String> multiValmap,String strSSO,String portalId) throws MaterialsException;
		public String getDisplayMessage(String message, String strSSO,String portalId) throws MaterialsException;
		public OrderStatusBO addBulkPartDtls(String smssoid, String portalid,List<BulkAddPartBO> partsLst) throws MaterialsException;
		public List<BulkPartDetailsBO> getBulkSearchPartDtlBS(String strSSO,String portalId, String partNumbers) throws MaterialsException;
		/*** @return document file as Response*/
		public Response getRepairCatalogBS(String strSSO,String portalId,String engineModel) throws MaterialsException;
		/*** @return list of documents as Response*/
		public RepairCatalog getRepairCatalogListBS(MultivaluedMap<String, String> multiValmap,String strSSO,String portalId) throws MaterialsException;
		public CustGlobEnqDetails getGlobEnqCustIdList(String strSSO, String portalId) throws MaterialsException;
		
		
		
		
	IMaterialsItemApp
	
		import com.geaviation.materials.entity.ItemConfigHistoryBO;
		import com.geaviation.materials.entity.KitStructureBO;
		import com.geaviation.materials.entity.PartDetailsBO;
		import com.geaviation.materials.exception.MaterialsException;
		
		public KitStructureBO getKitStructureBS(String sso, String portalId, String inventoryItemId) throws MaterialsException;
		public PartDetailsBO getItemAvailPricDtlBS(String strSSO,String portalId,String invontoryItemId,String partNumber)throws MaterialsException ;
		public PartDetailsBO getItemAvailPricPartDtlBS(String strSSO,String portalId,String partNumber) throws MaterialsException ;
		public ItemConfigHistoryBO getItemConfigHistoryBS(String strSSO,String portalId,String invontoryItemId,String partNumber)throws MaterialsException ;
		public ItemConfigHistoryBO getRepUsedItemConfigHistory(String sso, String portalId, String partNumber) throws MaterialsException;
		
		
		
	
	IMaterialsLoginApp
	
		import com.geaviation.materials.entity.MaterialsLoginResponse;
		import com.geaviation.materials.exception.MaterialsException;
		
		/**
		 * Returns login details as MaterialsLoginResponse object for the given user.
		 * If userId or portalId input is null then it throws MaterialsException.
		 * The returned MaterialsLoginResponse object will have success and MaterialsUserBO object.
		 * The boolean value success denotes that the user is a valid materials user.
		 * If the user is invalid, message field is set with reason and thrown as MaterialsException.
		 * The MaterialsLoginResponse contains the following fields  
			*  success				denotes that the user is valid in AMPS.
			*  message				AMPS message for an invalid user.
			*  MaterialsUserBO
		 * @return MaterialsLoginResponse MaterialsLoginResponse objects*/
		public MaterialsLoginResponse requestMaterialsLogin(String userId, String portalId) throws MaterialsException;
		/**Returns repair materials access and role details for the given user. Used by Attivio platform.*/
		public MaterialsLoginResponse requestRepairsLoginAttivio(String userId, String portalId) throws MaterialsException;
		/**	* Returns repair materials access and role details for the given user.
			* @return MaterialsLoginResponse		*/
		public MaterialsLoginResponse requestRepairsLogin(String userId, String portalId) throws MaterialsException;
		
		
		
		
	IMaterialsOrdersApp
	
		import java.util.List;
		import org.apache.cxf.jaxrs.ext.multipart.Attachment;
		import javax.ws.rs.core.MultivaluedMap;
		import javax.ws.rs.core.Response;
		import com.geaviation.materials.entity.OrderAuditHistoryBO;
		import com.geaviation.materials.entity.OrderDetailsBO;
		import com.geaviation.materials.entity.OrderHeaderDetails;
		import com.geaviation.materials.entity.UpdateOrderRequestDetails;
		import com.geaviation.materials.entity.UpdateOrderResponseDetails;
		import com.geaviation.materials.entity.CustomerAdminDetailsBO;
		import com.geaviation.materials.entity.DeleteOrderLineBO;
		import com.geaviation.materials.entity.DisputeDocumentBO;
		import com.geaviation.materials.entity.InvoiceDocDO;
		import com.geaviation.materials.entity.LineDetailBO;
		import com.geaviation.materials.entity.MaterialsSortField;
		import com.geaviation.materials.entity.OrderStatusBO;
		import com.geaviation.materials.entity.UpdateShipmentBO;
		import com.geaviation.materials.exception.MaterialsException;

		public OrderHeaderDetails getHeaderDetailBS(String smssoid,String portalid,String msNumber,String deliveryId,String orderHeaderId,String invoiceHeaderId) throws MaterialsException;
		public OrderAuditHistoryBO getOrderAuditHistoryBS(String strSSO, String portalId,String headerId) throws MaterialsException;
		public Response getOrderTemplateBS(String strSSO, String portalId) throws MaterialsException;
		public List<UpdateOrderResponseDetails> updateOrderBS(String strSSO,String portalId,List<UpdateOrderRequestDetails> updateOrderRequestList) throws MaterialsException;
		public DeleteOrderLineBO deleteOrderLineBS(String strSSO,String portalId,String headerId,String lineId) throws MaterialsException;
		public UpdateShipmentBO updateShipmentDetailsBS(String sso, String portalId, String updateType, String existingContent, String updatedContent, String customerId) throws MaterialsException;
		public OrderStatusBO uploadOrderTemplateBS(String smssoid,String portalid,String custCode,List<Attachment> orderTemplate) throws MaterialsException;
		public Response materialOrderListCsvExportBS(String strSSO,String portalId,MultivaluedMap<String, String> multiValmap,String icaoCode,String custCodes) throws MaterialsException;
		public Response getcsvFile(String sso, String portalId, String msNumber, String deliveryId, String orderHeaderId, String invoiceHeaderId)throws MaterialsException;
		InvoiceDocDO getInvoiceDocBS(String strSSO,String portalId,String invoiceId) throws MaterialsException;
		public Response getMaterialsDocumentBS(String strSSO,String portalId,String msNumber,String docType,String deliveryId,String invoiceId,String notificationFlag) throws MaterialsException;
		public DisputeDocumentBO getPDFFile(String sso, String portalId, String orderHeaderId)throws MaterialsException;
		public OrderDetailsBO getOrderDetailsBS(String userId,String portalId,String headerId) throws MaterialsException;
		
		
		
		
	IMaterialsShipmentApp
	
		import java.util.List;
		import org.apache.cxf.jaxrs.ext.multipart.Attachment;
		import com.geaviation.materials.entity.DisputeDocumentBO;
		import com.geaviation.materials.entity.DisputeOrderInput;
		import com.geaviation.materials.entity.DisputeOrderStatusBO;
		import com.geaviation.materials.exception.MaterialsException;

		public DisputeDocumentBO downloadDisputeDocBS(String strSSO,String portalId,String orderHeaderId,String lineId,String docType) throws MaterialsException;
		/*** @return*/
		public DisputeOrderStatusBO createDisputeOrderBS(String sso, String portalId, DisputeOrderInput disputeOrderInput, List<Attachment> attachment) throws MaterialsException;
		
		
		
		
	IMaterialsWishListApp
	
		import java.util.List;
		import com.geaviation.materials.entity.BulkAddPartBO;
		import com.geaviation.materials.entity.DeleteWishListBO;
		import com.geaviation.materials.entity.InsertWishListResponse;
		import com.geaviation.materials.entity.OrderStatusBO;
		import com.geaviation.materials.entity.WishListDetailsBO;
		import com.geaviation.materials.exception.MaterialsException;
	
		public InsertWishListResponse insertWishListBS(String strSSO,String portalId,String partNumber) throws MaterialsException;
		public List<WishListDetailsBO> getWishListDetailsBS(String strSSo,String portalId) throws MaterialsException;
		public List<DeleteWishListBO> deleteWishListBS(String strSSo,String portalId,String partNumber) throws MaterialsException;
		public OrderStatusBO wishLstToSaveLstBS(String strSSO,String portalId,List<BulkAddPartBO> partnumberLst) throws MaterialsException;
	
	
	
	
UTIL

	Constants
	EngineModelAscComparator
	EngineModelDescComparator
	InMemoryOutputStream
	MaterialsAppConstants
	MaterialsAppStaticConst	
	MaterialsAppUtil	
	MaterialsDateFormatUtil	
	MaterialsDynamicComparator
	MaterialsSearchUtil
	RepairEffectiveDateDescComparator
	RepairEffectvieDateAscComparator
	RepairRevDateAscComparator
	RepairRevDateDescComparator
	
		
		
		
IMPLEMENTATION

	MaterialsAppImpl
	MaterialsCartAppImpl
	MaterialsItemAppImpl
	MaterialsLoginAppImpl
	MaterialsOrdersAppImpl
	MaterialsShipmentAppImpl
	MaterialsWishListAppImpl
	
	
	
	
	
	
	
	
	
	
	
