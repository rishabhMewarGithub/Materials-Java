




materials.app

API


	IMaterialsCartInterceptor
	
		import java.util.List;
		import javax.ws.rs.core.Response;
		import com.geaviation.materials.entity.SaveCartRequestDetails;
		import com.geaviation.materials.exception.MaterialsException;

		public Response getCartBS(String strSSO,String portalId,String cartHeaderId) throws MaterialsException;
		public Response deleteCartBS(String strSSO,String portalId,String cartHeaderId) throws MaterialsException;
		public Response getCartCountBS(String strSSO,String portalId) throws MaterialsException;
		public Response deleteCartLineBS(String strSSO,String portalId,String cartHeaderId,String cartLineId) throws MaterialsException;
		public Response saveCartBS(List<SaveCartRequestDetails> saveCartRequestList, String strSSO, String portalId) throws MaterialsException;
		public Response addLineItemBS(String strSSO, String portalId, String inventoryItemId, String selectedCustomerId, String selectedSupplierCode, String quantity, 
										String pricingListId, String commercialAgreementNumber,String quotationNumber, String quickOrder, String quoteHeaderId) throws MaterialsException;
		/**	* Returns PurchasePO Details
			* @return Response*/
		public Response purchasePOBS(String strSSO, String portalId, String cartHeaderId,String orderType) throws MaterialsException;
		
		
		
		
	IMaterialsInterceptor
	
		import javax.ws.rs.core.MultivaluedMap;
		import javax.ws.rs.core.Response;
		import com.geaviation.materials.entity.RepairCatalog;
		import com.geaviation.materials.exception.MaterialsException;

		public Response getLineDetailBS(String strSSO, String portalId, MultivaluedMap<String,String> inMap) throws MaterialsException;
		public Response getLineStatusHistoryBS(String strSSO,String portalId,MultivaluedMap<String, String> multiValmap) throws MaterialsException;
		public Response getPricingCatalog(MultivaluedMap<String, String> multiValmap,String strSSO,String portalId) throws MaterialsException;
		public Response getPricingCatalogDocBS(String platform, String doctype,String strSSO,String portalId,String effDate) throws MaterialsException;
		/**	* Returns Purchase order quotation Details
			* @return Response*/
		public Response getPoQuotations(String strSSO, String portalId, MultivaluedMap<String, String> multiValmap) throws MaterialsException;
		public Response getShiptoMarkforAddressBS(String strSSO, String portalId,String customerId,String custCode) throws MaterialsException ;
		public Response getCustAdminDetailsBS(String strSSO,String portalId,String custId) throws MaterialsException ;
		/**	* Get Commercial Agreement
			* @return Response*/
		public Response getCommercialAgreementBS(String strSSO, String portalId, MultivaluedMap<String, String> map)throws MaterialsException;
		/**	* Get Commercial Agreement Part
			* @return Response*/
		public Response getCommercialAgreementPartBS(String strSSO, String portalId, MultivaluedMap<String, String> multiValmap) throws MaterialsException;
		/**	* Get Rating PLug
			* @return Response*/
		public Response getRatingPlugBS(String strSSO, String portalId, MultivaluedMap<String, String> multiValmap)throws MaterialsException;
		/**	* Create Rating Plug Form
			* @return Response*/
		public Response createRatingPlugFormBS(String strSSO, String portalId, String ratingPlugDetails)throws MaterialsException;
		/**	* Get Rating Plug Form
			* @return Response*/
		public Response getRatingPlugFormBS(String strSSO, String portalId, MultivaluedMap<String, String> map)throws MaterialsException;
		/**	* @return document file as Response*/
		public Response getRepairCatalogBS(String strSSO,String portalId,String engineModel) throws MaterialsException;
		/**	* @return list of documents file as Response*/
		public RepairCatalog getRepairCatalogListBS(MultivaluedMap<String, String> multiValmap,String strSSO,String portalId) throws MaterialsException;
		
		
		
		
	IMaterialsItemInterceptor
	
		import javax.ws.rs.core.Response;
		import com.geaviation.materials.exception.MaterialsException;

		public Response getItemAvailPricDtlBS(String strSSO,String portalId,String invontoryItemId, String custCode, String custId,String partNumber) throws MaterialsException;
		public Response getKitStructureBS(String sso, String portalId, String inventoryItemId) throws MaterialsException;
		public Response getItemConfigHistoryBS(String strSSO, String portalId, String inventoryItemId,String partNumber) throws MaterialsException;
		public Response getRepUsedItemConfigHistory(String strSSO, String portalId, String partNumber) throws MaterialsException;
		
		
		
	
	IMaterialsLoginInterceptor
	
		import com.geaviation.materials.exception.MaterialsException;
		
		/**	* Returns materials access and role details for the given user.
			* @return Object	*/
		public Object requestMaterialsLogin(String strSSO, String portalId) throws MaterialsException;
		/**	* Used to conver role for myCFM users.
			* @return Object	*/
		public Object roleConversion(Object loginResponse, String strSSO, String portalId) throws MaterialsException;
		/**	* Returns materials access and role details for the given user. Used by Attivio platform.
			* @return Object	*/
		public Object requestMaterialsLoginAttivio(String strSSO, String portalId) throws MaterialsException;
		
		
		
		
	IMaterialsOrdersInterceptor
	
		import java.util.List;
		import javax.ws.rs.core.MultivaluedMap;
		import javax.ws.rs.core.Response;
		import org.apache.cxf.jaxrs.ext.multipart.Attachment;
		import com.geaviation.materials.entity.DisputeDocumentBO;
		import com.geaviation.materials.entity.DisputeOrderInput;
		import com.geaviation.materials.entity.DisputeOrderStatusBO;
		import com.geaviation.materials.entity.UpdateShipmentBO;
		import com.geaviation.materials.entity.UpdateOrderRequestDetails;
		import com.geaviation.materials.exception.MaterialsException;

		/**	* @return Object	*/
		public Response deleteOrderLineBS(String strSSO,String portalId,String headerId,String lineId) throws MaterialsException;
		public UpdateShipmentBO updateShipmentDetailsBS(String sso, String portalId, String updateType, String existingContent, String updatedContent, String customerId) throws MaterialsException;
		public DisputeDocumentBO downloadDisputeDocBS(String strSSO,String portalId,String orderHeaderId,String lineId,String docType) throws MaterialsException;
		public Response uploadOrderTemplateBS(String strSSO, String portalId,String custCode,List<Attachment> orderTemplate) throws MaterialsException;
		public DisputeOrderStatusBO createDisputeOrderBS(String sso, String portalId, DisputeOrderInput disputeOrderInput, List<Attachment> serialNumberPhotoAttachment) throws MaterialsException;
		public Response getOrders(String strSSO, String portalId, MultivaluedMap<String, String> multiValmap, String contentType,String icaoCode) throws MaterialsException;
		public Response getHeaderDetailBS(String smssoid, String portalid, String msNumber, String deliveryId, String orderHeaderId, String invoiceHeaderId) throws MaterialsException;
		public Response getOrderTemplateBS(String strSSO, String portalId) throws MaterialsException;
		public Response updateOrderBS(String strSSO,String portalId,List<UpdateOrderRequestDetails> updateOrderRequestList) throws MaterialsException;
		/**	* @return Object*/
		public Response getMaterialsDocumentBS(String strSSO, String portalId, String msNumber, String docType, String deliveryId,String invoiceId, 
											String proformaInvoiceId, String commercialInvoiceId,String notificationFlag) throws MaterialsException;
		
		
	
	IMaterialsRfqInterceptor
	
		import javax.ws.rs.core.MultivaluedMap;
		import javax.ws.rs.core.Response;
		import com.geaviation.materials.exception.MaterialsException;

		public Response listRFQBS(String strSSO, String portalId,MultivaluedMap<String, String> map) throws MaterialsException;	
		public Response getRFQDetailBS(String strSSO, String portalId, MultivaluedMap<String, String> multiValmap) throws MaterialsException;
		public Response getRFQBS(String strSSO, String portalId,MultivaluedMap<String, String> map) throws MaterialsException;
		public Response createRFQBS(String customerCode,String rfqClientNumber,String rfqSubmittedDate,String rfqPriorityCode,String partNumber,String orderedQuantity,String rfqConditionCode,String rfqCustomerRemarks,String strSSO, String portalId) throws MaterialsException;
		
		
		
		
	IMaterialsWishListInterceptor
	
		import java.util.List;
		import javax.ws.rs.core.Response;
		import com.geaviation.materials.entity.BulkAddPartBO;
		import com.geaviation.materials.exception.MaterialsException;
	
		public Response insertWishListBS( String strSSO, String portalId,String partNumber) throws MaterialsException;
		public Response getWishListDetailsBS(String strSSO, String portalId) throws MaterialsException;
		public Response deleteWishListBS(String strSSO,String portalId,String partNumber) throws MaterialsException;
		public Response wishLstToSaveLstBS(String strSSO,String portalId,List<BulkAddPartBO> partnumberLst) throws MaterialsException;
	
	
	
	
UTIL

	InMemoryOutputStream
	MaterialsDataTable
	MaterialsInterceptorConstants
	MaterialsInterceptorUtil
	MaterialsSortingUtil
	
		
IMPLEMENTATION

	MaterialsCartInterceptor
	MaterialsInterceptor
	MaterialsItemInterceptor
	MaterialsLoginInterceptor
	MaterialsOrdersInterceptor
	MaterialsRfqInterceptor
	MaterialsWishListInterceptor
	
	
	
	
	
	
	
	
	
	
	
