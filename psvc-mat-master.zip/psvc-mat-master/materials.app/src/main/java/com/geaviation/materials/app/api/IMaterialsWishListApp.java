package com.geaviation.materials.app.api;

import java.util.List;

import com.geaviation.materials.entity.BulkAddPartBO;
import com.geaviation.materials.entity.DeleteWishListBO;
import com.geaviation.materials.entity.InsertWishListResponse;
import com.geaviation.materials.entity.OrderStatusBO;
import com.geaviation.materials.entity.WishListDetailsBO;
import com.geaviation.materials.exception.MaterialsException;

public interface IMaterialsWishListApp {
	
	public InsertWishListResponse insertWishListBS(String strSSO,String portalId,String partNumber) throws MaterialsException;
	public List<WishListDetailsBO> getWishListDetailsBS(String strSSo,String portalId) throws MaterialsException;
	public List<DeleteWishListBO> deleteWishListBS(String strSSo,String portalId,String partNumber) throws MaterialsException;
	public OrderStatusBO wishLstToSaveLstBS(String strSSO,String portalId,List<BulkAddPartBO> partnumberLst) throws MaterialsException;

}
