/******************************************************** 
 * Project        :     Repair : CWC Services 
 * Date		      :    	Oct 13, 2015
 * Created By	  :		502335049	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     RepairSearchUtil.java
 * 
 * History        :  	Oct 13, 2015               
   Date                           
 **********************************************************/
package com.geaviation.materials.app.impl.util;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.geaviation.materials.entity.MaterialsSearchField;
import com.geaviation.materials.entity.MaterialsSortField;






public  class MaterialsSearchUtil {
	public static final String MDATA_PROP_STRING  ="mDataProp_";
	private static final Log LOG = LogFactory.getLog(MaterialsSearchUtil.class);

	private MaterialsSearchUtil(){
		
	}
	
	public static List<MaterialsSearchField> getFilterFields(MultivaluedMap<String,String> queryParams) {

		List<MaterialsSearchField> searchList = new ArrayList<MaterialsSearchField>();
		
		for (int i = 0; i < getQueryParamIntFromForm(queryParams,"iColumns",0); i++) {
		   if (queryParams.get("sSearch_" + i) != null) {
			   String searchColumn = queryParams.getFirst(MDATA_PROP_STRING+ i);
			   if (searchColumn != null) {
				   searchList.add(new MaterialsSearchField(searchColumn, queryParams.getFirst("sSearch_"+ i)));
			   }
			   
		   }
		   if (queryParams.get("sSearchEnd_" + i) != null) {
			   String searchColumnEnd = queryParams.getFirst(MDATA_PROP_STRING+ i);
			   if (searchColumnEnd != null) {
				   searchList.add(new MaterialsSearchField(searchColumnEnd+"End", queryParams.getFirst("sSearchEnd_"+ i)));
			   }
		   }
			}
		return searchList;
	}
	
	private static int getQueryParamIntFromForm(MultivaluedMap<String,String> queryParams,String param, int defaultInt) {
		try {
			defaultInt = Integer.parseInt(queryParams.getFirst(param));
		}catch (NumberFormatException e) {	
		}	
		return defaultInt;
	}

	

	public static List<MaterialsSortField> getSortFilterFields(
			MultivaluedMap<String, String> form) {


		List<MaterialsSortField> sortParamsList = new ArrayList<MaterialsSortField>();
		for (int i = 0; i < getQueryParamIntFromForm(form,"iColumns",0); i++) {
		   if (form.getFirst("iSortCol_" + i) != null) {
			   String sortColumn = form.getFirst(MDATA_PROP_STRING + form.getFirst("iSortCol_" + i));
			   if (sortColumn != null) {
				   sortParamsList.add(new MaterialsSortField(sortColumn+"Sort", ("desc".equalsIgnoreCase(form.getFirst("sSortDir" + "_" + i))?"desc":"asc")));
			   }
		   }
		}
		return sortParamsList;
	}
	}

