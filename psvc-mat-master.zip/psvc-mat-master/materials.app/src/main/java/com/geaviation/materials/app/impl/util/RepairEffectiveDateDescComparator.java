/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 12, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 * Code Review    :     Dec 11, 2015
 *                      All rights reserved 
 * Description    :     MaterialsAppImpl.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.app.impl.util;

import java.util.Comparator;

import com.geaviation.materials.entity.RepairCatalogBO;

public class RepairEffectiveDateDescComparator implements Comparator<RepairCatalogBO> {
	 public int compare(RepairCatalogBO repairCatDO1, RepairCatalogBO repairCatDO2) {
		 boolean isStrDate0Empty = (repairCatDO2.getEffectiveDate() == null || repairCatDO2.getEffectiveDate().isEmpty());
		    boolean isStrDate1Empty = (repairCatDO1.getEffectiveDate() == null || repairCatDO1.getEffectiveDate().isEmpty());

		    if (isStrDate0Empty && isStrDate1Empty)
		        return 0;
		    // at least one of them is not empty    
		    if (isStrDate0Empty)
		        return -1;
		    if (isStrDate1Empty)
		        return 1;
		    //none of them is empty
		  return repairCatDO2.getEffectiveDate().compareTo(repairCatDO1.getEffectiveDate());
	    }
}
