/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Aug 18, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     MaterialsDynamicComparator.java
 * 
 * History        :  	Aug 18, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.app.impl.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.util.Comparator;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author 720053
 *
 */
public class MaterialsDynamicComparator<T> implements Comparator<T> {
	
	private static final Log LOG = LogFactory.getLog(MaterialsDynamicComparator.class);
	
	private static final Object DATE_TIME_FORMAT = "DateTime";
	private final int sortAscending;
	private final Method method;
	private final String compareType;
	private Method formatMethod;
	
		
	public MaterialsDynamicComparator(Class<?> sortClass, String sortColumn, boolean ascending) {
		this.sortAscending = (ascending?1:-1);
		this.method = getMethod(sortClass,"get",sortColumn);
		this.compareType = (this.method==null?"":this.method.getReturnType().getName());
		if(("java.lang.Date".equals(compareType)))
		{
		this.formatMethod = getMethod(sortClass, "format", sortColumn);
		}
	}
	
	@Override
	public int compare(T o1, T o2) {
		if (this.method == null) return 0;
		int rtnCd = 0;
		
		if (o1 == null && o2 == null) {
			rtnCd = 0;
		} else if (o1 == null || o2 == null) {
			rtnCd = (o1 == null?-1:1);
		} else {
			
			try {
				if(formatMethod != null) {
					String format = ((String)formatMethod.invoke(o1, (Object[])null));
					if(format.equals(DATE_TIME_FORMAT)) {
						rtnCd = getCompareValueDateTime(o1,o2);
					}
				}
				else if ("java.lang.String".equals(compareType)) {
					rtnCd = getCompareValueString(o1,o2);
				}
				else if (("int".equals(compareType))) {
					rtnCd = ((Integer)method.invoke(o1, (Object[])null)).compareTo((Integer)method.invoke(o2, (Object[])null));
				} 
				else if("java.util.Date".equals(compareType)){
					rtnCd = getCompareValueDate(o1,o2);
				}
				else if("java.lang.Integer".equals(compareType)){
					rtnCd = getCompareValueInteger(o1,o2);
				}
				else if("java.lang.Double".equals(compareType)){
					rtnCd = getCompareValueDouble(o1,o2);
				}
				else if("java.lang.Boolean".equals(compareType)){
					rtnCd = getCompareValueBoolean(o1,o2);
				}
				else if("java.lang.Long".equals(compareType)){
					rtnCd = getCompareValueLong(o1,o2);
				}
			} catch (Exception e) {
				LOG.info(e);
				return 0;
		    }
		}
		return rtnCd * sortAscending;
	}
	
	private int getCompareValueLong(T o1, T o2) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Long l1 = ((Long)method.invoke(o1, (Object[])null));
		Long l2 = ((Long)method.invoke(o2, (Object[])null));
		
		if (l1 == null && l2 == null) {
			return 0;
		} else if (l1 == null) {
			return -1;
		} else if (l2 == null) {
			return 1;
		} else {
			return l1.compareTo(l2);
		}
	}

	private int getCompareValueBoolean(T o1, T o2) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Boolean b1 = ((Boolean)method.invoke(o1, (Object[])null));
		Boolean b2 = ((Boolean)method.invoke(o2, (Object[])null));
		
		if (b1 == null && b2 == null) {
			return 0;
		} else if (b1 == null) {
			return -1;
		} else if (b2 == null) {
			return 1;
		} else {
			return b1.compareTo(b2);
		}
	}

	private int getCompareValueDouble(T o1, T o2) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Double d1 = ((Double)method.invoke(o1, (Object[])null));
		Double d2 = ((Double)method.invoke(o2, (Object[])null));
		
		if (d1 == null && d2 == null) {
			return 0;
		} else if (d1 == null) {
			return -1;
		} else if (d2 == null) {
			return 1;
		} else {
			return d1.compareTo(d2);
		}
	}

	private int getCompareValueInteger(T o1, T o2) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Integer i1 = ((Integer)method.invoke(o1, (Object[])null));
		Integer i2 = ((Integer)method.invoke(o2, (Object[])null));
		
		if (i1 == null && i2 == null) {
			return 0;
		} else if (i1 == null) {
			return -1;
		} else if (i2 == null) {
			return 1;
		} else {
			return i1.compareTo(i2);
		}
	}

	private int getCompareValueDate(T o1, T o2) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Date d1 = ((Date)method.invoke(o1, (Object[])null));
		Date d2 = ((Date)method.invoke(o2, (Object[])null));
		
		if (d1 == null && d2 == null) {
			return 0;
		} else if (d1 == null) {
			return -1;
		} else if (d2 == null) {
			return 1;
		} else {
			return d1.compareTo(d2);
		}
	}

	private int getCompareValueString(T o1, T o2) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		String s1 = ((String)method.invoke(o1, (Object[])null));
		String s2 = ((String)method.invoke(o2, (Object[])null));
		if (s1 == null && s2 == null) {
			return 0;
		} else if (s1 == null) {
			return -1;
		} else if (s2 == null) {
			return 1;
		} else {
			return s1.compareTo(s2);
		}
	}

	private int getCompareValueDateTime(T o1, T o2) throws ParseException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		String s1 = ((String)method.invoke(o1, (Object[])null));
		String s2 = ((String)method.invoke(o2, (Object[])null));
		Date d1 = null;
		Date d2 = null;
		if(MaterialsAppUtil.isNotNullandEmpty(s1)){
			d1 = MaterialsDateFormatUtil.parseDate(s1);
		}
		if(MaterialsAppUtil.isNotNullandEmpty(s2)){
		 d2 = MaterialsDateFormatUtil.parseDate(s2);
		}
		if (d1 == null && d2 == null) {
			return 0;
		} else if (d1 == null) {
			return -1;
		} else if (d2 == null) {
			return 1;
		} else {
			return d1.compareTo(d2);
		}
	}

	private Method getMethod(Class<?> clazz, String prefix, String fieldName) {
		String methodName = prefix + fieldName.substring(0,1).toUpperCase() + fieldName.substring(1);
		try {
			return clazz.getMethod(methodName, (Class[])null);
		}
		catch (Exception e) {
			LOG.info(e);
		}
		return null;
	}

}
