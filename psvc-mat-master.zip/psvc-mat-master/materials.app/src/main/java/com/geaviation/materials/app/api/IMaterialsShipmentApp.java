/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Oct 21, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     IMaterialsShipmentApp.java
 * 
 * History        :  	Oct 21, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.app.api;

import java.util.List;

import org.apache.cxf.jaxrs.ext.multipart.Attachment;

import com.geaviation.materials.entity.DisputeDocumentBO;
import com.geaviation.materials.entity.DisputeOrderInput;
import com.geaviation.materials.entity.DisputeOrderStatusBO;
import com.geaviation.materials.exception.MaterialsException;


public interface IMaterialsShipmentApp {
	
	
	public DisputeDocumentBO downloadDisputeDocBS(String strSSO,String portalId,String orderHeaderId,String lineId,String docType) throws MaterialsException;
	
	/**
	 * @param sm_ssoid
	 * @param portal_id
	 * @param jpgFile
	 * @param disputeOrderInputBO
	 * @return
	 */
	
	public DisputeOrderStatusBO createDisputeOrderBS(String sso, String portalId, DisputeOrderInput disputeOrderInput, List<Attachment> attachment) throws MaterialsException;

	}
