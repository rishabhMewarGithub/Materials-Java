/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Aug 18, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     MaterialsDateFormatUtil.java
 * 
 * History        :  	Aug 18, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.app.impl.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * @author 720053
 *
 */
public class MaterialsDateFormatUtil {
	private MaterialsDateFormatUtil() {
		
	}
	public static final String DATE_TIME_FORMAT_STRING = "DateTime";
	private static final DateFormat DATE_TIME_FORMAT = new SimpleDateFormat("dd MMM yyyy HH:mm:ss '(GMT)'");
	private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
	
	public static String formatDateTime(Date date) {
		return DATE_TIME_FORMAT.format(date);
	}
	public static Date parseDateTime(String date) throws ParseException {
		return DATE_TIME_FORMAT.parse(date);
	}
	public static Date parseDate(String date) throws ParseException {
		return DATE_FORMAT.parse(date);
	}
	public static String formatDateFromSQLDate(java.sql.Timestamp dateTime ) {
		java.util.Date date = null;
		String dateString = null;
		if(null != dateTime){
			date = toDate(dateTime);
			dateString = DATE_FORMAT.format(date);
		}
		return dateString;
	}
	public static java.util.Date toDate(java.sql.Timestamp timestamp) {
	    long milliseconds = timestamp.getTime() + (timestamp.getNanos() / 1000000);
	    return new java.util.Date(milliseconds);
	}

}
