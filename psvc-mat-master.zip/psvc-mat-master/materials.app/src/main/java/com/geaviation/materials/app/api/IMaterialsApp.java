/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 12, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     IMaterialsApp.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.app.api;

import java.util.List;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import com.geaviation.materials.entity.BulkAddPartBO;
import com.geaviation.materials.entity.BulkPartDetailsBO;
import com.geaviation.materials.entity.CustGlobEnqDetails;
import com.geaviation.materials.entity.CustomerAdminDetailsBO;
import com.geaviation.materials.entity.LineDetailBO;
import com.geaviation.materials.entity.MaterialsSortField;
import com.geaviation.materials.entity.OrderStatusBO;
import com.geaviation.materials.entity.PricingCatalogBO;
import com.geaviation.materials.entity.RepairCatalog;
import com.geaviation.materials.entity.ShiptoMarkforAddress;
import com.geaviation.materials.exception.MaterialsException;

public interface IMaterialsApp {

	public ShiptoMarkforAddress getShiptoMarkforAddressBS(String strSSO, String portalId,String customerId)throws MaterialsException;
	public Integer fetchResultSize();
	public CustomerAdminDetailsBO getCustAdminDetailsBS(String userId, String portalId,String custId) throws MaterialsException;
	public LineDetailBO getLineDetailBS(String strSSO, String portalId,	String msNumber, String deliveryId, String orderHeaderId,
			String invoiceHeaderId, List<MaterialsSortField> sortFields,Integer start, Integer limit) throws MaterialsException;
	public String  getErrorCode(String message, String strSSO, String portalId,String partNumber) throws MaterialsException;
	public Response getPricingCatalogDocBS(String platform, String doctype,String strSSO,String portalId,String effDate) ;
	public PricingCatalogBO getPricingCatalog(MultivaluedMap<String, String> multiValmap,String strSSO,String portalId) throws MaterialsException;
	public String getDisplayMessage(String message, String strSSO,String portalId) throws MaterialsException;
	public OrderStatusBO addBulkPartDtls(String smssoid, String portalid,List<BulkAddPartBO> partsLst) throws MaterialsException;
	public List<BulkPartDetailsBO> getBulkSearchPartDtlBS(String strSSO,String portalId, String partNumbers) throws MaterialsException;
    /**
    * @param strSSO
    * @param portalId
    * @param engineModel
    * @return document file as Response
    * @throws MaterialsException
    */
    public Response getRepairCatalogBS(String strSSO,String portalId,String engineModel) throws MaterialsException;
    
    /**
    * @param multiValmap
    * @param strSSO
    * @param portalId
    * @return list of documents as Response
    * @throws MaterialsException
    */
    public RepairCatalog getRepairCatalogListBS(MultivaluedMap<String, String> multiValmap,String strSSO,String portalId) throws MaterialsException;
    public CustGlobEnqDetails getGlobEnqCustIdList(String strSSO, String portalId) throws MaterialsException;
}
