/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 12, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     IMaterialsApp.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.app.api;

import com.geaviation.materials.entity.MaterialsLoginResponse;
import com.geaviation.materials.exception.MaterialsException;

public interface IMaterialsLoginApp {
	
	/**
	 * Returns login details as MaterialsLoginResponse object for the given user.
	 * If userId or portalId input is null then it throws MaterialsException.
	 * The returned MaterialsLoginResponse object will have success and MaterialsUserBO object.
	 * The boolean value success denotes that the user is a valid materials user.
	 * If the user is invalid, message field is set with reason and thrown as MaterialsException.
	 * The MaterialsLoginResponse contains the following fields  
	*  success				denotes that the user is valid in AMPS.
	*  message				AMPS message for an invalid user.
	*  MaterialsUserBO
	*  
	*  
	 * @param userId   				valid user SSO. can not be NULL.
	 * @param portalId				valid portal id. can not be NULL. 
	 * @return MaterialsLoginResponse MaterialsLoginResponse objects
	 * @throws MaterialsException	
	 */
	public MaterialsLoginResponse requestMaterialsLogin(String userId, String portalId) throws MaterialsException;
	/**
	* Returns repair materials access and role details for the given user. Used by Attivio platform.
	* @param sm_ssoid   			valid user SSO. can not be NULL.
	* @param portal_id				valid portal_id. can not be NULL.
    * @throws MaterialsException	
	*/
	public MaterialsLoginResponse requestRepairsLoginAttivio(String userId, String portalId) throws MaterialsException;
	/**
	* Returns repair materials access and role details for the given user.
	* @param sm_ssoid   			valid user SSO. can not be NULL.
	* @param portal_id				valid portal_id. can not be NULL.
	* @return MaterialsLoginResponse		
    * @throws MaterialsException	
	*/
	public MaterialsLoginResponse requestRepairsLogin(String userId, String portalId) throws MaterialsException;
	
}
