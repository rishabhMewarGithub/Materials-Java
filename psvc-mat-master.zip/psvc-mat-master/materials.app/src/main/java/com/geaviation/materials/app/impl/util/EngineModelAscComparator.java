package com.geaviation.materials.app.impl.util;

import java.util.Comparator;

import com.geaviation.materials.entity.RepairCatalogBO;

public class EngineModelAscComparator implements Comparator<RepairCatalogBO> {
	 public int compare(RepairCatalogBO orderLineDO1, RepairCatalogBO orderLineDO2) {
		 boolean isPartDesc0Empty = (orderLineDO1.getEngineModel() == null || orderLineDO1.getEngineModel().isEmpty());
		   boolean isPartDesc1Empty = (orderLineDO2.getEngineModel() == null || orderLineDO2.getEngineModel().isEmpty());

		   if (isPartDesc0Empty && isPartDesc1Empty)
		       return 0;
		   // at least one of them is not empty    
		   if (isPartDesc0Empty)
		       return -1;
		   if (isPartDesc1Empty)
		       return 1;
		   //none of them is empty
		  return orderLineDO1.getEngineModel().compareTo(orderLineDO2.getEngineModel());
	    }

}
