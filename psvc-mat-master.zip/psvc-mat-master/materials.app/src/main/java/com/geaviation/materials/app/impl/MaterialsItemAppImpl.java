package com.geaviation.materials.app.impl;

import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.AERODP;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EMPTY_STRING;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_INVITMID_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_INVITMID_PARTNUMBER_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_PARTNUM_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.HYPHEN;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.MSG_CRITCL_CE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.MSG_CRITCL_GE_BUYER;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ROLE_BUYER;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ROLE_CE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ROLE_GE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.Y;
import static com.geaviation.materials.app.impl.util.MaterialsAppUtil.isNotNullandEmpty;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.app.api.IMaterialsApp;
import com.geaviation.materials.app.api.IMaterialsItemApp;
import com.geaviation.materials.app.api.IMaterialsLoginApp;
import com.geaviation.materials.app.impl.util.MaterialsAppConstants;
import com.geaviation.materials.app.impl.util.MaterialsAppUtil;
import com.geaviation.materials.data.api.IMaterialsItemDAO;
import com.geaviation.materials.entity.ConfigHistory;
import com.geaviation.materials.entity.CustLoginDetails;
import com.geaviation.materials.entity.CustomerBO;
import com.geaviation.materials.entity.ItemConfigHistoryBO;
import com.geaviation.materials.entity.KitStructureBO;
import com.geaviation.materials.entity.MaterialsConstants;
import com.geaviation.materials.entity.MaterialsLoginResponse;
import com.geaviation.materials.entity.MaterialsUserBO;
import com.geaviation.materials.entity.PartDetailsBO;
import com.geaviation.materials.exception.MaterialsErrorCodes;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;

@Component
public class MaterialsItemAppImpl implements IMaterialsItemApp {

	@Autowired
	private MaterialsExceptionUtil materialsExceptionUtil;
	@Autowired
	private MaterialsAppUtil materialsAppUtil;
	@Autowired
	private IMaterialsLoginApp materialsLoginApp;
	@Autowired
	private IMaterialsApp materialsApp;
	@Autowired
	private IMaterialsItemDAO materialsItemDAO;

	@Value("${MATERIALSSBLINKURL}")
	private String MATERIALSSBLINKURL;
	@Value("${MATERIALSSBLINKURL2}")
	private String MATERIALSSBLINKURL2;

	private static final Log log = LogFactory.getLog(MaterialsItemAppImpl.class);

	@Override
	public KitStructureBO getKitStructureBS(String sso, String portalId, String inventoryItemId) throws MaterialsException{
		CustLoginDetails custLoginDetails = null;
		KitStructureBO kitStructureBO = null;
		if (!isNotNullandEmpty(inventoryItemId)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8318,
					materialsExceptionUtil.getErrorMessage(
							MaterialsErrorCodes.ERROR_8318),
							ERR_INVITMID_NOT_FOUND);
		}
		custLoginDetails = materialsAppUtil.getCustLoginDetails(sso, portalId);
		kitStructureBO = materialsItemDAO.getKitStructureDS(sso,
				custLoginDetails.getIcaoCode(),
				custLoginDetails.getCustIdList(),
				custLoginDetails.getRole(),
				custLoginDetails.getOperatingUnitId(), inventoryItemId);
		
			if((kitStructureBO != null) && (isNotNullandEmpty(kitStructureBO.getP_msg()))){
				materialsAppUtil.throwERPMessage(kitStructureBO.getP_msg());
			}
		
		return kitStructureBO;
	}

	@Override
	public PartDetailsBO getItemAvailPricDtlBS(String strSSO, String portalId, String invontoryItemId,
			String partNumber) throws MaterialsException {
		log.info("Entered into getItemAvailPricDtlBS() method");
		if (!isNotNullandEmpty(invontoryItemId)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8318,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8318), ERR_INVITMID_NOT_FOUND);
		}
		String role = EMPTY_STRING;
		String icaoCode = EMPTY_STRING;
		String operatingUnitId = EMPTY_STRING;
		String displayMsg = EMPTY_STRING;
		PartDetailsBO partDetailsBO = null;
		MaterialsLoginResponse materialsLoginDetail = null;
		MaterialsUserBO materialsUserBO = null;
		List<CustomerBO> customerBOList = null;
		materialsLoginDetail = materialsLoginApp.requestMaterialsLogin(strSSO, portalId);
		if (materialsLoginDetail.getMaterialsUserBO() != null) {
			materialsUserBO = materialsLoginDetail.getMaterialsUserBO();
		}
		if (isNotNullandEmpty(materialsUserBO.getIcaoCode())) {
			icaoCode = materialsUserBO.getIcaoCode();
		}
		if (isNotNullandEmpty(materialsUserBO.getRole())) {
			role = materialsUserBO.getRole();
		}
		if (materialsUserBO.getCustomerBOList() != null && !materialsUserBO.getCustomerBOList().isEmpty()) {
			customerBOList = materialsUserBO.getCustomerBOList();
		}
		if (isNotNullandEmpty(materialsUserBO.getOperatingUnitId())) {
			operatingUnitId = materialsUserBO.getOperatingUnitId();
		}
		try {
			partDetailsBO = materialsItemDAO.getItemAvailPricDtlDS(strSSO, icaoCode, customerBOList, role, operatingUnitId,
					invontoryItemId);
		} catch (TechnicalException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}
		if (MaterialsAppUtil.isNotNullandEmpty(partDetailsBO.getPartPricMsg())) {
			String pricingMessage = materialsApp.getDisplayMessage(partDetailsBO.getPartPricMsg(), strSSO, portalId);
			partDetailsBO.setPartPricMsg(pricingMessage);
		}
		if (MaterialsAppUtil.isNotNullandEmpty(partDetailsBO.getPartAvailMsg())) {
			String availMessage = materialsApp.getDisplayMessage(partDetailsBO.getPartAvailMsg(), strSSO, portalId);
			partDetailsBO.setPartAvailMsg(availMessage);
		}

		if (MaterialsAppUtil.isNotNullandEmpty(partDetailsBO.getMessage())) {
			displayMsg = materialsApp.getErrorCode(partDetailsBO.getMessage(), strSSO, portalId, partNumber);
			partDetailsBO.setDisplayMessage(displayMsg);
		}
		if (MaterialsAppUtil.isNotNullandEmpty(partDetailsBO.getCriticalPartMessage())
				&& partDetailsBO.getCriticalPartMessage().equals(Y)) {
			if (role.equals(ROLE_GE)) {
				partDetailsBO.setCriticalPartMessage(MSG_CRITCL_GE_BUYER);
			} else if (role.equals(ROLE_BUYER)) {
				partDetailsBO.setCriticalPartMessage(MSG_CRITCL_GE_BUYER);
			} else if (role.equals(ROLE_CE)) {
				partDetailsBO.setCriticalPartMessage(MSG_CRITCL_CE);
			} else {
				partDetailsBO.setCriticalPartMessage(EMPTY_STRING);
			}
		}
		if (MaterialsAppUtil.isNotNullandEmpty(partDetailsBO.getDiscountMessage())) {
			String discountMsg = materialsApp.getErrorCode(partDetailsBO.getDiscountMessage(), strSSO, portalId,
					partNumber);
			partDetailsBO.setDiscountMessage(discountMsg);
		} else {
			partDetailsBO.setDiscountMessage(EMPTY_STRING);
		}
		log.info("Entered into getItemAvailPricDtlBS() method");
		return partDetailsBO;
	}

	@Override
	public PartDetailsBO getItemAvailPricPartDtlBS(String strSSO, String portalId, String partNumber)
			throws MaterialsException {
		log.info("Entered into getItemAvailPricPartDtlBS() method");
		if (!isNotNullandEmpty(partNumber)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8318,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8318), ERR_PARTNUM_NOT_FOUND);
		}
		String role = EMPTY_STRING;
		String icaoCode = EMPTY_STRING;
		String operatingUnitId = EMPTY_STRING;
		String displayMsg = EMPTY_STRING;
		PartDetailsBO partDetailsBO = null;
		MaterialsLoginResponse materialsLoginDetail = null;
		MaterialsUserBO materialsUserBO = null;
		List<CustomerBO> customerBOList = null;
		materialsLoginDetail = materialsLoginApp.requestMaterialsLogin(strSSO, portalId);
		if (materialsLoginDetail.getMaterialsUserBO() != null) {
			materialsUserBO = materialsLoginDetail.getMaterialsUserBO();
		}
		if (isNotNullandEmpty(materialsUserBO.getIcaoCode())) {
			icaoCode = materialsUserBO.getIcaoCode();
		}
		if (isNotNullandEmpty(materialsUserBO.getRole())) {
			role = materialsUserBO.getRole();
		}
		if (materialsUserBO.getCustomerBOList() != null && !materialsUserBO.getCustomerBOList().isEmpty()) {
			customerBOList = materialsUserBO.getCustomerBOList();
		}
		if (isNotNullandEmpty(materialsUserBO.getOperatingUnitId())) {
			operatingUnitId = materialsUserBO.getOperatingUnitId();
		}
		try {
			partDetailsBO = materialsItemDAO.getItemAvailPricPartDtlDS(strSSO, icaoCode, customerBOList, role,
					operatingUnitId, partNumber);
		} catch (TechnicalException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}
		if (MaterialsAppUtil.isNotNullandEmpty(partDetailsBO.getPartPricMsg())) {
			String pricingMessage = materialsApp.getDisplayMessage(partDetailsBO.getPartPricMsg(), strSSO, portalId);
			partDetailsBO.setPartPricMsg(pricingMessage);
		}
		if (MaterialsAppUtil.isNotNullandEmpty(partDetailsBO.getPartAvailMsg())) {
			String availMessage = materialsApp.getDisplayMessage(partDetailsBO.getPartAvailMsg(), strSSO, portalId);
			partDetailsBO.setPartAvailMsg(availMessage);
		}

		if (MaterialsAppUtil.isNotNullandEmpty(partDetailsBO.getMessage())) {
			log.info("partDetailsBO.getMessage()" + partDetailsBO.getMessage());
			displayMsg = materialsApp.getErrorCode(partDetailsBO.getMessage(), strSSO, portalId, partNumber);
			log.info("displayMsg" + displayMsg);
			partDetailsBO.setDisplayMessage(displayMsg);
		}
		if (MaterialsAppUtil.isNotNullandEmpty(partDetailsBO.getCriticalPartMessage())
				&& partDetailsBO.getCriticalPartMessage().equals(Y)) {
			if (role.equals(ROLE_GE)) {
				partDetailsBO.setCriticalPartMessage(MSG_CRITCL_GE_BUYER);
			} else if (role.equals(ROLE_BUYER)) {
				partDetailsBO.setCriticalPartMessage(MSG_CRITCL_GE_BUYER);
			} else if (role.equals(ROLE_CE)) {
				partDetailsBO.setCriticalPartMessage(MSG_CRITCL_CE);
			} else {
				partDetailsBO.setCriticalPartMessage(EMPTY_STRING);
			}
		}
		if (MaterialsAppUtil.isNotNullandEmpty(partDetailsBO.getDiscountMessage())) {
			String discountMsg = materialsApp.getErrorCode(partDetailsBO.getDiscountMessage(), strSSO, portalId,
					partNumber);
			partDetailsBO.setDiscountMessage(discountMsg);
		} else {
			partDetailsBO.setDiscountMessage(EMPTY_STRING);
		}
		log.info("End getItemAvailPricDtlBS() method");
		return partDetailsBO;
	}

	@Override
	public ItemConfigHistoryBO getItemConfigHistoryBS(String strSSO, String portalId, String invontoryItemId,
			String partNumber) throws MaterialsException {
		log.info("Entered into getItemConfigHistoryBS() method");
		MaterialsLoginResponse materialsLoginDetail = null;
		MaterialsUserBO materialsUserBO = null;
		List<CustomerBO> customerBOList = null;
		ItemConfigHistoryBO itemConfigHistoryBO = null;
		List<ConfigHistory> configHistoryListFrom = null;
		List<ConfigHistory> configHistoryList = new ArrayList<ConfigHistory>();
		String role = MaterialsAppConstants.EMPTY_STRING;
		String icaoCode = MaterialsAppConstants.EMPTY_STRING;
		String operatingUnitId = MaterialsAppConstants.EMPTY_STRING;
		String task = EMPTY_STRING;
		String displayMsg = EMPTY_STRING;
		if (!(isNotNullandEmpty(invontoryItemId)) && !(isNotNullandEmpty(partNumber))) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8316,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8318),
					ERR_INVITMID_PARTNUMBER_NOT_FOUND);
		}
		StopWatch watch = new StopWatch();
		task = "requestMaterialsLogin";
		materialsAppUtil.startLogging(task, watch);
		materialsLoginDetail = materialsLoginApp.requestMaterialsLogin(strSSO, portalId);
		materialsAppUtil.endLogging(task, watch);
		if (materialsLoginDetail.getMaterialsUserBO() != null) {
			materialsUserBO = materialsLoginDetail.getMaterialsUserBO();
		}
		if (isNotNullandEmpty(materialsUserBO.getIcaoCode())) {
			icaoCode = materialsUserBO.getIcaoCode();
		}
		if (isNotNullandEmpty(materialsUserBO.getRole())) {
			role = materialsUserBO.getRole();
		}
		if (materialsUserBO.getCustomerBOList() != null && !materialsUserBO.getCustomerBOList().isEmpty()) {
			customerBOList = materialsUserBO.getCustomerBOList();
		}
		if (isNotNullandEmpty(materialsUserBO.getOperatingUnitId()))
			operatingUnitId = materialsUserBO.getOperatingUnitId();
		try {
			task = "getItemConfigHistoryDS";
			materialsAppUtil.startLogging(task, watch);
			itemConfigHistoryBO = materialsItemDAO.getItemConfigHistoryDS(strSSO, icaoCode, customerBOList, role,
					operatingUnitId, invontoryItemId, partNumber);
			materialsAppUtil.endLogging(task, watch);
		} catch (TechnicalException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}
		if (isNotNullandEmpty(itemConfigHistoryBO.getMessage())) {

			displayMsg = materialsApp.getErrorCode(itemConfigHistoryBO.getMessage(), null, null, null);
		}
		itemConfigHistoryBO.setDisplayMessage(displayMsg);
		configHistoryListFrom = itemConfigHistoryBO.getConfigHistoryList();
		if (!configHistoryListFrom.isEmpty()) {
			for (ConfigHistory configHistory : configHistoryListFrom) {
				String serviceBulletinUpdted = EMPTY_STRING;
				ConfigHistory configHistoryNew = new ConfigHistory();
				BeanUtils.copyProperties(configHistory, configHistoryNew);
				String serviceBulletin = configHistory.getServiceBulletin();
				// Aero dp requested to put service bulletin as empty. In future
				// enhancement this has to be updated
				if (portalId.equalsIgnoreCase(AERODP)) {
					serviceBulletin = EMPTY_STRING;
				}
				if (isNotNullandEmpty(serviceBulletin)) {
					serviceBulletinUpdted = HYPHEN + "sb" + HYPHEN + getSubStringFromString(serviceBulletin);
				}
				if (MaterialsConstants.MYCFM.equalsIgnoreCase(portalId)) {
					configHistoryNew.setMaterialsSbLink(EMPTY_STRING);
				} else {
					configHistoryNew
							.setMaterialsSbLink(MATERIALSSBLINKURL + configHistory.getGekNumber() + MATERIALSSBLINKURL2
									+ configHistory.getTechPubPlatform().toLowerCase() + serviceBulletinUpdted);
				}
				configHistoryList.add(configHistoryNew);
			}
		}
		itemConfigHistoryBO.setConfigHistoryList(configHistoryList);
		log.info("MATL-PERF : <materialsApp.getItemConfigHistoryBS method> END - Tasks " + watch.getTaskCount() + " in "
				+ watch.getTotalTimeMillis() + " msec");
		return itemConfigHistoryBO;
	}

	@Override
	public ItemConfigHistoryBO getRepUsedItemConfigHistory(String strSSO, String portalId, String partNumber)
			throws MaterialsException {
		log.info("Entered into getRepUsedItemConfigHistory() method");
		MaterialsLoginResponse materialsLoginDetail = null;
		MaterialsUserBO materialsUserBO = null;
		ItemConfigHistoryBO itemConfigHistoryBO = null;
		List<ConfigHistory> configHistoryListFrom = null;
		List<ConfigHistory> configHistoryList = new ArrayList<ConfigHistory>();
		String role = MaterialsAppConstants.EMPTY_STRING;
		String icaoCode = MaterialsAppConstants.EMPTY_STRING;
		String operatingUnitId = MaterialsAppConstants.EMPTY_STRING;
		String task = EMPTY_STRING;
		String displayMsg = EMPTY_STRING;
		StopWatch watch = new StopWatch();
		task = "requestMaterialsLogin";
		materialsAppUtil.startLogging(task, watch);
		materialsLoginDetail = materialsLoginApp.requestMaterialsLogin(strSSO, portalId);
		materialsAppUtil.endLogging(task, watch);
		if (materialsLoginDetail.getMaterialsUserBO() != null) {
			materialsUserBO = materialsLoginDetail.getMaterialsUserBO();
		}
		if (isNotNullandEmpty(materialsUserBO.getIcaoCode())) {
			icaoCode = materialsUserBO.getIcaoCode();
		}
		if (isNotNullandEmpty(materialsUserBO.getRole())) {
			role = materialsUserBO.getRole();
		}
		if (isNotNullandEmpty(materialsUserBO.getOperatingUnitId()))
			operatingUnitId = materialsUserBO.getOperatingUnitId();
		try {
			task = "getRepUsedItemConfigHistory";
			materialsAppUtil.startLogging(task, watch);
			itemConfigHistoryBO = materialsItemDAO.getRepUsedItemConfigHistory(strSSO, icaoCode, role, operatingUnitId,
					partNumber);
			materialsAppUtil.endLogging(task, watch);
		} catch (TechnicalException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}
		if (isNotNullandEmpty(itemConfigHistoryBO.getMessage())) {

			displayMsg = materialsApp.getErrorCode(itemConfigHistoryBO.getMessage(), null, null, null);
		}
		itemConfigHistoryBO.setDisplayMessage(displayMsg);
		configHistoryListFrom = itemConfigHistoryBO.getConfigHistoryList();
		if (!configHistoryListFrom.isEmpty()) {
			for (ConfigHistory configHistory : configHistoryListFrom) {
				String serviceBulletinUpdted = EMPTY_STRING;
				ConfigHistory configHistoryNew = new ConfigHistory();
				BeanUtils.copyProperties(configHistory, configHistoryNew);
				String serviceBulletin = configHistory.getServiceBulletin();

				if (isNotNullandEmpty(serviceBulletin)) {
					serviceBulletinUpdted = HYPHEN + "sb" + HYPHEN + getSubStringFromString(serviceBulletin);
				}
				configHistoryNew
						.setMaterialsSbLink(MATERIALSSBLINKURL + configHistory.getGekNumber() + MATERIALSSBLINKURL2
								+ configHistory.getTechPubPlatform().toLowerCase() + serviceBulletinUpdted);

				configHistoryList.add(configHistoryNew);
			}
		}
		itemConfigHistoryBO.setConfigHistoryList(configHistoryList);
		log.info("MATL-PERF : <materialsApp.getRepUsedItemConfigHistory method> END - Tasks " + watch.getTaskCount()
				+ " in " + watch.getTotalTimeMillis() + " msec");
		return itemConfigHistoryBO;
	}
	private String getSubStringFromString(String str1) {
		String completeString = null;
		String firstString = str1.split("\\s")[0];
		String secondString = firstString.split("-")[0];
		String toBeappended = firstString.split("-")[1];
		String zeroPaddedString = appendZero(toBeappended);
		completeString = secondString + HYPHEN + zeroPaddedString;
		return completeString;
	}

	private String appendZero(String string1) {
		int number = Integer.parseInt(string1);
		return String.format("%04d", number);
	}
}
