package com.geaviation.materials.app.api;

import com.geaviation.materials.entity.ItemConfigHistoryBO;
import com.geaviation.materials.entity.KitStructureBO;
import com.geaviation.materials.entity.PartDetailsBO;
import com.geaviation.materials.exception.MaterialsException;

public interface IMaterialsItemApp {
	
	public KitStructureBO getKitStructureBS(String sso, String portalId, String inventoryItemId) throws MaterialsException;
	public PartDetailsBO getItemAvailPricDtlBS(String strSSO,String portalId,String invontoryItemId,String partNumber)throws MaterialsException ;
	//Added new interface for JIRA fix 5059
	public PartDetailsBO getItemAvailPricPartDtlBS(String strSSO,String portalId,String partNumber) throws MaterialsException ;
	public ItemConfigHistoryBO getItemConfigHistoryBS(String strSSO,String portalId,String invontoryItemId,String partNumber)throws MaterialsException ;
	public ItemConfigHistoryBO getRepUsedItemConfigHistory(String sso, String portalId, String partNumber) throws MaterialsException;
}
