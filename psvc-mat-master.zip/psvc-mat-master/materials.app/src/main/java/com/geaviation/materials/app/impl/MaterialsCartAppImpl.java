/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	May 19, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     MaterialsCartAppImpl.java
 * 
 * History        :  	May 19, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.app.impl;
import static com.geaviation.materials.app.impl.util.Constants.HTML_BREAK;
import static com.geaviation.materials.app.impl.util.Constants.HTML_COLUMN;
import static com.geaviation.materials.app.impl.util.Constants.HTML_ROW;
import static com.geaviation.materials.app.impl.util.Constants.HTML_STYLE;
import static com.geaviation.materials.app.impl.util.Constants.HTML_STYLE1;
import static com.geaviation.materials.app.impl.util.Constants.HTML_STYLE2;
import static com.geaviation.materials.app.impl.util.Constants.HTML_STYLE3;
import static com.geaviation.materials.app.impl.util.Constants.HTML_SUP;
import static com.geaviation.materials.app.impl.util.Constants.SUP_STYLE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.COLON;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.COMMA;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.CONST_UPDATE_ORDER;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EMPTY_STRING;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EQUALS_STRING;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_CART_HEADER_ID_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_CART_LINE_ID_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_CART_INVALID_ESN;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_CODE_8020;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_CODE_8156;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_CODE_8167;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_INVITMID_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_PORTAL_ID_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_PRIORITY;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_PRIORITY_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_QUANTITY_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_SELECTEDCUSTID_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_SLCTD_SUPPLIERCD_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_SSO_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.FALSE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.MAIL_EXCHANGE_SERVER;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.PIPE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.PRIORITY_WORKSTOP;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.PRIORITY_WORK_STOP;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.PRIORITY_NORMAL;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.SPACE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.TRUE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.WORK_STOP_DATE_AND_QTY_INVALID;
import static com.geaviation.materials.app.impl.util.MaterialsAppUtil.isCollectionNotEmpty;
import static com.geaviation.materials.app.impl.util.MaterialsAppUtil.isNotNullandEmpty;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.app.api.IMaterialsApp;
import com.geaviation.materials.app.api.IMaterialsCartApp;
import com.geaviation.materials.app.api.IMaterialsLoginApp;
import com.geaviation.materials.app.api.IMaterialsOrdersApp;
import com.geaviation.materials.app.impl.util.MaterialsAppConstants;
import com.geaviation.materials.app.impl.util.MaterialsAppUtil;
import com.geaviation.materials.data.api.IMaterialsCartDAO;
import com.geaviation.materials.entity.CartBO;
import com.geaviation.materials.entity.CartCountBS;
import com.geaviation.materials.entity.CartDO;
import com.geaviation.materials.entity.CartHDRInfoDO;
import com.geaviation.materials.entity.CartMessageDO;
import com.geaviation.materials.entity.CartOrderLineBO;
import com.geaviation.materials.entity.CustAdmin;
import com.geaviation.materials.entity.CustLoginDetails;
import com.geaviation.materials.entity.CustomerAdminDetailsBO;
import com.geaviation.materials.entity.CustomerBO;
import com.geaviation.materials.entity.DeleteCartLineBO;
import com.geaviation.materials.entity.EmailContentInputBO;
import com.geaviation.materials.entity.ItemDetailHeaderInputDO;
import com.geaviation.materials.entity.ItemDtlHeaderBO;
import com.geaviation.materials.entity.LineDetailBO;
import com.geaviation.materials.entity.LineInfoBO;
import com.geaviation.materials.entity.LineMessageDO;
import com.geaviation.materials.entity.MaterialsConstants;
import com.geaviation.materials.entity.MaterialsLoginResponse;
import com.geaviation.materials.entity.MaterialsSortField;
import com.geaviation.materials.entity.MaterialsUserBO;
import com.geaviation.materials.entity.OrderHeaderDetails;
import com.geaviation.materials.entity.OrderLineMessageBO;
import com.geaviation.materials.entity.PartDO;
import com.geaviation.materials.entity.PriorityBO;
import com.geaviation.materials.entity.Property;
import com.geaviation.materials.entity.PurchaseOrderEmailBodyBO;
import com.geaviation.materials.entity.PurchasePOBO;
import com.geaviation.materials.entity.PurchasePODO;
import com.geaviation.materials.entity.SaveCartDetailsOutputDO;
import com.geaviation.materials.entity.SaveCartInputDO;
import com.geaviation.materials.entity.SaveCartLineMessageOutputDO;
import com.geaviation.materials.entity.SaveCartMessageOutputDO;
import com.geaviation.materials.entity.SaveCartOrderLineBO;
import com.geaviation.materials.entity.SaveCartOrderLineInputDO;
import com.geaviation.materials.entity.SaveCartOrderLineMessageBO;
import com.geaviation.materials.entity.SaveCartRequestDetails;
import com.geaviation.materials.entity.SaveCartResponseDetails;
import com.geaviation.materials.entity.ShiptoMarkforAddress;
import com.geaviation.materials.entity.StatusBO;
import com.geaviation.materials.entity.TotalPurchaseOrderBO;
import com.geaviation.materials.entity.User;
import com.geaviation.materials.exception.MaterialsErrorCodes;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;

/**
 * @author 212589907
 *
 */
@Component
@Configuration
public class MaterialsCartAppImpl implements IMaterialsCartApp{

	private static final Log log = LogFactory.getLog(MaterialsCartAppImpl.class);
	MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
	@Autowired
	private IMaterialsCartDAO materialsCartDAO;
	@Autowired
	private MaterialsAppUtil materialsAppUtil;
	@Autowired
	private IMaterialsLoginApp materialsLoginApp;
	
	@Autowired
	private IMaterialsApp materialsApp;
	
	@Autowired
    private IMaterialsOrdersApp materialsOrdersApp;
	
	@Value("${NOTIFICATION_SERVICE_URL}")
    private String notificationServiceUrl;

	
	private final String STYLE_BORDER = " border: 1px solid #555555; ";
    private final String STYLE_BORDER_TOP = " border-top:1px solid #555555; ";
    private final String STYLE_BORDER_RIGHT_TOP = " border-right:1px solid #555555;border-top:1px solid #555555; ";
    private final String STYLE_BORDER_RIGHT = " border-right:1px solid #555555; ";
    private final String STYLE_BORDER_NONE = " border: none; ";
    private final String STYLE_NORMAL_FONT = " font-weight:normal; ";
    private final String STYLE_ITALIC_FONT = " font-style:italic; ";
    private final String STYLE_BOLD_FONT = " font-weight:bold; ";
    private final String STYLE_FONT_FAMILY = " font-family:Arial; ";
    private final String STYLE_TABLE_DATA_FONT_SIZE = " color: #252525; font-family: arial; font-size: 11px; font-weight: normal; ";
    private final String STYLE_BODY_FONT_SIZE_12 = " color: #252525; font-family: arial; font-size: 12px; font-weight: normal; ";
    private final String STYLE_NOTE = " color:#555555; font-size:10px; font-style:italic; line-height: 5px;";
    private final String STYLE_DISCLAIMER_FONT_COLOR = " font-size: 15pt; font-weight: normal; color:#ff0000; ";
    private final String STYLE_FONT_COLOR_BLUE = " color:#0000ff; ";
    private final String STYLE_ALIGN_LEFT = " text-align:left; ";
    private final String STYLE_ALIGN_CENTER = " text-align:center; ";
    private final String STYLE_ALIGN_RIGHT = " text-align:right; ";
    private final String STYLE_NO_WRAP = " white-space: nowrap; ";
   



	@Override
	public TotalPurchaseOrderBO getCartBS(String strSSO, String portalId) throws MaterialsException {
		log.info("getCartBS - START");
		String role = MaterialsAppConstants.EMPTY_STRING;
		String icaoCode = MaterialsAppConstants.EMPTY_STRING;
		String operatingUnitId = MaterialsAppConstants.EMPTY_STRING;
		String custId = "";
		TotalPurchaseOrderBO purchaseOrderBO = null;
		CartBO cartBO = null;
		CartOrderLineBO cartOrderLineBO = null;
		CartDO cartDO= null;
		MaterialsLoginResponse materialsLoginDetail = null;
		MaterialsUserBO materialsUserBO = null;
		List<CartBO> lstcartBO= null;
		List<PartDO> lstPartDO = null;
		List<CartOrderLineBO> lstCartOrderLineBO = null;
		List<CustomerBO> customerBOList = null;
		List<PriorityBO> priorityBO = null;
		List<CartHDRInfoDO> lstcartHDRInfoDO = null;
		ShiptoMarkforAddress  shiptoMarkforAddress = null;
		try {
			materialsLoginDetail = materialsLoginApp.requestMaterialsLogin(strSSO, portalId);
		} catch (TechnicalException e) {
			log.error(e.getMessage());
			materialsAppUtil.throwAsBusinessException(e);
		}
		try {
			purchaseOrderBO = new TotalPurchaseOrderBO();
			lstcartHDRInfoDO = new ArrayList<CartHDRInfoDO>();
			lstcartBO= new ArrayList<CartBO>();
			lstPartDO = new ArrayList<PartDO>();
			materialsUserBO = materialsLoginDetail.getMaterialsUserBO();
			if (isNotNullandEmpty(materialsUserBO.getIcaoCode()))
				icaoCode = materialsUserBO.getIcaoCode();
			if (isNotNullandEmpty(materialsUserBO.getRole()))
				role = materialsUserBO.getRole();
			if (materialsUserBO.getCustomerBOList() != null
					&& !materialsUserBO.getCustomerBOList().isEmpty()) {
				customerBOList = materialsUserBO.getCustomerBOList();
			}
			if (isNotNullandEmpty(materialsUserBO.getOperatingUnitId())){
				operatingUnitId = materialsUserBO.getOperatingUnitId();
			}
			if(null != customerBOList){
				for(CustomerBO customerId : customerBOList){
					custId += PIPE+customerId.getCustId();
				}
			}
			if(!MaterialsAppConstants.EMPTY_STRING.equals(custId))
			{
				custId = custId.substring(1);
			}
			else
			{
				custId = null;
			}
			try{
				cartDO = materialsCartDAO.getCartDS(strSSO, icaoCode, customerBOList,role, operatingUnitId, portalId);
			} catch (TechnicalException e) {
				log.error(e.getMessage());
				materialsAppUtil.throwAsBusinessException(e);
			}
			if(cartDO != null)
			{
				priorityBO = materialsAppUtil.getPriority(strSSO,portalId);

				if(priorityBO != null && !priorityBO.isEmpty())
				{
					purchaseOrderBO.setPriorityBO(priorityBO);	
				}
				else
				{
					throw new MaterialsException(MaterialsErrorCodes.ERROR_8307, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8307), ERR_PRIORITY_NOT_FOUND);
				}
				if(isNotNullandEmpty(cartDO.getP_msg())){
					String[] parts = cartDO.getP_msg().split(COLON,2);
					if(parts[0].equals(ERR_CODE_8020))
					{
						purchaseOrderBO.setTotalPurchaseOrderValue(MaterialsAppConstants.EMPTY_STRING);
						purchaseOrderBO.setCartBO(lstcartBO);
						return purchaseOrderBO;
					}
					else
					{
						materialsAppUtil.throwERPMessage(cartDO.getP_msg());
					}
				}
				else{
					purchaseOrderBO.setTotalPurchaseOrderValue(cartDO.getPo_total());
					lstcartHDRInfoDO = cartDO.getCartDO();
					for(CartHDRInfoDO cartHDRInfo : lstcartHDRInfoDO){
						cartBO = new CartBO();
						cartBO.setCartHeaderId(cartHDRInfo.getCartHeaderId());
						cartBO.setPurchaseOrderNumber(cartHDRInfo.getPurchaseOrderNumber());
						cartBO.setRequestedDaysToAdd(cartHDRInfo.getRequestedDaysToAdd());
						cartBO.setCustomerId(cartHDRInfo.getCustomerId());
						cartBO.setCustomerCode(cartHDRInfo.getCustomerCode());
						cartBO.setSupplierDescription(cartHDRInfo.getSupplierDescription());
						cartBO.setSupplierCode(cartHDRInfo.getSupplierCode());
						cartBO.setPurchaseOrderValue(cartHDRInfo.getPurchaseOrderValue());
						cartBO.setOrderHeaderDate(cartHDRInfo.getOrderHeaderDate());
						cartBO.setOrderPriority(materialsAppUtil.getPortalDisplayPriority(portalId,cartHDRInfo.getOrderPriority()));
						lstPartDO = cartDO.getPartDO();
						lstCartOrderLineBO = new ArrayList<CartOrderLineBO>();
						addCartOrderLine(lstPartDO, cartOrderLineBO, lstCartOrderLineBO, cartHDRInfo, portalId);
						cartBO.setOrderLineBO(lstCartOrderLineBO);
						/*calling  getShiptoMarkforAddressBS service for mapping Address*/
						shiptoMarkforAddress = materialsApp.getShiptoMarkforAddressBS(strSSO, portalId,cartHDRInfo.getCustomerId());
						cartBO.setLstShppingAddressBO(shiptoMarkforAddress.getLstShppingAddressBO());
						lstcartBO.add(cartBO);
					}
				}
			}
			purchaseOrderBO.setCartBO(lstcartBO);
		}
		catch (TechnicalException e) {
			log.error(e.getMessage());
			materialsAppUtil.throwAsBusinessException(e);
		}
		log.info("getCartBS - END");
		return purchaseOrderBO;
	}
	
	private void addCartOrderLine(List<PartDO> lstPartDO, CartOrderLineBO cartOrderLineBO,
			List<CartOrderLineBO> lstCartOrderLineBO, CartHDRInfoDO cartHDRInfo, String portalId) {

		for (PartDO part : lstPartDO) {
			if (cartHDRInfo.getCartHeaderId().equals(part.getCartHeaderId())) {
				cartOrderLineBO = new CartOrderLineBO();
				cartOrderLineBO.setCartLineId(part.getCartLineId());
				cartOrderLineBO.setPartNumber(part.getPartNumber());
				cartOrderLineBO.setQuantity(part.getQuantity());
				cartOrderLineBO.setUpq(part.getUpq());
				cartOrderLineBO.setLeadTime(part.getLeadTime());
				cartOrderLineBO.setPartDescription(part.getPartDescription());
				cartOrderLineBO.setUnitPrice(part.getUnitPrice());
				cartOrderLineBO.setExtendedPrice(part.getExtendedPrice());
				cartOrderLineBO.setInventoryItemId(part.getInventoryItemId());
				cartOrderLineBO.setCustomerPurchaseOrderLineNumber(part.getCustomerPurchaseOrderLineNumber());
				cartOrderLineBO.setOrderLinePriority(
						materialsAppUtil.getPortalDisplayPriority(portalId, part.getOrderLinePriority()));
				cartOrderLineBO.setOrderLineRequestedDate(part.getOrderLineRequestedDate());
				cartOrderLineBO.setDiscountPrice(part.getDiscountPrice());
				cartOrderLineBO.setNetPrice(part.getNetPrice());
				cartOrderLineBO.setKitIndicator(part.getKitIndicator());
				cartOrderLineBO.setOrderLineESN(part.getOrderLineESN());
				
				cartOrderLineBO.setOrderLineWorkStopDate(part.getOrderLineWorkStopDate());
				cartOrderLineBO.setOrderLineWorkStopQuantity(part.getOrderLineWorkStopQuantity());

				lstCartOrderLineBO.add(cartOrderLineBO);
			}
		}

	}

	@Override
	public StatusBO deleteCartBS(String strSSO,String portalId) throws MaterialsException{

		if(!isNotNullandEmpty(strSSO)){
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8301, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND);
		}
		if(!isNotNullandEmpty(portalId)){
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8302, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8302),ERR_PORTAL_ID_NOT_FOUND);
		}

		String message="true";
		CustLoginDetails custLoginDetails = null;
		StatusBO status=null;
		custLoginDetails =  materialsAppUtil.getCustLoginDetails(strSSO,portalId);
		try {
			message = materialsCartDAO.deleteCartDS(strSSO,
					custLoginDetails.getIcaoCode(),
					custLoginDetails.getCustIdList(),
					custLoginDetails.getRole(),
					custLoginDetails.getOperatingUnitId());
		} catch (TechnicalException e) {
			materialsAppUtil.throwAsBusinessException(e);
		}
		if (isNotNullandEmpty(message)) {
			materialsAppUtil.throwERPMessage(message);
		}
		else
		{
			message="true";
		}
		status=new StatusBO();
		status.setSuccess(message);
		return status;
		
	}

	@Override
	public CartCountBS getCartCountBS(String strSSO,String portalId) throws MaterialsException {

		if(!isNotNullandEmpty(strSSO)){
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8301, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND);
		}
		if(!isNotNullandEmpty(portalId)){
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8302, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8302),ERR_PORTAL_ID_NOT_FOUND);
		}
		String[] countValues=null;
		CartCountBS cartCountBS = new CartCountBS();
		try {
			CustLoginDetails custLoginDetails = null;
			custLoginDetails =  materialsAppUtil.getCustLoginDetails(strSSO,portalId);
			countValues = materialsCartDAO.getCartCountDS(strSSO,
					custLoginDetails.getIcaoCode(),
					custLoginDetails.getCustIdList(),
					custLoginDetails.getRole(),
					custLoginDetails.getOperatingUnitId());
		} catch (TechnicalException e) {
			materialsAppUtil.throwAsBusinessException(e);
		}
		if (isNotNullandEmpty(countValues[0])) {
			materialsAppUtil.throwERPMessage(countValues[0]);
		} 
		cartCountBS.setItemCount(countValues[1]);
		return cartCountBS;
	}

	@Override
	public DeleteCartLineBO deleteCartLineBS(String strSSO, String portalId,
			String cartHeaderId, String cartLineId) throws MaterialsException {
		if (!isNotNullandEmpty(cartHeaderId)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8320,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8320),
					ERR_CART_HEADER_ID_NOT_FOUND);
		}
		if (!isNotNullandEmpty(cartLineId)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8321,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8321),
					ERR_CART_LINE_ID_NOT_FOUND);
		}
		DeleteCartLineBO deleteCartLineBO = null;
		CustLoginDetails custLoginDetails = null;
		custLoginDetails = materialsAppUtil.getCustLoginDetails(strSSO, portalId);
		try {
			deleteCartLineBO = materialsCartDAO.deleteCartLineDS(strSSO,
					custLoginDetails.getIcaoCode(),
					custLoginDetails.getCustIdList(),
					custLoginDetails.getRole(),
					custLoginDetails.getOperatingUnitId(), cartHeaderId,
					cartLineId);
		} catch (TechnicalException e) {
			log.error(e.getMessage());
			materialsAppUtil.throwAsBusinessException(e);
		}
		if (isNotNullandEmpty(deleteCartLineBO.getP_msg())) {
			materialsAppUtil.throwERPMessage(deleteCartLineBO.getP_msg());
		}
		return deleteCartLineBO;
	}	
	

	
	@Override
	public List<SaveCartResponseDetails> saveCartBS(List<SaveCartRequestDetails> saveCartRequestList,
			String strSSO, String portalId) throws MaterialsException {
		log.info("Entered into saveCartBS() method");
		if (!isNotNullandEmpty(strSSO)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8301,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND);
		}
		if (!isNotNullandEmpty(portalId)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8302,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8302), ERR_PORTAL_ID_NOT_FOUND);
		}
		String TASK = EMPTY_STRING;
		StopWatch watch = new StopWatch();
		List<SaveCartResponseDetails> saveCartResponseDetailsList = null;
		SaveCartDetailsOutputDO saveCartDetailsOutputDO = null;
		List<SaveCartInputDO> saveCartInputDOList = null;
		List<SaveCartOrderLineInputDO> saveCartOrderLineInputDOList = null;
		List<SaveCartMessageOutputDO> saveCartMessageOutputDOList = null;
		List<SaveCartLineMessageOutputDO> saveCartLineMessageOutputDOList = null;
		List<SaveCartOrderLineMessageBO> saveCartOrderLineMessageBOList = null;
		SaveCartInputDO saveCartInputDO = null;
		SaveCartOrderLineInputDO saveCartOrderLineInputDO = null;
		SaveCartResponseDetails saveCartResponseDetails = null;
		CustLoginDetails custLoginDetails = null;
		String deliverId = null;
		String orderLineESN = EMPTY_STRING;
		saveCartInputDOList = new ArrayList<SaveCartInputDO>();
		saveCartOrderLineInputDOList = new ArrayList<SaveCartOrderLineInputDO>();
		boolean esnValid = true;
		List<Boolean> esnValidFlagList = new ArrayList<>();
		List<String> priorityList = new ArrayList<>();

		for (SaveCartRequestDetails saveCartRequestDetails : saveCartRequestList) {
			if (isNotNullandEmpty(saveCartRequestDetails.getCartHeaderId())) {
				deliverId = saveCartRequestDetails.getDeliverAddressId();
				// Jira#3173
				if (deliverId != null && deliverId.isEmpty()) {
					deliverId = null;
				}

				// normal prioritycode for aerodp newly added
				String constHeaderPriority = materialsAppUtil.getPriorityCode(portalId,
						saveCartRequestDetails.getOrderHeaderPriority());
				if (!isNotNullandEmpty(constHeaderPriority) && ("AERODP".equalsIgnoreCase(portalId))) {
					throw new MaterialsException(MaterialsErrorCodes.ERROR_8401,
							materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8401), ERR_PRIORITY);
				}
				saveCartInputDO = new SaveCartInputDO(Integer.parseInt(saveCartRequestDetails.getCartHeaderId()),
						saveCartRequestDetails.getPurchaseOrderNumber(), saveCartRequestDetails.getShipAddressId(),
						deliverId, materialsAppUtil.getSQLDate(saveCartRequestDetails.getOrderHeaderRequestedDate()),
						constHeaderPriority);

				for (SaveCartOrderLineBO saveCartOrderLineBO : saveCartRequestDetails.getOrderLineBO()) {
					if (isNotNullandEmpty(saveCartOrderLineBO.getCartLineId())) {
						// normal prioritycode for aerodp newly added
						String constLinePriority = materialsAppUtil.getPriorityCode(portalId,
								saveCartOrderLineBO.getOrderLinePriority());
						if (!isNotNullandEmpty(constLinePriority) && ("AERODP".equalsIgnoreCase(portalId))) {
							throw new MaterialsException(MaterialsErrorCodes.ERROR_8401,
									materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8401),
									ERR_PRIORITY);
						}
						orderLineESN = saveCartOrderLineBO.getOrderLineESN();
						priorityList.add(saveCartOrderLineBO.getOrderLinePriority());
						// To validate ESN

						if ((isNotNullandEmpty(orderLineESN)))
							esnValid = Boolean.parseBoolean(materialsAppUtil.validateEsn(orderLineESN));
						else
							esnValid = false;

						if (saveCartOrderLineBO.getOrderLinePriority().equalsIgnoreCase(PRIORITY_NORMAL) && !(esnValid)
								&& (isNotNullandEmpty(orderLineESN))) {
							esnValidFlagList.add(false);
						} else if (saveCartOrderLineBO.getOrderLinePriority().equalsIgnoreCase(PRIORITY_WORKSTOP)
								&& !(esnValid)) {
							esnValidFlagList.add(false);
						} else {
							esnValidFlagList.add(true);
						}

						// Validate work stop quantity and workstop date - Start

						java.sql.Date workStopDate = null;
						int workStopQty = 0;

						if (MaterialsAppUtil.isNotNullandEmpty(saveCartOrderLineBO.getOrderLineWorkStopDate())) {
							workStopDate = materialsAppUtil.getSQLDate(saveCartOrderLineBO.getOrderLineWorkStopDate());
						}
						if (MaterialsAppUtil.isNotNullandEmpty(saveCartOrderLineBO.getOrderLineWorkStopQuantity())) {
							workStopQty = Integer.parseInt(saveCartOrderLineBO.getOrderLineWorkStopQuantity());
						}
						// Validate work stop quantity and workstop date - END

						saveCartOrderLineInputDO = new SaveCartOrderLineInputDO(
								Integer.parseInt(saveCartRequestDetails.getCartHeaderId()),
								Integer.parseInt(saveCartOrderLineBO.getCartLineId()),
								saveCartOrderLineBO.getCustomerPurchaseOrderLineNumber(),
								materialsAppUtil.getValidQuantity(saveCartOrderLineBO.getQuantity()), constLinePriority,
								materialsAppUtil.getSQLDate(saveCartOrderLineBO.getOrderLineRequestedDate()),
								orderLineESN, workStopDate, workStopQty);
						saveCartOrderLineInputDOList.add(saveCartOrderLineInputDO);
					} else {
						throw new MaterialsException(MaterialsErrorCodes.ERROR_8321,
								materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8321),
								ERR_CART_LINE_ID_NOT_FOUND);
					}
				}
				saveCartInputDOList.add(saveCartInputDO);
			} else {
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8320,
						materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8320),
						ERR_CART_HEADER_ID_NOT_FOUND);
			}
		}
		TASK = "getCustLoginDetails";
		materialsAppUtil.startLogging(TASK, watch);
		custLoginDetails = materialsAppUtil.getCustLoginDetails(strSSO, portalId);
		materialsAppUtil.endLogging(TASK, watch);
		try {
			TASK = "materialsCartDAO.saveCartDS";
			materialsAppUtil.startLogging(TASK, watch);
			saveCartDetailsOutputDO = materialsCartDAO.saveCartDS(strSSO, custLoginDetails.getRole(),
					custLoginDetails.getIcaoCode(), custLoginDetails.getCustIdList(),
					custLoginDetails.getOperatingUnitId(), saveCartInputDOList, saveCartOrderLineInputDOList,
					esnValidFlagList, priorityList);
			materialsAppUtil.endLogging(TASK, watch);

		} catch (TechnicalException e) {
			materialsAppUtil.throwAsBusinessException(e);
		}
		if (null != saveCartDetailsOutputDO) {
			String pMessage = saveCartDetailsOutputDO.getProcMessage();
			if (isNotNullandEmpty(pMessage)) {
				materialsAppUtil.throwERPMessage(pMessage);
			} else {
				saveCartResponseDetailsList = new ArrayList<SaveCartResponseDetails>();

				saveCartMessageOutputDOList = saveCartDetailsOutputDO.getSaveCartDOList();
				saveCartLineMessageOutputDOList = saveCartDetailsOutputDO.getSaveCartOrderLineDOList();
				for (SaveCartMessageOutputDO cartMessageDO : saveCartMessageOutputDOList) {
					saveCartResponseDetails = new SaveCartResponseDetails();
					saveCartOrderLineMessageBOList = new ArrayList<SaveCartOrderLineMessageBO>();
					saveCartResponseDetails.setCartHeaderId(cartMessageDO.getCartHeaderId());
					saveCartResponseDetails
							.setStatusMessage(materialsAppUtil.getStatusMessage(cartMessageDO.getStatusMessage()));
					SaveCartResponseDetails saveCartResponse = getSaveCartResponse(saveCartLineMessageOutputDOList,
							saveCartOrderLineMessageBOList, cartMessageDO, saveCartResponseDetails);
					saveCartResponseDetailsList.add(saveCartResponse);
				}
			}
		}
		log.info("MATL-PERF : <materialsApp.saveCartBS() method> END - Tasks " + watch.getTaskCount() + " in "
				+ watch.getTotalTimeMillis() + " msec(s)");
		return saveCartResponseDetailsList;
	}

	private SaveCartResponseDetails getSaveCartResponse(
			List<SaveCartLineMessageOutputDO> saveCartLineMessageOutputDOList,
			List<SaveCartOrderLineMessageBO> saveCartOrderLineMessageBOList, SaveCartMessageOutputDO cartMessageDO,SaveCartResponseDetails saveCartResponseDetails) throws MaterialsException {
		SaveCartOrderLineMessageBO saveCartOrderLineMessageBO = null;
		for (SaveCartLineMessageOutputDO lineMessageDO : saveCartLineMessageOutputDOList) {
			if(cartMessageDO.getCartHeaderId().equals(lineMessageDO.getCartHeaderId()))
			{
				saveCartOrderLineMessageBO = new SaveCartOrderLineMessageBO();
				saveCartOrderLineMessageBO.setCartLineId(lineMessageDO.getCartLineId());
				saveCartOrderLineMessageBO.setStatusMessage(materialsAppUtil.getStatusMessage(lineMessageDO.getStatusMessage()));
				saveCartOrderLineMessageBO.setEsnValidFlag(lineMessageDO.getEsnValidFlag());
				saveCartOrderLineMessageBO.setEsnStatusMsg(lineMessageDO.getEsnStatusMsg());
				if(isNotNullandEmpty(lineMessageDO.getStatusMessage()))
				{
					saveCartOrderLineMessageBO.setSuccess(false);
				}
				else
				{
					saveCartOrderLineMessageBO.setSuccess(true);
				}
				saveCartOrderLineMessageBOList.add(saveCartOrderLineMessageBO);
			}
			saveCartResponseDetails.setOrderLineMessageBOList(saveCartOrderLineMessageBOList);
		}
		return saveCartResponseDetails;
	}



	@Override
    public StatusBO addLineItemBS(String strSSO,String portalId,String inventoryItemId,String selectedCustomerId,
                  String selectedSupplierCode,String quantity,String pricingListId, String quoteHeaderId) throws MaterialsException {
           
           if(!isNotNullandEmpty(strSSO)){
                  throw new MaterialsException(MaterialsErrorCodes.ERROR_8301, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND);
           }
           if(!isNotNullandEmpty(portalId)){
                  throw new MaterialsException(MaterialsErrorCodes.ERROR_8302, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8302),ERR_PORTAL_ID_NOT_FOUND);
           }
           if(!isNotNullandEmpty(inventoryItemId)){
                  throw new MaterialsException(MaterialsErrorCodes.ERROR_8318, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8318),ERR_INVITMID_NOT_FOUND);
           }
           if(!isNotNullandEmpty(selectedCustomerId)){
                  throw new MaterialsException(MaterialsErrorCodes.ERROR_8326, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8326),ERR_SELECTEDCUSTID_NOT_FOUND);
           }
           if(!materialsAppUtil.isNumbersOnly(quantity)){
                  throw new MaterialsException(MaterialsErrorCodes.ERROR_8322, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8322),ERR_QUANTITY_NOT_FOUND);
           }
           if(!isNotNullandEmpty(selectedSupplierCode)){
                  throw new MaterialsException(MaterialsErrorCodes.ERROR_8323, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8323),ERR_SLCTD_SUPPLIERCD_NOT_FOUND);
           }
           
           String message = TRUE.toLowerCase();
           CustLoginDetails custLoginDetails = null;
           StatusBO status=null;
           custLoginDetails =  materialsAppUtil.getCustLoginDetails(strSSO,portalId);
           try {
                  message = materialsCartDAO.addLineItemDS(strSSO,
                               custLoginDetails.getIcaoCode(),
                               custLoginDetails.getCustIdList(),
                               custLoginDetails.getRole(),
                               custLoginDetails.getOperatingUnitId(), inventoryItemId,
                               selectedCustomerId, selectedSupplierCode, quantity,
                               pricingListId, quoteHeaderId);
           } catch (TechnicalException e) {
                  materialsAppUtil.throwAsBusinessException(e);
           }
           if (isNotNullandEmpty(message)) {
                  materialsAppUtil.throwERPMessage(message);
           }
           else
           {
                  message = TRUE.toLowerCase();
           }

           status=new StatusBO();
           status.setSuccess(message);
           return status;
    }

	void lineListDetails(List<LineInfoBO> lineInfoBOListForPurchaseNew, List<LineInfoBO> lineInfoBOListForPurchase) {
		int count = 0;
		// Forming a list of line details as to match the size
		// of the purchase list (at the line level)
		if (isCollectionNotEmpty(lineInfoBOListForPurchaseNew)) {
			for (LineInfoBO lineInfoObject : lineInfoBOListForPurchaseNew) {
				String itemTypeCodeForKit = lineInfoBOListForPurchaseNew.get(count).getItemTypeCode();
				if (("STANDARD").equalsIgnoreCase(itemTypeCodeForKit)
						|| "MODEL".equalsIgnoreCase(itemTypeCodeForKit)
						|| "OPTION".equalsIgnoreCase(itemTypeCodeForKit)
						|| "CLASS".equalsIgnoreCase(itemTypeCodeForKit)) {
					LineInfoBO lineInfoBONew = new LineInfoBO();
					BeanUtils.copyProperties(lineInfoObject, lineInfoBONew);
					lineInfoBOListForPurchase.add(lineInfoObject);
				}
				count++;
			}
		}
	}
	
	private void orderLineMessageUpdate(List<LineMessageDO> lstOrderLineMessageDO, OrderLineMessageBO orderLineMessageBO,
			CartMessageDO cartMessageDO, List<LineInfoBO> lineInfoBOListForPurchase, boolean isOrderCreated,
			LinkedHashSet<OrderLineMessageBO> lstOrderLineMessageBO, String isPartPriced) throws MaterialsException {

		int index = 0;
		String unitListPrice = EMPTY_STRING;
		String unitSellPrice = EMPTY_STRING;
		for (LineMessageDO lineMessageDO : lstOrderLineMessageDO) {
			if (cartMessageDO.getCartHeaderId().equals(lineMessageDO.getCartHeaderId())) {
				orderLineMessageBO = new OrderLineMessageBO();
				orderLineMessageBO.setCartLineId(lineMessageDO.getCartLineId());
				log.info("Cart HeaderId :: " + cartMessageDO.getCartHeaderId() + " Cart Line Id  :: "
						+ lineMessageDO.getCartLineId() + " Cart Line  Status Message :: "
						+ lineMessageDO.getStatusMessage());
				orderLineMessageBO
						.setStatusMessage(materialsAppUtil.getStatusMessage(lineMessageDO.getStatusMessage()));
				if (isOrderCreated) {
					String itemTypeCodeForKit = lineInfoBOListForPurchase.get(index).getItemTypeCode();
					if ("STANDARD".equalsIgnoreCase(itemTypeCodeForKit)
							|| "MODEL".equalsIgnoreCase(itemTypeCodeForKit)) {
						// if(orderLineId.equals(lineMessageDO.getOrderLineId())){
						orderLineMessageBO.setLineNumber(lineInfoBOListForPurchase.get(index).getCustomerLineNumber());
						orderLineMessageBO.setPartNumber(lineInfoBOListForPurchase.get(index).getOrderedItem());
						orderLineMessageBO.setKeyword(lineInfoBOListForPurchase.get(index).getKeyword());
						orderLineMessageBO
								.setOrderedQuantity(lineInfoBOListForPurchase.get(index).getOrderedQuantity());
						orderLineMessageBO.setRequestDate(lineInfoBOListForPurchase.get(index).getRequestDate());
						unitListPrice = lineInfoBOListForPurchase.get(index).getUnitListPrice();
						unitSellPrice = lineInfoBOListForPurchase.get(index).getUnitSellingPrice();
						orderLineMessageBO.setUnitListPrice(unitListPrice);
						orderLineMessageBO.setUnitSellingPrice(unitSellPrice);
						if (MaterialsAppUtil.isNullOrEmpty(unitListPrice)
								|| MaterialsAppUtil.isNullOrEmpty(unitSellPrice)) {
							isPartPriced = FALSE;
						}
						orderLineMessageBO
								.setDiscountPercent(lineInfoBOListForPurchase.get(index).getDiscountPercent());
						lineInfoBOListForPurchase.get(index).getCriticalPartFlag();
						orderLineMessageBO
								.setCriticalPartFlag(lineInfoBOListForPurchase.get(index).getCriticalPartFlag());

						orderLineMessageBO.setExternalPrice(lineInfoBOListForPurchase.get(index).getExternalPrice());
						// }
					}
				}
				lstOrderLineMessageBO.add(orderLineMessageBO);
				index++;
			}
		}
	}
	
	void setCartHeaderId(ArrayList<String> cartHeaderIdList, String[] cartHeaderIds, String cartHeaderId){
		
		cartHeaderIdList = new ArrayList<String>(Arrays.asList(cartHeaderId.split("\\|")));
		if (cartHeaderIdList != null && !cartHeaderIdList.isEmpty()) {
			cartHeaderIds = new String[cartHeaderIdList.size()];
			int customerCount = 0;
			for (; customerCount < cartHeaderIdList.size(); customerCount++) {

				cartHeaderIds[customerCount] = cartHeaderIdList.get(customerCount);
			}
		}
		
	}
	
	private String[] setOrderTypes(String orderType, String[] cartHeaderIds, String[] orderTypes, ArrayList<String> orderTypeList) {
		if (orderType == null || orderType.isEmpty()) {
			String ordrType = EMPTY_STRING;

			orderTypes = new String[cartHeaderIds.length];
			int orderCount = 0;
			for (; orderCount < cartHeaderIds.length; orderCount++) {

				orderTypes[orderCount] = ordrType;

			}
		} else {

			orderTypeList = new ArrayList<String>(Arrays.asList(orderType.split("\\|")));
			if (orderTypeList != null && !orderTypeList.isEmpty()) {
				orderTypes = new String[orderTypeList.size()];
				int orderCount = 0;
				for (; orderCount < orderTypeList.size(); orderCount++) {

					orderTypes[orderCount] = orderTypeList.get(orderCount);
				}
			}
		}
		return orderTypes;
	}
	
	@Override
	public List<PurchasePOBO> purchasePOBS(String strSSO, String portalId, String cartHeaderId, String orderType)
			throws MaterialsException {
		log.info("Entered into purchasePOBS() method");
		if (!isNotNullandEmpty(cartHeaderId)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8320,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8320),
					ERR_CART_HEADER_ID_NOT_FOUND);
		}
		StopWatch watch = new StopWatch();
		String TASK = EMPTY_STRING;
		String urlStr = EMPTY_STRING;
		String updateOrder_HeaderId = EMPTY_STRING;
		boolean isOrderCreated = false;
		PurchasePOBO purchasePOBO = null;
		PurchasePODO purchasePODO = null;
		CustLoginDetails custLoginDetails = null;
		OrderLineMessageBO orderLineMessageBO = null;
		ArrayList<String> cartHeaderIdList = null;
		ArrayList<String> orderTypeList = null;
		String cartHeaderIds[] = null;
		String orderTypes[] = null;
		List<CartMessageDO> lstCartMessageDO = null;
		List<LineMessageDO> lstOrderLineMessageDO = null;
		List<PurchasePOBO> lstPurchasePOBO = null;
		List<ItemDetailHeaderInputDO> lstDetailHeaderInputDOs = null;
		ItemDetailHeaderInputDO itemDetailsDO = null;
		LinkedHashSet<OrderLineMessageBO> lstOrderLineMessageBO = null;
		lstPurchasePOBO = new ArrayList<PurchasePOBO>();
		custLoginDetails = materialsAppUtil.getCustLoginDetails(strSSO, portalId);

		// getHeaderDetailBS and getLineDetailBS for order ack - start
		OrderHeaderDetails orderHeaderDetailsForPurchase = null;
		LineDetailBO lineDetailBO = null;
		List<LineInfoBO> lineInfoBOListForPurchase = null;
		List<LineInfoBO> lineInfoBOListForPurchaseNew = null;
		ItemDtlHeaderBO itemDtlHeaderBO = null;
		List<ItemDtlHeaderBO> lstItemDtlHeaderBOs = new ArrayList<ItemDtlHeaderBO>();
		// getHeaderDetailBS and getLineDetailBS for order ack - end
		try {
			
			cartHeaderIdList = new ArrayList<String>(Arrays.asList(cartHeaderId.split("\\|")));
			if (cartHeaderIdList != null && !cartHeaderIdList.isEmpty()) {
				cartHeaderIds = new String[cartHeaderIdList.size()];
				int customerCount = 0;
				for (; customerCount < cartHeaderIdList.size(); customerCount++) {

					cartHeaderIds[customerCount] = cartHeaderIdList.get(customerCount);
				}
			}
			orderTypes = setOrderTypes(orderType, cartHeaderIds, orderTypes, orderTypeList);
			for (int orderCount = 0; orderCount < cartHeaderIds.length; orderCount++)

			{
				itemDtlHeaderBO = new ItemDtlHeaderBO();
				itemDtlHeaderBO.setQuoteHeaderId(Integer.parseInt(cartHeaderIds[orderCount]));
				itemDtlHeaderBO.setType(orderTypes[orderCount]);
				lstItemDtlHeaderBOs.add(itemDtlHeaderBO);
			}

			lstDetailHeaderInputDOs = new ArrayList<ItemDetailHeaderInputDO>();
			for (ItemDtlHeaderBO itemDtlHdrBO : lstItemDtlHeaderBOs) {
				itemDetailsDO = new ItemDetailHeaderInputDO(itemDtlHdrBO.getQuoteHeaderId(), itemDtlHdrBO.getType());
				lstDetailHeaderInputDOs.add(itemDetailsDO);
			}

			purchasePODO = materialsCartDAO.purchasePODS(strSSO, custLoginDetails.getRole(),
					custLoginDetails.getIcaoCode(), custLoginDetails.getCustIdList(),
					custLoginDetails.getOperatingUnitId(), cartHeaderId, lstDetailHeaderInputDOs);

		} catch (TechnicalException e) {
			log.error(e.getMessage());
			materialsAppUtil.throwAsBusinessException(e);
		}
		if (purchasePODO != null) {
			if (isNotNullandEmpty(purchasePODO.getP_msg())) {
				if (purchasePODO.getP_msg().contains(ERR_CODE_8167)) {
					String[] parts = purchasePODO.getP_msg().split(COLON, 2);
					throw new MaterialsException(8167, parts[1], parts[1]);
				}
				materialsAppUtil.throwERPMessage(purchasePODO.getP_msg());
			} else {
				lstCartMessageDO = purchasePODO.getLstCartMessageDO();
				lstOrderLineMessageDO = purchasePODO.getLstLineMessageDO();
				for (CartMessageDO cartMessageDO : lstCartMessageDO) {
					purchasePOBO = new PurchasePOBO();
					isOrderCreated = false;
					Map<String, String> addressMap = null;
					String headerID = cartMessageDO.getOrderHeaderId();
					purchasePOBO.setCartHeaderId(cartMessageDO.getCartHeaderId());
					purchasePOBO.setStatusMessage(materialsAppUtil.getStatusMessage(cartMessageDO.getStatusMessage()));
					// Temporary fix made for Unknown error JIRA 8682
					if (isNotNullandEmpty(cartMessageDO.getStatusMessage())
							&& (cartMessageDO.getStatusMessage().contains(ERR_CODE_8156))) {
						purchasePOBO.setStatusMessage(materialsAppUtil.getStatusMessage(
								materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8156)));
					}
					// Fix ends
					log.info("Cart HeaderId :: " + cartMessageDO.getCartHeaderId() + " And  Status Message :: "
							+ cartMessageDO.getStatusMessage());
					if (isNotNullandEmpty(cartMessageDO.getSuccess())
							&& "Y".equalsIgnoreCase(cartMessageDO.getSuccess())) {
						purchasePOBO.setSuccess(true);
					} else {
						purchasePOBO.setSuccess(false);
					}
					purchasePOBO.setOrderHeaderId(headerID);
					// Order Ack - start
					// Calling header Detail service to get the header
					// information to populate the JSON
					if (isNotNullandEmpty(headerID)) {
						isOrderCreated = true;
						// Start making pipe seperated CartHeaderId
						
						updateOrder_HeaderId += PIPE + headerID;
						// end making pipe separated CartHeaderId
					}
					if (isOrderCreated) {
						// Calling Header details service to obtain
						// TotalOrderValue and totalDiscount
						orderHeaderDetailsForPurchase = materialsOrdersApp.getHeaderDetailBS(strSSO, portalId, null,
								null, headerID, null);
						purchasePOBO.setPurchaseOrderNumber(
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getCustomerPONumber());
						purchasePOBO.setTotalOrderValue(
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getTotalOrderValue());
						purchasePOBO.setTotalDiscount(
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getTotalDiscount());
						addressMap = new HashMap<String, String>();
						addressMap.put("SHIP_TO_LOCATION",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getShipToLocation());
						addressMap.put("SHIP_ADDRESS_1",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getShipToAddress_1());
						addressMap.put("SHIP_ADDRESS_2",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getShipToAddress_2());
						addressMap.put("SHIP_ADDRESS_3",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getShipToAddress_3());
						addressMap.put("SHIP_ADDRESS_4",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getShipToAddress_4());
						addressMap.put("SHIP_ADDRESS_5",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getShipToAddress_5());
						addressMap.put("DELVR_TO_LOCATION",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getDeliverToLocation());
						addressMap.put("DELVR_ADDRESS_1",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getDeliverToAddress_1());
						addressMap.put("DELVR_ADDRESS_2",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getDeliverToAddress_2());
						addressMap.put("DELVR_ADDRESS_3",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getDeliverToAddress_3());
						addressMap.put("DELVR_ADDRESS_4",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getDeliverToAddress_4());
						addressMap.put("DELVR_ADDRESS_5",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getDeliverToAddress_5());
						addressMap.put("BILL_TO_LOCATION",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getInvoiceToLocation());
						addressMap.put("BILL_ADDRESS_1",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getInvoiceToAddress_1());
						addressMap.put("BILL_ADDRESS_2",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getInvoiceToAddress_2());
						addressMap.put("BILL_ADDRESS_3",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getInvoiceToAddress_3());
						addressMap.put("BILL_ADDRESS_4",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getInvoiceToAddress_4());
						addressMap.put("BILL_ADDRESS_5",
								orderHeaderDetailsForPurchase.getOrderHeaderInfoBO().getInvoiceToAddress_5());

						purchasePOBO.setAddressMap(addressMap);
					}
					// Order Ack - end
					lstOrderLineMessageBO = new LinkedHashSet<OrderLineMessageBO>();
					// Order Ack - start
					// Calling line Detail service to get the line information
					// to populate the JSON
					String isPartPriced = TRUE;
					String isCriticalPartFlag = FALSE;
					Boolean criticalPartFlag = false;
					if (isOrderCreated) {
						lineDetailBO = materialsApp.getLineDetailBS(strSSO, portalId, null, null, headerID, null,
								new ArrayList<MaterialsSortField>(), 0, 0);
						lineInfoBOListForPurchaseNew = lineDetailBO.getOrderLineList();
						lineInfoBOListForPurchase = new ArrayList<LineInfoBO>();
						lineListDetails(lineInfoBOListForPurchaseNew, lineInfoBOListForPurchase);
					}
					orderLineMessageUpdate(lstOrderLineMessageDO, orderLineMessageBO,
								cartMessageDO, lineInfoBOListForPurchase, isOrderCreated, lstOrderLineMessageBO, isPartPriced);
					if (isOrderCreated) {
						removeEmptyObjects(lstOrderLineMessageBO);
					}
					purchasePOBO.setLstOrderLineMessageBO(lstOrderLineMessageBO);
					purchasePOBO.setPricingFlag(isPartPriced);
					lstPurchasePOBO.add(purchasePOBO);
				}
				log.info("In purchase service - orderHeader Id :: " + updateOrder_HeaderId);
				if (isNotNullandEmpty(updateOrder_HeaderId)) {
					updateOrder_HeaderId = updateOrder_HeaderId.substring(1);
					urlStr = materialsAppUtil.getAttivioServicesURL() + CONST_UPDATE_ORDER + EQUALS_STRING
							+ updateOrder_HeaderId;
					materialsAppUtil.invokeService(urlStr, "Purchase PO");
					// call Notification service - start
					TASK = "notifyUser";
					materialsAppUtil.startLogging(TASK, watch);
					notifyUser(lstPurchasePOBO, strSSO, portalId);
					materialsAppUtil.endLogging(TASK, watch);
					// call Notification servicer - end
				}
			}
		}
		return lstPurchasePOBO;
	}
 	 
 	 private void removeEmptyObjects(Set<OrderLineMessageBO> lstOrderLineMessageBO) {
 		 Iterator<OrderLineMessageBO> itr = lstOrderLineMessageBO.iterator();
 		 while (itr.hasNext()) {
 			 OrderLineMessageBO orderLineMessage = (OrderLineMessageBO) itr.next();
 			 if (MaterialsAppUtil.isNullOrEmpty(orderLineMessage.getLineNumber())) {
 				 itr.remove(); // Use itr.remove() method
 			 }
 		 }
 	 }

	@Async
	private void notifyUser(List<PurchasePOBO> lstPurchasePOBO, String sso, String portalId) {
		EmailContentInputBO mailContentInputBO = populateEmailContent(sso, portalId);
		PurchaseOrderEmailBodyBO emailBodyBO = null;
		String custPONumber = null;
		String totalOrderValue = null;
		String totalDiscount = null;
		String partPricedFlag = null;
		Set<OrderLineMessageBO> lineDetailsBo = null;
		Map<String, String> addressMap = null;
		for (PurchasePOBO purchasePOBO : lstPurchasePOBO) {
			if (isNotNullandEmpty(purchasePOBO.getOrderHeaderId())) {
				custPONumber = purchasePOBO.getPurchaseOrderNumber();
				totalOrderValue = purchasePOBO.getTotalOrderValue();
				totalDiscount = purchasePOBO.getTotalDiscount();
				addressMap = purchasePOBO.getAddressMap();
				lineDetailsBo = purchasePOBO.getLstOrderLineMessageBO();
				partPricedFlag = purchasePOBO.getPricingFlag();
				emailBodyBO = populateEmailBody(sso, custPONumber, totalOrderValue, totalDiscount, addressMap);
				emailBodyBO.setPartPricedFlag(partPricedFlag);
				mailContentInputBO.setSubject(generateSubject(custPONumber));
				mailContentInputBO.setBody(buildBodyContent(emailBodyBO, lineDetailsBo, portalId));
				mailContentInputBO.getIdentityId();
				materialsAppUtil.invokeNotificationService(mailContentInputBO, notificationServiceUrl,
						MaterialsAppConstants.PURCHASE_ORDER);
			}
		}
	}
	
    private PurchaseOrderEmailBodyBO populateEmailBody(String sso, String custPONumber,       String totalOrderValue, String totalDiscount, Map<String, String> addressMap) {
        PurchaseOrderEmailBodyBO emailBody = new PurchaseOrderEmailBodyBO();
        emailBody.setFirstName(materialsAppUtil.getFirstName(sso));
        emailBody.setLastName(materialsAppUtil.getLastName(sso));
        emailBody.setPurchaseOrderNumber(custPONumber);
        emailBody.setTotalOrderValue(totalOrderValue);
        emailBody.setTotalDiscount(totalDiscount);
        emailBody.setShipAddress(makeShipToAddressString(addressMap));
        emailBody.setDeliverAddress(makeDeliverToAddressString(addressMap));
        emailBody.setBillToAddress(makeBillToAddressString(addressMap));
        return emailBody;
 }
 private String makeShipToAddressString(Map<String, String> inputMap){
        String shipAddress = EMPTY_STRING;
        String tempStr= EMPTY_STRING;
        StringBuilder sbuilder = null;
        if(MaterialsAppUtil.isMapNotEmpty(inputMap)){
              sbuilder = new StringBuilder();
              tempStr = materialsAppUtil.getAsString(inputMap.get("SHIP_TO_LOCATION"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("SHIP_ADDRESS_1"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("SHIP_ADDRESS_2"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("SHIP_ADDRESS_3"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("SHIP_ADDRESS_4"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("SHIP_ADDRESS_5"));
              sbuilder.append(tempStr);

              shipAddress = sbuilder.toString();
        }
        return shipAddress;
 }
 private String makeDeliverToAddressString(Map<String, String> inputMap){
        String deliverAddress = EMPTY_STRING;
        String tempStr= EMPTY_STRING;
        StringBuilder sbuilder = null;
        if(MaterialsAppUtil.isMapNotEmpty(inputMap)){
              sbuilder = new StringBuilder();
              tempStr = materialsAppUtil.getAsString(inputMap.get("DELVR_TO_LOCATION"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("DELVR_ADDRESS_1"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("DELVR_ADDRESS_2"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("DELVR_ADDRESS_3"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("DELVR_ADDRESS_4"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("DELVR_ADDRESS_5"));
              sbuilder.append(tempStr);

              deliverAddress = sbuilder.toString();
        }
        return deliverAddress;
 }
 
 private String makeBillToAddressString(Map<String, String> inputMap){
        String billAddress = EMPTY_STRING;
        String tempStr= EMPTY_STRING;
        StringBuilder sbuilder = null;
        if(MaterialsAppUtil.isMapNotEmpty(inputMap)){
              sbuilder = new StringBuilder();
              tempStr = materialsAppUtil.getAsString(inputMap.get("BILL_TO_LOCATION"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("BILL_ADDRESS_1"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("BILL_ADDRESS_2"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("BILL_ADDRESS_3"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("BILL_ADDRESS_4"));
              sbuilder.append(tempStr);
              if(isNotNullandEmpty(tempStr)){
                     sbuilder.append(HTML_BREAK);
              }
              tempStr = materialsAppUtil.getAsString(inputMap.get("BILL_ADDRESS_5"));
              sbuilder.append(tempStr);

              billAddress = sbuilder.toString();
        }
        return billAddress;
 }
 private String generateSubject(String orderNumber){
        StringBuilder subjectStrSB = new StringBuilder();
        subjectStrSB.append("PO # ");
        subjectStrSB.append(orderNumber);
        subjectStrSB.append(" - Order Confirmation Acknowledgement");
        return subjectStrSB.toString();
 }
 
 private String buildBodyContent(PurchaseOrderEmailBodyBO emailBodyBO, Set<OrderLineMessageBO> lineDetailsBo, String portalId) {
        StringBuilder htmlBuilder = new StringBuilder();
        String envmt = materialsAppUtil.getDeployedEnvironment();
        String blueBoldFont = STYLE_BOLD_FONT + STYLE_FONT_COLOR_BLUE;
        String deliverToAddress = EMPTY_STRING;
        deliverToAddress = emailBodyBO.getDeliverAddress();
        String isCriticalFlag  = FALSE;
        
        String bilToAddress= emailBodyBO.getBillToAddress();

        if("DEV".equalsIgnoreCase(envmt) || "QA".equalsIgnoreCase(envmt)){
              htmlBuilder.append("<h5 style='color:#0000ff;font-size:12px; font-family: ge-inspira, Helvetica Neue, Helvetica, Arial, sans-serif;'>This is a test mail. You can ignore this.</h5>");
        }
        htmlBuilder.append("<div style='"+STYLE_BODY_FONT_SIZE_12+"'>");
        //Salutation and PO # details - start
        htmlBuilder.append("Hello" + SPACE + "<b>"+emailBodyBO.getFirstName() + SPACE + emailBodyBO.getLastName() + COMMA + "</b>");
        htmlBuilder.append("<br>Your Purchase Order # (");
        htmlBuilder.append("<span style='"+STYLE_BODY_FONT_SIZE_12+STYLE_FONT_FAMILY+blueBoldFont+"'>"+emailBodyBO.getPurchaseOrderNumber()+"</span>");
        htmlBuilder.append(") was successfully created on "+materialsAppUtil.getFormattedCurrentDate("MMM-dd-yyyy"));
        //Salutation and PO # details - end
        htmlBuilder.append("<br><br>");
        //Shipping and Delivery Address - start
        htmlBuilder.append("<table width='auto' style='"+STYLE_BORDER+"'>");
        htmlBuilder.append(HTML_ROW);
        if(isNotNullandEmpty(deliverToAddress)){
              htmlBuilder.append("<td width='34%' style='"+STYLE_BORDER_RIGHT+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+blueBoldFont+STYLE_ALIGN_CENTER+"'>Ship To</td>");
              htmlBuilder.append(HTML_STYLE+STYLE_BORDER_RIGHT+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+blueBoldFont+STYLE_ALIGN_CENTER+"'>Deliver To</td>");
              htmlBuilder.append(HTML_STYLE+STYLE_BORDER_NONE+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+blueBoldFont+STYLE_ALIGN_CENTER+"'>Bill To</td>");
        }else{
              htmlBuilder.append(HTML_STYLE1+STYLE_BORDER_RIGHT+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+blueBoldFont+STYLE_ALIGN_CENTER+"'>Ship To</td>");
              htmlBuilder.append(HTML_STYLE1+STYLE_BORDER_NONE+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+blueBoldFont+STYLE_ALIGN_CENTER+"'>Bill To</td>");
        }
        htmlBuilder.append("</tr>");

        htmlBuilder.append(HTML_ROW);
        
        if(isNotNullandEmpty(deliverToAddress)){
              htmlBuilder.append("<td width='34%' style='"+STYLE_BORDER_RIGHT_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_LEFT+"'>"+emailBodyBO.getShipAddress()+HTML_COLUMN);
              htmlBuilder.append(HTML_STYLE+STYLE_BORDER_RIGHT_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_LEFT+"'>"+emailBodyBO.getDeliverAddress()+HTML_COLUMN);//for Deliver to address
              htmlBuilder.append(HTML_STYLE+STYLE_BORDER_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_LEFT+"'>"+emailBodyBO.getBillToAddress()+HTML_COLUMN);
        }else{
              htmlBuilder.append(HTML_STYLE1+STYLE_BORDER_RIGHT_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_LEFT+"'>"+emailBodyBO.getShipAddress()+HTML_COLUMN);
              htmlBuilder.append(HTML_STYLE1+STYLE_BORDER_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_LEFT+"'>"+emailBodyBO.getBillToAddress()+HTML_COLUMN);
        }
        htmlBuilder.append("</tr>");
        htmlBuilder.append("</table>");
        //Shipping and Delivery Address - end

        //Discount and Order Value - start
        if("TRUE".equals(emailBodyBO.getPartPricedFlag())){
               htmlBuilder.append("<br>"+MaterialsAppConstants.PURCHASE_ORDER_TOTAL_ORDER_VALUE + SPACE +materialsAppUtil.getCurrencyFormattedValue(emailBodyBO.getTotalOrderValue()));
              if(!MaterialsConstants.MYCFM.equalsIgnoreCase(portalId))
               htmlBuilder.append("<br>"+MaterialsAppConstants.PURCHASE_ORDER_TOTAL_DISCOUNT + SPACE + materialsAppUtil.getCurrencyFormattedValue(emailBodyBO.getTotalDiscount()));
        }
        else{
              htmlBuilder.append("<br><sup style='"+STYLE_DISCLAIMER_FONT_COLOR+HTML_SUP+MaterialsAppConstants.PURCHASE_ORDER_TOTAL_ORDER_VALUE + SPACE +materialsAppUtil.getCurrencyFormattedValue(emailBodyBO.getTotalOrderValue()));
              if(!MaterialsConstants.MYCFM.equalsIgnoreCase(portalId))
              htmlBuilder.append("<br><sup style='"+STYLE_DISCLAIMER_FONT_COLOR+HTML_SUP+MaterialsAppConstants.PURCHASE_ORDER_TOTAL_DISCOUNT + SPACE + materialsAppUtil.getCurrencyFormattedValue(emailBodyBO.getTotalDiscount()));
        }
        //Discount and Order Value - end
        //PO details - start
        htmlBuilder.append("<br><br><b>" + MaterialsAppConstants.PURCHASE_ORDER_MAIL_MESSAGE + "</b>");
        htmlBuilder.append(insertOrderDetailsTable(lineDetailsBo,emailBodyBO));
        if("FALSE".equals(emailBodyBO.getPartPricedFlag())){
              htmlBuilder.append(SUP_STYLE+STYLE_DISCLAIMER_FONT_COLOR+"'>**</sup><span style='"+STYLE_NOTE+"'>"+MaterialsAppConstants.PURCHASE_ORDER_PRICING_NOTE+"</span><br>");
        }
        isCriticalFlag = criticalFlag(lineDetailsBo);
        log.info("isCriticalFlag--"+isCriticalFlag);
        if("TRUE".equals(isCriticalFlag)){
              htmlBuilder.append(SUP_STYLE+STYLE_DISCLAIMER_FONT_COLOR+"'>**</sup><span style='"+STYLE_NOTE+"'>"+MaterialsAppConstants.ON_ALLOCATION_PART_MSG+"</span><br>");
        }
        //PO details - end
        htmlBuilder.append("<br><span style='"+STYLE_ITALIC_FONT+STYLE_BOLD_FONT+"'>"+MaterialsAppConstants.PURCHASE_ORDER_THANKING+"</span>");
        htmlBuilder.append("</div>");
        return htmlBuilder.toString();
 }

 
 private String insertOrderDetailsTable(Set<OrderLineMessageBO> lineDetailsBo, PurchaseOrderEmailBodyBO emailBodyBO) {
        StringBuilder details = new StringBuilder();
        details.append("<br>");
        if(isCollectionNotEmpty(lineDetailsBo)){
              boolean discountFlag = true;
              String reqDate = EMPTY_STRING;
              String unitListPrice = EMPTY_STRING;
              String unitSellPrice = EMPTY_STRING;
              String extPrice = EMPTY_STRING;
              String blueBoldFont = STYLE_BOLD_FONT +"*"+ STYLE_FONT_COLOR_BLUE;
              String totalDiscount = emailBodyBO.getTotalDiscount();
              Boolean criticalPartFlag=true;
              log.info("In purchasePO insertOrderDetailsTable, Total Discount: "+totalDiscount);
              if(MaterialsAppUtil.isNullOrEmpty(totalDiscount) || "0".equals(totalDiscount)){
                     discountFlag = false;
              }
              details.append("<table width='100%' style='"+STYLE_BORDER+STYLE_NO_WRAP+"'>");
              details.append("<tr><td width='12%' style='"+STYLE_BORDER_RIGHT+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+blueBoldFont+STYLE_ALIGN_CENTER+"'>PO Line #</td>");
              details.append(HTML_STYLE2+STYLE_BORDER_RIGHT+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+blueBoldFont+STYLE_ALIGN_CENTER+"'>Part Number</td>");
              details.append(HTML_STYLE2+STYLE_BORDER_RIGHT+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+blueBoldFont+STYLE_ALIGN_CENTER+"'>Keyword</td>");
              details.append(HTML_STYLE2+STYLE_BORDER_RIGHT+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+blueBoldFont+STYLE_ALIGN_CENTER+"'>Ord.Qty.</td>");
              details.append(HTML_STYLE2+STYLE_BORDER_RIGHT+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+blueBoldFont+STYLE_ALIGN_CENTER+"'>Req.Date</td>");
              details.append(HTML_STYLE3+STYLE_BORDER_RIGHT+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+blueBoldFont+STYLE_ALIGN_CENTER+"'>List Price");
              if(discountFlag){
                     details.append(HTML_STYLE3+STYLE_BORDER_RIGHT+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+blueBoldFont+STYLE_ALIGN_CENTER+"'>Discount (%)</td>");
              }
              details.append(HTML_STYLE3+STYLE_BORDER_RIGHT+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+blueBoldFont+STYLE_ALIGN_CENTER+"'>Selling Price");
              details.append(HTML_STYLE3+STYLE_BORDER_NONE+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+blueBoldFont+STYLE_ALIGN_CENTER+"'>Ext Price</td></tr>");
              for (OrderLineMessageBO orderLineMessageBO : lineDetailsBo) {
                     reqDate = materialsAppUtil.getFormattedDate(orderLineMessageBO.getRequestDate(), "yyyy-MM-dd", "MMM-dd-yyyy");
                     unitListPrice = materialsAppUtil.getCurrencyFormattedValue(orderLineMessageBO.getUnitListPrice());
                     unitSellPrice = materialsAppUtil.getCurrencyFormattedValue(orderLineMessageBO.getUnitSellingPrice());
                     extPrice = materialsAppUtil.getCurrencyFormattedValue(orderLineMessageBO.getExternalPrice());
                     criticalPartFlag = orderLineMessageBO.getCriticalPartFlag();
                     details.append("<tr><td style='"+STYLE_BORDER_RIGHT_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_CENTER+"'>"+orderLineMessageBO.getLineNumber()+HTML_COLUMN);
                     if(criticalPartFlag){
                            log.info("criticalPartFlag"+criticalPartFlag+"aprtNumber--"+orderLineMessageBO.getPartNumber());
                            details.append(HTML_STYLE1+STYLE_BORDER_RIGHT_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_CENTER+"'>"+orderLineMessageBO.getPartNumber()+SUP_STYLE+STYLE_DISCLAIMER_FONT_COLOR+HTML_SUP);
                     }
                     else
                     {
                     details.append(HTML_STYLE1+STYLE_BORDER_RIGHT_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_CENTER+"'>"+orderLineMessageBO.getPartNumber()+HTML_COLUMN);
                     }
                     details.append(HTML_STYLE1+STYLE_BORDER_RIGHT_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_CENTER+"'>"+orderLineMessageBO.getKeyword()+HTML_COLUMN);
                     details.append(HTML_STYLE1+STYLE_BORDER_RIGHT_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_CENTER+"'>"+orderLineMessageBO.getOrderedQuantity()+HTML_COLUMN);
                     details.append(HTML_STYLE1+STYLE_BORDER_RIGHT_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_CENTER+"'>"+reqDate+HTML_COLUMN);
                     details.append(HTML_STYLE1+STYLE_BORDER_RIGHT_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_RIGHT+"'>"+unitListPrice+HTML_COLUMN);
                     if(discountFlag){
                            details.append(HTML_STYLE1+STYLE_BORDER_RIGHT_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_CENTER+"'>"+orderLineMessageBO.getDiscountPercent()+HTML_COLUMN);
                     }
                     details.append(HTML_STYLE1+STYLE_BORDER_RIGHT_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_RIGHT+"'>"+unitSellPrice+HTML_COLUMN);
                     details.append(HTML_STYLE1+STYLE_BORDER_TOP+STYLE_TABLE_DATA_FONT_SIZE+STYLE_FONT_FAMILY+STYLE_NORMAL_FONT+STYLE_ALIGN_RIGHT+"'>"+extPrice+"</td></tr>");
              }
              details.append("</table><br>");
        }
        return details.toString();
 }
 public String getFormattedDate(String date, String inputFormat, String outputFormat) {
        DateFormat outFormat = null;
        DateFormat inFormat = null;
        String formattedDt = EMPTY_STRING;
        try{
              if((null!=date&&!date.isEmpty()) && null!=outputFormat&&!outputFormat.isEmpty()){
                     inFormat = new SimpleDateFormat(inputFormat);
                     outFormat = new SimpleDateFormat(outputFormat);
                     formattedDt = outFormat.format(inFormat.parse(date));
              }
        } catch (Exception e) {
              log.info(e);
              formattedDt = date;
        }
        return formattedDt;
 }

	private String criticalFlag(Set<OrderLineMessageBO> lineDetailsBo) {
		String criticalFlag = FALSE;
		StringBuilder criticalPartFlag = new StringBuilder();
		for (OrderLineMessageBO orderLineMessageBO : lineDetailsBo) {
			criticalPartFlag.append(orderLineMessageBO.getCriticalPartFlag());
			log.info("orderLineMessageBO.getCriticalPartFlag()" + orderLineMessageBO.getCriticalPartFlag());
		}
		if (criticalPartFlag.toString().contains("true")) {
			criticalFlag = TRUE;
			log.info("inside");
		}
		return criticalFlag;
	}

	private EmailContentInputBO populateEmailContent(String sso, String portalId) {
		String toMailId = EMPTY_STRING;
		String envmt = EMPTY_STRING;
		String appOwnerId = EMPTY_STRING;
		envmt = materialsAppUtil.getDeployedEnvironment();
		appOwnerId = materialsAppUtil.getAppOwnerId();
		EmailContentInputBO emailContent = new EmailContentInputBO();
		emailContent.setIdentityId(materialsAppUtil.getAppOwnerId());
		emailContent.setPortalId(portalId);
		emailContent.setFrom(materialsAppUtil.getFromEmailForPortal(portalId));
		if ("PROD".equalsIgnoreCase(envmt)) {
			toMailId = materialsAppUtil.getEmailId(sso);
			if (MaterialsAppUtil.isNullOrEmpty(toMailId)) {
				log.info("Recipient mail id does not exists, mail will be sent to App owner");
				toMailId = appOwnerId + MAIL_EXCHANGE_SERVER;
			}
			emailContent.setTo(toMailId);
		} else {
			emailContent.setTo("mygeav-materaials.devqaemails@ge.com");// For
																		// Dev/QA
		}
		return emailContent;
	}
}
