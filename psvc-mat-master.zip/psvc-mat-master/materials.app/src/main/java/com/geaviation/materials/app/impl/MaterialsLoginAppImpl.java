/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 12, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     MaterialsAppImpl.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.app.impl;

import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.AERODP;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.DESC_ATTIVIO_ACCESS;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EMPTY_STRING;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_ICAO_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_OPR_UNIT_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_PORTAL_ID_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_SSO_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.GEAE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.NO;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.YES;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.app.api.IMaterialsLoginApp;
import com.geaviation.materials.app.impl.util.MaterialsAppUtil;
import com.geaviation.materials.data.api.IMaterialsLoginDAO;
import com.geaviation.materials.entity.MaterialsLoginResponse;
import com.geaviation.materials.entity.MaterialsUserAccess;
import com.geaviation.materials.entity.MaterialsUserBO;
import com.geaviation.materials.exception.MaterialsErrorCodes;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;


@Component
public class MaterialsLoginAppImpl implements IMaterialsLoginApp{
	MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
	@Autowired
	private MaterialsAppUtil materialsAppUtil;
	
	@Autowired
	private IMaterialsLoginDAO materialsLoginDAO;

	private static final Log log = LogFactory.getLog(MaterialsLoginAppImpl.class);


	@Override
	public MaterialsLoginResponse requestMaterialsLogin(String sso, String portalId) throws MaterialsException {
		MaterialsLoginResponse loginResponse = null;
		StopWatch watch = new StopWatch();
		String	task = "getIcaoCode";
		materialsAppUtil.startLogging(task, watch);
		String icao = materialsAppUtil.getIcaoCode(sso, portalId);
		materialsAppUtil.endLogging(task, watch);
		List<Object> loginDetailLst = getLoginAllData(sso,portalId,icao);
		if(MaterialsAppUtil.isCollectionNotEmpty(loginDetailLst)){
			Object cachedObj = loginDetailLst.get(0);
			if(cachedObj instanceof MaterialsLoginResponse){
				loginResponse = (MaterialsLoginResponse) cachedObj;
			}
		}
		return loginResponse;
	}
	
	private MaterialsLoginResponse requestMaterialsLoginBS(String sso, String portalId,String icao) throws MaterialsException {
		log.info("Entered into requestMaterialsLogin() method");
		String icaoCode = icao;
		if(!MaterialsAppUtil.isNotNullandEmpty(sso)){
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8301, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND);
		}
		if(!MaterialsAppUtil.isNotNullandEmpty(portalId)){
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8302, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8302), ERR_PORTAL_ID_NOT_FOUND);
		}
		String impersonator = NO;
		boolean isLoginSuccess = false;
		MaterialsLoginResponse loginDetail = null;
		MaterialsUserBO userBO = null;
		MaterialsUserAccess materialsUserAccess = null;
		//call portal service getOrgId to get ICAO code
		//Removed getting the icao code from portalIdas requested for AreoDp ( added newly )
		StopWatch watch = new StopWatch();
		if(MaterialsAppUtil.isNotNullandEmpty(icaoCode)){
			//for AeroDP ICAO change
			if(!portalId.equalsIgnoreCase(AERODP)){
				String task = "getDefaultOrg";
				materialsAppUtil.startLogging(task, watch);
				String defaultOrgId = materialsAppUtil.getDefaultOrg(sso, portalId);
				materialsAppUtil.endLogging(task, watch);
					if ((MaterialsAppUtil.isNotNullandEmpty(defaultOrgId)) && ((GEAE.equalsIgnoreCase(defaultOrgId)) && (!defaultOrgId.equalsIgnoreCase(icaoCode)))) {
						impersonator = NO;
					}
			}
		}
		else
		{
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8303, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8303), ERR_ICAO_NOT_FOUND);
		}
		log.info("Is Impersonator : " +impersonator);
		//get operatingUnitId
		String task = "getPortalOUDS";
		materialsAppUtil.startLogging(task, watch);
		String opUid =  materialsLoginDAO.getPortalOUDS(portalId.toUpperCase(), true);
		materialsAppUtil.endLogging(task, watch);
		if(MaterialsAppUtil.isNotNullandEmpty(opUid)){
			//Call the ERP procedure-1 to check access
			task = "isHavingAccessDS";
			materialsAppUtil.startLogging(task, watch);
			try {
				materialsUserAccess =  materialsLoginDAO.isHavingAccessDS(sso, icaoCode, opUid);
			} catch (TechnicalException e) {
				log.error(e);
				materialsAppUtil.throwAsBusinessException(e);
			}
			materialsAppUtil.endLogging(task, watch);
		}
		else
		{
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8304, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8304), ERR_OPR_UNIT_NOT_FOUND);
		}
		isLoginSuccess = materialsUserAccess.isSuccess();
		String ouId = materialsUserAccess.getOuid();
		loginDetail = new MaterialsLoginResponse();
		loginDetail.setSuccess(isLoginSuccess);
		if(isLoginSuccess){
			//Call the ERP procedure-2 to populate CustomerBO
			task = "requestLoginDS";
			materialsAppUtil.startLogging(task, watch);
			try {
				 userBO = materialsLoginDAO.requestLoginDS(sso, icaoCode, ouId, impersonator);
			 } catch (TechnicalException e) {
				 log.error(e);
				 materialsAppUtil.throwAsBusinessException(e);
			 }
			materialsAppUtil.endLogging(task, watch);
			 if(MaterialsAppUtil.isNotNullandEmpty(userBO.getMessage())){
				 materialsAppUtil.throwERPMessage(userBO.getMessage());
			 }
			 userBO.setOperatingUnitId(ouId);
			 userBO.setIcaoCode(icaoCode);
			 userBO.setSso(sso);
			 loginDetail.setMaterialsUserBO(userBO);
		}else{
			materialsAppUtil.throwERPMessage(materialsUserAccess.getMessage());
		}
		log.info("MATL-PERF : <materialsDAO.requestMaterialsLogin method> END - Tasks "+ watch.getTaskCount() +" in "+ watch.getTotalTimeMillis() +" msec");
		return loginDetail;
	}
	//passing the icao parameter to getLoginAllData() as requested for AreoDp ( added newly )
		public List<Object> getLoginAllData(final String sso, final String portalId,final String icao) throws MaterialsException {
			
					log.info("getLoginAllData() : the target original method is called to get the values.");
					List<Object> list = new ArrayList();
					MaterialsLoginResponse materialsLoginResponse = null;
					//passing the icao parameter to requestMaterialsLoginBS()
					materialsLoginResponse = requestMaterialsLoginBS(sso,portalId,icao);
					if(null!= materialsLoginResponse && materialsLoginResponse.isSuccess()){
						list.add(materialsLoginResponse);
					}
					return list;
			
			
		}
	
		@Override
		public MaterialsLoginResponse requestRepairsLoginAttivio(String userId,
				String portalId) throws MaterialsException {

			if ("CWC".equalsIgnoreCase(portalId)) {
				return requestRepairsLogin(userId, portalId);

			} else{
				log.info("logmsg :This service is only for CWC user");
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8277,
						materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8277), DESC_ATTIVIO_ACCESS);
			}	
		}
		
		@Override
		public MaterialsLoginResponse requestRepairsLogin(String sso, String portalId) throws MaterialsException {
			MaterialsLoginResponse loginResponse = null;
			StopWatch watch = new StopWatch();
			String task = "getIcaoCode";
			materialsAppUtil.startLogging(task, watch);
			String icao = materialsAppUtil.getIcaoCode(sso, portalId);
			materialsAppUtil.endLogging(task, watch);
			List<Object> loginDetailLst = getLoginAllDataRepairs(sso,portalId,icao);
			if(MaterialsAppUtil.isCollectionNotEmpty(loginDetailLst)){
				Object cachedObj = loginDetailLst.get(0);
			  if(cachedObj instanceof MaterialsLoginResponse){
					loginResponse = (MaterialsLoginResponse) cachedObj;
				}
			
			}
			return loginResponse;
		}
		public List<Object> getLoginAllDataRepairs(final String sso, final String portalId,final String icao) throws MaterialsException {
			
					log.info("getLoginAllDataRepairs() : the target original method is called to get the values.");
					List<Object> list = new ArrayList();
					MaterialsLoginResponse materialsLoginResponse = null;
					//passing the icao parameter to requestMaterialsLoginBS()
					materialsLoginResponse = requestRepairsLoginBS(sso,portalId,icao);
					if(null!= materialsLoginResponse && materialsLoginResponse.isSuccess()){
						list.add(materialsLoginResponse);
					}
					return list;
			
		}
		
		private MaterialsLoginResponse requestRepairsLoginBS(String sso, String portalId,String icao) throws MaterialsException {
			log.info("Entered into requestMaterialsLogin() method");
			if(!MaterialsAppUtil.isNotNullandEmpty(sso)){
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8301, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND);
			}
			if(!MaterialsAppUtil.isNotNullandEmpty(portalId)){
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8302, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8302), ERR_PORTAL_ID_NOT_FOUND);
			}
			String defaultOrgId = EMPTY_STRING;
			String impersonator = NO;
			boolean isLoginSuccess = false;
			MaterialsLoginResponse loginDetail = null;
			MaterialsUserBO userBO = null;
			StopWatch watch = new StopWatch();
			if(MaterialsAppUtil.isNotNullandEmpty(icao)){
				if(!portalId.equalsIgnoreCase(AERODP)){
					String task = "getDefaultOrg";
					materialsAppUtil.startLogging(task, watch);
					defaultOrgId = materialsAppUtil.getDefaultOrg(sso, portalId);
					materialsAppUtil.endLogging(task, watch);
					if ((MaterialsAppUtil.isNotNullandEmpty(defaultOrgId)) && ((GEAE.equalsIgnoreCase(defaultOrgId)) && (!defaultOrgId.equalsIgnoreCase(icao)))) {
						impersonator = YES;
					}
				}
			}
			else
			{
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8303, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8303), ERR_ICAO_NOT_FOUND);
			}
			log.info("Is Impersonator : " +impersonator);
			String task = "getPortalOUDS";
			materialsAppUtil.startLogging(task, watch);
			String opUid =  materialsLoginDAO.getPortalOUDS(portalId.toUpperCase(), false);
			materialsAppUtil.endLogging(task, watch);
			if(MaterialsAppUtil.isNotNullandEmpty(opUid)){
				loginDetail = new MaterialsLoginResponse();
					task = "requestRepairsLoginDS";
					materialsAppUtil.startLogging(task, watch);
								try {			
						userBO = materialsLoginDAO.requestLoginRepairsDS(sso, icao, opUid, impersonator);
					  } catch (TechnicalException e) {
						  log.error(e);
						 materialsAppUtil.throwAsBusinessException(e);
					 }
						materialsAppUtil.endLogging(task, watch);
					 if(!MaterialsAppUtil.isNotNullandEmpty(userBO.getMessage())){
						 isLoginSuccess =true;
						 userBO.setOperatingUnitId(opUid);
						 userBO.setIcaoCode(icao);
						 userBO.setSso(sso);
						 loginDetail.setSuccess(isLoginSuccess);
						 loginDetail.setMaterialsUserBO(userBO);
						 
					 }
					 else
					 {
						 materialsAppUtil.throwERPMessage(userBO.getMessage());
					 }
			
			}
			else
			{
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8304, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8304), ERR_OPR_UNIT_NOT_FOUND);
			}
			
			log.info("MATL-PERF : <materialsDAO.requestRepairsLoginBS method> END - Tasks "+ watch.getTaskCount() +" in "+ watch.getTotalTimeMillis() +" msec");
			return loginDetail;
		}
		

}
