/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 13, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     MaterialsAppConstants.java
 * 
 * History        :  	Mar 13, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.app.impl.util;
public class MaterialsAppConstants {
	public static final String PATH_STATICFILES_SHIPMENT ="/ShipmentTemplates/";
	public static final String EMPTY_STRING = "";
	public static final String DOT = ".";
	public static final String HYPHEN = "-";
	public static final String COLON = ":";
	public static final String SEMI_COLON = ";";
	public static final String PIPE= "|";
	public static final String TILDE= "~";
	public static final String COMMA= ",";
	public static final int ZERO = 0;
	public static final String ZERO_STRING = "0";
	public static final String BLANK_SPACE = " ";
	public static final String BLANK_SPACE_DOT = ". ";
	public static final String TRUE = "TRUE";
	public static final String FALSE = "FALSE";
	public static final String YES = "YES";
	public static final String NO = "NO";
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String GEAE = "GEAE";
	public static final String ATTR_USER_ORG = "user.org";
	public static final String ATTR_USER_CURRORG = "user.currentorg";
	public static final String ATTR_USER_ICAO = "org.icaocode";
	public static final String ATTR_USER_ALTUID = "user.altuid";;
	public static final String ATTR_CWC = "cwc";
	public static final String UNKNOWN_ERROR = "UNKNOWN_ERROR";
	public static final String ERR_MESSAGE_RB = "errorMessage";
	public static final String AOC = "AOC";
	public static final String AOC_PLACEHOLDER = "##AOC##";
	public static final String SUCCESS = "success";
	public static final String FAILURE = "failure";
	public static final String AND= " and ";
	public static final String SPACE= " ";
	public static final String EQUALS_STRING = "=";
	public static final String ASTERISK = "*";
	public static final String MDATAPROP = "mDataProp_";
	
	//Constants added for getOrder Details Data table
	public static final String PART_DESC = "partDesc";
	public static final String CUST_PO_NUM = "custPOLineNumber";
	public static final String ORDER_STATUS = "orderLnStatus";
	public static final String PART_NUMBER = "partNumber";
	public static final String REQUESTED_QTY = "requestedQty";
	public static final String ORDER_LN_SELL_PRC = "orderLnSellPrc";
	public static final String ORDER_LN_EXT_PRC = "orderLnExtPrc";
	public static final String ORDER_LN_REQ_DT = "orderLnReqDt";
	public static final String ORDER_LN_SHIP_DT = "orderLnShipDt";
	public static final String ASC = "asc";
	public static final String SSORTDIR_0 = "sSortDir_0";
	public static final String IDISPLAY_START = "iDisplayStart";
	public static final String IDISPLAY_LENGTH = "iDisplayLength";
	public static final String SECHO = "sEcho";
	public static final String ISORTCOL_0 = "iSortCol_0";
	
	// Constants added for getPricingCatalogBS Service
	public static final String DOCTYPE = "&docType=";
	public static final String XLXS = ".xlsx";
	// public static final String excelDocType = "&docType";
	public static final String PLATFORM = "platform";
	public static final String EFFDATE_STRING = "effDt";
	public static final String REVISION_DATE = "revisionDate";
	public static final String EFFECTIVE_DATE = "effectiveDate";
	public static final String EXCEL_CATALOG_LINK = "excelCatalogLink";
	public static final String PDF_CATALOG_LINK = "pdfCatalogLink";
	public static final String ENGINE_MODEL = "engineModel";
	public static final String EFFDATE = "&effDate=";
	
	//constants added for getCSVFile service
	public static final String PURCHASE_ORDER_UNDERSCORE ="Purchase_Order_";
	public static final String SHIPMENT_1="Shipment_";
	public static final String INVOICE_1="Invoice_";
	public static final String CSV =".csv";
	public static final String SHIPMENT_UNDERSCORE="Shipment_";
	public static final String INVOICE_UNDERSCORE="Invoice_";
	
	
	public static final String MATERIALURL = "services/materials/getPricingCatalogDocBS?platform=";
	public static final String MATERIALDOCURL = "services/materials/getMaterialsDocumentBS?msNumber=";
	public static final String CFMMATERIALDOCURL = "services/materials/getInvoiceDocumentBS?invoiceId=";
	public static final String DELIVERYID = "&deliveryId=";
	public static final String M = "M";
	public static final String F = "F";
	public static final String INVOICE = "Invoice";
	public static final String SCRAP = "scrap"; 
	public static final String RETURN = "return";
	public static final String RETURN_INSTRUECTIONS = "returnIns";
	public static final String RETURN_LABEL = "returnLbl";
	public static final String BUYBACK = "buyback";
	public static final String BUYBACK_INSTRUCTIONS = "buyBackIns";
	public static final String PROFORMA = "proforma";
	public static final String ATA = "ata";
	public static final String DISCREPANCY = "DISCREPANCY";
	public static final String OVERAGE = "OVERAGE";
	public static final String OVERAGE_RETURN = "Overage Return";
	public static final String OVERAGE_SCRAP = "Overage Scrap";
	public static final String UPS = "UPS";
	public static final String DISPUTE_DOCS_URL = "services/materials/downloadDisputeDocBS?docType=";
	public static final String ORDER_HEADER_ID = "&orderHeaderId=";
	public static final String ORDER_LINE_ID = "&lineId=";
	
	//VALIDATION MESSAGES
	public static final String ERR_SSO_NOT_FOUND = "SSO ID not found";
	public static final String ERR_PORTAL_ID_NOT_FOUND = "Portal ID not found";
	public static final String ERR_ICAO_NOT_FOUND = "ICAO not found";
	public static final String ERR_OPR_UNIT_NOT_FOUND = "Operating UnitId not found";
	public static final String ERR_HEADER_ID_NOT_FOUND = "Header ID not found";
	public static final String ERR_PRIORITY_NOT_FOUND = "Order priority not found";
	public static final String ERR_CUST_NOT_FOUND = "Cust ID not found";
	public static final String ERR_ORDER_LINE_NOT_FOUND = "OrderLine details not found";
	public static final String ERR_DATATABLE_ERROR_OCCURED = "Error occured while reading datatable values";
	public static final String ERR_DATATABLE_DISPLAY_ERROR_OCCURED = "iDisplayStart should be less than total number of records";
	public static final String ERR_NO_PLATFORM_AVAIL = "There are no platform available";
	public static final String ERR_PLATFORM_NOT_FOUND ="No Valid Input to Service-platForm not found";
	public static final String ERR_DOCTYPE_NOT_FOUND="No Valid Input to Service-docType not found";
	public static final String ERR_DOCUMENT_NOT_FOUND="Document not Found";
	public static final String ERR_INVITMID_NOT_FOUND="Inventory Item Id not found";
	public static final String ERR_INVITMID_PARTNUMBER_NOT_FOUND="Inventory Item Id and partNumber are not found";
	public static final String ERR_CSV_ERROR = "Error";
	
	//JIRA 5059
	public static final String ERR_PARTNUM_NOT_FOUND="Part Number not found";
	public static final String ERR_SELECTEDCUSTID_NOT_FOUND ="Selected CustomerID not found";
	public static final String ERR_QUANTITY_NOT_FOUND="Quantity not found";
	public static final String ERR_SLCTD_SUPPLIERCD_NOT_FOUND="Selected SupplierCode not found";
	public static final String ERR_CART_HEADER_ID_NOT_FOUND = "Cart Header Id not found";
	public static final String ERR_CART_LINE_ID_NOT_FOUND = "Cart Line Id not found";
	public static final String ERR_UPDATE_ORDER_ID = "Error accured while saving the Order Header Id";
	public static final String PDF ="PDF";
	public static final String EXCEL ="EXCEL";
	public static final String ERR_DATE_FORMAT_NOT_CORRECT = "Given Date format is not Correct";
	public static final String ERR_MSNUM_EXPECTED_WITH_DELIVERID = "MS Number expected with Delivery Id";
	public static final String ERR_DELIVERID_EXPECTED_WITH_MSNUM= "Delivery Id expected with MS Number";
	public static final String ERR_ORDERHRDRID_FOUND_WITH_MSNUM_AND_DELIVERID = "Order Header Id found with MS Number and Delivery Id";
	public static final String ERR_INVOICEHRDRID_FOUND_WITH_MSNUM_AND_DELIVERID = "Invoice Header Id found with MS Number and Delivery Id";
	public static final String ERR_INVOICEHRDRID_FOUND_WITH_ORDERHRDRID = "Invoice Header Id found with Order Header Id";
	public static final String ERR_INVALID_INPUTS = "Invalid Inputs";
	public static final String ERR_INSUFFICIENT_INPUTS = "Insufficient inputs";
	public static final String ERR_EMAIL_NOTIFICATION_FAILED ="Email Notification to CAM is failed";
	public static final String PO_NUM = "PONumber";
	public static final String LINE_NUM = "LineNumber";
	public static final String PART_NUM = "PartNumber";
	public static final String ERR_CODE_8125= "8125";
	public static final String ERR_CODE_8126= "8126";
	public static final String ERR_CODE_8127= "8127";
	public static final String ERR_CODE_8128= "8128";
	public static final String ERR_CODE_8129= "8129";
	public static final String ERR_CODE_8130= "8130";
	public static final String ERR_CODE_8131= "8131";
	public static final String ERR_CODE_8132= "8132";
	public static final String ERR_CODE_8133= "8133";
	public static final String ERR_CODE_8134= "8134";
	public static final String ERR_CODE_8135= "8135";
	public static final String ERR_CODE_8136= "8136";
	public static final String ERR_CODE_8137= "8137";
	public static final String ERR_CODE_8138= "8138";
	public static final String ERR_CODE_8200= "8200";
	public static final String ERR_CODE_8020= "8020";
	public static final String ERR_CODE_8300 = "8300";
	public static final String ERR_CODE_8034 = "8034";
	public static final String ERR_CODE_8035 = "8035";
	public static final String ERR_CODE_8400= "8400";
	public static final String ERR_CODE_8023 = "8023";
	public static final String ERR_CODE_8031 = "8031";
	public static final String ERR_CODE_8167 = "8167";
	public static final String ERR_CODE_8156 = "8156";
	public static final String ERR_CODE_8024 = "8024";
	public static final String ERR_CODE_8025 = "8025";
	public static final String ERR_CODE_8026 = "8026";
	public static final String PORTAL_NAME= "@PORTALNAME";
	public static final String CONST_HTTP_GET = "GET";
	public static final String CONST_UPDATE_ORDER = "updateOrder?order_header_id";
	public static final String CONST_PRICE_MSG = "Price_Msg";
	public static final String CONST_AVAIL_MSG = "Avail_Msg";
	public static final String CONST_MESSAGE_CODE = " \n Message Code: ";
	public static final String ERR_LINE_ID_NOT_FOUND = "Line Id not found";
	public static final String INVALID_DATE = "Requested date should be greater than current date";
	public static final String UNAUTHORISED_USER ="You are not authorised to download the template";
	public static final String ERR_TEMPLATE_NOT_FOUND ="Bulk Cart template not found";
	public static final String ERR_FOLDER_DOES_NOT_EXIST = "Folder does not exist";
	public static final String ERR_CAN_NOT_READ_THE_FILE = "Can not read the file";
	public static final String ERR_FOLDER_IS_NOT_A_DIRECTORY = "Folder is not a directory";
	public static final String ERR_ORDER_TEMPLATE_EMPTY = "Empty Template found";
	public static final String ERR_ORDER_TEMPLATE_NOT_VALIDATED = "Order Template is not Validated. Please validate all fields in the template and try again.";
	public static final String ERR_ORDER_TEMPLATE_NOT_LATEST_VERSION = "File format is invalid.  Please compare the file to the Bulk Order Template and try again.";
	public static final String ERR_ORDER_TEMPLATE_CONTAIN_DUPLICATES = "Order Template contains duplicate PO Number ";
	public static final String ERR_ORDER_TEMPLATE_CONTAIN_INCOMPLETE_DATA = "Order Template contains incomplete details in Row Number ";
	public static final String PO_NUM_BLANK = " PO Number is blank;";
	public static final String LINE_NUM_BLANK = " Line Number is blank;";
	public static final String PART_NUM_BLANK = " Part Number is blank;";
	public static final String QUANTITY_BLANK = " Quantity is blank;";
	public static final String PRIORITY_BLANK = " Priority is blank;";
	public static final String PRIORITY_WORKSTOP = "Work Stop";
	public static final String PRIORITY_NORMAL = "Normal";
	public static final String WSP = "WSP";
	public static final String REQUESTED_DATE_BLANK = " Requested date is blank;";
	public static final String CUSTOMER_CODE_BLANK = " Customer code is blank;";
	public static final String NO_RECORDS_FOUND = "No Records Found";
	//constants added for new fields in bulk order template US161328
	public static final String PRIORITY_WORK_STOP = "Work Stop";
	public static final String WORK_STOP_DATE_AND_QTY_BLANK = " Work Stop Date and Quantity cannot be blank if high priority;";
	public static final String WORK_STOP_DATE_AND_QTY_INVALID = " Please ensure that Work Stop Date is after Request Date and Work Stop Quantity is less than or equal to Request Quantity";
	public static final String ESN_INVALID = " If Priority is Work Stop, a valid ESN must be provided";
	public static final String BULK_UPLOAD_ERROR = "Error while uploading bulk upload excel template. Please ensure bulk upload excel template is validated successfully before uploading";
	// normal priority ESN status message
	public static final String ESN_STATUS_MSG_UPDATE = "ESN entered is invalid. Enter a Valid ESN";
	//Workstop changes
	public static final String WORK_STOP_ESN_MSG = "Valid ESN required for priority work stop";
	public static final String WORK_STOP_WARNING_MSG = "ESN entered for work stop priority is invalid. Please update the ESN before purchasing";
	//declared contant for normal priority requested by the AERODP(newly added)
	public static final String ERR_PRIORITY="Only normal priority is accepted";
	public static final String ERR_INVALID_PARTNUM1 =" Part number is invalid in Row ";
	public static final String ERR_INVALID_PARTNUM =" Invalid Part Number ";
	public static final String ERR_INVALID_PARTNUM2 = ". Please adjust and try again.";
	public static final String ERR_CART_INVALID_ESN = "Unable to process PO Purchase. Valid ESN required if Priority is Work Stop.";
	public static final String ERR_UPDATE_ORDER_ESN = "Unable to modify. Valid ESN required if Priority is Work Stop.";
	// Constants added for purchasePOBS Service
	public static final String READ_TIMED_OUT = "Read timed out";
	public static final char CHAR_COMMA = ',';
	public static final char CHAR_PIPE = '|';
	public static final String AVIAL_MSG_1 = "http://www.aviall.com/aviallstorefront/search?text=";
	public static final String AVIAL_MSG_2= " \n  <a href='http://www.aviall.com/aviallstorefront/customerservicecenters 'target='_blank'>Customer Service Centers</a> \n AOG Support: aog@aviall.com \n 1-800-AVIALL-1 or +1-972-586-1566.";
	//Constants added for getOrderTemplateBS Service
	public static final String BUYER = "Buyer";
	public static final String TEMPLATE_FILE_PATH = "/Bulk_Template";
	public static final String ERR_CODE_8179 = "8179";
	public static final String ERR_CODE_8033 = "8033";
	public static final String ERR_SHIP_CODE ="The ship code is past use and procurement code is not X or Y and there is no on hand";
	public static final String ERR_MSNUMBER_NOT_FOUND ="No Valid Input to Service-msnumber not found";
	public static final String ERR_DELIVERYID_NOT_FOUND ="No Valid Input to Service-deliveryId not found";
	public static final String ERR_AUTHORISED_ACCESS ="Not authorised to access the document";
	public static final String PATH_WCI_INVOICE_DOC ="/opt/shared/data/dsd";
	public static final String PATH_MATERIALS_SUB_DOC ="/dsd";
	public static final String UNDERSCORE = "_";
	public static final String SLASH = "/";
	public static final String SSO= "SSO";
	public static final String PORTAL_ID= "PORTAL_ID";
	public static final String HEADER_ID= "HEADER_ID";
	public static final String DOC_TYPE= "DOC_TYPE";
	public static final String MS_DOC_DESC_TYPE = "ms";
	public static final String FAA_DOC_DESC_TYPE = "faa";
	public static final String MS_DOC_CD = "M";
	public static final String FAA_DOC_CD = "F";
	public static final String WCC_DOCTYPE_MS = "Memo-Of-Shipment";
	public static final String WCC_DOCTYPE_FAA = "8130";
	public static final String SCRAP_DOC_DESC = "scrap";
	public static final String SCRAP_DOC_PATH ="/Scrap";
	public static final String RETURN_DOC_DESC = "return";
	public static final String SHIPMENT_DOC_PATH ="/Shipment/";
	public static final String SCRAP_DOC_NAME="ScrapInstructions";
	public static final String SCRAP_DOC_DISPLAY_NAME="Scrap Instructions";
	public static final String RETURN_INS_DOC_NAME = "Return_ShipmentInstructions";
	public static final String RETURN_INS_DOC_DISPLAY_NAME = "Return Shipment Instructions";
	public static final String RETURN_LABEL_DOC_NAME = "Return_Label";
	public static final String RETURN_LABEL_DOC_DISPLAY_NAME = "Return Labels";
	public static final String PROFORMA_DOC_NAME = "ProformaInvoice";
	public static final String PROFORMA_DOC_DISPLAY_NAME = "PRO-FORMA INVOICE";
	public static final String BUYBACK_INS_DOC_NAME = "Buyback_ShipmentInstructions";
	public static final String BUYBACK_INS_DOC_DISPLAY_NAME = "Buy-Back Return Instructions";
	public static final String ATA_DOC_NAME = "ATA106";
	public static final String ATA_DOC_DISPLAY_NAME = "ATA106";
	public static final String ERR_INVOICEID_NOT_FOUND ="Invoice Id not found";
	public static final String INVOICE_DOC_DESC = "Invoice";
	public static final String INVOICE_ID = "&invoiceId=";
	public static final String ERR_EMAIL_REQUEST = "Document request placed, you will get the document in 2 hours, please contact ##AOC## for any questions";
	public static final String ERR_USER_MAILING_DETAILS ="User mailing details not found";
	public static final String ERR_MSFAA_DETALIS_NOT_FOUND="Problem in getting the MS/FAA documents Details";
	public static final String UI_DISPUTE_TYPE_SN = "Serial Number";
	public static final String UI_DISPUTE_TYPE_DD = "Discrepancy";
	public static final String UI_DISPUTE_TYPE_UD = "Under Shipment";
	public static final String UI_DISPUTE_TYPE_OD = "Over Shipment";
	public static final String UI_DISPUTE_TYPE_BB = "BuyBack Request";
	public static final String UI_DISPUTE_TYPE_PE = "Pricing Error";
	
	public static final String ERP_DISPUTE_TYPE_SN = "Serial Number Dispute";
	public static final String ERP_DISPUTE_TYPE_DD = "Discrepancy Dispute";
	public static final String ERP_DISPUTE_TYPE_UD = "Under Shipment";
	public static final String ERP_DISPUTE_TYPE_OD = "Overage Dispute";
	public static final String ERP_DISPUTE_TYPE_BB = "Buyback";
	public static final String ERP_DISPUTE_TYPE_PE = "Pricing Error";
	
	public static final String EMAIL_DISPUTE_TYPE_SN_ON_PAPER="Serial Number on paperwork";
	public static final String EMAIL_DISPUTE_TYPE_SN_ON_PART="Serial Number on part";
	public static final String EMAIL_DISPUTE_TYPE_DD="Part Received";
	public static final String EMAIL_DISPUTE_TYPE_UD="Shortage Quantity";
	public static final String EMAIL_DISPUTE_TYPE_OD="Overage Quantity";
	public static final String EMAIL_DISPUTE_TYPE_BB="BuyBack";
	public static final String EMAIL_DISPUTE_TYPE_PE="Expected Unit Price";
	
	public static final String DISPUTE_MAIL_MESSAGE_MYGEA = "Thank you for using myGEAviation.com for your order.";
	public static final String DISPUTE_MAIL_MESSAGE_MYHONDA = "Thank you for using myGEHonda.com for your order.";
	public static final String DISPUTE_MAIL_MESSAGE_MYCFM = "Thank you for using myCFM.com for your order.";
	
	
	public static final String DISPUTE_MAIL_MESSAGE ="We are sorry for any inconvenience this error may have caused.<br/><br/>Please review the details for the disputed claim below";
	//public static final String DISPUTE_MAIL_MESSAGE ="Thank you for using myGEAviation.com for your order. We are sorry for any inconvenience this error may have caused.<br/><br/>Please review the details for the disputed claim below";
	public static final String DISPUTE = "Dispute";
	public static final String EMAIL_SUBJECT ="Shipment Dispute Order Acknowledgement";
	public static final String RMA_NUMBER ="RMA # ";
	public static final String EMAIL_SUBJECT_DISPUTE_TYPE_SN = "Serial Number Dispute Acknowledgement";
	public static final String EMAIL_SUBJECT_DISPUTE_TYPE_DD = "Discrepancy Dispute Acknowledgement";
	public static final String EMAIL_SUBJECT_DISPUTE_TYPE_UD = "Shipment Dispute Acknowledgement";
	public static final String EMAIL_SUBJECT_DISPUTE_TYPE_OD = "Shipment Dispute Acknowledgement";
	public static final String EMAIL_SUBJECT_DISPUTE_TYPE_BB = "Buy-Back Request Acknowledgement";
	public static final String EMAIL_SUBJECT_DISPUTE_TYPE_PE = "Invoice Dispute Acknowledgement";
	public static final String EMAIL_BODY_MESSAGE_FOR_ATTACHMENT = "Please review attached instructions.";
	public static final String RETURN_LBL_LOGO_DEFAULT = "CWC_ReturnLogo.jpg";
	public static final String RETURN_LBL_LOGO_SUFFIX = "_ReturnLogo.jpg";
	public static final String UTF_8 = "UTF-8";
	public static final String COMP_REPAIR_DOC_NAME_0="/Comp_Repair_";
	public static final String COMP_REPAIR_DOC_NAME_1="_Catalog";
	public static final String COMP_REPAIR_URL ="/RepairCatalog/";
	public static final String COMP_REPAIR_DIR ="/RepairCatalog";
	public static final String REPAIR_DOCS_URL = "services/materials/getRepairCatalogBS?fileName=";
	public static final String CSV_FILE_PATH = "/OrderDetails/";
	public static final String ERR_EMAIL_REQ_MSG = "Your previous request for same document is in process please check your email after 2 Hrs, please contact ##AOC## for any questions";
	public static final String GE_LOGO = "GE_Logo.png";
	public static final String PO_CONFIRM_LOGO = "_logo.png";
	public static final String CWC_PID = "CWC";
	public static final String GEHONDA_PID = "GEHONDA";
	public static final String MMGE = "MMGE";
	public static final String MMCF = "MMCF";
	public static final String CUSTNUM = "CustNum";
	
	//Item Discount Constants
	public static final String ROLE_GE = "Global Enquiry";
	public static final String ROLE_BUYER = "Buyer";
	public static final String ROLE_CE = "Cust Enquiry";
	public static final String MSG_CRITCL_GE_BUYER = "Inventory,On Allocation";
	public static final String MSG_CRITCL_CE = "On Allocation";
	public static final String PRICE_MSG_02	= "Price_Msg_02";
	public static final String ERR_CODE_8202="8202";
	public static final String ERR_CODE_8203 = "8203";
	public static final String ERR_CODE_8204 = "8204";
	public static final String VENDOR_MESSG=".Please visit https://cage.dla.mil/search//begin_search.aspx for the additional vendor information,Please contact your CAM for more details";
	public static final String AERODP = "AERODP";
	public static final String ICAO_CODE = "icao_code";
	public static final String PURCHASE_ORDER = "PURCHASE_ORDER";
	public static final String PURCHASE_ORDER_MAIL_MESSAGE = "Purchase Order Details:";
	public static final String PURCHASE_ORDER_TOTAL_DISCOUNT = "Total Discount:";
	public static final String PURCHASE_ORDER_TOTAL_ORDER_VALUE = "Total Order value:";
	public static final String PURCHASE_ORDER_THANKING = "Thank you for your order,";
	public static final String ASTERIC_SYMBOL = "**";
	public static final String ON_ALLOCATION_PART_MSG = "One or more parts are on allocation please contact your CAM for Scheduled ship date";
	public static final String PURCHASE_ORDER_PRICING_NOTE = "One or more parts are not priced currently, please contact your GE customer account manager for accurate order value";
	public static final String MAIL_EXCHANGE_SERVER = "@mail.ad.ge.com";
	
	public static final String ERR_CODE_8199 = "8199";
	public static final String AVAIL_MSG_03 = "Avail_Msg_03";
	public static final String SLASH_DOT = "\\.";
	public static final String AT = "at";
	
	public static final String WARNING_MSG_1 = "There is no data available for the selection.";
	public static final String WARNING_MSG_2 = "Please change the selection and try again.";
	public static final String ORDERS= "ORDER";
	public static final String RETURNS = "RETURN";
	public static final String NEW_ORDER = "NewOrders";
	public static final String NEW_RETURN= "NewReturns";
	public static final String MYCFM= "MYCFM";
	
	public static final String HTML_WARNING_MSG_1 = "<html><head></head><body><div style='background: orange;border-radius: 10px; padding: 4px 44px 18px 24px;background-color: #ed8000;border: 1px solid #ed8000;color: white;font-size: 17px;font-weight: normal;font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;line-height: 20px;text-shadow: none;margin-top: 36px;'><h3>Attention!</h3><span>";
	public static final String HTML_WARNING_MSG_2= " </span><a style='text-decoration: underline;'>";
	public static final String HTML_WARNING_MSG_3 = "</a></div></body></html>";
	
	public static final String ERROR_MSG_1 = "Oops some unexpected internal error, Please try again later or contact the Fleet Support Team at 1-877-432-3272 or 1-513-552-3272";
	public static final String ERROR_MSG_2 = "or via email aviation.fleetsupport@ge.com";
	
	public static final String HTML_ERROR_MSG_1 = "<html><head></head><body><div style='background: red;border-radius: 10px; padding: 4px 44px 18px 24px;background-color: #EE3324;border: 1px solid #EE3324;color: white;font-size: 17px;font-weight: normal;font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;line-height: 20px;text-shadow: none;margin-top: 36px;'><h3>Attention!</h3><span>";
	public static final String HTML_ERROR_MSG_2= " </span><a style='text-decoration: underline;'>";
	public static final String HTML_ERROR_MSG_3 = "</a></div></body></html>";
	
	//Constants added for GEAE LDAP settings
	public static final String LDAP_INITIAL_CONTEXT = "com.sun.jndi.ldap.LdapCtxFactory";
	public static final String LDAP_URL = "ldap://ldap.corporate.ge.com:2392";
	public static final String SECIRITY_PRINCIPLE = "CN=502441823,OU=All Businesses,DC=cdiad,DC=ge,DC=com";
	public static final String LDAP_SECURITY_AUTHENTICATION = "simple";
	public static final String DEPT_NOT_FOUND = "Department not found";
	public static final String DEPT_NOT_MATCH = "Department not Matched";
	public static final String LDAP_DEPTNAME = "department";
	public static final String LDAP_LEGAL_ENTITY = "gehrlegalentityname";
	public static final String LDAP_BU = "geBusinessUnit";
	public static final String LDAP_ALL_BASE = "OU=All Businesses,DC=CDIAD,DC=GE,DC=com";
	
	public static final String DEFAULT_ESN = "999999";	
	public static final String APPWX_SCHED = "APPWX_SCHED";	
	public static final String THROUGH_AMPS = "Through AMPS";
	public static final String VENDOR_062W0 = "062W0";
	public static final String VENDOR_99205 = "99205";
	public static final String GE_VENDOR_MSG = "This component is a widely available industry standard part.Please contact an approved industrial supply outlet  to support your requirement.";
	public static final String NON_GE_VENDOR_MSG1 = "This component is provided according to contractual arrangements by the OEM/supplier.The applicable supplier code is ";
	public static final String NON_GE_VENDOR_MSG2 =". Please visit https://cage.dla.mil/search//begin_search.aspx for the additional supplier information.If need be please contact your CAM for more details";
	public static final String CT7 = "CT7";
	public static final String CT7GA = "CT7GA";
	public static final String CF34 = "CF34";
	public static final String CF348S = "CF34-8S";
	public static final String CF34GA = "CF34GA";
	public static final String FLOW_STATUS_OPEN = "Open";
	
	//Checkmarx Fix
	public static final String PORTAL_CFM = "myCFM";
	public static final String PORTAL_GEHONDA = "GEHonda";
	public static final String PORTAL_AERODP = "AERODP";
	public static final String PORTAL_CWC = "CWC";
	// CSV Export - portal id 
	public static final String MYGEA_PORTAL = "myGEA"; 
	public static final String MYCFM_PORTAL = "myCFM";
	public static final String MYGEHONDA_PORTAL = "myGEHONDA";
	
	public static final String  DESC_ATTIVIO_ACCESS = "Attivio Access not found for Materials";
	public static final String HONDA_PRICECATALOGS_PATH ="/HondaPriceCatalogs/";
	
	public static final String EXCEL_CONTENT_TYPE = "application/vnd.ms-excel";
	public static final String CSV_CONTENT_TYPE = "text/csv;charset=utf-8";
	public static final String CONTENT_DISPOSITION = "Content-Disposition";
	public static final String EXPORT_FILE = "attachment; filename=";
	
	public static final String INDEX_1 = "1";
	public static final String INDEX_2 = "2";
	public static final String INDEX_3 = "3";
	public static final String INDEX_4 = "4";
	public static final String INDEX_5 = "5";
	public static final String INDEX_6 = "6";
	public static final String INDEX_7 = "7";
	public static final String INDEX_8 = "8";
	public static final String INDEX_9 = "9";
	public static final String INDEX_10 = "10";
	public static final String INDEX_11 = "11";
	public static final String INDEX_12 = "12";
	public static final String INDEX_13 = "13";
	public static final String INDEX_14 = "14";
	public static final String INDEX_15 = "15";
	public static final String INDEX_16 = "16";
	public static final String INDEX_17 = "17";
	public static final String INDEX_18 = "18";
	public static final String INDEX_19 = "19";
	public static final String INDEX_20 = "20";
	public static final String INDEX_21 = "21";
	public static final String INDEX_22 = "22";
	public static final String INDEX_23 = "23";
	public static final String INDEX_24 = "24";
	public static final String INDEX_25 = "25";
	public static final String INDEX_26 = "26";
	public static final String INDEX_27 = "27";
	public static final String INDEX_28 = "28";
	public static final String INDEX_29 = "29";
	public static final String INDEX_30 = "30";
	public static final String INDEX_31 = "31";
	public static final String INDEX_32 = "32";
	public static final String INDEX_33 = "33";
	public static final String INDEX_34 = "34";
	public static final String INDEX_35 = "35";
	public static final String INDEX_36 = "36";
	public static final String INDEX_37 = "37";
	public static final String INDEX_38 = "38";
	public static final String INDEX_39 = "39";
	public static final String INDEX_40 = "40";
	public static final String INDEX_41 = "41";
	public static final String INDEX_42 = "42";
	public static final String INDEX_43 = "43";
	public static final String INDEX_44 = "44";
	public static final String INDEX_45 = "45";
	public static final String INDEX_46 = "46";
	public static final String INDEX_47 = "47";
	public static final String INDEX_48 = "48";
	public static final String INDEX_49 = "49";
	public static final String INDEX_50 = "50";
	public static final String INDEX_51 = "51";
	public static final String INDEX_52 = "52";
	public static final String INDEX_53 = "53";
	public static final String INDEX_54 = "54";
	public static final String INDEX_55 = "55";
	
	public static final String EXPORT_COLUMN = "customerNumber,purchaseOrder,customerLineNumber,partNumber,orderStatus,requestedQty,cancelledQty,shippedQty,invoicedQuantity,orderedDate,requestDate,deliveryDate,shipmentDate,sellingPrice,listPrice,extendedPrice,msNumber,engineFamily,engineModel,awbNumber";
	public static final String BLANK_STRING = "";
	public static final String ORDER_TEMPLATE_PATH = "/Bulk_Template/";
	public static final String LOGO_PATH = "/Logos/";

}
