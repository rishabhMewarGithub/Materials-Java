/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 12, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     MaterialsAppImpl.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.app.impl.util;

import java.util.Comparator;

import com.geaviation.materials.entity.RepairCatalogBO;

public class RepairEffectvieDateAscComparator implements Comparator<RepairCatalogBO> {
	 public int compare(RepairCatalogBO orderLineDO1, RepairCatalogBO orderLineDO2) {
		 boolean isPartDesc0Empty = (orderLineDO1.getEffectiveDate() == null || orderLineDO1.getEffectiveDate().isEmpty());
		   boolean isPartDesc1Empty = (orderLineDO2.getEffectiveDate() == null || orderLineDO2.getEffectiveDate().isEmpty());

		   if (isPartDesc0Empty && isPartDesc1Empty)
		       return 0;
		   // at least one of them is not empty    
		   if (isPartDesc0Empty)
		       return -1;
		   if (isPartDesc1Empty)
		       return 1;
		   //none of them is empty
		  return orderLineDO1.getEffectiveDate().compareTo(orderLineDO2.getEffectiveDate());
	    }

}
