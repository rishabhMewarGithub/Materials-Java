/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 13, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     MaterialsAppConstants.java
 * 
 * History        :  	Mar 13, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.app.impl.util;

/**
 * @author 720053
 *
 */
public class Constants {
	
	public static final String HTML_MSG1 = " <html> <head> <meta charset='UTF-8'> <meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'> <meta name='viewport' content='width=device-width'> <title>myGEAviation Customer Portal | Simple. Effective. Yours.</title> <link id='theme' href='../../portal/static/ge_ux/css/iids.min.css' rel='stylesheet'> <link href='../../custom-login/cwcbb-custom-login.css' rel='stylesheet'> <script type='text/javascript' src='../../portal/static/ge.com.2013/components/jquery/jquery.min.js'></script> <script language=javascript> function window_onload() { var numRand = Math.floor(Math.random()*6)+1; $('#login-header').css('background', 'url(\"../../custom-login/img/login-bg-'+numRand+'-cropped.jpg\") no-repeat');} </script> </head> <body onload='javascript:window_onload();'> <div class='container maincontent'> <div id='login-header'> <div class='navbar'> <div class='masthead navbar-inner'> <div class='container'> <a class='brand' href='#'> <span class='ge-logo ge-logo-large'>General Electric</span> <div class='pull-left'><h2><span class='text-info'>my</span>GEAviation</h2> Simple. Effective. Yours.</div></a></div></div></div></div><div id='content' class='container'><div class='page-header'><h1 class='voice voice-brand' id='error_title'>Uh oh!</h1> <p id='error_message'>";
	public static final String CUSTOM_MSG = "Document format not supported.";
    public static final String HTML_MSG2 = "</p></div> <table id='help'> <thead><h2 class='voice-brand'>Contact Information</h2></thead> <tbody class='voice-brand'><tr><td> <h3>Aviation Operations Center - Cincinnati</h3><h3>Toll-free: +1 (877) 432-3272</h3> <h3>Phone: +1 (513) 552-3272</h3><h3>Email: <a href='mailto:geae.aoc@ge.com'>geae.aoc@ge.com</a></h3></td><td><h3>Aviation Operations Center - Shanghai</h3><h3>Phone: +86-400-820-6208</h3><h3>Fax: +86-21-38777666</h3><h3>Email: <a href='mailto:geae.choc@ge.com'>geae.choc@ge.com</a></h3></td><td><h3>Bizjet Operations Center</h3><h3>Toll-free: +1 (877) 456-JETS (5387)</h3><h3>Phone: +1 (513) 552-JETS (5387)</h3><h3>Email: <a href='mailto:bizjetops@ge.com'>bizjetops@ge.com</a></h3></td> </tr> </tbody></table></div><div class='navbar'><div class='masthead navbar-inner'><div class='container'><div class='brand logo'><span class='ge-logo'>General Electric</span> GE Aviation</div><div class='footer-links'><a data-toggle='modal' href='#cookies-modal'>Read about how we use cookies</a></div>    </div>    <div class='container'><h6>THIS SITE CONTAINS GE PROPRIETARY INFORMATION</h6>    <p>WARNING: The information contained in this site is GE proprietary information and is disclosed in confidence. It is the property of GE and shall not be used, disclosed to others or reproduced without the express written consent of GE, including, but without limitation, it is not to be used in the creation, manufacture, development, or derivation of any repairs, modifications, spare parts, designs, or configuration changes or to obtain FAA or any other government or regulatory approval to do so. If consent is given for reproduction in whole or in part, this notice and the notice set forth on each page of this site shall appear in any such reproduction in whole or in part. The information contained in this site may also be controlled by the U.S. export control laws. Unauthorized export or re-export is prohibited.</p>    </div></div></div></div> <!-- /outer container -->    <div id='cookies-modal' class='modal hide fade' style='display: none;'><div class='modal-header'><button type='button' class='close' data-dismiss='modal'>&times;</button><h3>Cookie Information</h3></div><div class='modal-body'><p>The Privacy and Electronic Communications (EC Directive) Regulations 2003 (the Regulations) cover theuse of cookies and similar technologies for storing information, and accessing information stored, on auser’s equipment such as their computer or mobile.</p><p>A cookie is a small file, typically of letters and numbers, downloaded on to a device when the useraccesses certain websites. Cookies are then sent back to originating website on each subsequent visit.Cookies are useful because they allow a website to recognize a user’s device. The Regulations apply tocookies and also to similar technologies for storing information. For more information see:<a href='http://www.allaboutcookies.org'>http://www.allaboutcookies.org</a></p><p>Web “Cookies” are also used within myGEAviation. Session cookies are used to establish the ability to accessmyGEAviation after logging into the website and are used to identify and maintain the user session within myGEAviation. Athird cookie is used to ensure a secure third-party can collect the user data as indicated above.</p></div><div class='modal-footer'><a href='#' class='btn btn-primary' data-dismiss='modal'>Close</a></div>        </div>      </body></html>";
    public static final String FINAL_MSG = HTML_MSG1+CUSTOM_MSG+HTML_MSG2;
    public static final String EMPTY_STRING = "";
    public static final String PDF_EXTENSION = ".pdf";
    public static final String XLS_EXTENSION = ".xls";
    public static final String XLSX_EXTENSION = ".xlsx";
    public static final String DOCX_EXTENSION = ".docx";
    public static final String DOC_EXTENSION = ".doc";
    public static final String ZIP_EXTENSION = ".zip";
    public static final String HTML_BREAK = "<br/>";
    public static final String HTML_STYLE = "<td width='33%' style='";
    public static final String HTML_STYLE1 = "<td style='";
    public static final String HTML_SUP = "'>**</sup>";
    public static final String SUP_STYLE = "<sup style='";
    public static final String HTML_STYLE2 = "<td width='12%' style='";
    public static final String HTML_STYLE3 = "<td width='10%' style='";	
    public static final String HTML_ROW = "<tr>";
    public static final String HTML_COLUMN = "</td>";    
}
