package com.geaviation.materials.app.impl;

import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EMPTY_STRING;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_PORTAL_ID_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_SSO_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.MSG_CRITCL_CE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.MSG_CRITCL_GE_BUYER;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.PIPE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ROLE_BUYER;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ROLE_CE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ROLE_GE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.Y;
import static com.geaviation.materials.app.impl.util.MaterialsAppUtil.isNotNullandEmpty;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.app.api.IMaterialsApp;
import com.geaviation.materials.app.api.IMaterialsLoginApp;
import com.geaviation.materials.app.api.IMaterialsWishListApp;
import com.geaviation.materials.app.impl.util.MaterialsAppUtil;
import com.geaviation.materials.data.api.IMaterialsWishListDAO;
import com.geaviation.materials.entity.BulkAddPartBO;
import com.geaviation.materials.entity.CustLoginDetails;
import com.geaviation.materials.entity.DeleteWishListBO;
import com.geaviation.materials.entity.InsertWishListResponse;
import com.geaviation.materials.entity.MaterialsLoginResponse;
import com.geaviation.materials.entity.MaterialsUserBO;
import com.geaviation.materials.entity.OrderStatusBO;
import com.geaviation.materials.entity.OrderTemplateStatusBO;
import com.geaviation.materials.entity.WishListDetailsBO;
import com.geaviation.materials.exception.MaterialsErrorCodes;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;

@Component
public class MaterialsWishListAppImpl implements IMaterialsWishListApp {

	@Autowired
	private MaterialsExceptionUtil materialsExceptionUtil;
	
	@Autowired
	private MaterialsAppUtil materialsAppUtil;
	@Autowired
	private IMaterialsLoginApp materialsLoginApp;
	
	@Autowired
	private IMaterialsWishListDAO materialsWishListDAO;
	@Autowired
	private IMaterialsApp materialsApp;
	
	private static final Log log = LogFactory.getLog(MaterialsWishListAppImpl.class);
	@Override
	public InsertWishListResponse insertWishListBS(
			String strSSO, String portalId,String partNumber) throws MaterialsException {
		log.info("Entered into saveCartBS() method");
		if(!isNotNullandEmpty(strSSO)){
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8301, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND);
		}
		if(!isNotNullandEmpty(portalId)){
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8302, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8302),ERR_PORTAL_ID_NOT_FOUND);
		}
		
		InsertWishListResponse response = null;
		MaterialsUserBO materialsUserBO = null;
		MaterialsLoginResponse materialsLoginDetail = null;
		String icaoCode = "";
		String operatingUnitId = "";
		try {
			materialsLoginDetail = materialsLoginApp.requestMaterialsLogin(strSSO, portalId);
		} catch (TechnicalException e) {
			log.error(e.getMessage());
			materialsAppUtil.throwAsBusinessException(e);
		}
		
		materialsUserBO = materialsLoginDetail.getMaterialsUserBO();
		if (isNotNullandEmpty(materialsUserBO.getIcaoCode()))
			icaoCode = materialsUserBO.getIcaoCode();
		if (isNotNullandEmpty(materialsUserBO.getOperatingUnitId())){
			operatingUnitId = materialsUserBO.getOperatingUnitId();
		}
		try{
			log.info("icaoCode--"+icaoCode+"operatingUnitId----"+operatingUnitId+"partNumber--"+partNumber);
			response = materialsWishListDAO.insertWishListDS(strSSO, icaoCode, operatingUnitId, partNumber);
		} catch (TechnicalException e) {
			log.error(e.getMessage());
			materialsAppUtil.throwAsBusinessException(e);
		} 
		
		return response;
	}
	
	public List<WishListDetailsBO> getWishListDetailsBS(String strSSO,String portalId)
 throws MaterialsException
 {
	if(!isNotNullandEmpty(strSSO)){
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8301, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND);
		}
		if(!isNotNullandEmpty(portalId)){
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8302, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8302),ERR_PORTAL_ID_NOT_FOUND);
		}
		List<WishListDetailsBO> wishListDetailsBOList = new ArrayList<WishListDetailsBO>();
		List<WishListDetailsBO> bulkPartResultLst = new ArrayList<WishListDetailsBO>();
		CustLoginDetails custLoginDetails = null;
		
		try {
			custLoginDetails =  materialsAppUtil.getCustLoginDetails(strSSO,portalId);
		} catch (TechnicalException e) {
			log.error(e.getMessage());
			materialsAppUtil.throwAsBusinessException(e);
		}
		
		try{
			wishListDetailsBOList = materialsWishListDAO.getWishListDetailsDS(strSSO, custLoginDetails.getIcaoCode(), custLoginDetails.getOperatingUnitId(),custLoginDetails.getCustIdList(),custLoginDetails.getRole());
		} catch (TechnicalException e) {
			log.error(e.getMessage());
			materialsAppUtil.throwAsBusinessException(e);
		} 
		
		
		for (WishListDetailsBO bulkPartDetailsBO : wishListDetailsBOList) {		
			
			 if(MaterialsAppUtil.isNotNullandEmpty(bulkPartDetailsBO.getMessage())) {
				 String displayMsg = materialsApp.getErrorCode(bulkPartDetailsBO.getMessage(), strSSO, portalId,bulkPartDetailsBO.getPartNumber());
				 bulkPartDetailsBO.setMessage(displayMsg);
			 }
		
					if(MaterialsAppUtil.isNotNullandEmpty(bulkPartDetailsBO.getPartAvailMsg())) {
							String availMessage = materialsApp.getDisplayMessage(bulkPartDetailsBO.getPartAvailMsg(), strSSO, portalId);
							bulkPartDetailsBO.setPartAvailMsg(availMessage);
			        }
			     	if(MaterialsAppUtil.isNotNullandEmpty(bulkPartDetailsBO.getDisplayMessage())) {
							String displayMsg = materialsApp.getErrorCode(bulkPartDetailsBO.getDisplayMessage(), strSSO, portalId,bulkPartDetailsBO.getPartNumber());
							bulkPartDetailsBO.setDisplayMessage(displayMsg);
			     	}
			     	if(MaterialsAppUtil.isNotNullandEmpty(bulkPartDetailsBO.getPricMessage()))
					{
						String pricingMessage = materialsApp.getDisplayMessage(bulkPartDetailsBO.getPricMessage(), strSSO, portalId);
						bulkPartDetailsBO.setPricMessage(pricingMessage);
					}
			    	if(MaterialsAppUtil.isNotNullandEmpty(bulkPartDetailsBO.getCriticalPartMessage()) && bulkPartDetailsBO.getCriticalPartMessage().equals(Y)) {
						if(custLoginDetails.getRole().equals(ROLE_GE)) {
						
							bulkPartDetailsBO.setCriticalPartMessage(MSG_CRITCL_GE_BUYER);
						} else if(custLoginDetails.getRole().equals(ROLE_BUYER)) {
							bulkPartDetailsBO.setCriticalPartMessage(MSG_CRITCL_GE_BUYER);
						} else if(custLoginDetails.getRole().equals(ROLE_CE)) {
							bulkPartDetailsBO.setCriticalPartMessage(MSG_CRITCL_CE);
						} else {
							
							bulkPartDetailsBO.setCriticalPartMessage(EMPTY_STRING);
					    }
					}					
			    	if(MaterialsAppUtil.isNotNullandEmpty(bulkPartDetailsBO.getDiscountMessage())) {
			    		String discountMsg = materialsApp.getErrorCode(bulkPartDetailsBO.getDiscountMessage(), strSSO, portalId,bulkPartDetailsBO.getPartNumber());
			    		bulkPartDetailsBO.setDiscountMessage(discountMsg);
					} else {
						bulkPartDetailsBO.setDiscountMessage(EMPTY_STRING);
						
					}
			    	
			    	bulkPartResultLst.add(bulkPartDetailsBO);
			 
		 }
	
		return bulkPartResultLst; 
 }

	@Override
	public  List<DeleteWishListBO> deleteWishListBS(String strSSO, String portalId,
			String partNumber) throws MaterialsException {
		List<DeleteWishListBO> deleteWishListBO = null;
		String[] partNumArr = partNumber.split("\\|");	
		if(!isNotNullandEmpty(strSSO)){
		
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8301, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND);
		}
		if(!isNotNullandEmpty(portalId)){
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8302, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8302),ERR_PORTAL_ID_NOT_FOUND);
		}
		CustLoginDetails custLoginDetails = null;
		
		try {
			custLoginDetails =  materialsAppUtil.getCustLoginDetails(strSSO,portalId);
		} catch (TechnicalException e) {
			log.error(e.getMessage());
			materialsAppUtil.throwAsBusinessException(e);
		}
		
		try{
			deleteWishListBO  = materialsWishListDAO.deleteWishListDS(strSSO,portalId, partNumArr, custLoginDetails.getIcaoCode());
		} catch (TechnicalException e) {
			log.error(e.getMessage());
			materialsAppUtil.throwAsBusinessException(e);
		} 
		return deleteWishListBO; 
 }
	
	@Override
	public OrderStatusBO wishLstToSaveLstBS(String strSSO, String portalId,
			List<BulkAddPartBO> partnumberLst) throws MaterialsException {
		OrderStatusBO orderStatusBO = null;
		List<OrderTemplateStatusBO> orderList = null; 
		StringBuilder partList= new StringBuilder();
		orderStatusBO = materialsApp.addBulkPartDtls(strSSO,portalId,partnumberLst);
		orderList = orderStatusBO.getOrdrStatusBO();
		for (OrderTemplateStatusBO partsBO : orderList) {
			String partNumber =partsBO.getPartNumber();
			String success = partsBO.getSuccess();
			if(success.equalsIgnoreCase(Y))
			{
				if(isNotNullandEmpty(partNumber)){
					
					partList.append(partNumber);
					partList.append(PIPE);
				}
			}
		}
		return orderStatusBO ;
	}

}
