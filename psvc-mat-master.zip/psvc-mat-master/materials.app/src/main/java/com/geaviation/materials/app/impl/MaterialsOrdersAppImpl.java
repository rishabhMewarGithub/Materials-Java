package com.geaviation.materials.app.impl;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.app.api.IMaterialsLoginApp;
import com.geaviation.materials.app.api.IMaterialsOrdersApp;
import com.geaviation.materials.app.impl.util.MaterialsAppConstants;
import com.geaviation.materials.app.impl.util.MaterialsAppStaticConst;
import com.geaviation.materials.app.impl.util.MaterialsAppUtil;
import com.geaviation.materials.app.impl.util.MaterialsSearchUtil;
import com.geaviation.materials.data.api.IMaterialsDAO;
import com.geaviation.materials.data.api.IMaterialsOrdersDAO;
import com.geaviation.materials.data.impl.util.MaterialsDataUtil;
import com.geaviation.materials.entity.*;
import com.geaviation.materials.exception.MaterialsErrorCodes;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.itextpdf.text.*;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.mongodb.client.gridfs.model.GridFSFile;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import javax.activation.DataHandler;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.StreamingOutput;
import java.io.*;
import java.text.Format;
import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.geaviation.materials.app.impl.util.Constants.*;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.*;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EMPTY_STRING;
import static com.geaviation.materials.app.impl.util.MaterialsAppUtil.*;

@Component
public class MaterialsOrdersAppImpl implements IMaterialsOrdersApp {

	private static final Log log = LogFactory.getLog(MaterialsOrdersAppImpl.class);

	@Autowired
	private MaterialsAppUtil materialsAppUtil;

	@Autowired
	private MaterialsExceptionUtil materialsExceptionUtil;

	@Autowired
	MaterialsAppImpl materialsAppImpl;
	
	@Autowired
	private IMaterialsLoginApp materialsLoginApp;

	@Autowired
	private IMaterialsOrdersDAO materialsOrdersDAO;
	
	@Autowired
	private IMaterialsDAO materialsDAO;
	
	@Autowired
	private MaterialsDataUtil materialsDataUtil;

	@Value("${LINE_DETAILS_SERVICE_URL}")
	private String lineDetailsServiceUrl;

	@Value("${NOTIFICATION_SERVICE_URL}")
	private String notificationServiceUrl;

	@Value("${SHIPMENT_SERVICE_PROVIDER}")
	private String shipmentServiceProvider;

	@Value("${ORDER_TEMPLATE_MAPPING}")
	private String orderTemplateMapping;
	
	public static final String DATE_FORMAT1= "yyyy-MM-dd";
	public static final String NEWLINE = "\"\n\n";
	public static final String SLASH_PATTERN = "\",,\"";
	public static final String NEWLINE_SLASH_PATTERN = "\"\n,,,\"";
	
	private static final String HTML_COLUMN = "</td>";
	private static final String HTML_COLUMN_STYLE = "<td style='";
	private static final String HTML_COLUMN_WIDTH = "<td width='11%' style='";
	private static final String PMESSAGE = "pMessage";
	private static final String GETCUSTLOGINDETAILS = "getCustLoginDetails";
	private final String STYLE_NORMAL_FONT = " font-weight:normal; ";
	private final String STYLE_ITALIC_FONT = " font-style:italic; ";
	private final String STYLE_BOLD_FONT = " font-weight:bold; ";
	private final String STYLE_FONT_FAMILY = " font-family:Arial; ";
	private final String STYLE_TABLE_DATA_FONT_SIZE = " color: #252525; font-family: arial; font-size: 11px; font-weight: normal; ";
	private final String STYLE_BODY_FONT_SIZE_12 = " color: #252525; font-family: arial; font-size: 12px; font-weight: normal; ";
	private final String STYLE_FONT_COLOR_BLUE = " color:#0000ff; ";
	private final String STYLE_ALIGN_CENTER = " text-align:center; ";
	private final String STYLE_NO_WRAP = " white-space: nowrap; ";
	private final String DEVQA_EMAILS = "mygeav-materaials.devqaemails@ge.com";

	/**
	 * Delete Order Line details
	 * @param strSSO
	 * @param portalId
	 * @param headerId
	 * @param lineId
	 * @return DeleteOrderLineBO object
	 * @throws MaterialsException
	 */
	public DeleteOrderLineBO deleteOrderLineBS(String strSSO, String portalId, String headerId, String lineId)
			throws MaterialsException {
		if (!isNotNullandEmpty(headerId)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8334,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8334), ERR_HEADER_ID_NOT_FOUND);
		}
		if (!isNotNullandEmpty(lineId)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8335,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8335), ERR_LINE_ID_NOT_FOUND);
		}
		DeleteOrderLineBO deleteOrderLineBO = null;
		CustLoginDetails custLoginDetails = null;
		custLoginDetails = materialsAppUtil.getCustLoginDetails(strSSO, portalId);
		try {
			deleteOrderLineBO = materialsOrdersDAO.deleteOrderLineDS(strSSO, custLoginDetails.getIcaoCode(),
					custLoginDetails.getCustIdList(), custLoginDetails.getRole(), custLoginDetails.getOperatingUnitId(),
					headerId, lineId);
		} catch (TechnicalException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}
		if (isNotNullandEmpty(deleteOrderLineBO.getP_msg())) {
			materialsAppUtil.throwERPMessage(deleteOrderLineBO.getP_msg());
		}
		String urlStr = materialsAppUtil.getAttivioServicesURL() + CONST_UPDATE_ORDER + EQUALS_STRING + headerId;
		materialsAppUtil.invokeService(urlStr, "Delete Order Line");
		return deleteOrderLineBO;
	}

	
	/**
	 * Update Shipment details
	 * @param sso
	 * @param portalId
	 * @param updateType
	 * @param existingContent
	 * @param updatedContent
	 * @param customerId
	 * @return UpdateShipmentBO object
	 * @throws MaterialsException
	 */
	public UpdateShipmentBO updateShipmentDetailsBS(String sso, String portalId, String updateType,
			String existingContent, String updatedContent, String customerId) throws MaterialsException {
		CustLoginDetails custLoginDetails = null;
		UpdateShipmentBO updateShipmentBO = null;
		List<String> ccMailIdList = null;
		List<String> ccMailList = null;
		String[] custIdList = { customerId };
		String ccMails = EMPTY_STRING;
		if (isNullOrEmpty(updateType) || isNullOrEmpty(updatedContent) || isNullOrEmpty(customerId)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8343,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8343), ERR_INSUFFICIENT_INPUTS);
		}
		String envmt = materialsAppUtil.getDeployedEnvironment();
		custLoginDetails = materialsAppUtil.getCustLoginDetails(sso, portalId);
		EmailContentInputBO emailContentInputBO = new EmailContentInputBO();
		emailContentInputBO.setFrom(materialsAppUtil.getFromEmailForPortal(portalId));
		String custAdminEmaiId = materialsAppUtil.getCAMEmailId(sso, custLoginDetails.getIcaoCode(), custIdList,
				custLoginDetails.getRole(), custLoginDetails.getOperatingUnitId());
		if (isNotNullandEmpty(custAdminEmaiId)) {
			ccMailIdList = materialsAppUtil.getStringAsList(custAdminEmaiId, SEMI_COLON);
			ccMailList = materialsAppUtil.removeDuplicateStringFromList(ccMailIdList);
			ccMails = materialsAppUtil.getListAsString(ccMailList);
		}

		if ("PROD".equalsIgnoreCase(envmt)) {
			emailContentInputBO.setTo(ccMails);
			emailContentInputBO.setCc(materialsAppUtil.getEmailId(sso));
		} else {
			emailContentInputBO.setTo(DEVQA_EMAILS);
		}
		emailContentInputBO.setSubject(MaterialsAppStaticConst.getShipmentupdatesubjectmap().get(updateType));
		emailContentInputBO.setPortalId(portalId);
		emailContentInputBO.setBody(emailContent(existingContent, updatedContent, updateType));
		emailContentInputBO.setIdentityId(materialsAppUtil.getAppOwnerId());
		boolean success = materialsAppUtil.invokeNotificationService(emailContentInputBO, notificationServiceUrl,
				"updateShipmentdetails");
		if (success) {
			updateShipmentBO = new UpdateShipmentBO();
			updateShipmentBO.setSuccess(true);
		} else {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8344,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8344),
					ERR_EMAIL_NOTIFICATION_FAILED);
		}
		return updateShipmentBO;
	}

	/**
	 * Return Email content in HTML format
	 * @param existingContent
	 * @param updatedContent
	 * @param issueType
	 * @return String
	 */
	private String emailContent(String existingContent, String updatedContent, String issueType) {
		StringBuilder htmlBuilder = new StringBuilder();
		htmlBuilder.append("<h4>Hello Customer Account Manager" + COMMA + "</h4>");
		htmlBuilder.append(MaterialsAppStaticConst.getShipmentupdatemap().get(issueType) + "<br>");
		if (isNotNullandEmpty(existingContent)) {
			String[] addressArray = existingContent.split("\\|");
			htmlBuilder.append("<br><u><b> Existing Information</u></b><br>");
			for (int count = 0; count < addressArray.length; count++) {
				htmlBuilder.append("<br>" + addressArray[count]);
			}
		}
		htmlBuilder.append("<br><br><u><b> Updated Information</u></b><br> ");
		String[] addressArray = updatedContent.split("\\|");
		for (int count = 0; count < addressArray.length; count++) {
			htmlBuilder.append("<br>" + addressArray[count]);
		}
		return htmlBuilder.toString();
	}

	
	/**
	 * Upload Order Template
	 * @param smssoid
	 * @param portalid
	 * @param custCode
	 * @param orderTemplate
	 * @return OrderStatusBO object
	 * @throws MaterialsException
	 */
	@SuppressWarnings({ "resource" })
	public OrderStatusBO uploadOrderTemplateBS(String sso, String portalId, String custCode,
			List<Attachment> orderTemplate) throws MaterialsException {
		log.info("uploadOrderTemplateBS");

		OrderStatusBO orderStatusBO = new OrderStatusBO();

		String fileName;
		String[] extension = null;
		InputStream stream = null;
		PartsInputDO1 partsInputDO1 = null;
		List<PartsInputDO1> partsInputDO1List = null;
		Map<String, String> statusMsgmap = new HashMap<String, String>();
		List<OrderTemplateStatusBO> orderList = null;
		CustLoginDetails custLoginDetails = null;
		String orderLineESN;
		boolean esnValid;
		List<Boolean> esnValidFlagList = new ArrayList<>();
		List<String> priorityList = new ArrayList<>();
		try {
			for (org.apache.cxf.jaxrs.ext.multipart.Attachment attr : orderTemplate) {
				DataHandler handler = attr.getDataHandler();
				stream = handler.getInputStream();
				String[] contentDisposition = attr.getHeaders().getFirst("Content-Disposition").split(SEMI_COLON);
				for (String filename : contentDisposition) {
					if (filename.trim().startsWith("filename")) {
						String[] name = filename.split("=");
						fileName = name[1].substring(name[1].trim().lastIndexOf("\\") + 1, name[1].length())
								.replaceAll("\"", "").replaceAll(" ", "").replaceAll("|", "");
						extension = fileName.split("\\.");
					}

				}
			}

			if (("xls").equalsIgnoreCase(extension[1])) {
				HSSFWorkbook wb = new HSSFWorkbook(stream);
				HSSFSheet sheet = wb.getSheetAt(0);

				if (sheet.getRow(0) == null || isNullOrEmpty(sheet.getRow(0).getCell(0).toString())
						|| !sheet.getRow(0).getCell(0).toString().equals(orderTemplateMapping)) {
					throw new MaterialsException(MaterialsErrorCodes.ERROR_8337,
							materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8337),
							ERR_ORDER_TEMPLATE_NOT_LATEST_VERSION);
				}

				if (isSheetEmpty(sheet)) {
					throw new MaterialsException(MaterialsErrorCodes.ERROR_8336,
							materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8336),
							ERR_ORDER_TEMPLATE_EMPTY);
				}

				List<PartBO> partsList = getPartsListDetails(sheet, sso, portalId, custCode);

				try {

					custLoginDetails = materialsAppUtil.getCustLoginDetails(sso, portalId);
					partsInputDO1List = new ArrayList<PartsInputDO1>();
					for (PartBO partBO : partsList) {

						orderLineESN = partBO.getOrderLineESN();
						priorityList.add(partBO.getPriority());
						// To validate ESN

						if ((isNotNullandEmpty(orderLineESN)))
							esnValid = Boolean.parseBoolean(materialsAppUtil.validateEsn(orderLineESN));
						else
							esnValid = false;

						if (partBO.getPriority().equalsIgnoreCase(PRIORITY_NORMAL) && !(esnValid)
								&& (isNotNullandEmpty(orderLineESN))) {
							orderLineESN = EMPTY_STRING;
							esnValidFlagList.add(false);
						} else if (partBO.getPriority().equalsIgnoreCase(MaterialsAppConstants.WSP) && !(esnValid)) {
							esnValidFlagList.add(false);
						} else {
							esnValidFlagList.add(true);
						}

						partsInputDO1 = new PartsInputDO1(partBO.getPoNumber(), partBO.getLineNumber(),
								partBO.getPartNumber(), partBO.getQuantity(), partBO.getRequestedDate(),
								partBO.getPriority(), partBO.getCustomerCode(), partBO.getRowNumber(),
								partBO.getCustomerAccountId(), partBO.getInventoryItemId(), partBO.getSupplierCode(),
								partBO.getPriceListId(), partBO.getQuoteHeaderId(), partBO.getQuoteLineId(),
								partBO.getStatusMessage(), orderLineESN, partBO.getOrderLineWorkStopDate(),
								partBO.getOrderLineWorkStopQuantity());
						partsInputDO1List.add(partsInputDO1);
					}

					orderList = materialsOrdersDAO.uploadOrderTemplateDS(sso, custLoginDetails.getIcaoCode(),
							custLoginDetails.getCustIdList(), custLoginDetails.getRole(),
							custLoginDetails.getOperatingUnitId(), partsInputDO1List, orderStatusBO, statusMsgmap,
							orderList, esnValidFlagList, priorityList);

				} catch (TechnicalException e) {
					materialsAppUtil.throwAsBusinessException(e);
				}
				if (orderList != null) {
					if (isNotNullandEmpty(orderStatusBO.getDisplayMessage())) {
						materialsAppUtil.throwERPMessage(orderStatusBO.getDisplayMessage());
					} else {
						orderStatusBO = getOrderStatusBO(orderList, orderStatusBO, statusMsgmap, sso, portalId);
					}

				}

				ArrayList<PartBO> partBOList = templateMailList(partsList, orderList);
				if (isCollectionNotEmpty(partBOList)) {
					notifyUser(partBOList, sso, portalId);
				}
			} else {
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8337,
						materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8337),
						ERR_ORDER_TEMPLATE_NOT_LATEST_VERSION);
			}
		} catch (TechnicalException e) {
			log.info(e);
		} catch (IOException e) {
			log.info(e);
		}
		return orderStatusBO;
	}
	
	private OrderStatusBO getOrderStatusBO(List<OrderTemplateStatusBO> orderList, OrderStatusBO orderStatusBO,
			Map<String, String> statusMsgmap, String sso, String portalId) throws MaterialsException {


		for (OrderTemplateStatusBO orderTemplateStatusBO : orderList) {
			if (isNotNullandEmpty(statusMsgmap.get(
					orderTemplateStatusBO.getPoLineNumber() + orderTemplateStatusBO.getPartNumber()))) {
				orderTemplateStatusBO.setStatusMessage(materialsAppImpl.getErrorCode(
						statusMsgmap.get(orderTemplateStatusBO.getPoLineNumber()
								+ orderTemplateStatusBO.getPartNumber()),
						sso, portalId, orderTemplateStatusBO.getPartNumber()));

			}
		}
		orderStatusBO.setTotalLines(Integer.toString(orderList.size()));
		orderStatusBO.setOrdrStatusBO(orderList);
		return orderStatusBO;
	}

	private List<PartBO> getPartsListDetails(HSSFSheet sheet, String sso, String portalId, String custCode) throws MaterialsException {
		
		PartBO part = null;
		HSSFRow row = null;
		
		List<PartBO> partsList = new ArrayList<PartBO>();
		Set<String> partSet = new HashSet<String>();

		for (int r = 2; r < 1002; r++) {
			row = sheet.getRow(r);

			if (row != null) {
				String customerCode = "";
				String poNumber = "";
				String lineNumber = "";
				String partNumber = "";
				String quantity = "";
				String requestDate = "";
				String priority = "";
				String orderLineESN = "";
				String orderLineWorkStopDate = "";
				String orderLineWorkStopQuantity = "";
				HSSFCell cell = null;
				
				/*
				 * Common columns for both myGEA and myCFM order
				 * templates
				 */
				
				//PO Number
				cell = row.getCell(0, Row.CREATE_NULL_AS_BLANK);
				if (cell != null) {
					DataFormatter df = new DataFormatter();
					poNumber = df.formatCellValue(cell);
				}

				//Line Number
				cell = row.getCell(1, Row.CREATE_NULL_AS_BLANK);
				if (cell != null) {
					DataFormatter df = new DataFormatter();
					lineNumber = df.formatCellValue(cell);
				}

				//Part Number
				cell = row.getCell(2, Row.CREATE_NULL_AS_BLANK);
				if (cell != null) {
					partNumber = cell.toString();
				}

				//Quantity
				cell = row.getCell(3, Row.CREATE_NULL_AS_BLANK);
				if (cell != null && !EMPTY_STRING.equals(cell.toString())) {
					//get quantity value from bulk order template
					//float value by default coming from excel
					Float fQuantity = Float.parseFloat(cell.toString().trim());
					//we only need the integer portion of the number and we assign back to a string
					quantity = String.valueOf(fQuantity.intValue());
				}

				//Requested Date
				cell = row.getCell(4, Row.CREATE_NULL_AS_BLANK);
				if (cell != null) {
					requestDate = cell.toString();
				}

				//Priority
				cell = row.getCell(5, Row.CREATE_NULL_AS_BLANK);
				if (cell != null) {
					priority = cell.toString();
				}
				
				if (portalId != null) {
					customerCode = custCode;
				}

				//ESN
				cell = row.getCell(6, Row.CREATE_NULL_AS_BLANK);
				cell.setCellType(Cell.CELL_TYPE_STRING);
				if (cell != null && isNotNullandEmpty(cell.toString()))
					orderLineESN = cell.toString();
				
				//We only need the work stop date and quantity details if the priority selected is actually Work Stop. Otherwise, they should be blank
				if(priority.equalsIgnoreCase(PRIORITY_WORK_STOP)) {
					//work stop date
					cell = row.getCell(7, Row.CREATE_NULL_AS_BLANK);
					if (cell != null)
						orderLineWorkStopDate = cell.toString();
					
					//work stop quantity
					cell = row.getCell(8, Row.CREATE_NULL_AS_BLANK);
					if (cell != null && !EMPTY_STRING.equals(cell.toString())) {
						//get work stop quantity value from template
						//by default it is a float value 
						Float fWsQuantity = Float.parseFloat(cell.toString().trim());
						//we just need the integer portion of quantity and we assign that back as a string
						orderLineWorkStopQuantity = String.valueOf(fWsQuantity.intValue());
					}
				}

				if (validateBulkOrderTemplateInputs(poNumber, lineNumber, partNumber, quantity, requestDate, priority, orderLineWorkStopDate, orderLineWorkStopQuantity, orderLineESN, r)
						&& (null != materialsAppUtil.validateDate(requestDate))) {
					part = new PartBO();
					part.setPoNumber(poNumber.trim());
					part.setLineNumber(lineNumber.trim());
					part.setPartNumber(partNumber.trim());
					part.setQuantity(Integer.parseInt(quantity));
					part.setRequestedDate(materialsAppUtil.getSQLDateFormat(requestDate));
				
					// normalpriority for AERODP changes(newly added)
					String constPriority = materialsAppUtil.getPriorityCode(portalId, priority);
					if (!isNotNullandEmpty(constPriority) && ((AERODP).equalsIgnoreCase(portalId))) {
						throw new MaterialsException(MaterialsErrorCodes.ERROR_8401,
								materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8401),
								ERR_PRIORITY);
					}
					part.setPriority(constPriority.trim());
					part.setCustomerCode(customerCode.trim());
					part.setOrderLineESN(orderLineESN);

					//for new bulk order template fields
					part.setOrderLineWorkStopDate(materialsAppUtil.getSQLDateFormat(orderLineWorkStopDate));
					if(!EMPTY_STRING.equals(orderLineWorkStopQuantity))
						part.setOrderLineWorkStopQuantity(Integer.parseInt(orderLineWorkStopQuantity));
					
					if (isNotNullandEmpty(poNumber) && isNotNullandEmpty(lineNumber)) {

						if (!partSet.add(poNumber + lineNumber)) {
							throw new MaterialsException(MaterialsErrorCodes.ERROR_8333,
									materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8333)
											+ COLON + poNumber + COMMA + LINE_NUM + COLON + lineNumber
											+ " in Row Number "
											+ r/*
											 * +COMMA+PART_NUM+
											 * COLON+ partNumber
											 */,
									ERR_ORDER_TEMPLATE_CONTAIN_DUPLICATES + poNumber + COMMA + LINE_NUM + COLON
											+ lineNumber + " in Row Number " + r);
						}
					}
					partsList.add(part);
				}
			}
		}
		return partsList;
	}


	/**
	 * Check if Excel Sheet is empty
	 * @param sheet
	 * @return true/false
	 */
	private boolean isSheetEmpty(HSSFSheet sheet) {
		HSSFRow row = null;
		String rowStr = null;
		for (int r = 2; r <= 1100; r++) {
			row = (HSSFRow) sheet.getRow(r);
			for (int c = 0; c <= 7; c++) {
				rowStr += row.getCell(c, Row.CREATE_NULL_AS_BLANK).toString();

			}
			if (isNotNullandEmpty(rowStr) || rowStr.equals("null")) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Validate Inputs for CFM
	 * @param poNumber
	 * @param lineNumber
	 * @param partNumber
	 * @param quantity
	 * @param requestDate
	 * @param priority
	 * @param rownum
	 * @return true/false
	 * @throws MaterialsException
	 */
	private boolean validateBulkOrderTemplateInputs(String poNumber, String lineNumber, String partNumber, String quantity,
			String requestDate, String priority, String workStopDate, String workStopQty, String orderLineESN,
			int rownum) throws MaterialsException {
		boolean flag = true;
		StringBuilder blanks = new StringBuilder();

		int nBlanks = 0;
		if (isNullOrEmpty(poNumber)) {
			nBlanks++;
			blanks.append(PO_NUM_BLANK);
		}
		if (isNullOrEmpty(lineNumber)) {
			nBlanks++;
			blanks.append(LINE_NUM_BLANK);
		}
		if (isNullOrEmpty(partNumber)) {
			nBlanks++;
			blanks.append(PART_NUM_BLANK);
		}
		if (isNullOrEmpty(quantity)) {
			nBlanks++;
			blanks.append(QUANTITY_BLANK);
		}
		if (isNullOrEmpty(requestDate)) {
			nBlanks++;
			blanks.append(REQUESTED_DATE_BLANK);
		}

		if (isNullOrEmpty(priority)) {
			nBlanks++;
			blanks.append(PRIORITY_BLANK);
		} else if (priority.equalsIgnoreCase(PRIORITY_WORK_STOP)
				&& (isNullOrEmpty(workStopDate) || isNullOrEmpty(workStopQty))) {
			// added this condition for the 2 new fields in bulk order template
			// US161328
			// requirement is that if Priority selected is Work Stop, these 2
			// fields must be provided
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8338, MaterialsAppConstants.BULK_UPLOAD_ERROR,
					MaterialsAppConstants.BULK_UPLOAD_ERROR);
		} else if (priority.equalsIgnoreCase(PRIORITY_WORK_STOP)
				&& (!materialsAppUtil.isValidWorkStopDate(workStopDate, requestDate)
						|| !materialsAppUtil.isValidWorkStopQty(workStopQty, quantity))) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8338, MaterialsAppConstants.BULK_UPLOAD_ERROR,
					MaterialsAppConstants.BULK_UPLOAD_ERROR);
		}

		if (!isNullOrEmpty(priority) && priority.equalsIgnoreCase(PRIORITY_WORK_STOP)
				&& (isNullOrEmpty(orderLineESN))) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8338, MaterialsAppConstants.BULK_UPLOAD_ERROR,
					MaterialsAppConstants.BULK_UPLOAD_ERROR);
		}

		// while the max possible value for nBlanks could be 6 (meaning, the row
		// is blank), we are not going to throw an error
		// we will simply ignore the row
		if (nBlanks > 0 && nBlanks < 6) {
			// deleting the last semi colon
			blanks.deleteCharAt(blanks.length() - 1);
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8338, materialsExceptionUtil
					.getErrorMessage(MaterialsErrorCodes.ERROR_8338) + rownum + COLON
					+ /*
						 * PO_NUM+poNumber+COMMA+LINE_NUM+COLON+lineNumber.trim(
						 * )+ COMMA+PART_NUM+COLON+partNumber.trim()+COMMA+
						 */blanks.toString(),
					ERR_ORDER_TEMPLATE_CONTAIN_INCOMPLETE_DATA + rownum + COLON
							+ /*
								 * poNumber+COMMA+LINE_NUM+COLON+lineNumber.trim
								 * () +COMMA+PART_NUM+COLON+partNumber.trim()+
								 * COMMA+
								 */blanks.toString());
		}
		return flag;
	}

	/**
	 * @param partsList
	 * @param orderList
	 * @return List of PartBO objects
	 */
	private ArrayList<PartBO> templateMailList(List<PartBO> partsList, List<OrderTemplateStatusBO> orderList) {
		ArrayList<PartBO> partBOList = new ArrayList<PartBO>();
		for (PartBO partBO : partsList) {
			for (OrderTemplateStatusBO orderTemplateStatusBO : orderList) {

				if ((partBO.getPoNumber().equalsIgnoreCase(orderTemplateStatusBO.getPoNumber()))
						&& (partBO.getLineNumber().equalsIgnoreCase(orderTemplateStatusBO.getPoLineNumber()))) {
					if (isNotNullandEmpty(orderTemplateStatusBO.getStatusMessage())) {
						PartBO partBONew = new PartBO();
						String poNumber = ((PartBO) partBO).getPoNumber();
						String poLineNumber = ((PartBO) partBO).getLineNumber();
						String partNumber = ((PartBO) partBO).getPartNumber();
						int quantity = ((PartBO) partBO).getQuantity();
						java.sql.Date requestedDate = ((PartBO) partBO).getRequestedDate();
						String statusMessage = ((OrderTemplateStatusBO) orderTemplateStatusBO).getStatusMessage();
						partBONew.setPoNumber(poNumber);
						partBONew.setLineNumber(poLineNumber);
						partBONew.setPartNumber(partNumber);
						partBONew.setQuantity(quantity);
						partBONew.setRequestedDate(requestedDate);
						partBONew.setStatusMessage(statusMessage);
						partBOList.add(partBONew);
					}
				}

			}

		}
		return partBOList;
	}

	/**
	 * @param partBOList
	 * @param sso
	 * @param portalId
	 */
	@Async
	private void notifyUser(List<PartBO> partBOList, String sso, String portalId) {
		EmailContentInputBO mailContentInputBO = populateEmailContent(sso, portalId);
		PurchaseOrderEmailBodyBO emailBodyBO = null;
		emailBodyBO = populateEmailBody(sso);
		mailContentInputBO.setSubject(generateSubject(portalId));
		mailContentInputBO.setBody(buildBodyContent(emailBodyBO, partBOList, portalId));
		mailContentInputBO.getIdentityId();
		materialsAppUtil.invokeNotificationService(mailContentInputBO, notificationServiceUrl,
				MaterialsAppConstants.PURCHASE_ORDER);
	}

	/**
	 * @param sso
	 * @return email body
	 */
	private PurchaseOrderEmailBodyBO populateEmailBody(String sso) {
		PurchaseOrderEmailBodyBO emailBody = new PurchaseOrderEmailBodyBO();
		emailBody.setFirstName(materialsAppUtil.getFirstName(sso));
		emailBody.setLastName(materialsAppUtil.getLastName(sso));
		return emailBody;
	}

	/**
	 * @param sso
	 * @param portalId
	 * @return email content
	 */
	private EmailContentInputBO populateEmailContent(String sso, String portalId) {
		String toMailId = EMPTY_STRING;
		String envmt = EMPTY_STRING;
		String appOwnerId = EMPTY_STRING;
		envmt = materialsAppUtil.getDeployedEnvironment();
		appOwnerId = materialsAppUtil.getAppOwnerId();
		EmailContentInputBO emailContent = new EmailContentInputBO();
		emailContent.setIdentityId(materialsAppUtil.getAppOwnerId());
		emailContent.setPortalId(portalId);
		emailContent.setFrom(materialsAppUtil.getFromEmailForPortal(portalId));
		if ("PROD".equalsIgnoreCase(envmt)) {
			toMailId = materialsAppUtil.getEmailId(sso);
			if (isNullOrEmpty(toMailId)) {
				// LOG.info("Recipient mail id does not exists, mail will be
				// sent to App owner");
				toMailId = appOwnerId + MAIL_EXCHANGE_SERVER;
			}
			emailContent.setTo(toMailId);
		} else {
			emailContent.setTo(DEVQA_EMAILS);// For
																		// Dev/QA
		}
		return emailContent;
	}

	/**
	 * @param portalId
	 * @return subject string
	 */
	private String generateSubject(String portalId) {
		StringBuilder subjectStrSB = new StringBuilder();
		String subject = portalId + COLON + "Bulk Upload Error-" + materialsAppUtil.getCurrentDateAsMMDDYYYY();
		subjectStrSB.append(subject);
		return subjectStrSB.toString();
	}

	/**
	 * @param emailBodyBO
	 * @param partBOList
	 * @param portalId
	 * @return String
	 */
	private String buildBodyContent(PurchaseOrderEmailBodyBO emailBodyBO, List<PartBO> partBOList, String portalId) {
		StringBuilder htmlBuilder = new StringBuilder();
		String envmt = materialsAppUtil.getDeployedEnvironment();
		if ("DEV".equalsIgnoreCase(envmt) || "QA".equalsIgnoreCase(envmt)) {
			htmlBuilder.append(
					"<h5 style='color:#0000ff;font-size:12px; font-family: ge-inspira, Helvetica Neue, Helvetica, Arial, sans-serif;'>This is a test mail. You can ignore this.</h5>");
		}
		htmlBuilder.append("<div style='" + STYLE_BODY_FONT_SIZE_12 + "'>"); // Salutation
																				// and
																				// PO
																				// #
																				// details
																				// -
																				// start
		htmlBuilder.append("Hello" + SPACE + "<b>" + emailBodyBO.getFirstName() + SPACE + emailBodyBO.getLastName()
				+ COMMA + "</b>");
		htmlBuilder.append("<br>The upload for the below PO's");
		htmlBuilder.append(" were un-successful. Please refer below data with error message and reupload ");
		// Salutation and PO # details - end
		// htmlBuilder.append("<br><br>");
		htmlBuilder.append(insertOrderDetailsTable(partBOList));
		// PO details - end
		htmlBuilder.append("<br><span style='" + STYLE_ITALIC_FONT + STYLE_BOLD_FONT + "'>"
				+ MaterialsAppConstants.PURCHASE_ORDER_THANKING + "</span>");
		htmlBuilder.append("</div>");
		return htmlBuilder.toString();
	}

	/**
	 * @param partBOList
	 * @return String
	 */
	private String insertOrderDetailsTable(List<PartBO> partBOList) {
		StringBuilder details = new StringBuilder();
		details.append("<br>");
		if (isCollectionNotEmpty(partBOList)) {
			String reqDate = EMPTY_STRING;
			String poNumber = EMPTY_STRING;
			String lineNumber = EMPTY_STRING;
			String partNumber = EMPTY_STRING;
			String statusMessage = EMPTY_STRING;
			String quantity = EMPTY_STRING;
			String blueBoldFont = STYLE_BOLD_FONT + "*" + STYLE_FONT_COLOR_BLUE;
			details.append("<table width='100%' border='1' style='" + STYLE_NO_WRAP + "'>");
			details.append("<tr><td width='11%' style='" + STYLE_TABLE_DATA_FONT_SIZE + STYLE_FONT_FAMILY + blueBoldFont
					+ STYLE_ALIGN_CENTER + "'>PO Number</td>");
			details.append(HTML_COLUMN_WIDTH + STYLE_TABLE_DATA_FONT_SIZE + STYLE_FONT_FAMILY + blueBoldFont
					+ STYLE_ALIGN_CENTER + "'>Line Number</td>");
			details.append(HTML_COLUMN_WIDTH + STYLE_TABLE_DATA_FONT_SIZE + STYLE_FONT_FAMILY + blueBoldFont
					+ STYLE_ALIGN_CENTER + "'>Part Number</td>");
			details.append(HTML_COLUMN_WIDTH + STYLE_TABLE_DATA_FONT_SIZE + STYLE_FONT_FAMILY + blueBoldFont
					+ STYLE_ALIGN_CENTER + "'>Requested Date</td>");
			details.append(HTML_COLUMN_WIDTH + STYLE_TABLE_DATA_FONT_SIZE + STYLE_FONT_FAMILY + blueBoldFont
					+ STYLE_ALIGN_CENTER + "'>Quantity</td>");
			details.append("<td width='45%' style='" + STYLE_TABLE_DATA_FONT_SIZE + STYLE_FONT_FAMILY + blueBoldFont
					+ STYLE_ALIGN_CENTER + "'>Error Reason</td></tr>");
			;
			for (PartBO partBO : partBOList) {
				reqDate = convertDatetoString(partBO.getRequestedDate());
				poNumber = (partBO.getPoNumber());
				lineNumber = (partBO.getLineNumber());
				partNumber = (partBO.getPartNumber());
				quantity = (Integer.toString(partBO.getQuantity()));
				statusMessage = (partBO.getStatusMessage());
				details.append("<tr><td style='" + STYLE_TABLE_DATA_FONT_SIZE + STYLE_FONT_FAMILY + STYLE_NORMAL_FONT
						+ STYLE_ALIGN_CENTER + "'>" + poNumber + HTML_COLUMN);
				details.append(HTML_COLUMN_STYLE + STYLE_TABLE_DATA_FONT_SIZE + STYLE_FONT_FAMILY + STYLE_NORMAL_FONT
						+ STYLE_ALIGN_CENTER + "'>" + lineNumber + HTML_COLUMN);
				details.append(HTML_COLUMN_STYLE + STYLE_TABLE_DATA_FONT_SIZE + STYLE_FONT_FAMILY + STYLE_NORMAL_FONT
						+ STYLE_ALIGN_CENTER + "'>" + partNumber + HTML_COLUMN);
				details.append(HTML_COLUMN_STYLE + STYLE_TABLE_DATA_FONT_SIZE + STYLE_FONT_FAMILY + STYLE_NORMAL_FONT
						+ STYLE_ALIGN_CENTER + "'>" + reqDate + HTML_COLUMN);
				details.append(HTML_COLUMN_STYLE + STYLE_TABLE_DATA_FONT_SIZE + STYLE_FONT_FAMILY + STYLE_NORMAL_FONT
						+ STYLE_ALIGN_CENTER + "'>" + quantity + HTML_COLUMN);
				details.append(HTML_COLUMN_STYLE + STYLE_TABLE_DATA_FONT_SIZE + STYLE_FONT_FAMILY + STYLE_NORMAL_FONT
						+ STYLE_ALIGN_CENTER + "'>" + statusMessage + "</td></tr>");
			}
			details.append("</table><br>");
		}
		return details.toString();
	}

	/**
	 * This method will convert date to string
	 * @param date
	 * @return String
	 */
	private String convertDatetoString(Date date) {
		String strDate = null;
		Format formatter;
		formatter = new SimpleDateFormat("MM/dd/yyyy");
		strDate = formatter.format(date);
		return strDate;
	}


	/**
	 * This method is used to get the Header Details
	 * 
	 * @param smssoid
	 * @param portalid
	 * @param msNumber
	 * @param deliveryId
	 * @param orderHeaderId
	 * @param invoiceHeaderId
	 * @return Order Header Details
	 * @throws MaterialsException
	 */
	@Override
	public OrderHeaderDetails getHeaderDetailBS(String ssoid, String portalId, String msNumber, String deliveryId,
			String orderHeaderId, String invoiceHeaderId) throws MaterialsException {
		log.info("getHeaderDetailBS()-<START>");
		OrderHeaderDetails orderHeaderDetails = null;
		OrderHeaderInfoBO orderHeaderInfoBO = null;
		List<PriorityBO> priorityBO = null;
		
		String[] custIdList = null;
		
		
		String role = EMPTY_STRING;
		String icaoCode = EMPTY_STRING;
		String operatingUnitId = EMPTY_STRING;
		StopWatch watch = new StopWatch();
		String task = GETCUSTLOGINDETAILS;
		materialsAppUtil.startLogging(task, watch);
		CustLoginDetails custLoginDetails = materialsAppUtil.getCustLoginDetails(ssoid, portalId);
		materialsAppUtil.endLogging(task, watch);
		if (MaterialsAppUtil.isNotNullandEmpty(custLoginDetails.getIcaoCode())) {
			icaoCode = custLoginDetails.getIcaoCode();
		}
		if (MaterialsAppUtil.isNotNullandEmpty(custLoginDetails.getRole())) {
			role = custLoginDetails.getRole();
		}
		if (custLoginDetails.getCustIdList() != null) {
			custIdList = custLoginDetails.getCustIdList();
		}
		if (MaterialsAppUtil.isNotNullandEmpty(custLoginDetails.getOperatingUnitId())) {
			operatingUnitId = custLoginDetails.getOperatingUnitId();
		}
		if (materialsAppUtil.validateInputs(msNumber, deliveryId, orderHeaderId, invoiceHeaderId)) {
			try {
				orderHeaderDetails = materialsOrdersDAO.getHeaderDetailDS(ssoid, icaoCode, custIdList, role,
						operatingUnitId, msNumber, deliveryId, orderHeaderId, invoiceHeaderId);
			} catch (TechnicalException e) {
				materialsAppUtil.throwAsBusinessException(e);
			}
			if (orderHeaderDetails != null) {
				if (MaterialsAppUtil.isNotNullandEmpty(orderHeaderDetails.getDisplayMessage())) {
					materialsAppUtil.throwERPMessage(orderHeaderDetails.getDisplayMessage());
				} else {
					orderHeaderInfoBO = orderHeaderDetails.getOrderHeaderInfoBO();
					setOrderHeaderInfoBODetails(orderHeaderInfoBO,portalId,msNumber,deliveryId,ssoid,custLoginDetails,orderHeaderId,invoiceHeaderId);
				}
			}
		} else {
			String desc = materialsAppUtil.getDescMsg(msNumber, deliveryId, orderHeaderId, invoiceHeaderId);
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8319, ERR_INVALID_INPUTS, desc);
		}
		try {
			priorityBO = materialsOrdersDAO.getPriorityDS(ssoid, portalId);
		} catch (TechnicalException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}
		if (priorityBO != null && !priorityBO.isEmpty()) {
			orderHeaderDetails.setPriorityBO(priorityBO);
		} else {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8307,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8307), ERR_PRIORITY_NOT_FOUND);
		}

		return orderHeaderDetails;
	}
	
	private void setOrderHeaderInfoBODetails(OrderHeaderInfoBO orderHeaderInfoBO, String portalId, String msNumber,
			String deliveryId, String ssoid, CustLoginDetails custLoginDetails, String orderHeaderId, String invoiceHeaderId) throws MaterialsException {
		
		String linkURL = EMPTY_STRING;
		byte[] bytes = null;
		List<DocumentDownloadBO> downloadLinks = null;
		ReturnLabelDO returnLabelDO = null;

		if (MaterialsAppUtil.isNotNullandEmpty(msNumber)) {
		
			//commenting out the old check for whether the MS doc exists in DSD; we need to check instead if the MS doc exists in WCC
			//if (materialsAppUtil.isFileExists(msNumber, MaterialsAppConstants.M, orderHeaderInfoBO.getShipmentDate()))
			if(materialsOrdersDAO.isWccFileExists(msNumber, materialsAppUtil.convertShipDocTypeToWccDocType(MaterialsAppConstants.M), orderHeaderInfoBO.getCustomerCode(), orderHeaderInfoBO.getShipmentDate()))
			{
				linkURL = materialsAppUtil.getApplicationURL(portalId)
						+ MaterialsAppConstants.MATERIALDOCURL + msNumber + MaterialsAppConstants.DELIVERYID
						+ deliveryId + MaterialsAppConstants.DOCTYPE + MaterialsAppConstants.M
						+ MaterialsAppConstants.INVOICE_ID;
				orderHeaderInfoBO.setMsLink(linkURL);
			}
	
			//commenting out the old check for whether the FAA doc exists in DSD; we need to check instead if the FAA doc exists in WCC
			//if (materialsAppUtil.isFileExists(msNumber, MaterialsAppConstants.F, orderHeaderInfoBO.getShipmentDate())) 
			if(materialsOrdersDAO.isWccFileExists(msNumber, materialsAppUtil.convertShipDocTypeToWccDocType(MaterialsAppConstants.F), orderHeaderInfoBO.getCustomerCode(), orderHeaderInfoBO.getShipmentDate()))
			{
				linkURL = materialsAppUtil.getApplicationURL(portalId)
						+ MaterialsAppConstants.MATERIALDOCURL + msNumber + MaterialsAppConstants.DELIVERYID
						+ deliveryId + MaterialsAppConstants.DOCTYPE + MaterialsAppConstants.F
						+ MaterialsAppConstants.INVOICE_ID;
				orderHeaderInfoBO.setFaaLink(linkURL);
			}
		}
		if (MaterialsAppUtil.isNotNullandEmpty(orderHeaderInfoBO.getInvoiceNumber())) {
			try {
				bytes = materialsOrdersDAO.getInvoiceDocDS(ssoid, orderHeaderInfoBO.getInvoiceNumber());
				if (bytes != null) {
					linkURL = materialsAppUtil.getApplicationURL(portalId)
							+ MaterialsAppConstants.MATERIALDOCURL + MaterialsAppConstants.DELIVERYID
							+ MaterialsAppConstants.DOCTYPE + MaterialsAppConstants.INVOICE
							+ MaterialsAppConstants.INVOICE_ID + invoiceHeaderId;
					orderHeaderInfoBO.setInvoiceLink(linkURL);
				}
			} catch (TechnicalException e) {
				log.warn(e.getMessage(), e); //existing functionality: log exception and continue loading header details
			}
		}
		// dispute docs - start
		if (MaterialsAppUtil.isNotNullandEmpty(orderHeaderId)) {
			String orderType = EMPTY_STRING, rmaNumber = EMPTY_STRING;
			downloadLinks = new ArrayList<DocumentDownloadBO>();
			returnLabelDO = materialsAppUtil.getDisputeOrderDetails(ssoid, orderHeaderId, custLoginDetails);
			if (null != returnLabelDO && MaterialsAppUtil.isNullOrEmpty(returnLabelDO.getpMessage())) {
				orderType = returnLabelDO.getReason();
				rmaNumber = returnLabelDO.getRmaNumber();
				if (MaterialsAppUtil.isNotNullandEmpty(orderType)) {
					if (orderType.equalsIgnoreCase(SCRAP)
							|| orderType.equalsIgnoreCase(OVERAGE_SCRAP)) {
						materialsAppUtil.createDownloadLinks(portalId, orderHeaderId, SCRAP,
								SCRAP_DOC_DISPLAY_NAME, downloadLinks, true);
					}
					if (orderType.equalsIgnoreCase(DISCREPANCY) || orderType.equalsIgnoreCase(OVERAGE)
									|| orderType.equalsIgnoreCase(OVERAGE_RETURN)) {
						materialsAppUtil.createDownloadLinks(portalId, orderHeaderId, RETURN_INSTRUECTIONS,
								RETURN_INS_DOC_DISPLAY_NAME, downloadLinks, true);
						materialsAppUtil.createDownloadLinks(portalId, orderHeaderId, PROFORMA,
								PROFORMA_DOC_DISPLAY_NAME, downloadLinks, true);
						materialsAppUtil.createDownloadLinks(portalId, orderHeaderId, RETURN_LABEL,
								RETURN_LABEL_DOC_DISPLAY_NAME + HYPHEN + rmaNumber, downloadLinks, true);
					}
					if (orderType.equalsIgnoreCase(BUYBACK)) {
						materialsAppUtil.createDownloadLinks(portalId, orderHeaderId, BUYBACK_INSTRUCTIONS,
								BUYBACK_INS_DOC_DISPLAY_NAME, downloadLinks, true);
						materialsAppUtil.createDownloadLinks(portalId, orderHeaderId, ATA, ATA_DOC_DISPLAY_NAME,
								downloadLinks, true);
						materialsAppUtil.createDownloadLinks(portalId, orderHeaderId, RETURN_LABEL,
								RETURN_LABEL_DOC_DISPLAY_NAME + HYPHEN + rmaNumber, downloadLinks, true);
					}
				}
			}
		}
		orderHeaderInfoBO.setDownloadDocumentBOList(downloadLinks);
		// dispute docs - end
		orderHeaderInfoBO.setReturnServiceProvider(shipmentServiceProvider);
	}

	/**
	 * This method will get the Order Audit History
	 * 
	 * @param strSSO
	 * @param portalId
	 * @param headerId
	 * @return Order Audit History
	 * @throws MaterialsException
	 */
	@Override
	public OrderAuditHistoryBO getOrderAuditHistoryBS(String strSSO, String portalId, String headerId)
			throws MaterialsException {
		log.info("Entered into getOrderAuditHistory() method");
		String task = EMPTY_STRING;
		StopWatch watch = new StopWatch();
		CustLoginDetails custLoginDetails = null;
		OrderAuditHistoryBO orderAuditHistoryBO = new OrderAuditHistoryBO();
		OrderAuditDetailsDO orderAuditDetailsDO = null;
		OrderAuditBO orderAuditBO = new OrderAuditBO();
		List<OrderAuditBO> orderAuditBOList = new ArrayList<OrderAuditBO>();
		List<OrderAuditDO> orderAuditDOList = null;
		task = "getOrderAuditHistory";
		materialsAppUtil.startLogging(task, watch);
		custLoginDetails = materialsAppUtil.getCustLoginDetails(strSSO, portalId);
		materialsAppUtil.endLogging(task, watch);
		if (!MaterialsAppUtil.isNotNullandEmpty(headerId)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8309,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8309), ERR_HEADER_ID_NOT_FOUND);
		}
		try {

			task = "materialsDAO.getOrderAuditDS";
			materialsAppUtil.startLogging(task, watch);
			orderAuditDetailsDO = materialsOrdersDAO.getOrderAuditDS(strSSO, custLoginDetails.getIcaoCode(),
					custLoginDetails.getCustIdList(), custLoginDetails.getRole(), custLoginDetails.getOperatingUnitId(),
					headerId);
			materialsAppUtil.endLogging(task, watch);
			if (null != orderAuditDetailsDO) {
				if (MaterialsAppUtil.isNotNullandEmpty(orderAuditDetailsDO.getMessage())) {
					String pMessage = orderAuditDetailsDO.getMessage();
					if (pMessage.startsWith(ERR_CODE_8024)) {
						log.info(PMESSAGE + pMessage);
						orderAuditHistoryBO.setDisplayMessage(
								materialsExceptionUtil.getErrorMessage(MaterialsAppConstants.ERR_CODE_8024));
						orderAuditHistoryBO.setOrderAuditBOList(orderAuditBOList);
						return orderAuditHistoryBO;
					} else if (pMessage.startsWith(ERR_CODE_8025)) {
						log.info(PMESSAGE + pMessage);
						orderAuditHistoryBO.setDisplayMessage(
								materialsExceptionUtil.getErrorMessage(MaterialsAppConstants.ERR_CODE_8025));
						orderAuditHistoryBO.setOrderAuditBOList(orderAuditBOList);
						return orderAuditHistoryBO;
					} else if (pMessage.startsWith(ERR_CODE_8026)) {
						log.info(PMESSAGE + pMessage);
						orderAuditHistoryBO.setDisplayMessage(
								materialsExceptionUtil.getErrorMessage(MaterialsAppConstants.ERR_CODE_8026));
						orderAuditHistoryBO.setOrderAuditBOList(orderAuditBOList);
						return orderAuditHistoryBO;
					}
					else {
						materialsAppUtil.throwERPMessage(orderAuditDetailsDO.getMessage());
					}
				} else {
					orderAuditHistoryBO.setStatusMessage(orderAuditDetailsDO.getError_status());
					orderAuditDOList = orderAuditDetailsDO.getOrderAuditDOList();
					if (!orderAuditDOList.isEmpty()) {
						for (OrderAuditDO orderAuditDO : orderAuditDOList) {
							orderAuditBO = new OrderAuditBO();
							orderAuditBO.setLineNumber(orderAuditDO.getLineNumber());
							orderAuditBO.setAttrName(orderAuditDO.getAttrName());
							orderAuditBO.setChangeDate(orderAuditDO.getChangeDate());
							orderAuditBO.setNewValue(orderAuditDO.getNewValue());
							orderAuditBO.setOldValue(orderAuditDO.getOldValue());
							orderAuditBO.setUpdatedBy(materialsAppUtil.getNameforSSO(orderAuditDO.getUpdatedBy()));
							orderAuditBOList.add(orderAuditBO);
						}
					}

				}
			}
			orderAuditHistoryBO.setOrderAuditBOList(orderAuditBOList);
		}

		catch (TechnicalException e) {
			materialsAppUtil.throwAsBusinessException(e);
		}
		return orderAuditHistoryBO;
	}

	/**
	 * This method will download Order Template
	 * 
	 * @param strSSO
	 * @param portalId
	 * @return Response object with template
	 * @throws MaterialsException
	 */
	@Override
	public Response getOrderTemplateBS(String strSSO, String portalId) throws MaterialsException {
		CustLoginDetails custLoginDetails = null;
		StopWatch watch = new StopWatch();
		String task = GETCUSTLOGINDETAILS;
		materialsAppUtil.startLogging(task, watch);
		custLoginDetails = materialsAppUtil.getCustLoginDetails(strSSO, portalId);
		materialsAppUtil.endLogging(task, watch);
		String role = custLoginDetails.getRole();
		
		byte[] bytes = null;
		if(portalId.equalsIgnoreCase("GEHONDA")){
			portalId= "GEHONDA";
		}		
		if(AERODP.equalsIgnoreCase(portalId)){
			portalId= AERODP;
		}		
		String fileName = portalId+XLS_EXTENSION;
		
		if (BUYER.equalsIgnoreCase(role) || (ROLE_CE.equalsIgnoreCase(role) && AERODP.equalsIgnoreCase(portalId))) {
		
			try {
				String path = ORDER_TEMPLATE_PATH + fileName;
				Resource resource = new ClassPathResource(path);
				bytes = IOUtils.toByteArray(resource.getInputStream());
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			throw new MaterialsException(
					MaterialsErrorCodes.ERROR_8330,
					materialsExceptionUtil
					.getErrorMessage(MaterialsErrorCodes.ERROR_8330),
					UNAUTHORISED_USER);
		}
		
		
		Response response = buildResponse(bytes, fileName);
		return response;
	}

	/**
	 * This method updates the Order details
	 * 
	 * @param strSSO
	 * @param portalId
	 * @param updateOrderRequestList
	 * @return List of updated Order details
	 * @throws MaterialsException
	 */
	@Override
	public List<UpdateOrderResponseDetails> updateOrderBS(String strSSO, String portalId,
			List<UpdateOrderRequestDetails> updateOrderRequestList) throws MaterialsException {

		String task = EMPTY_STRING;
		CustLoginDetails custLoginDetails = null;
		StopWatch watch = new StopWatch();
		task = GETCUSTLOGINDETAILS;
		materialsAppUtil.startLogging(task, watch);
		custLoginDetails = materialsAppUtil.getCustLoginDetails(strSSO, portalId);
		materialsAppUtil.endLogging(task, watch);
		String orderedQuantity = null;
		List<UpdateOrderResponseDetails> updateOrderResponseDetailsList = null;
		List<UpdateOrderInputDO> updateOrderInputDOList = null;
		List<UpdateOrderOutputDO> updateOrderOutputDOList = null;
		UpdateOrderDetailsOutputDO updateOrderDetailsOutputDO = null;
		UpdateOrderResponseDetails updateOrderResponseDetails = null;
		UpdateOrderInputDO updateOrderInputDO = null;
		updateOrderInputDOList = new ArrayList<>();
		
		// DE45544: Store invalid ESN line order for both priority normal and Work stop
		UpdateOrderDetailsOutputDO updateOrderESNErrorOutputDO = new UpdateOrderDetailsOutputDO();
		List<UpdateOrderOutputDO> updateOrderESNErrorList = new ArrayList<>();
		UpdateOrderOutputDO updateOrderESNError = new UpdateOrderOutputDO();
		
		String orderLineESN = EMPTY_STRING;
		boolean esnValid = true;
		List<Boolean> esnValidFlagList = new ArrayList<>();
		List<String> priorityList = new ArrayList<>();
		
		// save original data of order
		String lastSavedLineInfoHeaderId = EMPTY_STRING;
		List<LineInfoBO> lineInfoBOList = new ArrayList<>();	

		for (UpdateOrderRequestDetails updateOrderRequestDetails : updateOrderRequestList) {
			if (MaterialsAppUtil.isNotNullandEmpty(updateOrderRequestDetails.getHeaderId())) {
				if (MaterialsAppUtil.isNotNullandEmpty(updateOrderRequestDetails.getLineId())) {
					orderedQuantity = updateOrderRequestDetails.getOrderedQuantity();
					if (MaterialsAppUtil.isNullOrEmpty(orderedQuantity)) {
						orderedQuantity = null;
					} else {
						orderedQuantity = materialsAppUtil
								.getValidQuantity(updateOrderRequestDetails.getOrderedQuantity());
					}
					// normal priority for AERODP change(newly added)
					String constPriority = materialsAppUtil.getPriorityCode(portalId,
							updateOrderRequestDetails.getShipmentPriorityCode());
					if (!MaterialsAppUtil.isNotNullandEmpty(constPriority) && ((AERODP).equalsIgnoreCase(portalId))) {
						throw new MaterialsException(MaterialsErrorCodes.ERROR_8401,
								materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8401), ERR_PRIORITY);
					}
					orderLineESN = updateOrderRequestDetails.getOrderLineESN();

					// Validate ESN - Start
					if ((isNotNullandEmpty(orderLineESN)))
						esnValid = Boolean.parseBoolean(materialsAppUtil.validateEsn(orderLineESN));
					else
						esnValid = false;
					// ESN Validation End
		
					// Workstop date and workstop quantity - START
					java.sql.Date workStopDate = null;
					int workStopQty = 0;

					if (MaterialsAppUtil.isNotNullandEmpty(updateOrderRequestDetails.getOrderLineWorkStopDate())) {
						workStopDate = materialsAppUtil
								.getSQLDate(updateOrderRequestDetails.getOrderLineWorkStopDate());
					}
					if (MaterialsAppUtil.isNotNullandEmpty(updateOrderRequestDetails.getOrderLineWorkStopQuantity())) {
						workStopQty = Integer.parseInt(updateOrderRequestDetails.getOrderLineWorkStopQuantity());
					}
					// Workstop date and workstop quantity - END
					
					// DE45544: get original order data if priority is normal, esn is invalid and esn is not an empty
					if (updateOrderRequestDetails.getShipmentPriorityCode().equalsIgnoreCase(PRIORITY_NORMAL) && 
							!(esnValid) && (isNotNullandEmpty(orderLineESN)) && lineInfoBOList != null
							&& !(lastSavedLineInfoHeaderId.equalsIgnoreCase(updateOrderRequestDetails.getHeaderId()))) {
						try {
							LineDetailBO lineDetailBO = materialsAppImpl.getLineDetailBS(strSSO, portalId, null, null, updateOrderRequestDetails.getHeaderId(), null,
									new ArrayList<MaterialsSortField>(), 0, 0);
							lineInfoBOList = lineDetailBO.getOrderLineList();
							lastSavedLineInfoHeaderId = updateOrderRequestDetails.getHeaderId();
						} catch (MaterialsException e) {
							// reset lineInfoBOList to empty
							lineInfoBOList = new ArrayList<>();
							log.error("Failed to get currently saved order details "+e);
						}
					}

					if (updateOrderRequestDetails.getShipmentPriorityCode().equalsIgnoreCase(PRIORITY_WORKSTOP)
							&& !(esnValid)) {
						// Store invalid ESN line order for priority Work stop and does not pass to line order to DB
						updateOrderESNError = new UpdateOrderOutputDO();

						updateOrderESNError.setHeaderId(updateOrderRequestDetails.getHeaderId());
						updateOrderESNError.setLineId(updateOrderRequestDetails.getLineId());
						updateOrderESNError.setSuccess(MaterialsAppConstants.N);
						updateOrderESNError.setStatusMessage(MaterialsAppConstants.WORK_STOP_ESN_MSG);
						updateOrderESNError.setEsnValidFlag(MaterialsAppConstants.N);
						updateOrderESNError.setEsnStatusMsg(MaterialsAppConstants.WORK_STOP_ESN_MSG);

						updateOrderESNErrorList.add(updateOrderESNError);
						updateOrderESNErrorOutputDO.setUpdateOrderList(updateOrderESNErrorList);
					} else if (updateOrderRequestDetails.getShipmentPriorityCode().equalsIgnoreCase(PRIORITY_NORMAL)
							&& !(esnValid) && (isNotNullandEmpty(orderLineESN)) 
							&& !isLastSavedESNInUpdateOrder(updateOrderRequestDetails, lineInfoBOList)) {
						// DE45544: When updating line order with invalid ESN and currently stored line order does not contain this ESN in DB 
						// then throw error ESN not valid and does not pass line order to DB.
						updateOrderESNError = new UpdateOrderOutputDO();

						updateOrderESNError.setHeaderId(updateOrderRequestDetails.getHeaderId());
						updateOrderESNError.setLineId(updateOrderRequestDetails.getLineId());
						updateOrderESNError.setSuccess(MaterialsAppConstants.N);
						updateOrderESNError.setStatusMessage(MaterialsAppConstants.ESN_STATUS_MSG_UPDATE);
						updateOrderESNError.setEsnValidFlag(MaterialsAppConstants.N);
						updateOrderESNError.setEsnStatusMsg(MaterialsAppConstants.ESN_STATUS_MSG_UPDATE);

						updateOrderESNErrorList.add(updateOrderESNError);
						updateOrderESNErrorOutputDO.setUpdateOrderList(updateOrderESNErrorList);
					} else {
						// If above two condition not match, then we want to update line order in database.
						if (updateOrderRequestDetails.getShipmentPriorityCode()
								.equalsIgnoreCase(PRIORITY_WORKSTOP) && !(esnValid)) {
							esnValidFlagList.add(false);
						} else {
							esnValidFlagList.add(true);
						}
				 
						priorityList.add(updateOrderRequestDetails.getShipmentPriorityCode());
						
						updateOrderInputDO = new UpdateOrderInputDO(updateOrderRequestDetails.getHeaderId(),
								updateOrderRequestDetails.getLineId(), updateOrderRequestDetails.getCustPOLineNumber(),
								orderedQuantity, constPriority, updateOrderRequestDetails.getShipToLocation(),
								updateOrderRequestDetails.getDeliverToLocation(),
								materialsAppUtil.getSQLDate(
										materialsAppUtil.getValidDate(updateOrderRequestDetails.getRequestDate())),
								orderLineESN, workStopDate, workStopQty);
						updateOrderInputDOList.add(updateOrderInputDO);
					}		
				} else {
					throw new MaterialsException(MaterialsErrorCodes.ERROR_8308,
							materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8308),
							ERR_LINE_ID_NOT_FOUND);
				}
			} else {
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8309,
						materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8309),
						ERR_HEADER_ID_NOT_FOUND);
			}
		}
		try {
			task = "materialsDAO.updateOrderDS";
			materialsAppUtil.startLogging(task, watch);
			updateOrderDetailsOutputDO = materialsOrdersDAO.updateOrderDS(strSSO, custLoginDetails.getRole(),
					custLoginDetails.getIcaoCode(), custLoginDetails.getCustIdList(),
					custLoginDetails.getOperatingUnitId(), updateOrderInputDOList, esnValidFlagList, priorityList);
			materialsAppUtil.endLogging(task, watch);

		} catch (TechnicalException e) {
			materialsAppUtil.throwAsBusinessException(e);
		}

		if (null != updateOrderDetailsOutputDO) {
			String pMessage = updateOrderDetailsOutputDO.getProcMessage();
			if (MaterialsAppUtil.isNotNullandEmpty(pMessage)) {
				materialsAppUtil.throwERPMessage(pMessage);
			} else {
				updateOrderResponseDetailsList = new ArrayList<UpdateOrderResponseDetails>();
				updateOrderOutputDOList = updateOrderDetailsOutputDO.getUpdateOrderList();
				for (UpdateOrderOutputDO updateOrderDO : updateOrderOutputDOList) {
					updateOrderResponseDetails = new UpdateOrderResponseDetails();

					updateOrderResponseDetails.setHeaderId(updateOrderDO.getHeaderId());
					updateOrderResponseDetails.setLineId(updateOrderDO.getLineId());
					updateOrderResponseDetails.setEsnValidFlag(updateOrderDO.getEsnValidFlag());
					updateOrderResponseDetails.setEsnStatusMsg(updateOrderDO.getEsnStatusMsg());
					if (MaterialsAppUtil.isNullOrEmpty(updateOrderDO.getSuccess())) {
						updateOrderResponseDetails.setSuccess(true);
					}

					updateOrderResponseDetails
							.setSuccess(MaterialsAppUtil.getBooleanFrmString(updateOrderDO.getSuccess()));
					updateOrderResponseDetails
							.setStatusMessage(materialsAppUtil.getStatusMessage(updateOrderDO.getStatusMessage()));
					updateOrderResponseDetailsList.add(updateOrderResponseDetails);
					if (updateOrderResponseDetails.isSuccess()) {
						String urlStr = materialsAppUtil.getAttivioServicesURL() + CONST_UPDATE_ORDER + EQUALS_STRING
								+ (updateOrderDO.getHeaderId());
						materialsAppUtil.invokeService(urlStr, "Update Order");
					}
				}

				// Added this logic because we are not calling database if
				// esn is invalid so that we are not
				// updating the database, but sending the error message to user
				for (UpdateOrderOutputDO updateOrderDO : updateOrderESNErrorList) {
					updateOrderResponseDetails = new UpdateOrderResponseDetails();

					updateOrderResponseDetails.setHeaderId(updateOrderDO.getHeaderId());
					updateOrderResponseDetails.setLineId(updateOrderDO.getLineId());
					updateOrderResponseDetails.setEsnValidFlag(updateOrderDO.getEsnValidFlag());
					updateOrderResponseDetails.setEsnStatusMsg(updateOrderDO.getEsnStatusMsg());
					if (MaterialsAppUtil.isNullOrEmpty(updateOrderDO.getSuccess())) {
						updateOrderResponseDetails.setSuccess(true);
					}

					updateOrderResponseDetails
							.setSuccess(MaterialsAppUtil.getBooleanFrmString(updateOrderDO.getSuccess()));
					updateOrderResponseDetails
							.setStatusMessage(materialsAppUtil.getStatusMessage(updateOrderDO.getStatusMessage()));
					updateOrderResponseDetailsList.add(updateOrderResponseDetails);
					if (updateOrderResponseDetails.isSuccess()) {
						String urlStr = materialsAppUtil.getAttivioServicesURL() + CONST_UPDATE_ORDER + EQUALS_STRING
								+ (updateOrderDO.getHeaderId());
						materialsAppUtil.invokeService(urlStr, "Update Order");
					}
				}
			}
		}
		return updateOrderResponseDetailsList;
	}
	
	/**
	 * This method will check esn sent in update order is original ESN (last saved ESN) or not.
	 * 
	 * @param updateOrderRequestDetails
	 * @param lineInfoBOList
	 * @return true or false
	 */
	

	private boolean isLastSavedESNInUpdateOrder(UpdateOrderRequestDetails updateOrderRequestDetails, List<LineInfoBO> lineInfoBOList) {
		boolean isOriginalESN = false;
		
		if (lineInfoBOList == null || (lineInfoBOList != null && lineInfoBOList.isEmpty())) {
			return isOriginalESN;
		}
		
		for (LineInfoBO lineInfo : lineInfoBOList) {
			if (updateOrderRequestDetails.getHeaderId().equals(lineInfo.getHeaderId())
					&& updateOrderRequestDetails.getLineId().equals(lineInfo.getLineId())) {
				if (isNotNullandEmpty(lineInfo.getOrderLineESN()) 
						&& isNotNullandEmpty(updateOrderRequestDetails.getOrderLineESN()) 
						&& updateOrderRequestDetails.getOrderLineESN().equals(lineInfo.getOrderLineESN())) {
					isOriginalESN = true;
				}
				break;
			}
		}
		
		return isOriginalESN;
	}
	
	/**
	 * This method will prepare the e-mail with invoice document
	 * 
	 * @param strSSO
	 * @param portalId
	 * @param invoiceId
	 * @return invoiceDocDO
	 * @throws MaterialsException
	 */
	@Override
	public InvoiceDocDO getInvoiceDocBS(String strSSO, String portalId,
			String invoiceId) throws MaterialsException {
		CustLoginDetails custLoginDetails = null;
		InvoiceDocDO invoiceDocDO = null;
		List<String> attachmentNameList = new ArrayList<String>();
		List<String> attachmentList = new ArrayList<String>();
		custLoginDetails = materialsAppUtil.getCustLoginDetails( strSSO, portalId);
		String envmt = materialsAppUtil.getDeployedEnvironment();
		try{
			invoiceDocDO = materialsOrdersDAO.getInvoiceDocDS(strSSO, custLoginDetails.getIcaoCode(), 
					custLoginDetails.getCustIdList(), custLoginDetails.getRole(),custLoginDetails.getOperatingUnitId(), invoiceId);
		}
		catch(TechnicalException e){
			materialsAppUtil.throwAsBusinessException(e);
		}
		EmailContentInputBO emailContentInputBO = new EmailContentInputBO();
		emailContentInputBO.setFrom(materialsAppUtil.getFromEmailForPortal(portalId));
		
		if("PROD".equalsIgnoreCase(envmt)){
			emailContentInputBO.setTo(materialsAppUtil.getEmailId(strSSO));
		
		}else{
			emailContentInputBO.setTo(DEVQA_EMAILS);//For Dev/QA
		}
		
		//Added for JIRA 7194
		String[] invoiceNumArr = null;
		String invoiceNum = EMPTY_STRING;
		if(isNotNullandEmpty(invoiceDocDO.getFileName())){
			invoiceNumArr = invoiceDocDO.getFileName().split(SLASH_DOT);		
			invoiceNum = invoiceNumArr[0];
		}
		emailContentInputBO.setSubject("Invoice # "+invoiceNum);
		emailContentInputBO.setPortalId(portalId);
		emailContentInputBO.setIdentityId(materialsAppUtil.getAppOwnerId());
		if(isNotNullandEmpty(invoiceDocDO.getP_msg()))
		{
			emailContentInputBO.setBody(invoiceEmailContent(strSSO,"We are unable to provide Invoice Document because of "+invoiceDocDO.getP_msg()+ ". Please contact CAM."));
		}
		else{
			try{
				if(invoiceDocDO.getFileBlob().length > 0)
				{
					attachmentList.add(materialsAppUtil.encodeBytesToString(invoiceDocDO.getFileBlob()));
					attachmentNameList.add("Invoice_"+invoiceNum+PDF_EXTENSION);
					emailContentInputBO.setAttachmentName(attachmentNameList);
					emailContentInputBO.setMessageAttachment(attachmentList);
					emailContentInputBO.setBody(invoiceEmailContent(strSSO,"Please find the attached requested Invoice Document for Invoice # "+invoiceNum));
				}
			}catch (Exception e) {
				log.error(" document attachment failed. "+e);
			}
		}
		boolean success = materialsAppUtil.invokeNotificationService(emailContentInputBO, notificationServiceUrl, "InvoiceDoccument");
		if(success){
			invoiceDocDO = new InvoiceDocDO();
			invoiceDocDO.setSuccess(true);
			invoiceDocDO.setStatusMessage("Invoice Document sent successfully to your Email-Id.");
		}
		else{
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8344,
					materialsExceptionUtil.getErrorMessage(
							MaterialsErrorCodes.ERROR_8344),
							ERR_EMAIL_NOTIFICATION_FAILED);
		}
		return invoiceDocDO;
	}
	
	
	/**
	 * @param sso
	 * @param messageBody
	 * @return String
	 */
	private String invoiceEmailContent(String sso,String messageBody){

		StringBuilder htmlBuilder = new StringBuilder();
		htmlBuilder.append("<h4>Hello "+materialsAppUtil.getFirstName(sso)+" "+materialsAppUtil.getLastName(sso)+COMMA+"</h4>");
		htmlBuilder.append("<br> "+ messageBody +"");
		return htmlBuilder.toString();
	}
	
	/**
	 * Export CSV file with Order Details
	 * @param strSSO
	 * @param portalId
	 * @param multiValmap
	 * @param icaoCode
	 * @param custCodes
	 * @return Response
	 * @throws MaterialsException
	 */
	@Override
	public Response materialOrderListCsvExportBS(String strSSO, String portalId, MultivaluedMap<String, String> form,
			String icaoCode, String custCodes) throws MaterialsException {
		log.info("Entered materialOrderListCsvExportBS  ");
		OrderListResponse materialsOrderListResponse = null;
		OrderCFMListResponse materialsOrderCFMListResponse = null;
		String iDisplayStart = form.getFirst("iDisplayStart");
		String iDisplayLength = form.getFirst("iDisplayLength");
		String fileName = null;
		String orderLineType = null;
		boolean csvExportFlag = true;
		String csvResp = null;
		if (isNullOrEmpty(icaoCode)) {
			return materialsAppUtil.htmlErrorResponse(ERR_ICAO_NOT_FOUND);
		}

		if (!GEAE.equalsIgnoreCase(icaoCode) && isNullOrEmpty(custCodes)) {

			return materialsAppUtil.htmlErrorResponse(ERR_CUST_NOT_FOUND);
		}

		if (MYCFM.equalsIgnoreCase(portalId)) {
			materialsOrderCFMListResponse = materialsAppUtil.getMaterialsOrderListCFM(strSSO, portalId, form,
					new ArrayList<OrderExportCSVList>(), iDisplayStart, iDisplayLength, csvExportFlag, icaoCode,
					custCodes);
			if (!"SUCCESS".equalsIgnoreCase(materialsOrderCFMListResponse.getStatus())
					&& !"NOTVALID".equalsIgnoreCase(materialsOrderCFMListResponse.getStatus())

					&& !"NOROWS".equalsIgnoreCase(materialsOrderCFMListResponse.getStatus()))

			{
				return materialsAppUtil.htmlErrorResponse(WARNING_MSG_1 + WARNING_MSG_2);
			}

			List<MaterialsOrdersCFM> materialsExportList = materialsOrderCFMListResponse.getOrdersList();
			csvResp = materialsAppUtil.toCSVCFM(materialsExportList);
		} else

		{
			materialsOrderListResponse = getMaterialsOrderList(strSSO, portalId, form,
					new ArrayList<OrderExportCSVList>(), iDisplayStart, iDisplayLength, csvExportFlag, icaoCode,
					custCodes);

			if (!"SUCCESS".equalsIgnoreCase(materialsOrderListResponse.getStatus())
					&& !"NOTVALID".equalsIgnoreCase(materialsOrderListResponse.getStatus())

					&& !"NOROWS".equalsIgnoreCase(materialsOrderListResponse.getStatus()))

			{
				return materialsAppUtil.htmlErrorResponse(WARNING_MSG_1 + WARNING_MSG_2);
			}

			List<MaterialsOrders> materialsExportList = materialsOrderListResponse.getOrdersList();

			csvResp = materialsAppUtil.toCSV(materialsExportList);
		}

		if (csvResp != null && csvResp != EMPTY_STRING) {
			fileName = materialsAppUtil.getCsvFileName(portalId);
			String dateFormat = new SimpleDateFormat(DATE_FORMAT1).format(new Date());
			List<MaterialsSearchField> searchList = MaterialsSearchUtil.getFilterFields(form);
			for (MaterialsSearchField searchField : searchList) {
				if ("orderLineType".equalsIgnoreCase(searchField.getFieldName())
						&& isNotNullandEmpty(searchField.getFiltervalues())) {

					orderLineType = searchField.getFiltervalues();
				}
			}
			log.info("orderLineType" + orderLineType);

			if (ORDERS.equalsIgnoreCase(orderLineType)) {
				fileName = fileName + NEW_ORDER + dateFormat + ".csv";
			} else if (RETURNS.equalsIgnoreCase(orderLineType)) {
				fileName = fileName + NEW_RETURN + dateFormat + ".csv";
			} else {
				fileName = "Orders.csv";
			}

		}
		return materialsAppUtil.buildResponse(csvResp.getBytes(), fileName);
	}


	/**
	 * This method will return Order List
	 * @param strSSO
	 * @param portalId
	 * @param form
	 * @param arrayList
	 * @param iDisplayStart
	 * @param iDisplayLength
	 * @param csvExportFlag
	 * @param icaoCode
	 * @param custCodes
	 * @return OrderListResponse object
	 * @throws MaterialsException
	 */
	private OrderListResponse getMaterialsOrderList(String strSSO, String portalId, MultivaluedMap<String, String> form,
			ArrayList<OrderExportCSVList> arrayList, String iDisplayStart, String iDisplayLength, boolean csvExportFlag,
			String icaoCode, String custCodes) throws MaterialsException {
		log.info("Entered getMaterialsOrderList :: ");
		OrderListResponse materialsOrderListResponse = new OrderListResponse();
		List<MaterialsSearchField> searchList = MaterialsSearchUtil.getFilterFields(form);
		List<MaterialsSortField> sortList = MaterialsSearchUtil.getSortFilterFields(form);
		MaterialsOrderRequest materialsOrderRequest = materialsAppUtil.getFilterParamsForDB(searchList, icaoCode,
				custCodes, sortList);
		try {
			materialsOrderListResponse = materialsOrdersDAO.materialsOrderListDS(materialsOrderRequest, portalId);
		} catch (TechnicalException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}
		return materialsOrderListResponse;
	}
	
	/**
	 * Return CSV file with Order Details
	 * @param sso
	 * @param portalId
	 * @param msNumber
	 * @param deliveryId
	 * @param orderHeaderId
	 * @param invoiceHeaderId
	 * @return Response
	 * @throws MaterialsException
	 */
	@Override
	public Response getcsvFile(String sso, String portalId, String msNumber, String deliveryId, String orderHeaderId,
			String invoiceHeaderId) throws MaterialsException {
		List<String> stripedCols = new ArrayList<String>();
		//FileWriter writer = null;
		//BufferedReader reader = null;
		File file = null;
		byte[] fileBytes = null;
		String filename = EMPTY_STRING;
		String normalizedFilename = EMPTY_STRING;
		String outputFilename = EMPTY_STRING;
		try {
			OrderHeaderDetails orderHeaderDetails = getHeaderDetailBS(sso, portalId, msNumber, deliveryId,
					orderHeaderId, invoiceHeaderId);
			OrderHeaderInfoBO orderHeaderInfoBO = orderHeaderDetails.getOrderHeaderInfoBO();
			List<ColumnGroupBO> columnGroupList = orderHeaderDetails.getColumnGroupBO();
			List<ColumnBO> columnBOList = orderHeaderDetails.getColumnList();
			List<String> columns = new ArrayList<String>();
			Map<String, String> colMap = new HashMap<String, String>();
			List<String> csvColOrderList = new ArrayList<String>();
			for (ColumnGroupBO colgrp : columnGroupList) {
				if ("Main".equals(colgrp.getGroupName())) {
					csvColOrderList = colgrp.getColumnIds();
				}
			}
			for (ColumnGroupBO columnGroupBO : columnGroupList) {
				columns.addAll(columnGroupBO.getColumnIds());
			}
			for (ColumnBO columnBO : columnBOList) {
				colMap.put(columnBO.getColumnId(), columnBO.getColumnName());
			}
			Set<String> distinctCols = new HashSet<>(columns);
			List<String> remainCols = new ArrayList<>();

			if (isNotNullandEmpty(orderHeaderId)) {
				filename = PURCHASE_ORDER_UNDERSCORE + CSV;
				outputFilename = PURCHASE_ORDER_UNDERSCORE + orderHeaderInfoBO.getCustomerPONumber() + CSV;
				normalizedFilename = Normalizer.normalize(filename, Form.NFC);
				file = new File(normalizedFilename);
				try(FileWriter writer = new FileWriter(file)){
					writer.append("\"Purchase Order Number\",\"").append(orderHeaderInfoBO.getCustomerPONumber())
							.append(NEWLINE);
					writer.append("\"Order Date\",\"").append(orderHeaderInfoBO.getOrderedDate())
							.append("\",\"Customer Code\",\"").append(orderHeaderInfoBO.getCustomerCode()).append("\"\n");
					writer.append("\"Order Type\",\"").append(orderHeaderInfoBO.getOrderType())
							.append("\",\"Customer Name\",\"").append(orderHeaderInfoBO.getCustomerName()).append("\"\n");
					writer.append("\"Order Status\",\"").append(orderHeaderInfoBO.getOrderStatus())
							.append("\",\"Supplier Code\",\"").append(orderHeaderInfoBO.getSupplierCode()).append(NEWLINE);
				} catch(Exception e){
					log.error(e);
				}				
			} else if (isNotNullandEmpty(msNumber) && isNotNullandEmpty(deliveryId)) {

				filename = SHIPMENT_UNDERSCORE + CSV;
				outputFilename = SHIPMENT_UNDERSCORE + msNumber + CSV;
				normalizedFilename = Normalizer.normalize(filename, Form.NFC);
				file = new File(normalizedFilename);
				try(FileWriter writer = new FileWriter(file)){
					String shipAddress = orderHeaderInfoBO.getShipToLocation().replaceAll(",", "-");
					String deliverAddress = orderHeaderInfoBO.getDeliverToLocation().replaceAll(",", "-");
					String shipAddress1 = orderHeaderInfoBO.getShipToAddress_1().replaceAll(",", "-");
					String deliverAddress1 = orderHeaderInfoBO.getDeliverToAddress_1().replaceAll(",", "-");
					String shipAddress2 = orderHeaderInfoBO.getShipToAddress_2().replaceAll(",", "-");
					String deliverAddress2 = orderHeaderInfoBO.getDeliverToAddress_2().replaceAll(",", "-");
					String shipAddress3 = orderHeaderInfoBO.getShipToAddress_3().replaceAll(",", "-");
					String deliverAddress3 = orderHeaderInfoBO.getDeliverToAddress_3().replaceAll(",", "-");
					String shipAddress4 = orderHeaderInfoBO.getShipToAddress_4().replaceAll(",", "-");
					String deliverAddress4 = orderHeaderInfoBO.getDeliverToAddress_4().replaceAll(",", "-");
					String shipAddress5 = orderHeaderInfoBO.getShipToAddress_5().replaceAll(",", "-");
					String deliverAddress5 = orderHeaderInfoBO.getDeliverToAddress_5().replaceAll(",", "-");
					log.info(orderHeaderInfoBO.getShipmentDate());
					writer.append("\"Shipping Details\"\n\n");
					writer.append("\"Shipment Date\",\"").append(orderHeaderInfoBO.getShipmentDate())
							.append("\",\"Ship To\",\"").append(shipAddress + "\"");
					writer.append("\",\"Deliver To\",\"").append(deliverAddress).append("\"\n").append("\"MS Number\",\"")
							.append(msNumber).append(SLASH_PATTERN).append(shipAddress1).append(SLASH_PATTERN).append(deliverAddress1)
							.append("\"\n");
					writer.append("\"Airway Bill No\",\"").append(orderHeaderInfoBO.getAirWayBillNumber()).append(SLASH_PATTERN)
							.append(shipAddress2).append(SLASH_PATTERN).append(deliverAddress2).append("\"\n")
							.append("\"Warehouse Code\",\"").append(orderHeaderInfoBO.getWarehouseCode()).append("\",,");
					writer.append("\"" + shipAddress3 + "\"").append(",,\"").append(deliverAddress3).append(NEWLINE_SLASH_PATTERN)
							.append(shipAddress4).append(SLASH_PATTERN).append(deliverAddress4).append("\"\n,,,");
					writer.append("\"" + shipAddress5 + "\"").append(",,\"").append(deliverAddress5).append(NEWLINE);
				} catch(Exception e){
					log.error(e);
				} 			
			} else if (isNotNullandEmpty(invoiceHeaderId)) {
				filename = INVOICE_UNDERSCORE + CSV;
				outputFilename = INVOICE_UNDERSCORE + orderHeaderInfoBO.getInvoiceNumber() + CSV;
				normalizedFilename = Normalizer.normalize(filename, Form.NFC);
				file = new File(normalizedFilename);
				try(FileWriter writer = new FileWriter(file)){
					String address = orderHeaderInfoBO.getInvoiceToLocation().replaceAll(",", "-");
					String address1 = orderHeaderInfoBO.getInvoiceToAddress_1().replaceAll(",", "-");
					String address2 = orderHeaderInfoBO.getInvoiceToAddress_2().replaceAll(",", "-");
					String address3 = orderHeaderInfoBO.getInvoiceToAddress_3().replaceAll(",", "-");
					String address4 = orderHeaderInfoBO.getInvoiceToAddress_4().replaceAll(",", "-");
					String address5 = orderHeaderInfoBO.getInvoiceToAddress_5().replaceAll(",", "-");

					writer.append("\"Invoice Details\"\n\n");
					writer.append("\"Invoice Number\",\"").append(orderHeaderInfoBO.getInvoiceNumber())
							.append("\",Invoicing Address,\"").append(address).append("\"\n");
					writer.append("\"Invoice Date\",\"").append(orderHeaderInfoBO.getInvoiceDate()).append(SLASH_PATTERN)
							.append(address1).append("\"\\n").append("\"Invoice Value\",\"")
							.append(orderHeaderInfoBO.getInvoiceTotalAmount()).append(SLASH_PATTERN)
							.append("\"" + address2 + "\"").append("\"\n,,,").append(address3).append(NEWLINE_SLASH_PATTERN)
							.append(address4).append(NEWLINE_SLASH_PATTERN).append(address5).append(NEWLINE);
				} catch(Exception e){
					log.error(e);
				}			
			}

			HttpClient client = new HttpClient();
			PostMethod method = new PostMethod(lineDetailsServiceUrl);
			method.addRequestHeader("sm_ssoId", sso);
			method.addRequestHeader("portal_Id", portalId);
			if (isNotNullandEmpty(orderHeaderId))
				method.addParameter("orderHeaderId", orderHeaderId);
			else if (isNotNullandEmpty(invoiceHeaderId))
				method.addParameter("invoiceHeaderId", invoiceHeaderId);
			else {
				method.addParameter("msNumber", msNumber);
				method.addParameter("deliveryId", deliveryId);
			}
			method.addParameter("iDisplayStart", "0");
			method.addParameter("iDisplayLength", "0");
			client.executeMethod(method);
			String jsonString = method.getResponseBodyAsString();
			if (isNotNullandEmpty(jsonString)) {
				Pattern myPattern = Pattern.compile("\\[(.*)\\]");
				Matcher m = myPattern.matcher(jsonString);
				while (m.find()) {
					jsonString = m.group(1);
				}
				jsonString = '[' + jsonString + ']';
				JSONArray jsonArray = new JSONArray(jsonString);
				String csv = CDL.toString(jsonArray);
				String line = null;
				try(BufferedReader reader = new BufferedReader(new StringReader(csv))){
					line = reader.readLine();
				} catch(Exception e){
					log.error(e);
				} 				
				String[] csvCols = line.split(",");
				for (String col : csvCols) {
					if (!distinctCols.contains(col)) {
						stripedCols.add(col);
					} else
						remainCols.add(col);
				}
				for (int i = 0; i < jsonArray.length(); i++) {
					JSONObject jobject = jsonArray.getJSONObject(i);
					for (String col : stripedCols) {
						jobject.remove(col);
					}
					for (int j = 0; j < remainCols.size(); j++) {
						if (jobject.isNull(remainCols.get(j))) {
							jobject.remove(remainCols.get(j));
							jobject.put(remainCols.get(j), new String(""));
						}
					}
				}
				
				//  US274565: myGEA/myCFM/geHonda: Hide field 'Shipping Status' from UI
				Iterator<String> colIdIter = csvColOrderList.iterator();
				while(colIdIter.hasNext()) {
					  String colId = colIdIter.next();
					  if ("shippingStatus".equals(colId)) {
						  colIdIter.remove();
					  }
				}
				
				Iterator<ColumnBO> colIter = columnBOList.iterator();
				while(colIter.hasNext()) {
					ColumnBO col = (ColumnBO) colIter.next();
					if ("shippingStatus".equals(col.getColumnId())) {
						colIter.remove();
					}
				}
					
				File fileAppended = getCsvOrderListFileAppend(file, csvColOrderList, columnBOList, jsonArray);
				fileBytes = materialsAppUtil.getBytesFromFile(fileAppended);
				file.delete();
			}
		} catch (Exception e) {
			log.error(e);
		}
		return materialsAppUtil.buildResponse(fileBytes, outputFilename);
	}
	
	
	
	
	private File getCsvOrderListFileAppend(File file, List<String> csvColOrderList, List<ColumnBO> columnBOList, JSONArray jsonArray){
		try(FileWriter writer = new FileWriter(file)){
			for (String colname : csvColOrderList) {
				for (ColumnBO columnBO : columnBOList)
					if (columnBO.getColumnId().equals(colname))
						writer.append("\"" + columnBO.getColumnName() + "\"").append(",");
			}
			for (int i = 0; i < jsonArray.length(); i++) {
				writer.append("\n");
				JSONObject jobject = jsonArray.getJSONObject(i);
				for (String colname : csvColOrderList) {
					writer.append("\"" + jobject.get(colname).toString().replaceAll(",", "-").replaceAll("\\[", "")
							.replaceAll("\\]", "").replaceAll("\"", "") + "\"").append(",");
				}
			}
			writer.flush();
		} catch(Exception e){
			log.error(e);
		}
		return file;	
	}
	
	/**
	 * Get Materials document
	 * @param strSSO
	 * @param portalId
	 * @param msNumber
	 * @param docType
	 * @param deliveryId
	 * @param invoiceId
	 * @param notificationFlag
	 * @return Response
	 * @throws MaterialsException
	 */
	@Override
	public Response getMaterialsDocumentBS(String strSSO, String portalId, String msNumber, String docType,
			String deliveryId, String invoiceId, String notificationFlag) throws MaterialsException {
		Response response = null;
		OrderHeaderDetails orderHeaderDetails = null;
		CustLoginDetails custLoginDetails = null;
		WccFileBO wccShipDoc = null;
		OrderHeaderInfoBO orderHeaderInfoBO = null;
		byte[] invoiceDoc = null;
		custLoginDetails = materialsAppUtil.getCustLoginDetails(strSSO, portalId);
		// start getHeaderDetailDS call
		try {
			orderHeaderDetails = materialsOrdersDAO.getHeaderDetailDS(strSSO, custLoginDetails.getIcaoCode(),
					custLoginDetails.getCustIdList(), custLoginDetails.getRole(), custLoginDetails.getOperatingUnitId(),
					msNumber, deliveryId, null, invoiceId);
		} catch (TechnicalException e) {
			log.info(e);
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8339,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8339), ERR_AUTHORISED_ACCESS);
		}
		// end getHeaderDetailDS call
		if (orderHeaderDetails.getOrderHeaderInfoBO() != null) {
			orderHeaderInfoBO = orderHeaderDetails.getOrderHeaderInfoBO();
			if (orderHeaderInfoBO.getCustomerCode() != null) {
				if (INVOICE_DOC_DESC.equals(docType)) {
					try {
						invoiceDoc = materialsOrdersDAO.getInvoiceDocDS(strSSO, orderHeaderInfoBO.getInvoiceNumber());
					} catch (TechnicalException e) {
						log.info(e);
						throw new MaterialsException(MaterialsErrorCodes.ERROR_8340,
								materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8340),
								ERR_DOCUMENT_NOT_FOUND);
					}
					if (invoiceDoc != null) {
						response = materialsAppUtil.buildResponse(invoiceDoc, docType,
								docType + UNDERSCORE + invoiceId + PDF_EXTENSION);
					} else {
						throw new MaterialsException(MaterialsErrorCodes.ERROR_8340,
								materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8340),
								ERR_DOCUMENT_NOT_FOUND);
					}

				} else {
					try {
						//WCC stands for Oracle Web Center Content server
						//MS/FAA documents are being migrated from DSD to Web Center so we need to retrieve them from WCC
						wccShipDoc = materialsOrdersDAO.getWccShipDoc(msNumber, materialsAppUtil.convertShipDocTypeToWccDocType(docType), orderHeaderInfoBO.getCustomerCode(), orderHeaderInfoBO.getShipmentDate());
						
					} catch (TechnicalException e) {
						log.info(e);
						throw new MaterialsException(MaterialsErrorCodes.ERROR_8342,
								materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8342), e.getMessage());
					}
					
					if(wccShipDoc.getFileContent() == null) {
						throw new MaterialsException(MaterialsErrorCodes.ERROR_8457,
								materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8457), ERR_DOCUMENT_NOT_FOUND);
					}
					
					response = materialsAppUtil.buildResponse(wccShipDoc.getFileContent(), docType, wccShipDoc.getFileName());
				}
			} else {
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8339,
						materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8339), ERR_AUTHORISED_ACCESS);
			}
		} else {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8339,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8339), ERR_AUTHORISED_ACCESS);
		}
		return response;
	}
		
	
	private Response buildMSFaaDocStatusBS(String strSSO, MaterialsDocumentDetails materialDocURL, String docType) throws MaterialsException{
		String userId = EMPTY_STRING;
		String emailId = EMPTY_STRING;
		int status = 0;
		Response response = null;
		MsFaaDocStatusBS msFaaDocStatusBS = null;
		// call portal service to get the userId & userEmail
		try {
			userId = materialsAppUtil.getUserId(strSSO);
			emailId = materialsAppUtil.getEmailId(strSSO);
			if (isNullOrEmpty(userId) || isNullOrEmpty(emailId)) {
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8341,
						materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8341),
						ERR_USER_MAILING_DETAILS);
			}
			if (materialsOrdersDAO.isMSDocRequestExist(materialDocURL.getDocNumber(),
					materialDocURL.getDocTypeCd(), emailId)) {
				status = materialsOrdersDAO.requestEmailMaterialsDocDS(docType,
						materialDocURL.getDocNumber(), materialDocURL.getDocVersion(), userId, emailId);
			} else {
				String phoneAndEmailId = EMPTY_STRING;
				String statusMsg = EMPTY_STRING;
				msFaaDocStatusBS = new MsFaaDocStatusBS();
				phoneAndEmailId = materialsAppUtil.getPropertyValue(AOC);
				statusMsg = ERR_EMAIL_REQ_MSG.replaceAll(AOC_PLACEHOLDER, phoneAndEmailId);
				msFaaDocStatusBS.setDisplayMessage(statusMsg);
				response = Response.ok(msFaaDocStatusBS).build();
				return response;
			}
		} catch (TechnicalException e) {
			log.info(e);
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8341,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8341),
					ERR_USER_MAILING_DETAILS);
		}
		if (status == 1) {
			String phoneAndEmailId = EMPTY_STRING;
			String statusMsg = EMPTY_STRING;
			msFaaDocStatusBS = new MsFaaDocStatusBS();
			phoneAndEmailId = materialsAppUtil.getPropertyValue(AOC);
			statusMsg = ERR_EMAIL_REQUEST.replaceAll(AOC_PLACEHOLDER, phoneAndEmailId);
			msFaaDocStatusBS.setDisplayMessage(statusMsg);
			response = Response.ok(msFaaDocStatusBS).build();
			return response;
		} else {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8340,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8340),
					ERR_DOCUMENT_NOT_FOUND);
		}
	}
	
	
	private Response buildEmailMSDoc(String folder, String fileName,String docType, MaterialsDocumentDetails materialDocURL, String notificationFlag, String strSSO, String portalId) throws MaterialsException{
		byte[] bytes = null;
		try {
			log.info("Folder Name : "+ folder+ "File name : "+fileName);
			
			
			GridFSFile gridFSFile = materialsDAO.getFaaMsDoc(folder, fileName);
			
				if (gridFSFile == null) {

					throw new MaterialsException(MaterialsErrorCodes.ERROR_8340,
							materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8340),
							ERR_DOCUMENT_NOT_FOUND);
				} else {

					bytes = materialsDAO.getFileDataFully(gridFSFile.getObjectId(), "artifactsDoc");

				}

			
			String msDocNumber = materialDocURL.getDocNumber();
			if ("YES".equalsIgnoreCase(notificationFlag)) {
				materialsAppUtil.generateEmailMsDocs(strSSO, portalId, bytes, fileName, msDocNumber);
			}
		} catch (Exception e) {
			log.info("Exception occured in MS docType" + e);
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8340,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8340),
					ERR_DOCUMENT_NOT_FOUND);
		}
		Response response = materialsAppUtil.buildResponse(bytes, docType, fileName);
		return response;
	}
	
	
	/**
	 * Get Order Details in PDF file format
	 * @param sso
	 * @param portalId
	 * @param orderHeaderId
	 * @return DisputeDocumentBO object
	 * @throws MaterialsException
	 */
	@Override
	public DisputeDocumentBO getPDFFile(String sso, String portalId, String orderHeaderId) throws MaterialsException {
		DisputeDocumentBO documentBO = null;
		String fileName = EMPTY_STRING;
		ByteArrayOutputStream byteArrayOutput = new ByteArrayOutputStream();
		String deliverToAddress = EMPTY_STRING;
		String shipToAddress = EMPTY_STRING;
		boolean isPartPriced = true;
		boolean discountFlag = true;
		try {
			if (isNotNullandEmpty(orderHeaderId)) {
				documentBO = new DisputeDocumentBO();
				OrderHeaderDetails orderHeaderDetails = getHeaderDetailBS(sso, portalId, null, null, orderHeaderId,
						null);
				OrderHeaderInfoBO orderHeaderInfoBO = orderHeaderDetails.getOrderHeaderInfoBO();
				LineDetailBO lineDetailBO = materialsAppImpl.getLineDetailBS(sso, portalId, null, null, orderHeaderId, null,
						new ArrayList<MaterialsSortField>(), 0, 0);
				List<LineInfoBO> lineInfoBOList = lineDetailBO.getOrderLineList();
				String totalOrderValue = orderHeaderInfoBO.getTotalOrderValue();
				String totalDiscount = orderHeaderInfoBO.getTotalDiscount();
				String totalOrderLbl = PURCHASE_ORDER_TOTAL_ORDER_VALUE;
				String totalDiscoutLbl = PURCHASE_ORDER_TOTAL_DISCOUNT;
				if (isNullOrEmpty(totalDiscount) || "0".equals(totalDiscount)) {
					discountFlag = false;
				}
				List<LineInfoBO> lineInfoBOListNew = null;
				if (isCollectionNotEmpty(lineInfoBOList)) {
					lineInfoBOListNew = getLineInfoBOList(lineInfoBOList, isPartPriced);
				
				}
				fileName = orderHeaderDetails.getOrderHeaderInfoBO().getCustomerPONumber() + UNDERSCORE
						+ materialsAppUtil.getCurrentDateAsYYYYMMDD() + PDF_EXTENSION;
				Document doc = new Document(PageSize.A4, 25, 25, 25, 25);
				PdfWriter.getInstance(doc, byteArrayOutput);
				doc.open();
				Image image = null;
				
				String logoPath = LOGO_PATH + portalId.toLowerCase() + PO_CONFIRM_LOGO;
				Resource logoResource = new ClassPathResource(logoPath);
				String geLogoPath = LOGO_PATH + GE_LOGO;
				Resource geLogoResource = new ClassPathResource(geLogoPath);
				
				byte[] imageBytes = null;
				try {
					imageBytes = IOUtils.toByteArray(logoResource.getInputStream());
					image = Image.getInstance(imageBytes);
				} catch (IOException e) {
					log.info(e);
					try {
						imageBytes = IOUtils.toByteArray(geLogoResource.getInputStream());
						image = Image.getInstance(imageBytes);
					} catch (IOException ioException) {
						log.info(ioException);
					}					
				}
				
				if (CWC_PID.equalsIgnoreCase(portalId)) {
					image.scalePercent(40);
				}
				if (GEHONDA_PID.equalsIgnoreCase(portalId)) {
					image.scalePercent(40);
				}
				image.setBorder(Rectangle.NO_BORDER);
				image.setAlignment(Element.ALIGN_RIGHT);

				Font fontContent = new Font(FontFamily.HELVETICA, 8, Font.NORMAL, new BaseColor(64, 64, 64));
				Font fontContentBold = new Font(FontFamily.HELVETICA, 8, Font.BOLD, new BaseColor(64, 64, 64));
				Font fontHeadline = new Font(FontFamily.HELVETICA, 8, Font.BOLD, new BaseColor(0, 0, 255));

				Font disclaimerFont = new Font(FontFamily.HELVETICA, 7, Font.NORMAL, new BaseColor(152, 0, 0));
				Font noteFont = new Font(FontFamily.HELVETICA, 7, Font.ITALIC, new BaseColor(152, 152, 152));

				Chunk chunk = new Chunk("Purchase Order #: ", fontContent);
				Chunk chunkValue = new Chunk(orderHeaderInfoBO.getCustomerPONumber(), fontContentBold);
				Phrase phrasePONum = new Phrase();
				phrasePONum.add(chunk);
				phrasePONum.add(chunkValue);

				Chunk chunkOrderDt = new Chunk("Ordered Date: ", fontContent);
				Chunk chunkOrderDtValue = new Chunk(materialsAppUtil.getFormattedDate(
						orderHeaderInfoBO.getOrderedDate(), DATE_FORMAT1, "MMM-dd-yyyy"), fontContentBold);
				Phrase phraseOrderDt = new Phrase();
				phraseOrderDt.add(chunkOrderDt);
				phraseOrderDt.add(chunkOrderDtValue);

				Chunk chunkPricingNoteSuper = new Chunk(ASTERISK + ASTERISK, disclaimerFont);
				chunkPricingNoteSuper.setTextRise(5f);
				Chunk chunkOrder = new Chunk(totalOrderLbl, fontContent);
				Chunk chunkOrderValue = new Chunk(materialsAppUtil.getCurrencyFormattedValue(totalOrderValue),
						fontContentBold);
				Phrase phraseOrder = new Phrase();
				if (!isPartPriced) {
					phraseOrder.add(chunkPricingNoteSuper);
				}
				phraseOrder.add(chunkOrder);
				phraseOrder.add(chunkOrderValue);

				Chunk chunkDiscount = new Chunk(totalDiscoutLbl, fontContent);
				Chunk chunkDiscountValue = new Chunk(totalDiscount, fontContentBold);
				Phrase phraseDiscount = new Phrase(50);
				if (!isPartPriced) {
					phraseDiscount.add(chunkPricingNoteSuper);
				}
				phraseDiscount.add(chunkDiscount);
				phraseDiscount.add(chunkDiscountValue);

				Chunk chunkPODetails = new Chunk(PURCHASE_ORDER_MAIL_MESSAGE, fontContentBold);
				Phrase phrasePODetails = new Phrase();
				phrasePODetails.add(chunkPODetails);

				Chunk chunkPricingNote = new Chunk(PURCHASE_ORDER_PRICING_NOTE, noteFont);
				Phrase phrasePriceNote = new Phrase(50f);
				phrasePriceNote.add(chunkPricingNoteSuper);
				phrasePriceNote.add(chunkPricingNote);

				Map<String, String> addressMap = null;
				addressMap = new HashMap<String, String>();
				addressMap.put("SHIP_TO_LOCATION", orderHeaderInfoBO.getShipToLocation());
				addressMap.put("SHIP_ADDRESS_1", orderHeaderInfoBO.getShipToAddress_1());
				addressMap.put("SHIP_ADDRESS_2", orderHeaderInfoBO.getShipToAddress_2());
				addressMap.put("SHIP_ADDRESS_3", orderHeaderInfoBO.getShipToAddress_3());
				addressMap.put("SHIP_ADDRESS_4", orderHeaderInfoBO.getShipToAddress_4());
				addressMap.put("SHIP_ADDRESS_5", orderHeaderInfoBO.getShipToAddress_5());
				addressMap.put("DELVR_TO_LOCATION", orderHeaderInfoBO.getDeliverToLocation());
				addressMap.put("DELVR_ADDRESS_1", orderHeaderInfoBO.getDeliverToAddress_1());
				addressMap.put("DELVR_ADDRESS_2", orderHeaderInfoBO.getDeliverToAddress_2());
				addressMap.put("DELVR_ADDRESS_3", orderHeaderInfoBO.getDeliverToAddress_3());
				addressMap.put("DELVR_ADDRESS_4", orderHeaderInfoBO.getDeliverToAddress_4());
				addressMap.put("DELVR_ADDRESS_5", orderHeaderInfoBO.getDeliverToAddress_5());

				shipToAddress = materialsAppUtil.makeShipToAddressString(addressMap);
				deliverToAddress = materialsAppUtil.makeDeliverToAddressString(addressMap);

				Paragraph para = new Paragraph();
				PdfPTable addressTable = null;
				if (isNotNullandEmpty(deliverToAddress)) {
					addressTable = new PdfPTable(2);
					insertCell(addressTable, "Ship To", Element.ALIGN_CENTER, 1, fontHeadline);
					insertCell(addressTable, "Deliver To", Element.ALIGN_CENTER, 1, fontHeadline);
					insertCell(addressTable, shipToAddress, Element.ALIGN_LEFT, 1, fontContent);
					insertCell(addressTable, deliverToAddress, Element.ALIGN_LEFT, 1, fontContent);
				} else {
					addressTable = new PdfPTable(1);
					insertCell(addressTable, "Ship To", Element.ALIGN_CENTER, 1, fontHeadline);
					insertCell(addressTable, shipToAddress, Element.ALIGN_LEFT, 1, fontContent);
				}
				addressTable.setHorizontalAlignment(Element.ALIGN_LEFT);
				addressTable.setWidthPercentage(50f);
				PdfPTable lineDetailTable = null;
				if (discountFlag) {
					lineDetailTable = new PdfPTable(9);
				} else {
					lineDetailTable = new PdfPTable(8);
				}
				lineDetailTable.setWidthPercentage(100f);
				lineDetailTable.setSpacingAfter(10f);
				insertCell(lineDetailTable, "PO Line #", Element.ALIGN_CENTER, 1, fontHeadline);
				insertCell(lineDetailTable, "Part Number", Element.ALIGN_CENTER, 1, fontHeadline);
				insertCell(lineDetailTable, "Keyword", Element.ALIGN_CENTER, 1, fontHeadline);
				insertCell(lineDetailTable, "Ordered Qty.", Element.ALIGN_CENTER, 1, fontHeadline);
				insertCell(lineDetailTable, "Req.Date", Element.ALIGN_CENTER, 1, fontHeadline);
				insertCell(lineDetailTable, "List Price", Element.ALIGN_CENTER, 1, fontHeadline);
				insertCell(lineDetailTable, "Selling Price", Element.ALIGN_CENTER, 1, fontHeadline);
				if (discountFlag) {
					insertCell(lineDetailTable, "Discount %", Element.ALIGN_CENTER, 1, fontHeadline);
				}
				insertCell(lineDetailTable, "Ext Price", Element.ALIGN_CENTER, 1, fontHeadline);

				for (LineInfoBO lineInfoBO : lineInfoBOListNew) {
					insertCell(lineDetailTable, lineInfoBO.getCustomerLineNumber(), Element.ALIGN_CENTER, 1,
							fontContent);
					insertCell(lineDetailTable, lineInfoBO.getOrderedItem(), Element.ALIGN_CENTER, 1, fontContent);
					insertCell(lineDetailTable, lineInfoBO.getKeyword(), Element.ALIGN_CENTER, 1, fontContent);
					insertCell(lineDetailTable, lineInfoBO.getOrderedQuantity(), Element.ALIGN_CENTER, 1, fontContent);
					insertCell(lineDetailTable,
							materialsAppUtil.getFormattedDate(lineInfoBO.getRequestDate(), DATE_FORMAT1, "MMM-dd-yyyy"),
							Element.ALIGN_CENTER, 1, fontContent);
					insertCell(lineDetailTable,
							materialsAppUtil.getCurrencyFormattedValue(lineInfoBO.getUnitListPrice()),
							Element.ALIGN_RIGHT, 1, fontContent);
					insertCell(lineDetailTable,
							materialsAppUtil.getCurrencyFormattedValue(lineInfoBO.getUnitSellingPrice()),
							Element.ALIGN_RIGHT, 1, fontContent);
					if (discountFlag) {
						insertCell(lineDetailTable, lineInfoBO.getDiscountPercent(), Element.ALIGN_CENTER, 1,
								fontContent);
					}
					insertCell(lineDetailTable,
							materialsAppUtil.getCurrencyFormattedValue(lineInfoBO.getExternalPrice()),
							Element.ALIGN_RIGHT, 1, fontContent);
				}

				para.add(phrasePONum);
				para.add(Chunk.NEWLINE);
				para.add(phraseOrderDt);
				para.add(addressTable);
				para.add(phraseOrder);
				para.add(Chunk.NEWLINE);
				para.add(phraseDiscount);
				para.add(Chunk.NEWLINE);
				para.add(Chunk.NEWLINE);
				para.add(phrasePODetails);
				para.add(lineDetailTable);
				if (!isPartPriced) {
					para.add(phrasePriceNote);
				}
				doc.add(image);
				doc.add(para);
				doc.close();
				documentBO.setFileName(fileName);
				documentBO.setFileData(byteArrayOutput.toByteArray());
			} else {
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8343,
						materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8343),
						ERR_INSUFFICIENT_INPUTS);
			}
		} catch (TechnicalException e) {
			log.error(e);
		} catch (DocumentException e) {
			log.error(e);
		}
		return documentBO;
	}
	
	
	private List<LineInfoBO> getLineInfoBOList(List<LineInfoBO> lineInfoBOList, boolean isPartPriced){
		List<LineInfoBO> lineInfoBOListNew = new ArrayList<LineInfoBO>();
		for (LineInfoBO lineInfoObject : lineInfoBOList) {
			String iteCode = EMPTY_STRING;
			iteCode = lineInfoObject.getItemTypeCode();
			if (("STANDARD").equalsIgnoreCase(iteCode) || ("MODEL").equalsIgnoreCase(iteCode)) {
				String unitListPrice = lineInfoObject.getUnitListPrice();
				String unitSellPrice = lineInfoObject.getUnitSellingPrice();
				if (isNullOrEmpty(unitListPrice) || isNullOrEmpty(unitSellPrice)) {
					isPartPriced = false;
				}
				LineInfoBO lineInfoBONew = new LineInfoBO();
				BeanUtils.copyProperties(lineInfoObject, lineInfoBONew);
				lineInfoBOListNew.add(lineInfoBONew);
			}
		}
		return lineInfoBOListNew;
	}
	
	/**
	 * Inserts a cell into PDF Table
	 * @param table
	 * @param text
	 * @param align
	 * @param colspan
	 * @param font
	 */
	private static void insertCell(PdfPTable table, String text, int align, int colspan, Font font) {
		PdfPCell cell = new PdfPCell(new Phrase(text.trim(), font));
		cell.setHorizontalAlignment(align);
		cell.setColspan(colspan);
		if (("").equalsIgnoreCase(text.trim())) {
			cell.setMinimumHeight(10f);
		}
		table.addCell(cell);
	}
	
	
	/**
	 * @param bytes
	 * @param fileName
	 * @return Response
	 */
	private Response buildResponse(final byte[] bytes, String fileName) {
		log.info("filename" + fileName);
		StreamingOutput stream = null;
		stream = new StreamingOutput() {
			public void write(OutputStream out) throws IOException, WebApplicationException {
				try {
					out.write(bytes);
				} catch (Exception e) {
					log.error(e);
					throw new WebApplicationException(e);
				}
			}
		};
		if (bytes != null) {
			return Response.ok(stream).header("content-disposition", "attachment; filename = " + fileName).build();
		} else {

			return htmlErrorResponse(ERR_DOCUMENT_NOT_FOUND);
		}
	}
	
	/**
	 * @param message
	 * @return Response
	 */
	private Response htmlErrorResponse(String message) {
		ResponseBuilder rb = Response.noContent();
		rb = rb.type(MediaType.TEXT_HTML);
		rb = rb.status(Status.BAD_REQUEST);
		String finalMsg = HTML_MSG1 + message + HTML_MSG2;
		rb = rb.entity(finalMsg);
		return rb.build();
	}
	
	/**
	 * Get Order Details
	 * @param strSSO
	 * @param portalId
	 * @param headerId
	 * @return OrderDetailsBO object
	 * @throws MaterialsException
	 */
	@Override
	public OrderDetailsBO getOrderDetailsBS(String sso,String portalId,String headerId) throws MaterialsException
	{
		log.info(" <getOrderDetailsBS method> START  ");
		if(!isNotNullandEmpty(headerId)){
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8309, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8309), ERR_HEADER_ID_NOT_FOUND);
		}
		String role = EMPTY_STRING;
		String icaoCode = EMPTY_STRING;
		String operatingUnitId = EMPTY_STRING;
		String custId = EMPTY_STRING;
		OrderDO orderDO = null;
		MaterialsLoginResponse materialsLoginDetail = null;
		MaterialsUserBO materialsUserBO = null;
		List<CustomerBO> customerBOList = null;
		List<PriorityBO> priorityBO = null;
		OrderDetailsBO orderDetailsBO = new OrderDetailsBO();
		materialsLoginDetail = materialsLoginApp.requestMaterialsLogin(sso, portalId);
		if (materialsLoginDetail.getMaterialsUserBO() != null)
		{
			materialsUserBO = materialsLoginDetail.getMaterialsUserBO();
		}
		if (isNotNullandEmpty(materialsUserBO.getIcaoCode()))
		{
			icaoCode = materialsUserBO.getIcaoCode();
		}
		if (isNotNullandEmpty(materialsUserBO.getRole()))
		{
			role = materialsUserBO.getRole();
		}
		if(materialsUserBO.getCustomerBOList() != null && !materialsUserBO.getCustomerBOList().isEmpty()){
			customerBOList = materialsUserBO.getCustomerBOList();
		}

		if(customerBOList != null && !customerBOList.isEmpty())
		{
			for (CustomerBO customerBO : customerBOList) {
				custId = customerBO.getCustCode()+",";
				custId = custId.replace(custId.substring(custId.length()-1), EMPTY_STRING);
			}
		}
		if (isNotNullandEmpty( materialsUserBO.getOperatingUnitId()))
			operatingUnitId = materialsUserBO.getOperatingUnitId();
		try{
			orderDO =  materialsOrdersDAO.getOrderDetailsDS(sso, icaoCode, custId,role, operatingUnitId, headerId);
		} catch (TechnicalException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}

		if(isNotNullandEmpty(orderDO.getMessage())){
			materialsAppUtil.throwERPMessage(orderDO.getMessage());
		}
		orderDetailsBO.setCustCode(orderDO.getCustCode());
		orderDetailsBO.setCustName(orderDO.getCustName());
		orderDetailsBO.setOrderDt(materialsAppUtil.getFractionDateString(orderDO.getOrderDate()));
		orderDetailsBO.setOrderNumber(orderDO.getOrderNumber());
		orderDetailsBO.setOrderStatus(orderDO.getOrderStatus());
		orderDetailsBO.setCustId(orderDO.getCustId());
		orderDetailsBO.setHeaderId(headerId);	
		try{
			priorityBO = materialsOrdersDAO.getPriorityDS(sso,portalId);
		} catch (TechnicalException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}
		if(priorityBO != null && !priorityBO.isEmpty())
		{
			orderDetailsBO.setPriorityBO(priorityBO);	
		}
		else
		{ 
			//throwing normal prority error message for AEODP request (newly added)
			if((AERODP).equalsIgnoreCase(portalId))
			{
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8401, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8401),ERR_PRIORITY);
			}
			else
				
			{
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8307, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8307), ERR_PRIORITY_NOT_FOUND);
			}
		}
		log.info(" <getOrderDetailsBS method> END  ");
		return orderDetailsBO;
	}
}
