package com.geaviation.materials.app.api;

import java.util.List;

import org.apache.cxf.jaxrs.ext.multipart.Attachment;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;


import com.geaviation.materials.entity.OrderAuditHistoryBO;
import com.geaviation.materials.entity.OrderDetailsBO;
import com.geaviation.materials.entity.OrderHeaderDetails;
import com.geaviation.materials.entity.UpdateOrderRequestDetails;
import com.geaviation.materials.entity.UpdateOrderResponseDetails;
import com.geaviation.materials.entity.CustomerAdminDetailsBO;
import com.geaviation.materials.entity.DeleteOrderLineBO;
import com.geaviation.materials.entity.DisputeDocumentBO;
import com.geaviation.materials.entity.InvoiceDocDO;
import com.geaviation.materials.entity.LineDetailBO;
import com.geaviation.materials.entity.MaterialsSortField;
import com.geaviation.materials.entity.OrderStatusBO;
import com.geaviation.materials.entity.UpdateShipmentBO;
import com.geaviation.materials.exception.MaterialsException;

/**
 * @author 212582171
 *
 */
public interface IMaterialsOrdersApp {
	public OrderHeaderDetails getHeaderDetailBS(String smssoid,String portalid,String msNumber,String deliveryId,String orderHeaderId,String invoiceHeaderId) throws MaterialsException;
	public OrderAuditHistoryBO getOrderAuditHistoryBS(String strSSO, String portalId,String headerId) throws MaterialsException;
	public Response getOrderTemplateBS(String strSSO, String portalId) throws MaterialsException;
	public List<UpdateOrderResponseDetails> updateOrderBS(String strSSO,String portalId,List<UpdateOrderRequestDetails> updateOrderRequestList) throws MaterialsException;
	public DeleteOrderLineBO deleteOrderLineBS(String strSSO,String portalId,String headerId,String lineId) throws MaterialsException;
	public UpdateShipmentBO updateShipmentDetailsBS(String sso, String portalId, String updateType, String existingContent, String updatedContent, String customerId) throws MaterialsException;
	public OrderStatusBO uploadOrderTemplateBS(String smssoid,String portalid,String custCode,List<Attachment> orderTemplate) throws MaterialsException;
	public Response materialOrderListCsvExportBS(String strSSO,String portalId,MultivaluedMap<String, String> multiValmap,String icaoCode,String custCodes) throws MaterialsException;
	public Response getcsvFile(String sso, String portalId, String msNumber, String deliveryId, String orderHeaderId, String invoiceHeaderId)throws MaterialsException;
	InvoiceDocDO getInvoiceDocBS(String strSSO,String portalId,String invoiceId) throws MaterialsException;
	public Response getMaterialsDocumentBS(String strSSO,String portalId,String msNumber,String docType,String deliveryId,String invoiceId,String notificationFlag) throws MaterialsException;
	public DisputeDocumentBO getPDFFile(String sso, String portalId, String orderHeaderId)throws MaterialsException;
	public OrderDetailsBO getOrderDetailsBS(String userId,String portalId,String headerId) throws MaterialsException;
}
