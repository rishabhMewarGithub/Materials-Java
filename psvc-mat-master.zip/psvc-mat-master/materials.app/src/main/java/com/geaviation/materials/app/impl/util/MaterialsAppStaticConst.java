/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 13, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE,
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     MaterialsAppConstants.java
 * 
 * History        :  	Mar 13, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.app.impl.util;

import java.util.HashMap;
import java.util.Map;


public class MaterialsAppStaticConst {
	
    private MaterialsAppStaticConst() {
		
	}
    private static final Map<String, String> shipmentUpdateMap; 
	static{
		shipmentUpdateMap = new HashMap<String, String>();
		getShipmentupdatemap().put("GTA Issue", "There is a GTA issue reported. The details are given below.");
		getShipmentupdatemap().put("Ship Address Change", "There is a Ship to Address update reported. The details are given below.");
		getShipmentupdatemap().put("Deliver Address Change", "There is a Deliver to Address update reported. The details are given below.");
		getShipmentupdatemap().put("New Ship Address", "There is an addition of New Ship to Address reported. The details are given below.");
		getShipmentupdatemap().put("New Deliver Address", "There is an addition of New Deliver to Address reported. The details are given below.");
		getShipmentupdatemap().put("New Mapping", "There is a New Address Mapping reported. The details are given below.");
		getShipmentupdatemap().put("General", "There is an issue raised by the user. The details are given below.");
		
	}
	
    private static final Map<String, String> shipmentUpdateSubjectMap; 
	static{
		shipmentUpdateSubjectMap = new HashMap<String, String>();
		getShipmentupdatesubjectmap().put("GTA Issue", "GTA Review Request");
		getShipmentupdatesubjectmap().put("Ship Address Change", "Modified \"Ship To\" Address Request");
		getShipmentupdatesubjectmap().put("Deliver Address Change", "Modified \"Deliver To\" Address Request");
		getShipmentupdatesubjectmap().put("New Ship Address", "New \"Ship To\" Address Request");
		getShipmentupdatesubjectmap().put("New Deliver Address", "New \"Deliver To\" Address Request");
		getShipmentupdatesubjectmap().put("New Mapping", "New \"Address Mapping\" Request");
		getShipmentupdatesubjectmap().put("General", "General Query");
	}
	public static Map<String, String> getShipmentupdatesubjectmap() {
		return shipmentUpdateSubjectMap;
	}

	public static Map<String, String> getShipmentupdatemap() {
		return shipmentUpdateMap;
	}
}
