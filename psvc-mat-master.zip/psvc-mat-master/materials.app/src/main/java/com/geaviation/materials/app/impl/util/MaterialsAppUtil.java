/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 24, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     MaterialsAppUtil.java
 * 
 * History        :  	Mar 24, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.app.impl.util;

import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.APPWX_SCHED;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ATTR_USER_ORG;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.CHAR_PIPE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.COLON;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.COMMA;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.CONST_HTTP_GET;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.DISPUTE_DOCS_URL;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EMPTY_STRING;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_CODE_8167;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_CODE_8300;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_CODE_8400;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_DATE_FORMAT_NOT_CORRECT;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_DELIVERID_EXPECTED_WITH_MSNUM;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_DOCUMENT_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_INVOICEHRDRID_FOUND_WITH_MSNUM_AND_DELIVERID;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_INVOICEHRDRID_FOUND_WITH_ORDERHRDRID;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_MESSAGE_RB;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_MSNUM_EXPECTED_WITH_DELIVERID;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_ORDERHRDRID_FOUND_WITH_MSNUM_AND_DELIVERID;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_QUANTITY_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ICAO_CODE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.INVALID_DATE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.N;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ORDER_HEADER_ID;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ORDER_LINE_ID;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.RETURN_LBL_LOGO_DEFAULT;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.RETURN_LBL_LOGO_SUFFIX;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.THROUGH_AMPS;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.UNKNOWN_ERROR;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.Y;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.StreamingOutput;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections.comparators.ComparatorChain;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.phase.PhaseInterceptorChain;
import org.apache.cxf.transport.http.AbstractHTTPDestination;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONObject;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.app.impl.MaterialsLoginAppImpl;
import com.geaviation.materials.data.api.IMaterialsDAO;
import com.geaviation.materials.data.api.IMaterialsOrdersDAO;
import com.geaviation.materials.data.api.IMaterialsShipmentDAO;
import com.geaviation.materials.entity.CustLoginDetails;
import com.geaviation.materials.entity.CustomerBO;
import com.geaviation.materials.entity.DocumentDownloadBO;
import com.geaviation.materials.entity.EmailContentInputBO;
import com.geaviation.materials.entity.LineInfoBO;
import com.geaviation.materials.entity.MaterialsDocumentDetails;
import com.geaviation.materials.entity.MaterialsLoginResponse;
import com.geaviation.materials.entity.MaterialsOrderRequest;
import com.geaviation.materials.entity.MaterialsOrders;
import com.geaviation.materials.entity.MaterialsOrdersCFM;
import com.geaviation.materials.entity.MaterialsSearchField;
import com.geaviation.materials.entity.MaterialsSortField;
import com.geaviation.materials.entity.MaterialsUserBO;
import com.geaviation.materials.entity.OrderCFMListResponse;
import com.geaviation.materials.entity.OrderExportCSVList;
import com.geaviation.materials.entity.PriorityBO;
import com.geaviation.materials.entity.Property;
import com.geaviation.materials.entity.ReturnLabelDO;
import com.geaviation.materials.entity.User;
import com.geaviation.materials.exception.MaterialsErrorCodes;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;



@Configuration
@ConfigurationProperties
@EnableAutoConfiguration(exclude = DataSourceAutoConfiguration.class)
@Component
public class MaterialsAppUtil {
	@Autowired
	private MaterialsExceptionUtil materialsExceptionUtil;

	private static final String SM_HEADER = "sm_ssoid";
	private static final String PORTAL_ID = "portal_id";
	public static final String DATE_FORMAT1= "yyyy-MM-dd";
	public static final String DATE_FORMAT2= "dd-MMM-yyyy";
	public static final String USER="user/";
	private static final String DELIVERYDATE = "DELIVERY_DATE";

	public static final String PARAMETERS_STRING = "parameters";
	public static final String SSO_PATH_PARAMETER = "{sso}";
	
	public static final String REQUEST_DATE1_STRING= "requestDate";
	public static final String REQUEST_DATE2_STRING = "REQUEST_DATE";
	public static final String ORDERED_DATE_STRING = "ORDERED_DATE";
	public static final String SHIPMENT_DATE_STRING = "SHIPMENT_DATE";
	public static final String CUSTOMER_NUMBER_STRING  ="CUSTOMER_NUMBER";

	@Value("${PORTAL.URL}")
	private String portalBaseUrl;

	@Value("${ATTIVIO_SERVICES_URL}")
	private String attivioServicesURL;

	@Value("${DEPLOYED_ENVIRONMENT}")
	private String environment;

	@Value("${PORTAL_FROM_EMAIL_MAPPING}")
	private String emailMapping;

	@Value("${APP_OWNER_SSO}")
	private String appOwnerSSO;

	@Value("${PORTAL_PRIORITY_CODE_MAPPING}")
	private String portalToERPPriority;

	@Value("${PORTAL_APP_URL_MAPPING}")
	private String portalApplicationURL;
	
	@Value("{NOTIFICATION_SERVICE_URL}")
	private String notificationServiceUrl;
	
	@Value("${ASSET.URL}")
	private String assetBaseUrl;
	
	private static final String VALIDATE_ESN_ASSET_SERVICE = "ae/exists?esn=";

	@Autowired
	private IMaterialsDAO materialsDAO;
	@Autowired
	private IMaterialsOrdersDAO materialsOrdersDAO;

	@Autowired
	private MaterialsLoginAppImpl materialsLoginAppImpl;

	@Autowired
	private IMaterialsShipmentDAO materialsShipmentData;
	private static final Log LOG = LogFactory.getLog(MaterialsAppUtil.class);

	/**
	 * This method will get the ICAO Code from SSO and Portal Id
	 * 
	 * @param sso
	 * @param portalId
	 * @return IcaoCode string
	 */
	public String getIcaoCode(String sso, String portalId) {
	
	    LOG.info("getIcaoCode()-<START>");
        String icao = EMPTY_STRING;
        if("AERODP".equalsIgnoreCase(portalId)){
               HttpServletRequest req = (HttpServletRequest)PhaseInterceptorChain.getCurrentMessage().getExchange().getInMessage().get(AbstractHTTPDestination.HTTP_REQUEST);
               icao = StringEscapeUtils.escapeJava(Encode.forHtml(Normalizer.normalize(req.getHeader(ICAO_CODE), Form.NFC)));
        }else{
        	icao = getUserIcaoCode(sso, portalId, "user/orgid/");
        }
        LOG.info("ICAO:: "+icao+ "SSO"+sso+ "PORTAL ID"+portalId);
		LOG.info("getIcaoCode()-<END>");  
        return icao;
	}

	/**
	 * This method will retrieve ICAO cod from User uri
	 * 
	 * @param sso
	 * @param portalId
	 * @param path
	 * @return ICAO code as string
	 */
	public String getUserIcaoCode(String sso, String portalId, String path) {
		String userString = null;
		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
			headers.set(SM_HEADER, sso);
			headers.set(PORTAL_ID, portalId);
			HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
			String url = portalBaseUrl + path + "{sso}";
			Map<String, String> uriParams = new HashMap<>();
			uriParams.put("sso", sso);
			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url);
			SimpleClientHttpRequestFactory rf = (SimpleClientHttpRequestFactory) restTemplate.getRequestFactory();
			rf.setConnectTimeout(Integer.parseInt("5000"));
			userString = restTemplate
					.exchange(builder.buildAndExpand(uriParams).toUri(), HttpMethod.GET, entity, String.class)
					.getBody();
		}

		catch (Exception e) {
			LOG.error("Exception inside getUserDetailsItem: " + e.getMessage(), e);
		}

		return userString;
	}

	/**
	 * Returns true if the given string is not null and not empty
	 * 
	 * @param strData
	 * @return boolean
	 */
	public static boolean isNotNullandEmpty(final String strData) {
		boolean isValid = false;
		if (null != strData && !strData.trim().equals(EMPTY_STRING)) {
			isValid = true;
		}
		return isValid;
	}

	/**
	 * This method will check whether the passed collection is not null & not
	 * empty
	 * 
	 * @param list
	 * @return boolean
	 */
	public static boolean isCollectionNotEmpty(final Collection<? extends Object> list) {
		return (list != null && !list.isEmpty());
	}

	/**
	 * Method to retrieve use's Organization (Default Organization from portal)
	 * 
	 * @param strSso
	 * @param portalId
	 * @return defaultOrg
	 */
	public String getDefaultOrg(String strSso, String portalId) {
		String defaultOrg = EMPTY_STRING;
		LOG.info("SSO: " + strSso + "PORTAL ID: " + portalId);
		defaultOrg = getUserAttributes(strSso, portalId, ATTR_USER_ORG, "user/prop/");
		return defaultOrg;

	}


	/**
	 * This method will get User properties from UserBO object
	 * 
	 * @param sso
	 * @param portal
	 * @param prop
	 * @param path
	 * @return User attribute in string
	 */
	public String getUserAttributes(String sso, String portal, String prop, String path) {
		String userBO = null;
		String propValue = null;
		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.set(SM_HEADER, sso);
			headers.set(PORTAL_ID, portal);
			HttpEntity<String> entity = new HttpEntity<>(PARAMETERS_STRING, headers);
			String url = portalBaseUrl + path + "{prop}/{sso}";
			Map<String, String> uriParams = new HashMap<>();
			uriParams.put("sso", sso);
			uriParams.put("prop", prop);
			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url);
			SimpleClientHttpRequestFactory rf = (SimpleClientHttpRequestFactory) restTemplate.getRequestFactory();
			rf.setConnectTimeout(Integer.parseInt("5000"));
			userBO = restTemplate
					.exchange(builder.buildAndExpand(uriParams).toUri(), HttpMethod.GET, entity, String.class)
					.getBody();
			JSONObject jsonObject = new JSONObject(userBO);
			propValue = jsonObject.getJSONArray("userProperty").getJSONObject(0).getString("propValue");

		}

		catch (Exception e) {
			LOG.error("Exception inside getUserAttributes: " + e.getMessage(), e);

		}

		return propValue;
	}

	/**
	 * @param ex
	 * @throws MaterialsException
	 */
	public void throwAsBusinessException(Exception ex) throws MaterialsException {
		int errorCodeInt;
		String errorCd = EMPTY_STRING;
		String errorMessage = EMPTY_STRING;
		errorMessage = ex.getMessage();
		if (ex instanceof SQLException) {
			errorCd = getOracleErrorCode(errorMessage);
			errorCd = getPropertyValue(errorCd);
			errorCodeInt = Integer.parseInt(errorCd);
			throw new MaterialsException(errorCodeInt, materialsExceptionUtil.getErrorMessage(errorCodeInt),
					errorMessage);
		}
		throw new MaterialsException(MaterialsErrorCodes.ERROR_8400,
				materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8400), errorMessage);
	}

	/**
	 * @param errMsg
	 * @return Oracle error code
	 */
	private String getOracleErrorCode(String errMsg) {
		int start = 0;
		String errCode = EMPTY_STRING;
		if (errMsg.contains("ORA-")) {
			start = errMsg.indexOf("ORA-");
			errCode = errMsg.substring(start, start + 9);
		} else {
			LOG.info("ORACLE Error Code not available");
		}
		return errCode;
	}

	/**
	 * @param msgKey
	 * @return String
	 * @throws Exception
	 */
	public String getPropertyValue(String msgKey) throws MaterialsException {
		String msgVal = EMPTY_STRING;
		if (isNotNullandEmpty(msgKey)) {
			msgVal = getPropertyValue(msgKey, ERR_MESSAGE_RB);
		}
		return msgVal;
	}

	/**
	 * @param msgKey
	 * @param propertyFile
	 * @return String
	 * @throws Exception
	 */
	public String getPropertyValue(String msgKey, String propertyFile) throws MaterialsException {
		String msgVal = "Property entry not found for the key '" + msgKey + "'";
		ResourceBundle rb = null;
		try {
			rb = ResourceBundle.getBundle(propertyFile);
			if (isNotNullandEmpty(msgKey)) {
				msgVal = rb.getString(msgKey);
			}
		} catch (MissingResourceException mre) {
			LOG.info(mre);
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8400,
					materialsExceptionUtil.getErrorMessage(UNKNOWN_ERROR), msgVal);
		}
		return msgVal;
	}

	public void throwERPMessage(String message) throws MaterialsException {
		int errorCodeInt;
		String errorCd = EMPTY_STRING;
		String errorMessage = EMPTY_STRING;
		String[] parts = getErrorCdnMsg(message);
		errorCd = parts[0];
		errorMessage = parts[1];
		try {
			errorCodeInt = Integer.parseInt(errorCd);
		} catch (Exception e) {
			LOG.info(e);
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8400,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8400), message);
		}
		throw new MaterialsException(errorCodeInt, materialsExceptionUtil.getErrorMessage(errorCodeInt), errorMessage);
	}

	/**
	 * @param errCdnMsg
	 * @return String
	 */
	public String[] getErrorCdnMsg(String errCdnMsg) {
		int errorCodeInt = MaterialsErrorCodes.ERROR_8400;
		String[] errMsgArr = new String[2];
		if (isNotNullandEmpty(errCdnMsg) && errCdnMsg.contains(COLON)) {
			String[] parts = errCdnMsg.split(COLON, 2);
			errMsgArr[0] = parts[0];
			errMsgArr[1] = parts[1];
		} else {
			errMsgArr[0] = String.valueOf(errorCodeInt);
			errMsgArr[1] = errCdnMsg;
		}
		return errMsgArr;
	}

	// Cart- implementation start
	/**
	 * @param map
	 * @return
	 */
	public static boolean isMapNotEmpty(final Map<String, String> map) {
		return (map != null && !map.isEmpty());
	}

	/**
	 * This method will start a logging task
	 * 
	 * @param task
	 * @param watch
	 */
	public void startLogging(String task, StopWatch watch) {
		watch.start(task);
		LOG.info("MATL-PERF : <Calling " + task + " method> START ");
	}

	/**
	 * This method will ends a logging task
	 * 
	 * @param task
	 * @param watch
	 */
	public void endLogging(String task, StopWatch watch) {
		watch.stop();
		LOG.info("MATL-PERF : <Calling " + task + " method> END - " + watch.getLastTaskTimeMillis());
	}

	/**
	 * @param strSSO
	 * @param portalId
	 * @return Customer Login details
	 * @throws MaterialsException
	 */
	public CustLoginDetails getCustLoginDetails(String strSSO, String portalId) throws MaterialsException {
		String role = EMPTY_STRING;
		String icaoCode = EMPTY_STRING;
		String operatingUnitId = EMPTY_STRING;
		String[] custIdList = null;
		MaterialsUserBO materialsUserBO = null;
		CustLoginDetails custLoginDetails = null;
		MaterialsLoginResponse materialsLoginDetail = null;
		List<CustomerBO> customerBOList = null;
		materialsLoginDetail = materialsLoginAppImpl.requestMaterialsLogin(strSSO, portalId);
		if (materialsLoginDetail.getMaterialsUserBO() != null) {
			materialsUserBO = materialsLoginDetail.getMaterialsUserBO();
		}
		if (isNotNullandEmpty(materialsUserBO.getIcaoCode())) {
			icaoCode = materialsUserBO.getIcaoCode();
		}
		if (isNotNullandEmpty(materialsUserBO.getRole())) {
			role = materialsUserBO.getRole();
		}
		if (isNotNullandEmpty(materialsUserBO.getOperatingUnitId())) {
			operatingUnitId = materialsUserBO.getOperatingUnitId();
		}
		if (isCollectionNotEmpty(materialsUserBO.getCustomerBOList())) {
			customerBOList = materialsUserBO.getCustomerBOList();
		}
		if (customerBOList != null) {
			custIdList = new String[customerBOList.size()];
			if (custIdList != null) {
				int customerCounter = 0;
				int customerCounterSize = customerBOList.size();
				CustomerBO customerBO = null;
				for (; customerCounter < customerCounterSize; customerCounter++) {
					customerBO = customerBOList.get(customerCounter);
					custIdList[customerCounter] = customerBO.getCustId();
				}
			}
		}
		custLoginDetails = new CustLoginDetails();
		custLoginDetails.setRole(role);
		custLoginDetails.setIcaoCode(icaoCode);
		custLoginDetails.setOperatingUnitId(operatingUnitId);
		custLoginDetails.setCustIdList(custIdList);
		return custLoginDetails;
	}

	/**
	 * Returns true if the given string is not null and not empty
	 * 
	 * @param strData
	 * @return boolean
	 */
	public static boolean isNullOrEmpty(final String strData) {
		boolean isValid = false;
		if (null == strData || strData.trim().equals(EMPTY_STRING)) {
			isValid = true;
		}
		return isValid;
	}

	public boolean isFileExists(String msNumber, String docType, String shipmentDate) throws MaterialsException {
		boolean isFile = false;
		MaterialsDocumentDetails materialsDocs = null;
		String path = EMPTY_STRING;
		try {
			materialsDocs = materialsOrdersDAO.getMaterialsDocumentDS(msNumber, docType, shipmentDate);
		} catch (TechnicalException e) {
			LOG.error(e);
		}
		
		if (materialsDocs != null && isNotNullandEmpty(materialsDocs.getDocTypeCd())) {
			path = materialsDocs.getStoragePathText();
			if (isNotNullandEmpty(path)) {
				isFile = true;
			}
		}
		
		return isFile;
	}
	
	

	public List<PriorityBO> getPriority(String sso, String portalId) {
		return materialsDAO.getPriorityDS(sso, portalId);
	}

	public String getPortalDisplayPriority(String portalName, String priority) {
		Map<String, Map<String, String>> priorityERPConfigMap = null;
		priorityERPConfigMap = getPortalERPConfigAsMap(portalToERPPriority);
		Map<String, String> portalNamesMap = priorityERPConfigMap.get(portalName.toUpperCase());
		String priorityStr = getKeyFromValue(portalNamesMap, priority);
		if (isNullOrEmpty(priorityStr)) {
			priorityStr = priority;
		}
		return priorityStr;
	}

	@SuppressWarnings("rawtypes")
	public String getKeyFromValue(Map map, Object value) {
		for (Object obj : map.keySet()) {
			if (map.get(obj).equals(value)) {
				return getAsString(obj);
			}
		}
		return null;
	}

	public String getAsString(Object obj) {
		if (null != obj) {
			return obj.toString();
		}
		return EMPTY_STRING;
	}

	/**
	 * This method will take date String and return java.sql.Date
	 * 
	 * @param inputDate
	 * @return
	 */
	public java.sql.Date getSQLDate(String inputDate) {
		String fmtedDt = null;
		java.sql.Date sqlDate = null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT1);
		SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(DATE_FORMAT2);
		try {
			if (isNotNullandEmpty(inputDate)) {
				fmtedDt = simpleDateFormat2.format(simpleDateFormat.parse(inputDate));
				java.util.Date date = simpleDateFormat2.parse(fmtedDt);
				sqlDate = new java.sql.Date(date.getTime());
			}
		} catch (Exception e) {
			LOG.error(e);
		}
		return sqlDate;
	}

	public String getNameforSSO(String sso) {

		if (isNullOrEmpty(sso)) {
			return THROUGH_AMPS;
		} else {
			StringBuilder nameForSSO = new StringBuilder();
			if (sso.contains(APPWX_SCHED)) {
				return THROUGH_AMPS;
			} else {
				nameForSSO = nameForSSO.append(getFirstName(sso)).append(" ").append(getLastName(sso));
				if (isNotNullandEmpty(nameForSSO.toString())) {
					return nameForSSO.toString();
				} else {
					return THROUGH_AMPS;
				}
			}
		}

	}

	public boolean validateInputs(String msNumber, String deliveryId, String orderHeaderId, String invoiceHeaderId) {
		boolean isSuccess = false;
		boolean condition1 = (isNotNullandEmpty(msNumber) && isNotNullandEmpty(deliveryId))
				&& isNullOrEmpty(orderHeaderId) && isNullOrEmpty(invoiceHeaderId);
		boolean condition2 = (isNullOrEmpty(msNumber) && isNullOrEmpty(deliveryId)) && isNotNullandEmpty(orderHeaderId)
				&& isNullOrEmpty(invoiceHeaderId);
		boolean condition3 = (isNullOrEmpty(msNumber) && isNullOrEmpty(deliveryId)) && isNullOrEmpty(orderHeaderId)
				&& isNotNullandEmpty(invoiceHeaderId);
		if (condition1 ||condition2 || condition3) {
			isSuccess = true;
		}
		return isSuccess;
	}
	
	/**
	 * This maps shipping document type to the correct doc type stored in WCC
	 * M = Memo-of-Shipment
	 * F = 8130 
	 * @param docType
	 * @return
	 */
	public String convertShipDocTypeToWccDocType(String docType) {
		if(docType.equalsIgnoreCase(MaterialsAppConstants.MS_DOC_CD))
			return MaterialsAppConstants.WCC_DOCTYPE_MS;
		else
			return MaterialsAppConstants.WCC_DOCTYPE_FAA;
	}

	@SuppressWarnings("unchecked")
	public static <T> void sortList(List<T> list, List<MaterialsSortField> sortFields) {

		if (list == null || list.isEmpty()) {
			return;
		}

		Class<?> clazz = list.get(0).getClass();
		ComparatorChain comparatorChain = new ComparatorChain();
		String sortFieldName = EMPTY_STRING;
		for (MaterialsSortField sortField : sortFields) {
			sortFieldName = sortField.getFieldName();
			if ("shippingStatus".equals(sortFieldName)) {
				sortFieldName = "shippingStatusStr";
			}
			if ("countryOfOrigin".equals(sortFieldName)) {
				sortFieldName = "countryOfOriginStr";
			}
			comparatorChain.addComparator(new MaterialsDynamicComparator<T>(clazz, sortFieldName,
					("asc".equals(sortField.getSortOrder()) ? true : false)));
		}
		if (comparatorChain.size() > 0) {
			Collections.sort(list, comparatorChain);
		}
	}

	/**
	 * @param input
	 * @param delimitter
	 * @return array
	 * @Description:This method splits the input String according to the
	 *                   delimiter.
	 */
	public String[] splitString(final String input, final String delimitter) {
		String result[] = null;
		if (isNotNullandEmpty(input)) {
			StringTokenizer stringToken = new StringTokenizer(input, delimitter);
			int count = stringToken.countTokens();
			result = new String[count];
			int index = 0;
			while (stringToken.hasMoreTokens()) {
				result[index] = stringToken.nextToken().trim();
				index++;
			}
		}
		return result;
	}
	
	public static List<LineInfoBO> filterResultList(List<LineInfoBO> list, Integer start, Integer limit) {
		if (start == null || start < 0) {
			start = 0;
		}
		int toIndex = list.size();
		if ((limit != null && limit > 0) && (limit <= list.size() && ((start) + limit) <= list.size())) {
			toIndex = (start) + limit;
		}
		if (start >= toIndex) {
			start = 0;
		}
		return list.subList(start, toIndex);
	}

	public String getDescMsg(String msNumber, String deliveryId, String orderHeaderId, String invoiceHeaderId) {
		String desc = EMPTY_STRING;
		if (isNotNullandEmpty(msNumber) && isNullOrEmpty(deliveryId)) {
			desc = ERR_DELIVERID_EXPECTED_WITH_MSNUM;
		} else if (isNullOrEmpty(msNumber) && isNotNullandEmpty(deliveryId)) {
			desc = ERR_MSNUM_EXPECTED_WITH_DELIVERID;
		} else if (isNotNullandEmpty(msNumber) && isNotNullandEmpty(deliveryId) && isNotNullandEmpty(orderHeaderId)) {
			desc = ERR_ORDERHRDRID_FOUND_WITH_MSNUM_AND_DELIVERID;
		} else if (isNotNullandEmpty(msNumber) && isNotNullandEmpty(deliveryId) && isNotNullandEmpty(invoiceHeaderId)) {
			desc = ERR_INVOICEHRDRID_FOUND_WITH_MSNUM_AND_DELIVERID;
		} else if (isNotNullandEmpty(orderHeaderId) && isNotNullandEmpty(invoiceHeaderId)) {
			desc = ERR_INVOICEHRDRID_FOUND_WITH_ORDERHRDRID;
		}
		return desc;
	}

	public User getUserDetails(String sso, String portalId, String path) {
		User userBO = null;
		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.set(SM_HEADER, sso);
			headers.set(PORTAL_ID, portalId);
			HttpEntity<String> entity = new HttpEntity<>(PARAMETERS_STRING, headers);
			String url = portalBaseUrl + path + SSO_PATH_PARAMETER;
			Map<String, String> uriParams = new HashMap<>();
			uriParams.put("sso", sso);
			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url);
			SimpleClientHttpRequestFactory rf = (SimpleClientHttpRequestFactory) restTemplate.getRequestFactory();
			rf.setConnectTimeout(Integer.parseInt("5000"));
			userBO = restTemplate
					.exchange(builder.buildAndExpand(uriParams).toUri(), HttpMethod.GET, entity, User.class).getBody();
		}

		catch (Exception e) {
			LOG.error("Exception inside getUserDetails: " + e.getMessage(), e);
		}

		return userBO;
	}

	/**
	 * This method will get the firstname form User object
	 * 
	 * @param sso
	 * @return First name
	 */
	public String getFirstName(String sso) {
		User user = getUserDetails(sso, " ", USER);
		String firstName = null;
		if (user != null) {
			firstName = user.getGivenName();
		} else {
			return "";
		}
		return firstName;
	}

	public String getLastName(String sso) {
		User user = getUserDetails(sso, " ", USER);
		String familyName = null;
		if (user != null) {
			familyName = user.getFamilyName();
		} else {
			return "";
		}
		return familyName;
	}


	public String getValidQuantity(String inputVal) throws MaterialsException {
		if (!isNumbersOnly(inputVal)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8322,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8322), ERR_QUANTITY_NOT_FOUND);
		}
		return inputVal;
	}

	public boolean isNumbersOnly(final String strData) {
		String inputData = strData;
		boolean isValid = false;
		if (inputData != null) {
			inputData = inputData.trim();
		}
		if (((inputData != null) && (inputData.length() > 0))
				&& (!inputData.startsWith(MaterialsAppConstants.ZERO_STRING))) {
			inputData = inputData.replaceAll(MaterialsAppConstants.BLANK_SPACE, EMPTY_STRING);
			final Pattern pattern = Pattern.compile("^[0-9]*$", Pattern.CASE_INSENSITIVE);
			final Matcher matcher = pattern.matcher(inputData);
			if (matcher.find()) {
				isValid = true;
			} else {
				isValid = false;
			}
		}
		return isValid;
	}

	/**
	 * This will return priority code from Portal name
	 * 
	 * @param portalName
	 * @param priority
	 * @return Priority code
	 */
	public String getPriorityCode(String portalName, String priority) {
		Map<String, Map<String, String>> priorityERPConfigMap = null;
		priorityERPConfigMap = getPortalERPConfigAsMap(portalToERPPriority);
		Map<String, String> portalNamesMap = priorityERPConfigMap.get(portalName.toUpperCase());
		String priorityStr = portalNamesMap.get(priority);
		return priorityStr;
	}

	/**
	 * @param priorityERP
	 * @return Priority ERP Config map
	 */
	public Map<String, Map<String, String>> getPortalERPConfigAsMap(String priorityERP) {
		List<String> priorityPortalList = null;
		List<String> priorityList = null;
		Map<String, String> priorityERPMap = null;
		Map<String, Map<String, String>> priorityERPConfigMap = new HashMap<String, Map<String, String>>();
		priorityPortalList = new ArrayList<String>(Arrays.asList(priorityERP.split(MaterialsAppConstants.COMMA)));
		for (String portalId : priorityPortalList) {
			String[] portalPriorityNames = portalId.split(MaterialsAppConstants.EQUALS_STRING, 2);
			priorityList = new ArrayList<String>(
					Arrays.asList(portalPriorityNames[1].split(MaterialsAppConstants.TILDE)));
			priorityERPMap = new HashMap<String, String>();
			for (String priority : priorityList) {
				String[] priorityValues = priority.split(COLON, 2);
				priorityERPMap.put(priorityValues[0], priorityValues[1]);
			}
			priorityERPConfigMap.put(portalPriorityNames[0], priorityERPMap);
		}
		return priorityERPConfigMap;
	}

	/**
	 * @param inputDate
	 * @return validated date
	 * @throws MaterialsException
	 */
	public String getValidDate(String inputDate) throws MaterialsException {
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT1);
		java.util.Date date1 = null;
		java.util.Date date2 = null;
		String returnDate = null;
		if (isNullOrEmpty(inputDate)) {
			return returnDate;
		} else {
			try {
				date1 = sdf.parse(inputDate);
				date2 = sdf.parse(getCurrentDateAsYYYYMMDD());
			} catch (ParseException e) {
				LOG.error(e);
			}
			if (date1.before(date2) || date1.equals(date2)) {
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8329,
						materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8329), INVALID_DATE);
			} else {
				returnDate = inputDate;
			}
		}
		return returnDate;
	}

	public String getCurrentDateAsYYYYMMDD() {
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT1);
		return dateFormat.format(new java.util.Date());
	}

	public static Boolean getBooleanFrmString(String strFlag) {
		Boolean flag = false;
		if ((isNotNullandEmpty(strFlag)) && (Y.equalsIgnoreCase(strFlag))) {
			flag = true;
		}
		return flag;
	}

	/**
	 * @param statusMessage
	 * @return Status message
	 * @throws MaterialsException
	 */
	public String getStatusMessage(String statusMessage) throws MaterialsException {
		String statusMsg = EMPTY_STRING;
		if (statusMessage.contains(MaterialsAppConstants.PIPE)) {
			char lastChar_statusMessage = statusMessage.charAt(statusMessage.length() - 1);
			if (lastChar_statusMessage == CHAR_PIPE) {
				statusMessage = statusMessage.substring(0, statusMessage.length() - 1);
			}
			ArrayList<String> statusMessagesList = new ArrayList<String>(Arrays.asList(statusMessage.split("\\|")));
			if (statusMessagesList.size() > 1) {
				for (String strMessage : statusMessagesList) {
					String errorCode[] = getErrorCdnMsg(strMessage);
					if (errorCode[0].equals(ERR_CODE_8400) || errorCode[0].equals(ERR_CODE_8300)) {
						statusMsg += errorCode[1] + MaterialsAppConstants.BLANK_SPACE_DOT;
					} else {
						statusMsg += materialsExceptionUtil.getErrorMessage(errorCode[0])
								+ MaterialsAppConstants.BLANK_SPACE_DOT;
					}
				}
			} else if (statusMessage.contains(MaterialsAppConstants.COLON)) {
				String errorCode[] = getErrorCdnMsg(statusMessage);
				if (errorCode[0].equals(ERR_CODE_8167)) {
					String procMsg[] = errorCode[1].split("\\.");
					statusMsg = materialsExceptionUtil.getErrorMessage(errorCode[0]);
					String[] statusMsgParts = statusMsg.split("\\.");
					statusMsg = statusMsgParts[0] + MaterialsAppConstants.DOT + procMsg[1];
				} else {
					statusMsg = materialsExceptionUtil.getErrorMessage(errorCode[0]);
				}
			} else {
				String[] strMessage = getErrorCdnMsg(statusMessage);
				statusMsg += strMessage[1];
			}
		} else {
			if (statusMessage.contains(MaterialsAppConstants.COLON)) {
				String errorCode[] = getErrorCdnMsg(statusMessage);
				if (errorCode[0].equals(ERR_CODE_8300)) {
					statusMsg += errorCode[1];
				} else {
					statusMsg += materialsExceptionUtil.getErrorMessage(errorCode[0]);
				}
			} else {
				String[] strMessage = getErrorCdnMsg(statusMessage);
				statusMsg += strMessage[1];
			}
		}
		return statusMsg;
	}

	public String getAttivioServicesURL() {
		return attivioServicesURL;
	}

	public boolean invokeService(String urlStr, String module) {
		LOG.info("invokeAttivioService()-<START>");
		boolean success = true;
		URL url = null;
		HttpURLConnection connection = null;
		try {
			url = new URL(urlStr);
			connection = (HttpURLConnection) url.openConnection();
			connection.setReadTimeout(5000);
			connection.setConnectTimeout(5000);
			connection.setRequestMethod(CONST_HTTP_GET);
			if (connection.getResponseCode() != 200) {
				success = false;
				LOG.info("Order updation in attivio is unsuccessful for " + module + ",reason==> "
						+ connection.getResponseCode());
			}
		} catch (Exception e) {
			success = false;
			LOG.error("Exception in Attivio Order updation:: " + e);
		} finally {
			connection.disconnect();
		}
		LOG.info("invokeAttivioService()-<END>");
		return success;
	}

	public String getEmailId(String sso) {
		User user = getUserDetails(sso, " ", USER);
		String emailId = null;
		if (user != null) {
			emailId = user.getEmailId();
		} else {
			return "";
		}
		return emailId;
	}

	public String getDeployedEnvironment() {
		return environment;
	}

	public String getFromEmailForPortal(String portalId) {
		Map<String, String> emailMap = null;
		emailMap = getPortalConfigAsMap(emailMapping);
		return emailMap.get(portalId.toUpperCase());
	}

	public Map<String, String> getPortalConfigAsMap(String portalConfigString) {
		List<String> portalIdList = null;
		Map<String, String> portalConfigMap = new HashMap<String, String>();
		portalIdList = new ArrayList<String>(Arrays.asList(portalConfigString.split(MaterialsAppConstants.COMMA)));
		for (String portalId : portalIdList) {
			String[] parts = portalId.split(MaterialsAppConstants.TILDE, 2);
			portalConfigMap.put(parts[0], parts[1]);
		}
		return portalConfigMap;
	}

	public String getCAMEmailId(String sso, String icao, String[] custIds, String role, String opUid) {
		return materialsOrdersDAO.getCAMEmailDS(sso, icao, custIds, role, opUid);
	}

	public List<String> getStringAsList(final String input, final String delimitter) {
		List<String> resultList = new ArrayList<String>();
		if (isNotNullandEmpty(input) && input.contains(delimitter)) {
			StringTokenizer stringToken = new StringTokenizer(input, delimitter);
			while (stringToken.hasMoreTokens()) {
				resultList.add(stringToken.nextToken().trim());
			}
		} else {
			resultList.add(input);
		}
		return resultList;
	}

	public List<String> removeDuplicateStringFromList(List<String> inputList) {
		List<String> newList = new ArrayList<String>(new LinkedHashSet<String>(inputList));
		return newList;
	}

	public String getListAsString(List<String> list) {
		String strReturn = EMPTY_STRING;
		if (null != list && !list.isEmpty()) {
			strReturn = list.toString();
			strReturn = strReturn.substring(1, strReturn.length() - 1);
		}
		return strReturn;
	}

	public String getAppOwnerId() {
		return appOwnerSSO;
	}

	public boolean invokeNotificationService(EmailContentInputBO mailContentInputBO, String notificationServiceUrl,
			String module) {
		LOG.info("invokeNotificationService()-<START>");
		HttpURLConnection httpConnection = null;
		ObjectMapper mapper = new ObjectMapper();
		String jsonEmail = null;
		boolean success = true;
		try {
			URL notificationURL = new URL(notificationServiceUrl);
			httpConnection = (HttpURLConnection) notificationURL.openConnection();
			if (mailContentInputBO != null) {
				httpConnection.setDoOutput(true);
				httpConnection.setRequestMethod("POST");
				httpConnection.setRequestProperty("Content-Type", "application/json");
				jsonEmail = mapper.writeValueAsString(mailContentInputBO);
				OutputStream outputStream = httpConnection.getOutputStream();
				outputStream.write(jsonEmail.getBytes());
				outputStream.flush();
				if (httpConnection.getResponseCode() != 200) {
					success = false;
					LOG.info(module + " Email notifiaction is unsuccessful, reason==> "
							+ httpConnection.getResponseCode());
				}
			}
		} catch (Exception e) {
			success = false;
			LOG.error("Error in sending " + module + " mail notifiaction " + e);
		} finally {
			httpConnection.disconnect();
		}
		LOG.info("invokeNotificationService()-<END>");
		return success;
	}

	public ReturnLabelDO getDisputeOrderDetails(String strSSO, String orderHeaderId, CustLoginDetails custLoginDetails)
			throws MaterialsException {
		LOG.info("getDisputeOrderDetails()-<START>");
		ReturnLabelDO returnLabelDO = null;
		returnLabelDO = materialsShipmentData.getReturnLabelDetailDS(strSSO, orderHeaderId, custLoginDetails);
		LOG.info("getDisputeOrderDetails()-<END>");
		return returnLabelDO;
	}

	public byte[] generatePDFReturnLabel(String portalId, ReturnLabelDO returnLabelDO) {
		LOG.info("generatePDFReturnLabel()-<START>");
		ByteArrayOutputStream byteArrayOutput = new ByteArrayOutputStream();
		try {
			String returnAddrCaption = EMPTY_STRING;
			String rmaAddress = EMPTY_STRING;
			if ("GEHonda".equalsIgnoreCase(portalId)) {
				returnAddrCaption = "GE Honda Aero Engines Materials Returns";
				rmaAddress = "\n Attn: OS&D \n" + "Honda Aero, Inc \n" + "2989 Tucker Street\n"
						+ "Burlington, NC 27215\n";
			} else {
				returnAddrCaption = "GE / CFMI Aviation Material Returns Program";
				rmaAddress = "\n Attn: OS&D \n" + "5443 Duff Drive\n"
						+ "Cincinnati, OH 45246 US\n";
			}
			Document document = new Document(PageSize.A4, 5, 5, 60, 60);
			PdfWriter writer = PdfWriter.getInstance(document, byteArrayOutput);
			document.open();

			PdfPTable table = new PdfPTable(2);
			table.setComplete(true);
			table.setWidthPercentage(90);
			float[] columnWidths = { 1.5f, 2.5f };

			table.setWidths(columnWidths);

			Font fontHeadline = new Font(FontFamily.TIMES_ROMAN, 18, java.awt.Font.CENTER_BASELINE,
					new BaseColor(0, 0, 0));
			Font fontContent = new Font(FontFamily.TIMES_ROMAN, 18, Font.BOLD, new BaseColor(0, 0, 255));
			Font fontContentValue = new Font(FontFamily.TIMES_ROMAN, 18, 0, new BaseColor(0, 0, 0));
			Font fontAddressHeadline = new Font(FontFamily.TIMES_ROMAN, 24, Font.BOLD, new BaseColor(0, 0, 0));
			Font fontAddressBody = new Font(FontFamily.TIMES_ROMAN, 24, 0, new BaseColor(0, 0, 0));
			Font fontDHLAccount = new Font(FontFamily.TIMES_ROMAN, 22, 0, new BaseColor(255, 0, 0));
			Font fontUPSScsAccount = new Font(FontFamily.TIMES_ROMAN, 11, 0, new BaseColor(255, 0, 0));
			Image image = null;
			
			Resource resource = new ClassPathResource(MaterialsAppConstants.PATH_STATICFILES_SHIPMENT);
			String shipmentDocPath =  resource.getURL().toString();
			try {
				image = Image.getInstance(shipmentDocPath + portalId.toUpperCase() + RETURN_LBL_LOGO_SUFFIX);
			} catch (Exception e) {
				LOG.info(e);
				image = Image.getInstance(shipmentDocPath + RETURN_LBL_LOGO_DEFAULT);
			}
			image.scaleAbsolute(220, 200);
			PdfPCell cell1 = new PdfPCell(image, false);
			cell1.setBorder(Rectangle.NO_BORDER);
			cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			cell1.setVerticalAlignment(Element.ALIGN_BOTTOM);
			table.addCell(cell1);

			PdfPCell cell2 = new PdfPCell(new Paragraph("Cell 2"));
			cell2.disableBorderSide(Rectangle.NO_BORDER);

			PdfPTable nestedTable = new PdfPTable(2);

			nestedTable.setComplete(true);
			nestedTable.setWidthPercentage(100);
			float[] nestedcellColumnWidths = { 2f, 2f };
			nestedTable.setWidths(nestedcellColumnWidths);
			nestedTable.getDefaultCell().setBorder(0);

			// Return label
			Paragraph paragraphLabel1 = new Paragraph();
			paragraphLabel1.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunk1 = new Chunk("Return Details :", fontHeadline);
			chunk1.setUnderline(0.2f, -2f);
			paragraphLabel1.add(chunk1);
			nestedTable.addCell(paragraphLabel1);

			Paragraph paragraphValue1 = new Paragraph();
			paragraphValue1.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunkValue1 = new Chunk();
			paragraphValue1.add(chunkValue1);
			nestedTable.addCell(paragraphValue1);

			// RMA Number
			Paragraph paragraphLabel2 = new Paragraph();
			paragraphLabel2.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunk2 = new Chunk("RMA Number:", fontContent);
			paragraphLabel2.add(chunk2);
			nestedTable.addCell(paragraphLabel2);

			Paragraph paragraphValue2 = new Paragraph();
			paragraphValue2.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunkValue2 = new Chunk(returnLabelDO.getRmaNumber(), fontContentValue);
			paragraphValue2.add(chunkValue2);
			nestedTable.addCell(paragraphValue2);

			// Purchase Order
			Paragraph paragraphLabel3 = new Paragraph();
			paragraphLabel3.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunk3 = new Chunk("Purchase Order:", fontContent);
			paragraphLabel3.add(chunk3);
			nestedTable.addCell(paragraphLabel3);

			Paragraph paragraphValue3 = new Paragraph();
			paragraphValue3.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunkValue3 = new Chunk(returnLabelDO.getPoNumber(), fontContentValue);
			paragraphValue3.add(chunkValue3);
			nestedTable.addCell(paragraphValue3);

			// Part Number
			Paragraph paragraphLabel4 = new Paragraph();
			paragraphLabel4.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunk4 = new Chunk("Part Number: ", fontContent);
			paragraphLabel4.add(chunk4);
			nestedTable.addCell(paragraphLabel4);

			Paragraph paragraphValue4 = new Paragraph();
			paragraphValue4.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunkValue4 = new Chunk(returnLabelDO.getPartNumber(), fontContentValue);
			paragraphValue4.add(chunkValue4);
			nestedTable.addCell(paragraphValue4);

			// Quantity
			Paragraph paragraphLabel5 = new Paragraph();
			paragraphLabel5.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunk5 = new Chunk("Quantity:", fontContent);
			paragraphLabel5.add(chunk5);
			nestedTable.addCell(paragraphLabel5);

			Paragraph paragraphValue5 = new Paragraph();
			paragraphValue5.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunkValue5 = new Chunk(returnLabelDO.getQuantity(), fontContentValue);
			paragraphValue5.add(chunkValue5);
			nestedTable.addCell(paragraphValue5);

			// Reason
			Paragraph paragraphLabel6 = new Paragraph();
			paragraphLabel6.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunk6 = new Chunk("Reason: ", fontContent);
			paragraphLabel6.add(chunk6);
			nestedTable.addCell(paragraphLabel6);

			Paragraph paragraphValue6 = new Paragraph();
			paragraphValue6.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunkValue6 = new Chunk(returnLabelDO.getReason(), fontContentValue);
			paragraphValue6.add(chunkValue6);
			nestedTable.addCell(paragraphValue6);

			// Country of Origin
			Paragraph paragraphLabel7 = new Paragraph();
			paragraphLabel7.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunk7 = new Chunk("Country of Origin: ", fontContent);
			paragraphLabel7.add(chunk7);
			nestedTable.addCell(paragraphLabel7);

			Paragraph paragraphValue7 = new Paragraph();
			paragraphValue7.setAlignment(Element.ALIGN_RIGHT);
			Chunk chunkValue7 = new Chunk(returnLabelDO.getCountryOfOrigin(), fontContentValue);
			paragraphValue7.add(chunkValue7);
			nestedTable.addCell(paragraphValue7);

			// Address Cell
			cell2.setBorder(Rectangle.NO_BORDER);
			cell2.addElement(nestedTable);
			table.addCell(cell2);

			Paragraph addressPara = new Paragraph();
			paragraphLabel1.setAlignment(Element.ALIGN_MIDDLE);
			Chunk chunkAddress = new Chunk(returnAddrCaption, fontAddressHeadline);
			chunkAddress.setUnderline(0.2f, -2f);
			addressPara.add(chunkAddress);
			PdfPCell cell3 = new PdfPCell(addressPara);
			cell3.setColspan(2);
			cell3.setBorder(Rectangle.NO_BORDER);
			cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell3.setVerticalAlignment(Element.ALIGN_BOTTOM);
			table.addCell(cell3);

			Paragraph addressBodyPara = new Paragraph();
			addressBodyPara.setAlignment(Element.ALIGN_MIDDLE);
			Chunk chunkAddress1 = new Chunk(rmaAddress, fontAddressBody);
			addressPara.add(chunkAddress1);
			PdfPCell cell4 = new PdfPCell(addressBodyPara);
			cell4.setColspan(2);
			cell4.setBorder(Rectangle.NO_BORDER);
			table.addCell(cell4);
			
			if ("GEHonda".equalsIgnoreCase(portalId)) {
				Paragraph upsScs = new Paragraph();
				upsScs.setAlignment(Element.ALIGN_MIDDLE);
				Chunk geUpsAccount = new Chunk("(GE - UPS Account #)", fontUPSScsAccount);
				geUpsAccount.setLineHeight(30f);
				geUpsAccount.setTextRise(-12f);
				geUpsAccount.setUnderline(1.2f, 1f);
				upsScs.add(geUpsAccount);
				upsScs.setSpacingAfter(10);
				upsScs.setSpacingBefore(10);
				PdfPCell cell5 = new PdfPCell(upsScs);
				cell5.setColspan(2);
				cell5.setBorder(Rectangle.NO_BORDER);
				cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
				cell5.setVerticalAlignment(Element.ALIGN_BOTTOM);
				table.addCell(cell5);
			} else {
				Paragraph deliverInstr = new Paragraph();
				deliverInstr.setAlignment(Element.ALIGN_MIDDLE);
				Chunk geDhlAccount = new Chunk("Return material per DHL Express Account # 962167401", fontDHLAccount);
				addressPara.add(geDhlAccount);
				PdfPCell cell5 = new PdfPCell(deliverInstr);
				cell5.setColspan(2);
				cell5.setBorder(Rectangle.NO_BORDER);
				table.addCell(cell5);
			}
			
			document.add(table);

			document.close();
			writer.close();
		} catch (DocumentException e) {
			LOG.error(e);
		} catch (FileNotFoundException e) {
			LOG.error(e);
		} catch (Exception e) {
			LOG.error(e);
		}
		LOG.info("generatePDFReturnLabel()-<END>");
		return byteArrayOutput.toByteArray();
	}

	public String getCurrentDateAsMMDDYYYY() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
		return dateFormat.format(new java.util.Date());
	}

	public String validateDate(String inputDate) throws MaterialsException {
		DateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT2);
		java.util.Date date1 = null;
		java.util.Date date2 = null;
		String returnDate = null;
		if (isNullOrEmpty(inputDate)) {
			return returnDate;
		} else {
			try {
				date1 = simpleDateFormat.parse(inputDate);
				date2 = simpleDateFormat.parse(simpleDateFormat.format(new Date()));
			} catch (ParseException e) {
				LOG.error(e);
			}
			if (date1.before(date2) || date1.equals(date2)) {
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8329,
						materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8329), INVALID_DATE);
			} else {
				returnDate = inputDate;
			}
		}
		return returnDate;
	}
	
	/**
	 * @param workStopDate
	 * @param requestedDate
	 * @return boolean
	 * @throws MaterialsException
	 * 
	 * Work Stop Date must be after Requested Date. Returns true if work stop date meets this requirement.
	 * Otherwise, returns false.
	 */
	public boolean isValidWorkStopDate(String workStopDate, String requestedDate) throws MaterialsException {
		if(isNullOrEmpty(requestedDate))
			return false;
		
		String validWorkStopDate = null;
		String validRequestedDate = null;
		boolean bValidWorkStopDate = true;
		
		validWorkStopDate = validateDate(workStopDate);
		validRequestedDate = validateDate(requestedDate);
		
		DateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT2);
		java.util.Date date1 = null;
		java.util.Date date2 = null;
		
		try {
			date1 = simpleDateFormat.parse(validWorkStopDate);
			date2 = simpleDateFormat.parse(validRequestedDate);
			
			if(date1.before(date2) || date1.equals(date2))
				bValidWorkStopDate = false;
		} 
		catch (ParseException e) {
			LOG.error(e);
		}
		
		return bValidWorkStopDate;
	}
	
	/**
	 * @param workStopQty
	 * @param requestedQty
	 * @return boolean
	 * @throws NumberFormatException
	 * @throws MaterialsException
	 * 
	 * Work Stop Quantity must be less than or equal to Requested Quantity. If WS Quantity meets the requirement, return true.
	 * Otherwise, return false.
	 */
	public boolean isValidWorkStopQty(String workStopQty, String requestedQty) throws MaterialsException {
		if(isNullOrEmpty(requestedQty))
			return false;
		
		int nWorkStopQty = Integer.parseInt(getValidQuantity(workStopQty));
		int nRequestedQty = Integer.parseInt(getValidQuantity(requestedQty));
		
		return (nWorkStopQty <= nRequestedQty);
	}

	public java.sql.Date getSQLDateFormat(String inputDate) {
		java.sql.Date sqlDate = null;
		DateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT2);
		try {
			if (isNotNullandEmpty(inputDate)) {
				java.util.Date date = simpleDateFormat.parse(inputDate);
				sqlDate = new java.sql.Date(date.getTime());
			}
		} catch (Exception e) {
			LOG.error(e);
		}
		return sqlDate;
	}

	public String getDisputeTypeForERP(String disputeType) {
		Map<String, String> disputeTypeMap = new HashMap<String, String>();
		disputeTypeMap.put(MaterialsAppConstants.UI_DISPUTE_TYPE_SN, MaterialsAppConstants.ERP_DISPUTE_TYPE_SN);
		disputeTypeMap.put(MaterialsAppConstants.UI_DISPUTE_TYPE_DD, MaterialsAppConstants.ERP_DISPUTE_TYPE_DD);
		disputeTypeMap.put(MaterialsAppConstants.UI_DISPUTE_TYPE_UD, MaterialsAppConstants.ERP_DISPUTE_TYPE_UD);
		disputeTypeMap.put(MaterialsAppConstants.UI_DISPUTE_TYPE_OD, MaterialsAppConstants.ERP_DISPUTE_TYPE_OD);
		disputeTypeMap.put(MaterialsAppConstants.UI_DISPUTE_TYPE_BB, MaterialsAppConstants.ERP_DISPUTE_TYPE_BB);
		disputeTypeMap.put(MaterialsAppConstants.UI_DISPUTE_TYPE_PE, MaterialsAppConstants.ERP_DISPUTE_TYPE_PE);
		return disputeTypeMap.get(disputeType);
	}

	public String getStringFromBoolean(Boolean boolFlag) {
		String strVal = N;
		if (null != boolFlag && boolFlag) {
			strVal = Y;
		}
		return strVal;
	}

	public String encodeBytesToString(byte[] bytes) {
		return new String(Base64.encodeBase64(bytes));
	}

	public void createDownloadLinks(String portalId, String orderId, String docType, String linkName,
			List<DocumentDownloadBO> docList, boolean fileAttached) {
		String linkURL = EMPTY_STRING;
		if (fileAttached) {
			linkURL = getApplicationURL(portalId) + DISPUTE_DOCS_URL + docType + ORDER_HEADER_ID + orderId
					+ ORDER_LINE_ID;
			docList.add(new DocumentDownloadBO(linkName, linkURL));
		}
	}

	public String getApplicationURL(String portalId) {
		Map<String, String> portalAppUrlMap = new HashMap<String, String>();
		portalAppUrlMap = getPortalConfigAsMap(portalApplicationURL);
		return portalAppUrlMap.get(portalId.toUpperCase());
	}

	public String getCurrencyFormattedValue(String value) {
		String result = EMPTY_STRING;
		if (isNullOrEmpty(value)) {
			return result;
		} else {
			double dblVal = Double.parseDouble(value);
			NumberFormat numberFormat = NumberFormat.getCurrencyInstance(java.util.Locale.US);
			try {
				result = numberFormat.format(dblVal);
			} catch (Exception e) {
				LOG.error(e);
			}
		}
		return result;
	}
	public byte[] getBytesFromFile(File file) throws IOException {
		byte[] bytes = null;
		try(InputStream is= new FileInputStream(file)) {
			
			long length = file.length();
			if (length > Integer.MAX_VALUE) {
				return bytes;
			}
			bytes = new byte[(int) length];
			int offset = 0;
			int numRead = 0;
			while ((offset < bytes.length) && ((numRead = is.read(bytes, offset, bytes.length - offset)) >= 0)) {
				offset += numRead;
			}
		}
		return bytes;
	}
	
	public String decodeURLString(String urlStringInput) {
		String returnString = EMPTY_STRING;
		if (isNotNullandEmpty(urlStringInput)) {
			try {
				returnString = URLDecoder.decode(urlStringInput, MaterialsAppConstants.UTF_8);
			} catch (Exception e) {
				LOG.error("Getting exception in decoding the URL String, so returning the same"+e);
				returnString = urlStringInput;
			}
		}
		return returnString;
	}
	
	public String getFileName(String filename) {
		String fileNameOut;
		String[] name = filename.split("=");
		fileNameOut = name[1].substring(name[1].trim().lastIndexOf("\\") + 1, name[1].length()).replaceAll("\"", "").replaceAll(" ", "").replaceAll("|", "");
		return fileNameOut;
	}
	public static String Base64Encode(String value)
	{
	byte[] encodedBytes = Base64.encodeBase64(value.getBytes());
	    return new String(encodedBytes);
	}
	
	public String convertDate(String date) throws MaterialsException {
		DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT1);
		SimpleDateFormat smplDateFormat = new SimpleDateFormat(DATE_FORMAT1);
		String dateFrmt = EMPTY_STRING;
		try {
			if (isNotNullandEmpty(date)) {
				dateFrmt = dateFormat.format(smplDateFormat.parse(date));
			}
		} catch (Exception e) {
			LOG.info(e);
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8311,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8311),
					ERR_DATE_FORMAT_NOT_CORRECT);
		}
		return dateFrmt;
	}

	public static String Base64Decode(String value) {
		byte[] decodedBytes = Base64.decodeBase64(value.getBytes());
		return new String(decodedBytes);
	}

	public String getFormattedCurrentDate(String format) {
        SimpleDateFormat dateFormat = null;
        String defaultFormat = DATE_FORMAT1;
        try{
            if(isNotNullandEmpty(format)){
                dateFormat = new SimpleDateFormat(format);
            }else{
                dateFormat = new SimpleDateFormat(defaultFormat);
            }
        }catch(Exception e){
            LOG.info(e);
            dateFormat = new SimpleDateFormat(defaultFormat);
        }
        return dateFormat.format(new java.util.Date());
    }

	public String getFormattedDate(String date, String inputFormat, String outputFormat) {
		DateFormat outFormat = null;
		DateFormat inFormat = null;
		String formattedDt = EMPTY_STRING;
		try {
			if ((null != date && !date.isEmpty()) && null != outputFormat && !outputFormat.isEmpty()) {
				inFormat = new SimpleDateFormat(inputFormat);
				outFormat = new SimpleDateFormat(outputFormat);
				formattedDt = outFormat.format(inFormat.parse(date));
			}
		} catch (Exception e) {
			LOG.info(e);
			formattedDt = date;
		}
		return formattedDt;
	}
	
	
	public String validateEsn(String esn){
		LOG.info("Inside validateEsn method: esn  = "+ esn);
		StringBuilder builder = new StringBuilder();
		try(BufferedReader responseBuffer = new BufferedReader(new InputStreamReader((new URL(assetBaseUrl + VALIDATE_ESN_ASSET_SERVICE + esn).openConnection().getInputStream())))) {
			String output = "";
			while ((output = responseBuffer.readLine()) != null) {
				builder.append(output);
			}
		}
		 catch (Exception e) {
			 LOG.error("Exception inside validateEsn: " + e.getMessage(), e);
				throw new TechnicalException(e.getMessage(), e.getCause());
			}
		LOG.info("Inside validateEsn method: is valid esn = "+ builder.toString());
		return builder.toString();
	}
	
	// for ignoring certificate - start
	static {
		disableSslVerification();
	}

	private static void disableSslVerification() {
		try {
			// Create a trust manager that does not validate certificate chains
			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}
				public void checkClientTrusted(X509Certificate[] certs, String authType) {
					//no certificate required for client
				}
				public void checkServerTrusted(X509Certificate[] certs, String authType) {
					//no certificate required for server
				}
			} };

			// Install the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

			// Create all-trusting host name verifier
			HostnameVerifier allHostsValid = new HostnameVerifier() {
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			};

			// Install the all-trusting host verifier
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		} catch (NoSuchAlgorithmException e) {
			LOG.error(e);
		} catch (KeyManagementException e) {
			LOG.error(e);
		}
	}
	// for ignoring certificate - end
	public Response htmlErrorResponse(String message) {
		ResponseBuilder rb = Response.noContent();
		rb = rb.type(javax.ws.rs.core.MediaType.TEXT_HTML);
		rb = rb.status(Status.BAD_REQUEST);
		String finalMsg = Constants.HTML_MSG1 + message + Constants.HTML_MSG2;
		rb = rb.entity(finalMsg);
		return rb.build();
	}

	public MaterialsOrderRequest getFilterParamsForDB(List<MaterialsSearchField> searchList, String icaoCode,
			String custCodes, List<MaterialsSortField> sortList) {
		MaterialsOrderRequest materialsOrderFilter = new MaterialsOrderRequest();
		if(searchList == null ){
			LOG.error("Search List is NUll");
		} else if(searchList.isEmpty()){
			LOG.error("Search List is Empty");
		}
		for (MaterialsSearchField searchField : searchList) {
			materialsOrderFilter.setIcaoCode(icaoCode);
			materialsOrderFilter.setCustCode(custCodes);
			setRequestDateOrderDate(searchField, materialsOrderFilter);


			setDeliveryDateShippmentDate(searchField, materialsOrderFilter);
	
			setMsCustomerInvoiceNumber(searchField, materialsOrderFilter);
	
			setCustomerLineNumberStatusPartNumber(searchField, materialsOrderFilter);

			setRequestedCancelledShippedQty(searchField, materialsOrderFilter);
			
			setEngineFamilyAwbNumberSellingPrice(searchField, materialsOrderFilter);
			
			setListExtendedPriceEngineModelType(searchField, materialsOrderFilter);
			

		}
		for (MaterialsSortField sortField : sortList) {
			LOG.info("Entered sortFiles ::: ");
			setSortTypeOrderDate(sortField, materialsOrderFilter);
	

			setMSCustNumLineTypeOrderSort(sortField, materialsOrderFilter);
			
	
			setInvoiceLineOrderPart(sortField, materialsOrderFilter);
		
			setReqCancelShippedInvoiceEngineSort(sortField, materialsOrderFilter);
		

			setAWBSellListEtnEngineSort(sortField, materialsOrderFilter);
	

		}
		return materialsOrderFilter;
	}

	private void setAWBSellListEtnEngineSort(MaterialsSortField sortField, MaterialsOrderRequest materialsOrderFilter){
		if ("awbNumberSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("AWB_NUMBER");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("sellingPriceSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("SELLING_PRICE");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("listPriceSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("LIST_PRICE");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("extendedPriceSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("EXTENDED_PRICE");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("engineModelSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("ENGINE_MODEL");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}
	}
	
	private void setReqCancelShippedInvoiceEngineSort(MaterialsSortField sortField, MaterialsOrderRequest materialsOrderFilter){
		if ("requestedQtySort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("ORDERED_QUANTITY");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("cancelledQtySort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("CANCELLED_QUANTITY");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("shippedQtySort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("SHIPPED_QUANTITY");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("invoicedQuantitySort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("INVOICED_QUANTITY");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("engineFamilySort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("ENGINE_FAMILY");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}
	}
	
	private void setInvoiceLineOrderPart(MaterialsSortField sortField, MaterialsOrderRequest materialsOrderFilter){
		if ("invoiceNumberSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setInvoiceNumber("INVOICE_NUMBER");
			materialsOrderFilter.setInvoiceNumberValue(sortField.getSortOrder());
		}

		if ("customerLineNumberSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("LINE_NUMBER");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("orderStatusSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("LINE_STATUS");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("partNumberSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("ORDERED_ITEM");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}
	}
	
	private void setMSCustNumLineTypeOrderSort(MaterialsSortField sortField, MaterialsOrderRequest materialsOrderFilter){
		if ("msNumberSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("MS_NUMBER");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("orderLineTypeSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("LINE_CATEGORY_CODE");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}
		if ("customerNumber".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setCustomerNumber(CUSTOMER_NUMBER_STRING);
			materialsOrderFilter.setCustomerNumberValue(sortField.getSortOrder());
		}
		if ("customerNumberSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn(CUSTOMER_NUMBER_STRING);
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("purchaseOrderSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn("CUST_PO_NUMBER");
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}
	}
	
	private void setSortTypeOrderDate(MaterialsSortField sortField, MaterialsOrderRequest materialsOrderFilter){
		if ("requestDateSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn(REQUEST_DATE2_STRING);
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("orderedDate".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderedDate(ORDERED_DATE_STRING);
			materialsOrderFilter.setOrderedDateFrom(sortField.getSortOrder());
		}

		if ("orderedDateSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn(ORDERED_DATE_STRING);
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("deliveryDateSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn(DELIVERYDATE);
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}

		if ("shipmentDateSort".equalsIgnoreCase(sortField.getFieldName())
				&& isNotNullandEmpty(sortField.getSortOrder())) {
			materialsOrderFilter.setOrderByColumn(SHIPMENT_DATE_STRING);
			materialsOrderFilter.setSortType(sortField.getSortOrder());
		}
	}
	
	private void setListExtendedPriceEngineModelType(MaterialsSearchField searchField, MaterialsOrderRequest materialsOrderFilter){
		if ("listPrice".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setListPrice("LIST_PRICE");
			materialsOrderFilter.setListPriceValue(searchField.getFiltervalues());
		}

		if ("extendedPrice".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setExtendedPrice("EXTENDED_PRICE");
			materialsOrderFilter.setExtendedPriceValue(searchField.getFiltervalues());
		}

		if ("engineModel".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setEngineModel("PRODUCT_LINE");
			materialsOrderFilter.setEngineModelValue(searchField.getFiltervalues());
		}
		if ("engineModelSort".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setOrderByColumn("PRODUCT_LINE");
			materialsOrderFilter.setSortType(searchField.getFiltervalues());
		}
	}
	
	private void setEngineFamilyAwbNumberSellingPrice(MaterialsSearchField searchField, MaterialsOrderRequest materialsOrderFilter){
		if ("engineFamily".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setEngineFamily("ENG_FAMILY");
			materialsOrderFilter.setEngineFamilyValue(searchField.getFiltervalues());
		}

		if ("awbNumber".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setAwbNumber("WAYBILL");
			materialsOrderFilter.setAwbNumberValue(searchField.getFiltervalues());
		}

		if ("sellingPrice".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setSellingPrice("SELLING_PRICE");
			materialsOrderFilter.setSellingPriceValue(searchField.getFiltervalues());
		}
	}
	
	private void setRequestedCancelledShippedQty(MaterialsSearchField searchField, MaterialsOrderRequest materialsOrderFilter){
		if ("requestedQty".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setRequestedQty("ORDERED_QUANTITY");
			materialsOrderFilter.setRequestedQtyValue(searchField.getFiltervalues());
		}

		if ("cancelledQty".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setCancelledQty("CANCELLED_QUANTITY");
			materialsOrderFilter.setCancelledQtyValue(searchField.getFiltervalues());
		}

		if ("shippedQty".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setShippedQty("SHIPPED_QUANTITY");
			materialsOrderFilter.setShippedQtyValue(searchField.getFiltervalues());
		}

		if ("invoicedQuantity".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setInvoicedQuantity("INVOICED_QUANTITY");
			materialsOrderFilter.setInvoicedQuantityValue(searchField.getFiltervalues());
		}
	}
	
	private void setCustomerLineNumberStatusPartNumber(MaterialsSearchField searchField, MaterialsOrderRequest materialsOrderFilter){
		if ("customerLineNumber".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setCustomerLineNumber("LINE_NUMBER");
			materialsOrderFilter.setCustomerLineNumberValue(searchField.getFiltervalues());
		}

		if ("orderStatus".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setOrderStatus("LINE_STATUS");
			materialsOrderFilter.setOrderStatusValue(searchField.getFiltervalues());
		}

		if ("partNumber".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setPartNumber("ORDERED_ITEM");
			materialsOrderFilter.setPartNumberValue(searchField.getFiltervalues());
		}
	}
	
	private void setRequestDateOrderDate(MaterialsSearchField searchField, MaterialsOrderRequest materialsOrderFilter){
		if (REQUEST_DATE1_STRING.equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setRequestedDate(REQUEST_DATE2_STRING);
			materialsOrderFilter.setRequestDateFrom(searchField.getFiltervalues());
			LOG.info(REQUEST_DATE1_STRING + materialsOrderFilter.getOrderedDateFrom());
		}
		if ("requestDateEnd".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setRequestedDate(REQUEST_DATE2_STRING);
			materialsOrderFilter.setRequestDateTo(searchField.getFiltervalues());
			LOG.info(REQUEST_DATE1_STRING + materialsOrderFilter.getOrderedDateTo());
		}

		if ("orderedDate".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setOrderedDate(ORDERED_DATE_STRING);
			materialsOrderFilter.setOrderedDateFrom(searchField.getFiltervalues());
		}
		if ("orderedDateEnd".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setOrderedDate(ORDERED_DATE_STRING);
			materialsOrderFilter.setOrderedDateTo(searchField.getFiltervalues());
		}
	}
	
	
	private void setDeliveryDateShippmentDate(MaterialsSearchField searchField, MaterialsOrderRequest materialsOrderFilter){
		if ("deliveryDate".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setDeliveryDate(DELIVERYDATE);
			materialsOrderFilter.setDeliveryDateFrom(searchField.getFiltervalues());
		}
		if ("deliveryDateEnd".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setDeliveryDate(DELIVERYDATE);
			materialsOrderFilter.setDeliveryDateTo(searchField.getFiltervalues());
		}

		if ("shipmentDate".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setShippmentDate(SHIPMENT_DATE_STRING);
			materialsOrderFilter.setShipmentDateFrom(searchField.getFiltervalues());
		}
		if ("shipmentDateEnd".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setShippmentDate(SHIPMENT_DATE_STRING);
			materialsOrderFilter.setShipmentDateTo(searchField.getFiltervalues());
		}
	}
	
	
	private void setMsCustomerInvoiceNumber(MaterialsSearchField searchField, MaterialsOrderRequest materialsOrderFilter){
		if ("msNumber".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setMsNumber("MS_NUMBER");
			materialsOrderFilter.setMsNumberValue(searchField.getFiltervalues());
			LOG.info("msNumber::" + materialsOrderFilter.getMsNumber());
		}

		if ("orderLineType".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setOrderLineType("LINE_CATEGORY_CODE");
			materialsOrderFilter.setOrderLineTypeValue(searchField.getFiltervalues());
		}

		if ("customerNumber".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setCustomerNumber(CUSTOMER_NUMBER_STRING);
			materialsOrderFilter.setCustomerNumberValue(searchField.getFiltervalues());
		}

		if ("purchaseOrder".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setPurchaseOrder("CUST_PO_NUMBER");
			materialsOrderFilter.setPurchareOrderValue(searchField.getFiltervalues());
		}

		if ("invoiceNumber".equalsIgnoreCase(searchField.getFieldName())
				&& isNotNullandEmpty(searchField.getFiltervalues())) {
			materialsOrderFilter.setInvoiceNumber("INVOICE_NUMBER");
			materialsOrderFilter.setInvoiceNumberValue(searchField.getFiltervalues());
		}
	}
	
	public OrderCFMListResponse getMaterialsOrderListCFM(String strSSO, String portalId,
			MultivaluedMap<String, String> form, ArrayList<OrderExportCSVList> arrayList, String iDisplayStart,
			String iDisplayLength, boolean csvExportFlag, String icaoCode, String custCodes) throws MaterialsException {
		LOG.info("Entered getMaterialsOrderList :: ");
		OrderCFMListResponse materialsOrdeCFMListResponse = new OrderCFMListResponse();
		List<MaterialsSearchField> searchList = MaterialsSearchUtil.getFilterFields(form);
		List<MaterialsSortField> sortList = MaterialsSearchUtil.getSortFilterFields(form);
		MaterialsOrderRequest materialsOrderRequest = getFilterParamsForDB(searchList, icaoCode, custCodes, sortList);
		try {

			materialsOrdeCFMListResponse = materialsOrdersDAO.materialsOrderCFMListDS(materialsOrderRequest, portalId);
		} catch (TechnicalException e) {
			LOG.error(e);
			throwAsBusinessException(e);
		}
		return materialsOrdeCFMListResponse;
	}

	public String toCSVCFM(List<MaterialsOrdersCFM> listOfPojos) {
		String csvStr = EMPTY_STRING;
		CsvMapper mapper = new CsvMapper();
		CsvSchema schema = mapper.schemaFor(MaterialsOrdersCFM.class).withHeader();
		try {

			csvStr = mapper.writer(schema).writeValueAsString(listOfPojos);
		} catch (JsonProcessingException e) {
			LOG.error(e);
		}
		return csvStr;
	}

	public String toCSV(List<MaterialsOrders> listOfPojos) {
		String csvStr = EMPTY_STRING;
		CsvMapper mapper = new CsvMapper();
		CsvSchema schema = mapper.schemaFor(MaterialsOrders.class).withHeader();
		try {

			csvStr = mapper.writer(schema).writeValueAsString(listOfPojos);
		} catch (JsonProcessingException e) {
			LOG.error(e);
		}
		return csvStr;
	}

	public String getCsvFileName(String portalId) {
		if (MaterialsAppConstants.PORTAL_CWC.equalsIgnoreCase(portalId)) {
			return MaterialsAppConstants.MYGEA_PORTAL;
		} else if (MaterialsAppConstants.PORTAL_GEHONDA.equalsIgnoreCase(portalId)) {
			return MaterialsAppConstants.MYGEHONDA_PORTAL;
		} else if (MaterialsAppConstants.PORTAL_CFM.equalsIgnoreCase(portalId)) {
			return MaterialsAppConstants.MYCFM_PORTAL;
		}
		return portalId;
	}

	public Response buildResponse(final byte[] bytes, String fileName) {
		Response response = null;
		StreamingOutput stream = null;
		stream = new StreamingOutput() {
			public void write(OutputStream out) throws IOException, WebApplicationException {
				try {
					out.write(bytes);
				} catch (Exception e) {
					LOG.info(e);
					throw new WebApplicationException(e);
				}
			}
		};
		if (bytes != null) {
			response = Response.ok(stream).header("content-disposition", "attachment; filename = " + fileName).build();
		}
		return response;
	}

	public String invoiceEmailContent(String sso, String messageBody) {
		StringBuilder htmlBuilder = new StringBuilder();
		htmlBuilder.append("<h4>Hello " + getFirstName(sso) + " " + getLastName(sso) + COMMA + "</h4>");
		htmlBuilder.append("<br> " + messageBody + "");
		return htmlBuilder.toString();
	}

	public Response buildResponse(final byte[] bytes, String doctype, String fileName) {
		LOG.info("filename: " + fileName);
		StreamingOutput stream = null;
		stream = new StreamingOutput() {
			public void write(OutputStream out) throws IOException, WebApplicationException {
				try {
					out.write(bytes);
				} catch (Exception e) {
					LOG.error(e);
					throw new WebApplicationException(e);
				}
			}
		};
		if (bytes != null) {
			return Response.ok(stream).header("content-disposition", "attachment; filename = " + fileName).build();
		} else {

			return htmlErrorResponse(doctype + " " + ERR_DOCUMENT_NOT_FOUND);
		}
	}

	public void generateEmailMsDocs(String strSSO, String portalId, byte[] bytes, String fileName, String msDocNumber) {
		LOG.info("fileName generateEmailMsDocs--" + fileName);
		List<String> attachmentNameList = new ArrayList<String>();
		List<String> attachmentList = new ArrayList<String>();
		String envmt = getDeployedEnvironment();
		EmailContentInputBO emailContentInputBO = new EmailContentInputBO();
		emailContentInputBO.setFrom(getFromEmailForPortal(portalId));

		if ("PROD".equalsIgnoreCase(envmt)) {
			emailContentInputBO.setTo(getEmailId(strSSO));

		} else {

			emailContentInputBO.setTo("mygeav-materaials.devqaemails@ge.com");// For
																				// Dev/QA

		}

		emailContentInputBO.setSubject("MS Document " + msDocNumber);
		emailContentInputBO.setPortalId(portalId);
		emailContentInputBO.setIdentityId(getAppOwnerId());
		try {
			attachmentList.add(encodeBytesToString(bytes));
			attachmentNameList.add(fileName);
			emailContentInputBO.setAttachmentName(attachmentNameList);
			emailContentInputBO.setMessageAttachment(attachmentList);
			emailContentInputBO.setBody(
					invoiceEmailContent(strSSO, "Please find the attached requested ms Document -" + msDocNumber));
		} catch (Exception e) {
			LOG.error(" document attachment failed. " + e);
		}

		invokeNotificationService(emailContentInputBO, notificationServiceUrl, "MSDocument");
	}


	public String getAltuid(String sso) throws MaterialsException {

		String altUid = null;
		User userBO = getUserDetails(sso, "", USER);
				
		if (null != userBO) {
			List<Property> userProperty = userBO.getUserProperty();
			for (Property property : userProperty) {
				if (MaterialsAppConstants.ATTR_USER_ALTUID.equalsIgnoreCase(property.getPropName())) {
					altUid = property.getPropValue();
					break;
				}
			}
		}

		return altUid;
	}

	public String getUserId(String sso) throws MaterialsException {
		String userId = null;
		userId = getAltuid(sso);
		return getAsString(userId);
	}

	public String makeShipToAddressString(Map<String, String> inputMap) {
		String shipAddress = EMPTY_STRING;
		String tempStr = EMPTY_STRING;
		StringBuilder sbuilder = null;
		if (isMapNotEmpty(inputMap)) {
			sbuilder = new StringBuilder();
			tempStr = getAsString(inputMap.get("SHIP_TO_LOCATION"));
			sbuilder.append(tempStr);
			if (isNotNullandEmpty(tempStr)) {
				sbuilder.append("\n");
			}
			tempStr = getAsString(inputMap.get("SHIP_ADDRESS_1"));
			sbuilder.append(tempStr);
			if (isNotNullandEmpty(tempStr)) {
				sbuilder.append("\n");
			}
			tempStr = getAsString(inputMap.get("SHIP_ADDRESS_2"));
			sbuilder.append(tempStr);
			if (isNotNullandEmpty(tempStr)) {
				sbuilder.append("\n");
			}
			tempStr = getAsString(inputMap.get("SHIP_ADDRESS_3"));
			sbuilder.append(tempStr);
			if (isNotNullandEmpty(tempStr)) {
				sbuilder.append("\n");
			}
			tempStr = getAsString(inputMap.get("SHIP_ADDRESS_4"));
			sbuilder.append(tempStr);
			if (isNotNullandEmpty(tempStr)) {
				sbuilder.append("\n");
			}
			tempStr = getAsString(inputMap.get("SHIP_ADDRESS_5"));
			sbuilder.append(tempStr);

			shipAddress = sbuilder.toString();
		}
		return shipAddress;
	}

	public String makeDeliverToAddressString(Map<String, String> inputMap) {
		String deliverAddress = EMPTY_STRING;
		String tempStr = EMPTY_STRING;
		StringBuilder sbuilder = null;
		if (isMapNotEmpty(inputMap)) {
			sbuilder = new StringBuilder();
			tempStr = getAsString(inputMap.get("DELVR_TO_LOCATION"));
			sbuilder.append(tempStr);
			if (isNotNullandEmpty(tempStr)) {
				sbuilder.append("\n");
			}
			tempStr = getAsString(inputMap.get("DELVR_ADDRESS_1"));
			sbuilder.append(tempStr);
			if (isNotNullandEmpty(tempStr)) {
				sbuilder.append("\n");
			}
			tempStr = getAsString(inputMap.get("DELVR_ADDRESS_2"));
			sbuilder.append(tempStr);
			if (isNotNullandEmpty(tempStr)) {
				sbuilder.append("\n");
			}
			tempStr = getAsString(inputMap.get("DELVR_ADDRESS_3"));
			sbuilder.append(tempStr);
			if (isNotNullandEmpty(tempStr)) {
				sbuilder.append("\n");
			}
			tempStr = getAsString(inputMap.get("DELVR_ADDRESS_4"));
			sbuilder.append(tempStr);
			if (isNotNullandEmpty(tempStr)) {
				sbuilder.append("\n");
			}
			tempStr = getAsString(inputMap.get("DELVR_ADDRESS_5"));
			sbuilder.append(tempStr);

			deliverAddress = sbuilder.toString();
		}
		return deliverAddress;
	}
	
	public String getFractionDateString(String dt) throws MaterialsException {
		String fmtedDt = null;
		if (isNotNullandEmpty(dt)) {
			SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
					"yyyy-MM-dd'T'HH:mm:ss.SS-05:00");
			try {
				fmtedDt = simpleDateFormat.format(simpleDateFormat1.parse(dt));
			} catch (ParseException e) {
				LOG.info(e);
				throw new MaterialsException(
						MaterialsErrorCodes.ERROR_8311,
						materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8311),
						ERR_DATE_FORMAT_NOT_CORRECT);
			}
			return fmtedDt;
		}
		return EMPTY_STRING;
	}

	public boolean isWorkStopDateValid(String orderLineWorkStopDate, String orderLineRequestedDate) {
		
		if(isNullOrEmpty(orderLineRequestedDate))
			return false;
		
		boolean bValidWorkStopDate = true;
				
		DateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT1);
		java.util.Date date1 = null;
		java.util.Date date2 = null;
		
		try {
			date1 = simpleDateFormat.parse(orderLineWorkStopDate);
			date2 = simpleDateFormat.parse(orderLineRequestedDate);
			
			if(date1.before(date2) || date1.equals(date2))
				bValidWorkStopDate = false;
		} 
		catch (ParseException e) {
			LOG.error(e);
		}
		
		return bValidWorkStopDate;
	}
}