
package com.geaviation.materials.app.impl;


import static com.geaviation.materials.app.impl.util.Constants.DOC_EXTENSION;
import static com.geaviation.materials.app.impl.util.Constants.PDF_EXTENSION;
import static com.geaviation.materials.app.impl.util.Constants.XLSX_EXTENSION;
import static com.geaviation.materials.app.impl.util.Constants.ZIP_EXTENSION;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ATA;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ATA_DOC_DISPLAY_NAME;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ATA_DOC_NAME;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.BUYBACK_INSTRUCTIONS;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.BUYBACK_INS_DOC_DISPLAY_NAME;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.BUYBACK_INS_DOC_NAME;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.CHAR_PIPE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.COMMA;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.CONST_UPDATE_ORDER;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.DOC_TYPE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EMAIL_SUBJECT_DISPUTE_TYPE_BB;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EMAIL_SUBJECT_DISPUTE_TYPE_DD;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EMAIL_SUBJECT_DISPUTE_TYPE_OD;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EMAIL_SUBJECT_DISPUTE_TYPE_PE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EMAIL_SUBJECT_DISPUTE_TYPE_SN;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EMAIL_SUBJECT_DISPUTE_TYPE_UD;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EMPTY_STRING;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EQUALS_STRING;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERP_DISPUTE_TYPE_BB;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERP_DISPUTE_TYPE_DD;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERP_DISPUTE_TYPE_OD;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERP_DISPUTE_TYPE_PE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERP_DISPUTE_TYPE_SN;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERP_DISPUTE_TYPE_UD;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_CODE_8300;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_CODE_8034;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_CODE_8035;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_DOCUMENT_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.HEADER_ID;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.HYPHEN;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.OVERAGE_RETURN;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.OVERAGE_SCRAP;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.PORTAL_ID;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.PROFORMA;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.PROFORMA_DOC_DISPLAY_NAME;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.PROFORMA_DOC_NAME;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.RETURN;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.RETURN_INSTRUECTIONS;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.RETURN_INS_DOC_DISPLAY_NAME;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.RETURN_INS_DOC_NAME;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.RETURN_LABEL;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.RETURN_LABEL_DOC_DISPLAY_NAME;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.RMA_NUMBER;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.SCRAP;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.SCRAP_DOC_DISPLAY_NAME;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.SCRAP_DOC_NAME;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.SEMI_COLON;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.SPACE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.SSO;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.UNDERSCORE;
import static com.geaviation.materials.app.impl.util.MaterialsAppUtil.isCollectionNotEmpty;
import static com.geaviation.materials.app.impl.util.MaterialsAppUtil.isNotNullandEmpty;
import static com.geaviation.materials.app.impl.util.MaterialsAppUtil.isNullOrEmpty;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.activation.DataHandler;

import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.app.api.IMaterialsShipmentApp;
import com.geaviation.materials.app.impl.util.InMemoryOutputStream;
import com.geaviation.materials.app.impl.util.MaterialsAppConstants;
import com.geaviation.materials.app.impl.util.MaterialsAppUtil;
import com.geaviation.materials.data.api.IMaterialsShipmentDAO;
import com.geaviation.materials.entity.CustLoginDetails;
import com.geaviation.materials.entity.DisputeDocumentBO;
import com.geaviation.materials.entity.DisputeOrderInput;
import com.geaviation.materials.entity.DisputeOrderStatusBO;
import com.geaviation.materials.entity.DocumentDownloadBO;
import com.geaviation.materials.entity.EmailBodyBO;
import com.geaviation.materials.entity.EmailContentInputBO;
import com.geaviation.materials.entity.MaterialsConstants;
import com.geaviation.materials.entity.ReturnLabelDO;
import com.geaviation.materials.exception.MaterialsErrorCodes;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;

@Component
public class MaterialsShipmentAppImpl implements IMaterialsShipmentApp {
	private static final Log log = LogFactory.getLog(MaterialsShipmentAppImpl.class);
	MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
	
	private static final String HTML_BREAK = "<br>";
	private static final String HTML_COLON_SPACE = "&#58;&nbsp;";
	private static final String HTML_COLON = "&#58;";
	private static final String HTML_COLUMN_ROW = "</td></tr>";
	
	@Autowired
	private MaterialsAppUtil materialsAppUtil;
	
	@Autowired
	private IMaterialsShipmentDAO materialsShipmentData;
	
	@Value("${NOTIFICATION_SERVICE_URL}")
	private String notificationServiceUrl;
	
	@Override
	public DisputeDocumentBO downloadDisputeDocBS(String strSSO, String portalId, String orderHeaderId, String lineId, String docType)
			throws MaterialsException {
		log.info("downloadDisputeDocBS()-<START>");
		String task = EMPTY_STRING;
		String path = EMPTY_STRING;
		String fileName = EMPTY_STRING;
		byte[] bytes = null;
		File file = null;
		ReturnLabelDO returnLabelDO = null;
		DisputeDocumentBO documentBO = null;
		StopWatch watch = new StopWatch();
		task = "getCustLoginDetails";
		materialsAppUtil.startLogging(task, watch);
		CustLoginDetails custLoginDetails = materialsAppUtil.getCustLoginDetails(strSSO,	portalId);
		materialsAppUtil.endLogging(task, watch);
		String portalIdUpperCase = portalId.toUpperCase();
		try {
			documentBO = new DisputeDocumentBO();
			
			
			if (RETURN_LABEL.equals(docType)) {
				returnLabelDO = materialsAppUtil.getDisputeOrderDetails(strSSO, orderHeaderId, custLoginDetails);
				if (null != returnLabelDO && isNullOrEmpty(returnLabelDO.getpMessage())) {
					fileName = RETURN_LABEL_DOC_DISPLAY_NAME+HYPHEN+returnLabelDO.getRmaNumber()+PDF_EXTENSION;					
				bytes = materialsAppUtil.generatePDFReturnLabel(portalIdUpperCase, returnLabelDO);
					documentBO.setFileName(fileName);
					documentBO.setFileData(bytes);
					return documentBO;
				}
			} else if (SCRAP.equals(docType)) {
				path = MaterialsAppConstants.PATH_STATICFILES_SHIPMENT +portalIdUpperCase + UNDERSCORE + SCRAP_DOC_NAME + XLSX_EXTENSION;
				fileName = SCRAP_DOC_DISPLAY_NAME + XLSX_EXTENSION;
			} else if (RETURN_INSTRUECTIONS.equals(docType)) {
				path = MaterialsAppConstants.PATH_STATICFILES_SHIPMENT + portalIdUpperCase +UNDERSCORE+ RETURN_INS_DOC_NAME + PDF_EXTENSION;
				fileName = RETURN_INS_DOC_DISPLAY_NAME + PDF_EXTENSION;
			} else if (BUYBACK_INSTRUCTIONS.equals(docType)) {
				path = MaterialsAppConstants.PATH_STATICFILES_SHIPMENT + portalIdUpperCase + UNDERSCORE + BUYBACK_INS_DOC_NAME + PDF_EXTENSION;
				fileName = BUYBACK_INS_DOC_DISPLAY_NAME + PDF_EXTENSION;
			} else if (PROFORMA.equals(docType)) {
				path = MaterialsAppConstants.PATH_STATICFILES_SHIPMENT + portalIdUpperCase +UNDERSCORE + PROFORMA_DOC_NAME + DOC_EXTENSION;
				fileName = PROFORMA_DOC_DISPLAY_NAME + DOC_EXTENSION;
			} else if (ATA.equals(docType)) {
				path = MaterialsAppConstants.PATH_STATICFILES_SHIPMENT + portalIdUpperCase + UNDERSCORE + ATA_DOC_NAME + DOC_EXTENSION;
				fileName = ATA_DOC_DISPLAY_NAME + DOC_EXTENSION;
			}
			
			Resource resource = new ClassPathResource(path);
			bytes = IOUtils.toByteArray(resource.getInputStream());
			documentBO.setFileName(fileName);
			documentBO.setFileData(bytes);
		} catch (Exception exception) {
			log.info(exception);
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8340,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8340), ERR_DOCUMENT_NOT_FOUND);
		}
		log.info("downloadDisputeDocBS()-<END>");
		return documentBO;
	}

	@Override
	public DisputeOrderStatusBO createDisputeOrderBS(String sso, String portalId, DisputeOrderInput disputeOrderInput, List<Attachment> attachmentList ) throws MaterialsException 
	{
		log.info("Entered into createDisputeOrderBS() method");
		String task = EMPTY_STRING;
		String urlStr = EMPTY_STRING ;
		String[] custArr = new String [1];
		DisputeOrderStatusBO disputeOrderStatusBO = null;
		StopWatch watch = new StopWatch();
		task = "getCustLoginDetails";
		materialsAppUtil.startLogging(task, watch);
		CustLoginDetails custLoginDetails = materialsAppUtil.getCustLoginDetails(sso, portalId);
		materialsAppUtil.endLogging(task, watch);
		//Decode URL String to get actual String 
		String disputeType = materialsAppUtil.decodeURLString(disputeOrderInput.getDisputeReason());
		//convert to ERP dispute type
		disputeOrderInput.setDisputeReason(materialsAppUtil.getDisputeTypeForERP(disputeType));
		//Decode URL String to get actual String 
		String userComments = materialsAppUtil.decodeURLString(disputeOrderInput.getDisputeComments());
		disputeOrderInput.setDisputeComments(userComments);
		disputeOrderInput.setSso(sso);
		disputeOrderInput.setPortalId(portalId);
		disputeOrderInput.setIcao(custLoginDetails.getIcaoCode());
		if(isNotNullandEmpty(disputeOrderInput.getCustomerId())){
			custArr[0] = disputeOrderInput.getCustomerId();
			disputeOrderInput.setCustIdArray(custArr);
		}else{
			disputeOrderInput.setCustIdArray(custLoginDetails.getCustIdList());
		}
		disputeOrderInput.setRole(custLoginDetails.getRole());
		disputeOrderInput.setOperatingUnitId(custLoginDetails.getOperatingUnitId());
		disputeOrderInput.setAddToCartFlagString(materialsAppUtil.getStringFromBoolean(disputeOrderInput.getAddToCartFlag()));
		if(ERP_DISPUTE_TYPE_SN.equalsIgnoreCase(disputeOrderInput.getDisputeReason())){
			ArchiveOutputStream archiveOutputStream = null;
			byte[] fileData = null;
			try(InMemoryOutputStream zipOutStream = new InMemoryOutputStream())
			{
				if(MaterialsAppUtil.isCollectionNotEmpty(attachmentList)){
					archiveOutputStream = new ArchiveStreamFactory().createArchiveOutputStream(ArchiveStreamFactory.ZIP, zipOutStream);
					getDetails(attachmentList,archiveOutputStream);
				}
			
			disputeOrderInput.setFileName("Dispute_"+materialsAppUtil.getCurrentDateAsYYYYMMDD()+ZIP_EXTENSION);
			archiveOutputStream.finish();
			fileData = zipOutStream.getZipContent();
			disputeOrderInput.setFileData(fileData);
			}
			catch (Exception e) {
				log.error(e);
			}
		}
		task = "createDisputeOrderDS";
		materialsAppUtil.startLogging(task, watch);
		try{
			disputeOrderStatusBO = materialsShipmentData.createDisputeOrderDS(disputeOrderInput);
			materialsAppUtil.endLogging(task, watch);
		if(null != disputeOrderStatusBO)
		{
			String pMessage = disputeOrderStatusBO.getpMessage();
			if(isNotNullandEmpty(pMessage)){
				throwMultipleERPMessage(pMessage);
			}
			disputeOrderStatusBO.setDisputeFlag(MaterialsAppUtil.getBooleanFrmString(disputeOrderStatusBO.getStatusMessage()));
			if(disputeOrderStatusBO.isDisputeFlag())
			{
				disputeOrderStatusBO.setDisputeType(disputeOrderInput.getDisputeReason());
				disputeOrderStatusBO.setComments(disputeOrderInput.getDisputeComments());
				String orderHeaderId = disputeOrderStatusBO.getDisputeOrderHeaderId();
				urlStr = materialsAppUtil.getAttivioServicesURL() + CONST_UPDATE_ORDER + EQUALS_STRING + orderHeaderId;
				materialsAppUtil.invokeService(urlStr,MaterialsAppConstants.DISPUTE);
			}
			task = "generateEmail";
			materialsAppUtil.startLogging(task, watch);
			generateEmail(disputeOrderInput,disputeOrderStatusBO);
			materialsAppUtil.endLogging(task, watch);
		}
		}
		catch(TechnicalException e){
			materialsAppUtil.throwAsBusinessException(e);
		}
		log.info("MATL-PERF : <createDisputeOrderBS method> END - Tasks "+ watch.getTaskCount() +" in "+ watch.getTotalTimeMillis() +" msec");
		return disputeOrderStatusBO;
	}
	

	
	private void getDetails(List<Attachment> attachmentList, ArchiveOutputStream archiveOutputStream) throws IOException {
		String fileName = EMPTY_STRING;
		for (org.apache.cxf.jaxrs.ext.multipart.Attachment attr : attachmentList)
		{
			DataHandler handler = attr.getDataHandler();
			InputStream stream = handler.getInputStream();
			String[] contentDisposition = attr.getHeaders().getFirst("Content-Disposition").split(SEMI_COLON);
			for (String filename : contentDisposition)
			{
				if (filename.trim().startsWith("filename"))
				{
					fileName = materialsAppUtil.getFileName(filename);
					makeAsZip(archiveOutputStream,stream,fileName);
				}
			}
		}
		
	}

	private void makeAsZip(ArchiveOutputStream logicalZip, InputStream stream, String fileName) {
		log.info("makeAsZip()-<START>");
		try {
			log.info("Adding... "+fileName);
			logicalZip.putArchiveEntry(new ZipArchiveEntry(fileName));
			IOUtils.copy(stream, logicalZip);
			logicalZip.closeArchiveEntry();
		}catch (Exception e) {
			log.error(e);
		}
		log.info("makeAsZip()-<END>");
	}
	
	private void throwMultipleERPMessage(String pMessage) throws MaterialsException{
		String uiMsg = EMPTY_STRING;
		char lastCharStatusMessage = pMessage.charAt(pMessage.length() - 1);
		if(lastCharStatusMessage == CHAR_PIPE)
		{
			pMessage = pMessage.substring(0, pMessage.length()-1);
		}
		if(pMessage.contains(MaterialsAppConstants.PIPE)){
			uiMsg = materialsAppUtil.getStatusMessage(pMessage);
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8500, uiMsg, pMessage);
		}else{
			if(pMessage.startsWith(ERR_CODE_8300)){
				String[] msgs = materialsAppUtil.getErrorCdnMsg(pMessage);
				throw new MaterialsException(8300, msgs[1], pMessage);
			}
			else if(pMessage.startsWith(ERR_CODE_8034)){
				String[] msgs = materialsAppUtil.getErrorCdnMsg(pMessage);
				throw new MaterialsException(8034, msgs[1], pMessage);
			}
			else if(pMessage.startsWith(ERR_CODE_8035)){
				String[] msgs = materialsAppUtil.getErrorCdnMsg(pMessage);
				throw new MaterialsException(8035, msgs[1], pMessage);
			}else{
				materialsAppUtil.throwERPMessage(pMessage);
			}
		}
	}
	
	private void generateEmail(DisputeOrderInput disputeOrderInput,DisputeOrderStatusBO disputeOrderStatusBO){
		EmailContentInputBO mailContentInputBO = populateEmailContent(disputeOrderInput, disputeOrderStatusBO);
		EmailBodyBO emailBodyBO = populateEmailBody(disputeOrderInput,disputeOrderStatusBO);
		mailContentInputBO.getTo();
		mailContentInputBO.getFrom();
		mailContentInputBO.getCc();
		String disputeOrderNumber = disputeOrderStatusBO.getDisputeOrderNumber();
		boolean attachedFlag = false;
		if(isCollectionNotEmpty(mailContentInputBO.getAttachmentName())){
			attachedFlag = true;
		}
		mailContentInputBO.setSubject(generateSubject(disputeOrderInput.getDisputeReason(), disputeOrderNumber));
		mailContentInputBO.setBody(emailContent(emailBodyBO,disputeOrderInput,attachedFlag,disputeOrderInput.getPortalId()));
		mailContentInputBO.getIdentityId();
		materialsAppUtil.invokeNotificationService(mailContentInputBO,notificationServiceUrl,MaterialsAppConstants.DISPUTE);
	}

	private String generateSubject(String disputeType, String orderNumber){
		StringBuilder subjectStrSB = new StringBuilder();
		if(ERP_DISPUTE_TYPE_SN.equals(disputeType)){
			subjectStrSB.append(RMA_NUMBER).append(orderNumber).append(SPACE).append(HYPHEN).append(SPACE).append(EMAIL_SUBJECT_DISPUTE_TYPE_SN);
		}else if(ERP_DISPUTE_TYPE_DD.equals(disputeType)){
			subjectStrSB.append(RMA_NUMBER).append(orderNumber).append(SPACE).append(HYPHEN).append(SPACE).append(EMAIL_SUBJECT_DISPUTE_TYPE_DD);
		}
		else if(ERP_DISPUTE_TYPE_UD.equals(disputeType)){
			subjectStrSB.append(RMA_NUMBER).append(orderNumber).append(SPACE).append(HYPHEN).append(SPACE).append(EMAIL_SUBJECT_DISPUTE_TYPE_UD);
		}
		else if(ERP_DISPUTE_TYPE_OD.equals(disputeType)){
			subjectStrSB.append(RMA_NUMBER).append(orderNumber).append(SPACE).append(HYPHEN).append(SPACE).append(EMAIL_SUBJECT_DISPUTE_TYPE_OD);
		}
		else if(ERP_DISPUTE_TYPE_BB.equals(disputeType)){
			subjectStrSB.append(RMA_NUMBER).append(orderNumber).append(SPACE).append(HYPHEN).append(SPACE).append(EMAIL_SUBJECT_DISPUTE_TYPE_BB);
		}
		else if(ERP_DISPUTE_TYPE_PE.equals(disputeType)){
			subjectStrSB.append(RMA_NUMBER).append(orderNumber).append(SPACE).append(HYPHEN).append(SPACE).append(EMAIL_SUBJECT_DISPUTE_TYPE_PE);
		}
		return subjectStrSB.toString();
	}

	private String emailContent(EmailBodyBO emailBodyBO, DisputeOrderInput disputeOrderInput, boolean attached, String portalID) {
		StringBuilder htmlBuilder = new StringBuilder();
		String envmt = materialsAppUtil.getDeployedEnvironment();
		if("DEV".equalsIgnoreCase(envmt) || "QA".equalsIgnoreCase(envmt)){
			htmlBuilder.append("<h5 style='color:#0000ff;font-size:12px; font-family: ge-inspira, Helvetica Neue, Helvetica, Arial, sans-serif;'>This is a test mail. You can ignore this.</h5>");
		}
		htmlBuilder.append("<h4>Hello" + SPACE + emailBodyBO.getFirstName()
				+ SPACE + emailBodyBO.getLastName() + COMMA + "</h4>");
		// Fix for MYJIRATEST-12411
		if("CWC".equalsIgnoreCase(portalID)){
			htmlBuilder.append(MaterialsAppConstants.DISPUTE_MAIL_MESSAGE_MYGEA+MaterialsAppConstants.DISPUTE_MAIL_MESSAGE + HTML_COLON);
		}else if("GEHonda".equalsIgnoreCase(portalID)){
			htmlBuilder.append(MaterialsAppConstants.DISPUTE_MAIL_MESSAGE_MYHONDA+MaterialsAppConstants.DISPUTE_MAIL_MESSAGE + HTML_COLON);
		}else if(MaterialsConstants.MYCFM.equalsIgnoreCase(portalID)){
			htmlBuilder.append(MaterialsAppConstants.DISPUTE_MAIL_MESSAGE_MYCFM+MaterialsAppConstants.DISPUTE_MAIL_MESSAGE + HTML_COLON);
		}
		
		htmlBuilder.append(insertOrderInfoTable(emailBodyBO, disputeOrderInput));
		if(attached){
			htmlBuilder.append(MaterialsAppConstants.EMAIL_BODY_MESSAGE_FOR_ATTACHMENT);
		}
		return htmlBuilder.toString();
	}
	
	private String insertOrderInfoTable(EmailBodyBO emailBodyBO, DisputeOrderInput disputeOrderInput){
		StringBuilder orderInfoContent = new StringBuilder();
		orderInfoContent.append("<style>");
		orderInfoContent.append("table,tbody,tr,td{border-spacing:1px; border-collapse: collapse; border-color: #26272b;}");
		orderInfoContent.append("table.innerTable{border-color: transparent;}");
		orderInfoContent.append(".textStyle{color: #26272b;font-family: ge-inspira, Helvetica Neue, Helvetica, Arial, sans-serif; font-style: normal; font-weight: normal; letter-spacing: normal;}");
		orderInfoContent.append("</style>");
		orderInfoContent.append(HTML_BREAK);
		orderInfoContent.append("<table width='100%' border='1px' align='left' class='textStyle'>");
		orderInfoContent.append("<tr><td>RMA</td><td>"+emailBodyBO.getRma()+HTML_COLUMN_ROW);
		orderInfoContent.append("<tr><td>Original Purchase Order</td><td>"+emailBodyBO.getOriginalPurchaseOrder()+HTML_COLUMN_ROW);
		orderInfoContent.append("<tr><td>Original Purchase Order Line</td><td>"+emailBodyBO.getOriginalPurchaseOrderLine()+"</tr>");
		orderInfoContent.append("<tr><td>Dispute Type</td><td>"+emailBodyBO.getDisputeType()+HTML_COLUMN_ROW);
		orderInfoContent.append("<tr><td>Discrepancy Reason</td>"+insertDisputeReasonTable(disputeOrderInput)+HTML_COLUMN_ROW);
		orderInfoContent.append("<tr><td>Order Value</td><td>"+materialsAppUtil.getCurrencyFormattedValue(emailBodyBO.getOrderValue())+HTML_COLUMN_ROW);
		orderInfoContent.append("<tr><td>Comments</td><td>"+disputeOrderInput.getDisputeComments()+HTML_COLUMN_ROW);
		orderInfoContent.append("</table><br/>");
		return orderInfoContent.toString();
	}
	
	private String insertDisputeReasonTable(DisputeOrderInput disputeOrderInput){
		String disputeType = disputeOrderInput.getDisputeReason();
		StringBuilder disputeReasonSb = new StringBuilder();
		List<String> receivedPartList = null;
		List<String> orderedPartList = null;
		if(ERP_DISPUTE_TYPE_SN.equals(disputeType)){
			receivedPartList = materialsAppUtil.getStringAsList(disputeOrderInput.getSerialNumberReceivedSerialNumber(), "|");
			orderedPartList = materialsAppUtil.getStringAsList(disputeOrderInput.getSerialNumberSelectedSerialNumber(), "|");
			disputeReasonSb.append("<td colspan='2'>");
			disputeReasonSb.append("<table border='1px' width='100%' class='innerTable'>");
			disputeReasonSb.append("<tr><td>"+MaterialsAppConstants.EMAIL_DISPUTE_TYPE_SN_ON_PAPER+"</td><td>"+MaterialsAppConstants.EMAIL_DISPUTE_TYPE_SN_ON_PART+HTML_COLUMN_ROW);
			//iterate this line
			for (int i = 0; i < receivedPartList.size(); i++) {
				disputeReasonSb.append("<tr><td>"+orderedPartList.get(i)+"</td><td>"+receivedPartList.get(i)+HTML_COLUMN_ROW);
			}
			disputeReasonSb.append("</table>");
		}else if(ERP_DISPUTE_TYPE_DD.equals(disputeType)){
			disputeReasonSb.append("<td>"+MaterialsAppConstants.EMAIL_DISPUTE_TYPE_DD+HTML_COLON_SPACE+disputeOrderInput.getDiscrepancyPartNumberReceived());
		}
		else if(ERP_DISPUTE_TYPE_UD.equals(disputeType)){
			disputeReasonSb.append("<td>"+MaterialsAppConstants.EMAIL_DISPUTE_TYPE_UD+HTML_COLON_SPACE+disputeOrderInput.getUnderShipmentQuantityReceived());
		}
		else if(ERP_DISPUTE_TYPE_OD.equals(disputeType)){
			disputeReasonSb.append("<td>"+MaterialsAppConstants.EMAIL_DISPUTE_TYPE_OD+HTML_COLON_SPACE+disputeOrderInput.getOverShipmentQuantityReceived());
		}
		else if(ERP_DISPUTE_TYPE_BB.equals(disputeType)){
			disputeReasonSb.append("<td>"+MaterialsAppConstants.EMAIL_DISPUTE_TYPE_BB);
		}
		else if(ERP_DISPUTE_TYPE_PE.equals(disputeType)){
			disputeReasonSb.append("<td>"+MaterialsAppConstants.EMAIL_DISPUTE_TYPE_PE+HTML_COLON_SPACE+materialsAppUtil.getCurrencyFormattedValue(disputeOrderInput.getPricingErrorExpectedUnitPrice()));
		}
		return disputeReasonSb.toString();
	}
	
	private EmailContentInputBO populateEmailContent(DisputeOrderInput disputeOrderInput,DisputeOrderStatusBO disputeOrderStatusBO){
		EmailContentInputBO emailContent = new EmailContentInputBO();
		List<String> ccMailIdList = null;
		List<String> ccMailList = null;
		List<String> attachmentNameList = new ArrayList<String>();
		List<String> attachmentList = new ArrayList<String>();
		List<DocumentDownloadBO> downloadLinks = new ArrayList<DocumentDownloadBO>();
		Map<String, String> downloadInputMap = null;
		String toMailId = EMPTY_STRING;
		String ccMails = EMPTY_STRING;
		String sso = disputeOrderInput.getSso();
		String portalId = disputeOrderInput.getPortalId();
		String icao = disputeOrderInput.getIcao();
		String role = disputeOrderInput.getRole();
		String opUid = disputeOrderInput.getOperatingUnitId();
		String disputeOrderId = disputeOrderStatusBO.getDisputeOrderHeaderId();
		String orderType = disputeOrderStatusBO.getScrapOrReturn();
		String envmt = materialsAppUtil.getDeployedEnvironment();
		boolean fileAttached = false;
		emailContent.setIdentityId(materialsAppUtil.getAppOwnerId());
		emailContent.setPortalId(portalId);
		emailContent.setFrom(materialsAppUtil.getFromEmailForPortal(portalId));
		String custAdminEmailId = materialsAppUtil.getCAMEmailId(sso, icao, disputeOrderInput.getCustIdArray(), role, opUid);
		if(isNotNullandEmpty(custAdminEmailId)){
			ccMailIdList = materialsAppUtil.getStringAsList(custAdminEmailId, SEMI_COLON);
			ccMailList = materialsAppUtil.removeDuplicateStringFromList(ccMailIdList);
			ccMails = materialsAppUtil.getListAsString(ccMailList);
			ccMails = ccMails.replaceAll(SEMI_COLON,COMMA);
		}
		if("PROD".equalsIgnoreCase(envmt)){
			toMailId = materialsAppUtil.getEmailId(disputeOrderInput.getSso());
			if(isNotNullandEmpty(toMailId)){
				emailContent.setTo(materialsAppUtil.getEmailId(disputeOrderInput.getSso()));
			}else{
				emailContent.setTo(ccMails);
			}
			emailContent.setCc(ccMails);//for Prod
		}else{
			emailContent.setTo("mygeav-materaials.devqaemails@ge.com");//For Dev/QA
			}
		downloadInputMap = new HashMap<String, String>();
		downloadInputMap.put(SSO, sso);
		downloadInputMap.put(PORTAL_ID, portalId);
		downloadInputMap.put(HEADER_ID, disputeOrderId);
		if(isNotNullandEmpty(orderType) && (orderType.equalsIgnoreCase(SCRAP) || orderType.equalsIgnoreCase(OVERAGE_SCRAP))){
			downloadInputMap.put(DOC_TYPE, SCRAP);
			fileAttached = addAttachment(attachmentNameList, attachmentList, downloadInputMap);
			materialsAppUtil.createDownloadLinks(portalId,disputeOrderId,SCRAP,SCRAP_DOC_DISPLAY_NAME,downloadLinks,fileAttached);
		}
		if(isNotNullandEmpty(orderType) && (orderType.equalsIgnoreCase(RETURN) || orderType.equalsIgnoreCase(OVERAGE_RETURN))){
			downloadInputMap.put(DOC_TYPE, RETURN_INSTRUECTIONS);
			fileAttached = addAttachment(attachmentNameList, attachmentList, downloadInputMap);
			materialsAppUtil.createDownloadLinks(portalId,disputeOrderId,RETURN_INSTRUECTIONS,RETURN_INS_DOC_DISPLAY_NAME,downloadLinks,fileAttached);

			downloadInputMap.put(DOC_TYPE, PROFORMA);
			fileAttached = addAttachment(attachmentNameList, attachmentList, downloadInputMap);
			materialsAppUtil.createDownloadLinks(portalId,disputeOrderId,PROFORMA,PROFORMA_DOC_DISPLAY_NAME,downloadLinks,fileAttached);

			downloadInputMap.put(DOC_TYPE, RETURN_LABEL);
			fileAttached = addAttachment(attachmentNameList, attachmentList, downloadInputMap);
			materialsAppUtil.createDownloadLinks(portalId,disputeOrderId,RETURN_LABEL,RETURN_LABEL_DOC_DISPLAY_NAME+HYPHEN+disputeOrderStatusBO.getDisputeOrderNumber(),downloadLinks,fileAttached);
		}
		if(isNullOrEmpty(orderType) && disputeOrderInput.getDisputeReason().equalsIgnoreCase(ERP_DISPUTE_TYPE_BB)){
			downloadInputMap.put(DOC_TYPE, BUYBACK_INSTRUCTIONS);
			fileAttached = addAttachment(attachmentNameList, attachmentList, downloadInputMap);
			materialsAppUtil.createDownloadLinks(portalId,disputeOrderId,BUYBACK_INSTRUCTIONS,BUYBACK_INS_DOC_DISPLAY_NAME,downloadLinks,fileAttached);

			downloadInputMap.put(DOC_TYPE, ATA);
			fileAttached = addAttachment(attachmentNameList, attachmentList, downloadInputMap);
			materialsAppUtil.createDownloadLinks(portalId,disputeOrderId,ATA,ATA_DOC_DISPLAY_NAME,downloadLinks,fileAttached);

			downloadInputMap.put(DOC_TYPE, RETURN_LABEL);
			fileAttached = addAttachment(attachmentNameList, attachmentList, downloadInputMap);
			materialsAppUtil.createDownloadLinks(portalId,disputeOrderId,RETURN_LABEL,RETURN_LABEL_DOC_DISPLAY_NAME+HYPHEN+disputeOrderStatusBO.getDisputeOrderNumber(),downloadLinks,fileAttached);

		}
		disputeOrderStatusBO.setDownloadDocumentBOList(downloadLinks);
		emailContent.setAttachmentName(attachmentNameList);
		emailContent.setMessageAttachment(attachmentList);
		return emailContent;
	}

	private boolean addAttachment(List<String> attachmentNameList, List<String> attachmentList, Map<String,String> inputMap){
		DisputeDocumentBO disputeDocumentBO = null;
		String docType = inputMap.get(DOC_TYPE);
		String sso = inputMap.get(SSO);
		String portalId = inputMap.get(PORTAL_ID);
		String headerId = inputMap.get("HEADER_ID");
		String fileName = EMPTY_STRING;
		byte[] attachment = null;
		boolean attached = true;
		try {
			disputeDocumentBO = downloadDisputeDocBS(sso,portalId,headerId,null,docType);
			if(null!=disputeDocumentBO){
				attachment = disputeDocumentBO.getFileData();
				if(null != attachment && attachment.length > 0){
					fileName = disputeDocumentBO.getFileName();
					attachmentNameList.add(fileName);
					attachmentList.add(materialsAppUtil.encodeBytesToString(attachment));
				}
			}
		}catch (MaterialsException e) {
			log.error(docType+" document attachment failed. "+e);
			attached = false;
		}
		return attached;
	}

	private EmailBodyBO populateEmailBody(DisputeOrderInput disputeOrderInput,DisputeOrderStatusBO disputeOrderStatusBO){
		EmailBodyBO emailContent = new EmailBodyBO();
		emailContent.setFirstName(materialsAppUtil.getFirstName(disputeOrderInput.getSso()));
		emailContent.setLastName(materialsAppUtil.getLastName(disputeOrderInput.getSso()));
		emailContent.setRma(disputeOrderStatusBO.getDisputeOrderNumber());
		emailContent.setOrderType(disputeOrderStatusBO.getScrapOrReturn());
		emailContent.setOrderValue(disputeOrderStatusBO.getOrderValue());
		emailContent.setOriginalPurchaseOrder(disputeOrderStatusBO.getOriginalPONumber());
		emailContent.setOriginalPurchaseOrderLine(disputeOrderStatusBO.getOriginalPOLineNumber());
		emailContent.setDisputeType(disputeOrderInput.getDisputeReason());
		return emailContent;
	}


}
