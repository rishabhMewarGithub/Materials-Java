/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 12, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     MaterialsAppImpl.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.app.impl;

import static com.geaviation.materials.app.impl.util.Constants.HTML_MSG1;
import static com.geaviation.materials.app.impl.util.Constants.HTML_MSG2;
import static com.geaviation.materials.app.impl.util.Constants.PDF_EXTENSION;
import static com.geaviation.materials.app.impl.util.Constants.XLS_EXTENSION;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.AVAIL_MSG_03;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.AVIAL_MSG_1;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.AVIAL_MSG_2;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.CF34;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.CF348S;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.CHAR_COMMA;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.COLON;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.CONST_AVAIL_MSG;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.CONST_MESSAGE_CODE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.CONST_PRICE_MSG;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.DOT;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EFFDATE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EFFECTIVE_DATE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EMPTY_STRING;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ENGINE_MODEL;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_CODE_8167;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_CUST_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_DATATABLE_DISPLAY_ERROR_OCCURED;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_DATATABLE_ERROR_OCCURED;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_DOCTYPE_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_DOCUMENT_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_FOLDER_DOES_NOT_EXIST;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_NO_PLATFORM_AVAIL;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_PARTNUM_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_PLATFORM_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_PORTAL_ID_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_SHIP_CODE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_SSO_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.EXCEL;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.FLOW_STATUS_OPEN;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.GE_VENDOR_MSG;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.MSG_CRITCL_CE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.MSG_CRITCL_GE_BUYER;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.NON_GE_VENDOR_MSG1;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.NON_GE_VENDOR_MSG2;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.PDF;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.PORTAL_CWC;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.PORTAL_GEHONDA;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.PRICE_MSG_02;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.REPAIR_DOCS_URL;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.REVISION_DATE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ROLE_BUYER;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ROLE_CE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ROLE_GE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.UNDERSCORE;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.VENDOR_062W0;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.VENDOR_99205;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.XLXS;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.Y;
import static com.geaviation.materials.app.impl.util.MaterialsAppUtil.isNotNullandEmpty;

import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.StreamingOutput;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.app.api.IMaterialsApp;
import com.geaviation.materials.app.api.IMaterialsLoginApp;
import com.geaviation.materials.app.impl.util.EngineModelAscComparator;
import com.geaviation.materials.app.impl.util.EngineModelDescComparator;
import com.geaviation.materials.app.impl.util.MaterialsAppConstants;
import com.geaviation.materials.app.impl.util.MaterialsAppUtil;
import com.geaviation.materials.app.impl.util.MaterialsDateFormatUtil;
import com.geaviation.materials.app.impl.util.RepairEffectiveDateDescComparator;
import com.geaviation.materials.app.impl.util.RepairEffectvieDateAscComparator;
import com.geaviation.materials.app.impl.util.RepairRevDateAscComparator;
import com.geaviation.materials.app.impl.util.RepairRevDateDescComparator;
import com.geaviation.materials.data.api.IMaterialsDAO;
import com.geaviation.materials.entity.BulkAddPartBO;
import com.geaviation.materials.entity.BulkPartDetailsBO;
import com.geaviation.materials.entity.CustAdmin;
import com.geaviation.materials.entity.CustGlobEnqDetails;
import com.geaviation.materials.entity.CustLoginDetails;
import com.geaviation.materials.entity.CustomerAdminDetailsBO;
import com.geaviation.materials.entity.CustomerBO;
import com.geaviation.materials.entity.DeliverAddress;
import com.geaviation.materials.entity.DeliveryAddressBO;
import com.geaviation.materials.entity.EffectiveDateAscComparator;
import com.geaviation.materials.entity.EffectiveDateDescComparator;
import com.geaviation.materials.entity.LineDetailBO;
import com.geaviation.materials.entity.LineDetailDO;
import com.geaviation.materials.entity.LineInfoBO;
import com.geaviation.materials.entity.LineInfoDO;
import com.geaviation.materials.entity.MappingAddress;
import com.geaviation.materials.entity.MaterialsLoginResponse;
import com.geaviation.materials.entity.MaterialsSortField;
import com.geaviation.materials.entity.MaterialsUserBO;
import com.geaviation.materials.entity.OrderStatusBO;
import com.geaviation.materials.entity.OrderTemplateStatusBO;
import com.geaviation.materials.entity.PartBO;
import com.geaviation.materials.entity.PartsInputDO2;
import com.geaviation.materials.entity.Platform;
import com.geaviation.materials.entity.PlatformAscComparator;
import com.geaviation.materials.entity.PlatformDecComparator;
import com.geaviation.materials.entity.Pricing;
import com.geaviation.materials.entity.PricingCatalogBO;
import com.geaviation.materials.entity.PricingCatalogDO;
import com.geaviation.materials.entity.PricingCatalogDates;
import com.geaviation.materials.entity.RepairCatalog;
import com.geaviation.materials.entity.RepairCatalogBO;
import com.geaviation.materials.entity.RevisionDateAscComparator;
import com.geaviation.materials.entity.RevisionDateDescComparator;
import com.geaviation.materials.entity.ShipAddress;
import com.geaviation.materials.entity.ShippingAddressBO;
import com.geaviation.materials.entity.ShiptoMarkforAddress;
import com.geaviation.materials.exception.MaterialsErrorCodes;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.mongodb.client.gridfs.model.GridFSFile;


@Component
public class MaterialsAppImpl implements IMaterialsApp{

	@Autowired
	private MaterialsExceptionUtil materialsExceptionUtil;
	
	@Autowired
	private MaterialsAppUtil materialsAppUtil;

	@Autowired
	private IMaterialsLoginApp materialsLoginApp;
	
	@Autowired
	private IMaterialsDAO materialsDAO;

	private static final Log log = LogFactory.getLog(MaterialsAppImpl.class);
	private Integer resultSize;
	
	@Value("${ICAO_CODE_AVIAL_GTA}")
	private String icaoCodeAvialGTA;

	@Value("${ICAO_CODE_GTA}")
	private String icaoCodeGTA;

	
	public Integer fetchResultSize() {
		return resultSize;
	}
	
	@Override
	public ShiptoMarkforAddress getShiptoMarkforAddressBS(String strSSO,String portalId,String custId) throws MaterialsException
		{
			if(!isNotNullandEmpty(custId)){
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8328, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8328), ERR_CUST_NOT_FOUND);
			}
			ShiptoMarkforAddress shiptoMarkforAddress = new ShiptoMarkforAddress();
			CustomerAdminDetailsBO custAdminDetailsBO = null;
			ShippingAddressBO shppingAddressBO = null;
			DeliveryAddressBO deliveryAddressBODetails = null;
			List<ShippingAddressBO> lstShppingAddressBO = new ArrayList<ShippingAddressBO>();
			List<MappingAddress> lstmappingAddress = null;
			List<DeliveryAddressBO> deliveryAddressBOList =null;
			Set<String> shipAddressCodesList = null;
			custAdminDetailsBO = getCustAdminDetailsBS(strSSO,portalId,custId);
			lstmappingAddress = custAdminDetailsBO.getMappingAddressList();
			
			List<ShipAddress> listShippingAddress = null;
			List<DeliverAddress> listDeliverAddress = null;
			listShippingAddress = custAdminDetailsBO.getShipAddressList();
			listDeliverAddress = custAdminDetailsBO.getDeliverAddressBOList();
			
			
			/*store the shipAddressCodesList into HashSet */
			shipAddressCodesList = new HashSet<String>();
			for(MappingAddress shipAddressCodes: lstmappingAddress) {
				shipAddressCodesList.add(shipAddressCodes.getShipAddressCode());
			}
			for(String shipAddressId: shipAddressCodesList) {
				shppingAddressBO = new ShippingAddressBO();
				deliveryAddressBOList = new ArrayList<DeliveryAddressBO>();
				for(MappingAddress mappingAddDetailsBO: lstmappingAddress) {
					if(shipAddressId.equals(mappingAddDetailsBO.getShipAddressCode())) {
						
						for(ShipAddress shipAddress: listShippingAddress) {
							if(shipAddress.getShipAddressId().equalsIgnoreCase(mappingAddDetailsBO.getShipAddressId())){
								shppingAddressBO.setShipAddressCode(mappingAddDetailsBO.getShipAddressCode());
								shppingAddressBO.setShipAddressId(mappingAddDetailsBO.getShipAddressId());
								shppingAddressBO.setCustomerId(mappingAddDetailsBO.getCustId());
								shppingAddressBO.setShipAddress1(mappingAddDetailsBO.getShipAddress1());
								//JIRA 6293 start								
								shppingAddressBO.setDefaultShipToInd(isDefaultShipToInd(shipAddress));
								//JIRA 6293 End
								shppingAddressBO.setShipAddress2(shipAddress.getAddress2());
								shppingAddressBO.setShipAddress3(shipAddress.getAddress3());
								shppingAddressBO.setShipAddress4(shipAddress.getAddress4());
								shppingAddressBO.setShipCity(shipAddress.getCity());
								shppingAddressBO.setShipState(shipAddress.getState());
								shppingAddressBO.setShipZip(shipAddress.getZip());
								shppingAddressBO.setShipCountry(shipAddress.getCountry());
								
								deliveryAddressBODetails = getDeliveryAddressBO(mappingAddDetailsBO,listDeliverAddress);
							}						
						}		
						deliveryAddressBOList.add(deliveryAddressBODetails);	
					}		
				}
				shppingAddressBO.setAddressList(deliveryAddressBOList);
				lstShppingAddressBO.add(shppingAddressBO);
			}
			shiptoMarkforAddress.setLstShppingAddressBO(lstShppingAddressBO);
			return shiptoMarkforAddress;
	}

	private boolean isDefaultShipToInd(ShipAddress shipAddress) {
		boolean result = false;
		if (isNotNullandEmpty(shipAddress.getDefaultShipToInd())) {
			if (shipAddress.getDefaultShipToInd().equals(MaterialsAppConstants.Y)) {
				result = true;
			}
		}
		return result;
	}

	private DeliveryAddressBO getDeliveryAddressBO(MappingAddress mappingAddDetailsBO,
			List<DeliverAddress> listDeliverAddress) {
		DeliveryAddressBO deliveryAddressBO = new DeliveryAddressBO();
		deliveryAddressBO.setDeliverAddress1(mappingAddDetailsBO.getDeliverAddress1());
		deliveryAddressBO.setDeliverAddressCode(mappingAddDetailsBO.getDeliverAddressCode());
		deliveryAddressBO.setDeliverAddressId(mappingAddDetailsBO.getDeliverAddressId());
		if(mappingAddDetailsBO.getDefaultInd().equals(MaterialsAppConstants.Y)) {
			deliveryAddressBO.setDefaultIndicator(true);
		} else {
			deliveryAddressBO.setDefaultIndicator(false);
		}
		
		for(DeliverAddress deliverAddress: listDeliverAddress) {
			if(deliverAddress.getDeliverAddressId().equalsIgnoreCase(mappingAddDetailsBO.getDeliverAddressId())){
				deliveryAddressBO.setDeliverAddress2(deliverAddress.getAddress2());
				deliveryAddressBO.setDeliverAddress3(deliverAddress.getAddress3());
				deliveryAddressBO.setDeliverAddress4(deliverAddress.getAddress4());
				deliveryAddressBO.setDeliverCity(deliverAddress.getCity());
				deliveryAddressBO.setDeliverState(deliverAddress.getState());
				deliveryAddressBO.setDeliverZip(deliverAddress.getZip());
				deliveryAddressBO.setDeliverCountry(deliverAddress.getCountry());
			}
		}
		return deliveryAddressBO;
	}

	/**
	 * @param custId
	 * @param sso
	 * @param portalId
	 * @return CustomerAdminDetailsBO
	 * @throws MaterialsException
	 */
	@Override
	public CustomerAdminDetailsBO getCustAdminDetailsBS(String strSSO,String portalId,String custId) throws MaterialsException {
			if(!isNotNullandEmpty(strSSO)){
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8301, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND);
			}
			if(!isNotNullandEmpty(portalId)){
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8302, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8302),ERR_PORTAL_ID_NOT_FOUND);
			}
			MaterialsLoginResponse materialsLoginDetail = null;
			MaterialsUserBO materialsUserBO =new MaterialsUserBO();
			List<CustomerBO> customerBOList = null;
			String role=MaterialsAppConstants.EMPTY_STRING;
			String icaoCode=MaterialsAppConstants.EMPTY_STRING;
			String operatingUnitId=MaterialsAppConstants.EMPTY_STRING;
			CustomerAdminDetailsBO custAdminDetails = null;
			try{
				materialsLoginDetail = materialsLoginApp.requestMaterialsLogin(strSSO, portalId);
			} catch (MaterialsException e) {
				log.error(e);
				materialsAppUtil.throwAsBusinessException(e);
			}
			materialsUserBO = materialsLoginDetail.getMaterialsUserBO();
			if (isNotNullandEmpty(materialsUserBO.getIcaoCode()))
				icaoCode = materialsUserBO.getIcaoCode();
			if (isNotNullandEmpty(materialsUserBO.getRole()))
				role = materialsUserBO.getRole();
			if (isNotNullandEmpty(materialsUserBO.getOperatingUnitId()))
				operatingUnitId = materialsUserBO.getOperatingUnitId();
			if(materialsUserBO.getCustomerBOList() != null && !materialsUserBO.getCustomerBOList().isEmpty()){
				customerBOList = materialsUserBO.getCustomerBOList();
			}
			String[] custIdList = null;
			if (custId != null) {
				ArrayList<String> custIdLst = new ArrayList<String>(
						Arrays.asList(custId.split("\\|")));
				custIdList = new String[custIdLst.size()];
				for (int i = 0; i < custIdLst.size(); i++) {
					custIdList[i] = custIdLst.get(i);
				}
			} else {
				if (customerBOList != null) {
					custIdList = new String[customerBOList.size()];

					if (custIdList != null) {
						for (int i = 0; i < customerBOList.size(); i++) {
							CustomerBO customerBO = customerBOList.get(i);
							custIdList[i] = customerBO.getCustId();
						}
					}
				}

			}
			try {
				custAdminDetails = materialsDAO.getCustDetailDS(strSSO, icaoCode,
						custIdList, role, operatingUnitId, "");
			} catch (TechnicalException e) {
				materialsAppUtil.throwAsBusinessException(e);
			}
			if (isNotNullandEmpty(custAdminDetails.getMessage())) {
				materialsAppUtil.throwERPMessage(custAdminDetails.getMessage());
			} else {
				custAdminDetails.setMaterialsUserBO(materialsUserBO);
			}
			return custAdminDetails;
	}
	@SuppressWarnings("unchecked")
	@Override
	public LineDetailBO getLineDetailBS(String strSSO, String portalId,	String msNumber, String deliveryId, String orderHeaderId,
			String invoiceHeaderId, List<MaterialsSortField> sortFields,Integer start, Integer limit) throws MaterialsException {
		log.info("Entered into getLineDetailBS() method");
		String task = EMPTY_STRING;
		StopWatch watch = new StopWatch();
		CustLoginDetails custLoginDetails = null;
		LineDetailDO lineDetailDO = null;
		LineDetailBO lineDetailBO = new LineDetailBO() ;
		List<LineInfoBO> lineInfoBOList = new ArrayList<LineInfoBO>();
		List<LineInfoBO> lineInfoBOListNew = new ArrayList<LineInfoBO>();
		List<LineInfoDO> lineInfoDOList = null;
		task = "getCustLoginDetails";
		materialsAppUtil.startLogging(task, watch);
		custLoginDetails =  materialsAppUtil.getCustLoginDetails(strSSO,portalId);
		materialsAppUtil.endLogging(task, watch);
		if(materialsAppUtil.validateInputs(msNumber, deliveryId, orderHeaderId, invoiceHeaderId)){
			try{
				task = "materialsCartDAO.getLineDetailBS";
				materialsAppUtil.startLogging(task, watch);
				lineDetailDO = materialsDAO.getLineDetailDS(strSSO,custLoginDetails.getIcaoCode(),custLoginDetails.getCustIdList(),
						custLoginDetails.getRole(),custLoginDetails.getOperatingUnitId(),msNumber,deliveryId,orderHeaderId,invoiceHeaderId);
				materialsAppUtil.endLogging(task, watch);
				if(null!=lineDetailDO){
					if(isNotNullandEmpty(lineDetailDO.getMessage())){
						String pMessage = lineDetailDO.getMessage();
						if(pMessage.startsWith(MaterialsAppConstants.ERR_CODE_8031)){
							lineDetailBO.setDisplayMessage(materialsExceptionUtil.getErrorMessage(MaterialsAppConstants.ERR_CODE_8031));
							lineDetailBO.setOrderLineList(lineInfoBOList);
							resultSize = lineInfoBOList.size();
							return lineDetailBO;
						}else{
							materialsAppUtil.throwERPMessage(lineDetailDO.getMessage());
						}
					}
					else{
						lineInfoDOList = lineDetailDO.getLineInfoDOList();
						if (!lineInfoDOList.isEmpty()) {
							lineInfoBOList = getLineInfoBOList(lineInfoDOList,portalId,lineInfoBOList);							
						}
					}
				}
				resultSize = lineInfoBOList.size();
				MaterialsAppUtil.sortList(lineInfoBOList, sortFields);
				//For Array sorting based on first value - start
				for(LineInfoBO lineInfoBO : lineInfoBOList) {
					LineInfoBO lineInfoBONew = new LineInfoBO();
					BeanUtils.copyProperties(lineInfoBO, lineInfoBONew);
					lineInfoBONew.setShippingStatus(materialsAppUtil.splitString(lineInfoBO.getShippingStatusStr(), "|"));
					lineInfoBONew.setCountryOfOrigin(materialsAppUtil.splitString(lineInfoBO.getCountryOfOriginStr(), "|"));
					lineInfoBOListNew.add(lineInfoBONew);
				}
				//For Array sorting based on first value - end
				lineInfoBOListNew = (List<LineInfoBO>) MaterialsAppUtil.filterResultList(lineInfoBOListNew, start, limit);
				lineDetailBO.setOrderLineList(lineInfoBOListNew);
			}catch (TechnicalException e) {
				materialsAppUtil.throwAsBusinessException(e);
			}
		}else{
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8319, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8319),
					materialsAppUtil.getDescMsg(msNumber, deliveryId, orderHeaderId, invoiceHeaderId));
		}
		return lineDetailBO;
	}
	
	private List<LineInfoBO> getLineInfoBOList(List<LineInfoDO> lineInfoDOList, String portalId, List<LineInfoBO> lineInfoBOList) {
		String[] msNumberArray = null;
		String[] setDeliveryIdArray = null;
		String[] setInvoiceNumberArray = null;
		String[] setInvoiceIdArray = null;
		for(LineInfoDO lineInfoDO : lineInfoDOList) {
			LineInfoBO lineInfoBO = new LineInfoBO();
			msNumberArray = new String[1];
			setDeliveryIdArray = new String[1];
			setInvoiceNumberArray = new String[1];
			setInvoiceIdArray = new String[1];
			
			msNumberArray[0] = lineInfoDO.getMsNumber();
			setDeliveryIdArray[0] = lineInfoDO.getDeliveryId();
			setInvoiceNumberArray[0] = lineInfoDO.getInvoiceNumber();
			setInvoiceIdArray[0] = lineInfoDO.getInvoiceId();
			String flowStatus = lineInfoDO.getFlowStatus();
			BeanUtils.copyProperties(lineInfoDO, lineInfoBO);
			//format anything if needed
			lineInfoBO.setRequestDate(MaterialsDateFormatUtil.formatDateFromSQLDate(lineInfoDO.getRequestDateTime()));
			lineInfoBO.setScheduleArrivalDate(MaterialsDateFormatUtil.formatDateFromSQLDate(lineInfoDO.getScheduleArrivalDateTime()));
			lineInfoBO.setScheduleShipDate(MaterialsDateFormatUtil.formatDateFromSQLDate(lineInfoDO.getScheduleShipDateTime()));
			lineInfoBO.setPricingDate(MaterialsDateFormatUtil.formatDateFromSQLDate(lineInfoDO.getPricingDateTime()));
			lineInfoBO.setCreationDate(MaterialsDateFormatUtil.formatDateFromSQLDate(lineInfoDO.getCreationDateTime()));
			lineInfoBO.setLastUpdateDate(MaterialsDateFormatUtil.formatDateFromSQLDate(lineInfoDO.getLastUpdateDateTime()));
			lineInfoBO.setActualShipmentDate(MaterialsDateFormatUtil.formatDateFromSQLDate(lineInfoDO.getActualShipmentDateTime()));
			lineInfoBO.setOrderedDate(MaterialsDateFormatUtil.formatDateFromSQLDate(lineInfoDO.getOrderedDateTime()));
			lineInfoBO.setInvoiceDate(MaterialsDateFormatUtil.formatDateFromSQLDate(lineInfoDO.getInvoiceDateTime()));
			lineInfoBO.setCancelUpdateAllowed(MaterialsAppUtil.getBooleanFrmString(lineInfoDO.getCancelUpdateAllowedFlag()));
			lineInfoBO.setShipmentDisputeAllowed(MaterialsAppUtil.getBooleanFrmString(lineInfoDO.getShipmentDisputeAllowedFlag()));
			lineInfoBO.setQuantityUpdateAllowed(MaterialsAppUtil.getBooleanFrmString(lineInfoDO.getQuantityUpdateAllowedFlag()));
			lineInfoBO.setShipmentPriorityCode(materialsAppUtil.getPortalDisplayPriority(portalId, lineInfoDO.getShipmentPriorityCode()));
			lineInfoBO.setMsNumberArray(msNumberArray);
			lineInfoBO.setDeliveryIdArray(setDeliveryIdArray);
			lineInfoBO.setInvoiceNumberArray(setInvoiceNumberArray);
			lineInfoBO.setInvoiceIdArray(setInvoiceIdArray);
	        lineInfoBO.setCreatedBy(materialsAppUtil.getNameforSSO(lineInfoDO.getCreatedBy()));
	        lineInfoBO.setDisputeCreated(MaterialsAppUtil.getBooleanFrmString(lineInfoDO.getDisputeCreated()));
	        lineInfoBO.setCriticalPartFlag(MaterialsAppUtil.getBooleanFrmString(lineInfoDO.getCriticalPartFlag()));

	        if((FLOW_STATUS_OPEN.equalsIgnoreCase(flowStatus)) && (lineInfoBO.getCriticalPartFlag()))
	        {
	        	lineInfoBO.setPromiseDate(null);
	        }
	        else
	        {
	        	lineInfoBO.setPromiseDate(MaterialsDateFormatUtil.formatDateFromSQLDate(lineInfoDO.getPromiseDateTime()));
	        }
	        
	        lineInfoBO.setOrderLineWorkStopDate(MaterialsDateFormatUtil.formatDateFromSQLDate(lineInfoDO.getOrderLineWorkStopDate()));
	        lineInfoBO.setOrderLineWorkStopQuantity(lineInfoDO.getOrderLineWorkStopQuantity());
	        lineInfoBOList.add(lineInfoBO);
		}
		
		return lineInfoBOList;
	}
	
	public String getErrorCode(String message, String strSSO, String portalId, String partNumber)
			throws MaterialsException {
		String statusMessage = EMPTY_STRING;
		String[] errorCode = materialsAppUtil.getErrorCdnMsg(message);
		if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8126)
				|| errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8131)) {
			statusMessage = getUIPipeMessage(message, errorCode);
		} else if (errorCode[0].equals(ERR_CODE_8167)) {
			String[] parts = message.split(COLON, 2);
			throw new MaterialsException(8167, parts[1], parts[1]);
		} else if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8203)) {

			statusMessage = getUITildeMessage(message, strSSO, portalId, errorCode, partNumber);
		} else {
			statusMessage = getUITildeMessage(message, strSSO, portalId, errorCode, partNumber);
		}
		return statusMessage;
	}

	public String getUITildeMessage(String message, String strSSO, String portalId, String[] errorCode,
			String partNumber) throws MaterialsException {
		String statusMessage = EMPTY_STRING;
		String errMessage = EMPTY_STRING;
		String[] errMsgAndCd = message.split(MaterialsAppConstants.TILDE, 2);
		errMessage = materialsExceptionUtil.getErrorMessage(Integer.parseInt(errorCode[0]));
		ArrayList<String> errCosdesList = new ArrayList<String>();
		errCosdesList.add(MaterialsAppConstants.ERR_CODE_8125);
		errCosdesList.add(MaterialsAppConstants.ERR_CODE_8129);
		errCosdesList.add(MaterialsAppConstants.ERR_CODE_8130);
		errCosdesList.add(MaterialsAppConstants.ERR_CODE_8133);
		errCosdesList.add(MaterialsAppConstants.ERR_CODE_8134);
		errCosdesList.add(MaterialsAppConstants.ERR_CODE_8135);
		errCosdesList.add(MaterialsAppConstants.ERR_CODE_8138);
		errCosdesList.add(MaterialsAppConstants.ERR_CODE_8200);
		errCosdesList.add(MaterialsAppConstants.ERR_CODE_8023);
		errCosdesList.add(MaterialsAppConstants.ERR_CODE_8179);
		errCosdesList.add(MaterialsAppConstants.ERR_CODE_8199);
		errCosdesList.add(MaterialsAppConstants.ERR_CODE_8202);
		errCosdesList.add(MaterialsAppConstants.ERR_CODE_8203);
		errCosdesList.add(MaterialsAppConstants.ERR_CODE_8204);
		if (errCosdesList.contains(errorCode[0])) {

			if (message.contains(MaterialsAppConstants.TILDE)) {
				if (MaterialsAppUtil.isNotNullandEmpty(errMsgAndCd[1])) {
					CustomerAdminDetailsBO custAdminDetailsBO;
					errMsgAndCd[1] = errMsgAndCd[1].replaceAll(MaterialsAppConstants.TILDE, MaterialsAppConstants.PIPE);
					String pipedErrCode = errMsgAndCd[1];
					custAdminDetailsBO = getCustAdminDetailsBS(strSSO, portalId, pipedErrCode.toString());
					List<CustAdmin> lstCustAdmin = custAdminDetailsBO.getCustAdmin();
					if (!lstCustAdmin.isEmpty()) {
						errMessage = getErrorMessage(lstCustAdmin,errorCode,errMessage,message);
					}
					if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8138)) {
						materialsAppUtil.throwERPMessage(message);
					} else if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8199)) {
						statusMessage = errMessage;
					} else if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8202)) {
						statusMessage = errMessage;
					} else if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8204)) {
						statusMessage = errMessage;
					}

					else {
						statusMessage = errMessage + CONST_MESSAGE_CODE + errorCode[0];
					}
				}
			} else if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8138)) {
				materialsAppUtil.throwERPMessage(message);
			} else {
				statusMessage = errMessage + CONST_MESSAGE_CODE + errorCode[0];
			}
		} else if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8127)) {
			statusMessage = errMessage + CONST_MESSAGE_CODE + errorCode[0];
		} else if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8132)) {

			statusMessage = errMessage + AVIAL_MSG_1 + partNumber + AVIAL_MSG_2;

		} else if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8179)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8179, errMessage, ERR_SHIP_CODE);
		} else if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8033)) {

			statusMessage = errMessage;

		} else {
			materialsAppUtil.throwERPMessage(message);
		}
		return statusMessage;
	}

	public String getUIPipeMessage(String message, String[] errorCode) throws MaterialsException {
		String statusMessage = EMPTY_STRING;
		String errMessage = EMPTY_STRING;
		errMessage = materialsExceptionUtil.getErrorMessage(Integer.parseInt(errorCode[0]));
		if (message.contains(MaterialsAppConstants.PIPE)) {
			String[] venderCodeORURL = message.split("\\|", 2);
			if (MaterialsAppUtil.isNotNullandEmpty(venderCodeORURL[1])) {
				if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8126)) {
					errMessage = errMessage.toString().replaceAll(MaterialsAppConstants.PORTAL_NAME,
							(String) venderCodeORURL[1]);
				} else if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8131)) {
					errMessage += " " + venderCodeORURL[1];
				}
			}
			statusMessage = errMessage + CONST_MESSAGE_CODE + errorCode[0];
		} else {
			statusMessage = errMessage + CONST_MESSAGE_CODE + errorCode[0];
		}
		return statusMessage;
	}

	public String getErrorMessage(List<CustAdmin> lstCustAdmin, String[] errorCode, String errMessage, String message){
		CustAdmin custAdmin = (CustAdmin) lstCustAdmin.get(0);
		String messageVendor = EMPTY_STRING;
		String vendorName = EMPTY_STRING;
		String vendorEmail = EMPTY_STRING;
		if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8203)) {
			 vendorName = MaterialsAppConstants.SPACE + custAdmin.getCustName();
		} else {
			errMessage += MaterialsAppConstants.SPACE + custAdmin.getCustName();
		}
		if (!custAdmin.getCustEmail().equals(EMPTY_STRING))
			if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8203)) {
				 vendorEmail = MaterialsAppConstants.SPACE + custAdmin.getCustEmail();
			} else {
				errMessage += MaterialsAppConstants.SPACE + MaterialsAppConstants.AT
						+ MaterialsAppConstants.SPACE + custAdmin.getCustEmail();
			}
		if (!(errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8199))
				&& (!custAdmin.getCustPhone().equals(EMPTY_STRING))) {

			errMessage += MaterialsAppConstants.AND + custAdmin.getCustPhone();
		}
		if (!(errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8202))
				&& (!custAdmin.getCustPhone().equals(EMPTY_STRING))) {

			errMessage += MaterialsAppConstants.AND + custAdmin.getCustPhone();
		}
		if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8203)
				&& (!custAdmin.getCustPhone().equals(EMPTY_STRING)))
			 messageVendor = MaterialsAppConstants.AND + custAdmin.getCustPhone();
		if (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8204)
				&& (!custAdmin.getCustPhone().equals(EMPTY_STRING))) {
			errMessage += MaterialsAppConstants.AND + custAdmin.getCustPhone();

		}
		
		if (message.contains(MaterialsAppConstants.PIPE)) {
			String[] venderCodeORURL = message.split("\\|", 2);
			
			if ((MaterialsAppUtil.isNotNullandEmpty(venderCodeORURL[1]))
					&& (errorCode[0].equals(MaterialsAppConstants.ERR_CODE_8203))) {
				log.info("vendor part" + venderCodeORURL[1]);
				if (venderCodeORURL[1].contains(VENDOR_062W0)
						|| venderCodeORURL[1].contains(VENDOR_99205)) {
					errMessage = GE_VENDOR_MSG;
				} else {
					errMessage = NON_GE_VENDOR_MSG1 + venderCodeORURL[1];
					String[] errMsg = errMessage.split("\\~");
					errMessage = errMsg[0] + NON_GE_VENDOR_MSG2 + MaterialsAppConstants.SPACE
							+ MaterialsAppConstants.AT + vendorName + CHAR_COMMA + vendorEmail
							+ messageVendor;
				}
			}
		}
		return errMessage;
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public PricingCatalogBO getPricingCatalog(MultivaluedMap<String, String> multiValmap, String strSSO,
			String portalId) throws MaterialsException {
		List<String> files = null;
		MaterialsUserBO materialsUserBO = new MaterialsUserBO();
		List<Pricing> lstPrice = new ArrayList<Pricing>();
		MaterialsLoginResponse materialsLoginDetail = new MaterialsLoginResponse();

		log.info("Entered into getPricingCatalog() method");
		if (!isNotNullandEmpty(strSSO)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8301,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND);
		}
		if (!isNotNullandEmpty(portalId)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8302,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8302), ERR_PORTAL_ID_NOT_FOUND);
		}
		try {
			materialsLoginDetail = materialsLoginApp.requestMaterialsLogin(strSSO, portalId);
		} catch (TechnicalException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}
		
		if (portalId.equals(PORTAL_GEHONDA)) {
			
			files = new ArrayList<String>();

			try {
				PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
				Resource[] resources = resolver.getResources(MaterialsAppConstants.HONDA_PRICECATALOGS_PATH + "*");
				for (Resource resource : resources) {
					files.add(resource.getFilename());
				}

			} catch (IOException e) {
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8331,
						materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8331),
						ERR_FOLDER_DOES_NOT_EXIST);
			}

			if (files.size() > 0) {
				lstPrice = getPriceListForHonda(files,portalId,lstPrice);
				} else {
					throw new MaterialsException(MaterialsErrorCodes.ERROR_8340,
							materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8340),
							ERR_DOCUMENT_NOT_FOUND);
				}
			
		} else {
			materialsUserBO = materialsLoginDetail.getMaterialsUserBO();
			lstPrice = getListPrice(materialsUserBO,lstPrice,portalId,strSSO);
		}
		return getPricingCatalogBO(multiValmap,lstPrice);
	}

	private PricingCatalogBO getPricingCatalogBO(MultivaluedMap<String, String> multiValmap, List<Pricing> lstPrice) throws MaterialsException {
		PricingCatalogBO pricingCatalogBO = new PricingCatalogBO();
		int iDisplayStart = 0;
		int sortColumn = 0;
		int iDisplayLength = 0;
		int sEcho = 0;
		String sortorder = null;
		String columnName = "";
		String order = "";
		HashMap filterSortList = null;
		
		// Reading multyValued map data table variables
		order = MaterialsAppConstants.ASC;
		try {
			filterSortList = getFilterSortList(multiValmap);
			if (null != multiValmap.get(MaterialsAppConstants.SSORTDIR_0)
					&& !("").equals(multiValmap.get(MaterialsAppConstants.SSORTDIR_0)))
				sortorder = multiValmap.get(MaterialsAppConstants.SSORTDIR_0).get(0);
			if (null != multiValmap.get(MaterialsAppConstants.IDISPLAY_START)
					&& !("").equals(multiValmap.get(MaterialsAppConstants.IDISPLAY_START)))
				iDisplayStart = Integer.parseInt(multiValmap.get(MaterialsAppConstants.IDISPLAY_START).get(0));
			if (null != multiValmap.get(MaterialsAppConstants.IDISPLAY_LENGTH)
					&& !("").equals(multiValmap.get(MaterialsAppConstants.IDISPLAY_LENGTH)))
				iDisplayLength = Integer.parseInt(multiValmap.get(MaterialsAppConstants.IDISPLAY_LENGTH).get(0));
			if (null != multiValmap.get(MaterialsAppConstants.SECHO)
					&& !("").equals(multiValmap.get(MaterialsAppConstants.SECHO)))
				sEcho = Integer.parseInt(multiValmap.get(MaterialsAppConstants.SECHO).get(0));
			if (null != multiValmap.get(MaterialsAppConstants.ISORTCOL_0)
					&& !("").equals(multiValmap.get(MaterialsAppConstants.ISORTCOL_0)))
				sortColumn = Integer.parseInt(multiValmap.get(MaterialsAppConstants.ISORTCOL_0).get(0));
			if (sortorder == null)
				sortorder = MaterialsAppConstants.ASC;

			columnName = (String) filterSortList.get(sortColumn);
			if (columnName == null)
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8310,
						materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8310),
						ERR_DATATABLE_ERROR_OCCURED);
		} catch (TechnicalException e) {
			log.info(e);
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8310,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8310),
					ERR_DATATABLE_ERROR_OCCURED);
		}
		pricingCatalogBO.setITotalRecords((double) lstPrice.size());
		pricingCatalogBO.setITotalDisplayRecords((double) lstPrice.size());
		if (lstPrice.isEmpty()) {
		} else {
			if (iDisplayStart > lstPrice.size() - 1) {
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8316,
						materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8316),
						ERR_DATATABLE_DISPLAY_ERROR_OCCURED);
			} else {
				int size = iDisplayStart + iDisplayLength;
				if (size >= lstPrice.size()) {
					size = lstPrice.size();
				}
				lstPrice = lstPrice.subList(iDisplayStart, size);
			}
		}
		pricingCatalogBO.setSuccess(true);
		pricingCatalogBO.setSEcho(sEcho);
		pricingCatalogBO.setResponse(getSortedListPrice(columnName,order,lstPrice,sortorder));
		return pricingCatalogBO;
	}

	private List<Pricing> getSortedListPrice(String columnName, String order, List<Pricing> lstPrice, String sortorder) {

		if (columnName.equals(MaterialsAppConstants.PLATFORM)) {
			if (sortorder.equals(order))
				Collections.sort(lstPrice, new PlatformAscComparator());
			else
				Collections.sort(lstPrice, new PlatformDecComparator());
		} else if (columnName.equals(EFFDATE)) {
			if (sortorder.equals(order))
				Collections.sort(lstPrice, new EffectiveDateAscComparator());
			else
				Collections.sort(lstPrice, new EffectiveDateDescComparator());
		} else if (columnName.equals(MaterialsAppConstants.REVISION_DATE)) {
			if (sortorder.equals(order))
				Collections.sort(lstPrice, new RevisionDateAscComparator());
			else
				Collections.sort(lstPrice, new RevisionDateDescComparator());
		}
		return lstPrice;
	}

	private HashMap getFilterSortList(MultivaluedMap<String, String> multiValmap) {
		
		HashMap filterSortList = new HashMap();
		for (int k = 0; k < multiValmap.size(); k++) {
			filterSortList.put(k, null);
		}
		Set set = multiValmap.entrySet();
		Iterator it = set.iterator();
		while (it.hasNext()) {
			Map.Entry<String, List<String>> entry = (Entry) it.next();
			List<String> value = entry.getValue();
			String val = value.get(0);
			if (entry.getKey().contains(MaterialsAppConstants.MDATAPROP)) {
				String position = entry.getKey().replace(MaterialsAppConstants.MDATAPROP, "").trim();
				int positionVal = 0;
				if (!("").equals(position))
					positionVal = Integer.parseInt(position);
				filterSortList.put(positionVal, val);
			}
		}
	return filterSortList;
	}

	private List<Pricing> getListPrice(MaterialsUserBO materialsUserBO, List<Pricing> lstPrice, String portalId, String strSSO) throws MaterialsException {
		Platform platform = null;
		List<CustomerBO> customerBOList = null;
		String role = MaterialsAppConstants.EMPTY_STRING;
		String operatingUnitId = MaterialsAppConstants.EMPTY_STRING;
		String icaoCode = EMPTY_STRING;
		String[] custIds = null;
		int i = 0;
		
		if (isNotNullandEmpty(materialsUserBO.getIcaoCode())) {
			icaoCode = materialsUserBO.getIcaoCode();
		}
		if (isNotNullandEmpty(materialsUserBO.getRole())) {
			role = materialsUserBO.getRole();
		}
		if (materialsUserBO.getCustomerBOList() != null && !materialsUserBO.getCustomerBOList().isEmpty()) {
			customerBOList = materialsUserBO.getCustomerBOList();
		}

		if (MaterialsAppUtil.isCollectionNotEmpty(customerBOList)) {
			custIds = new String[customerBOList.size()];
			for (CustomerBO customerBO : customerBOList) {
				custIds[i] = customerBO.getCustId();
				i++;
			}
		}
		if (isNotNullandEmpty(materialsUserBO.getOperatingUnitId()))
			operatingUnitId = materialsUserBO.getOperatingUnitId();
		try {

			// displaying all platforms for "GEAE" and "MMGE" users
			if (icaoCode.equalsIgnoreCase(MaterialsAppConstants.GEAE)
					|| (icaoCode.equalsIgnoreCase(MaterialsAppConstants.MMGE))) {
				platform = materialsDAO.getAllPricingCatalogDS(portalId, icaoCode, icaoCodeAvialGTA);
			} else {
				platform = materialsDAO.getPricingCatalogDS(strSSO, portalId, icaoCode, custIds, role,
						operatingUnitId, icaoCodeGTA, icaoCodeAvialGTA);
			}
		} catch (TechnicalException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}
		if (platform != null) {
			if (isNotNullandEmpty(platform.getMessage())) {
				materialsAppUtil.throwERPMessage(platform.getMessage());
			}
			lstPrice = getPriceList(platform,portalId,lstPrice,icaoCode);

		} else {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8313,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8313), ERR_NO_PLATFORM_AVAIL);
		}
		return lstPrice;
	}

	private List<Pricing> getPriceList(Platform platform, String portalId, List<Pricing> lstPrice, String icaoCode) throws MaterialsException {
		String encPlatform = null;
		Map<String, PricingCatalogDates> mapEffDates = null;
		List<String> lstPlatform = platform.getPlatform();
		try {

			if (icaoCode.equalsIgnoreCase(MaterialsAppConstants.GEAE)
					|| (icaoCode.equalsIgnoreCase(MaterialsAppConstants.MMGE))) {
				mapEffDates = materialsDAO.getGEAEEffectiveDateDS(lstPlatform);
			} else {
				mapEffDates = materialsDAO.getEffectiveDateDS(lstPlatform);

			}

		} catch (TechnicalException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}

		if (lstPlatform != null && !lstPlatform.isEmpty()) {
			for (Map.Entry<String, PricingCatalogDates> entry : mapEffDates.entrySet()) {
				Pricing price = new Pricing();
				PricingCatalogDates pricingCatalogDates = (PricingCatalogDates) entry.getValue();
				if ((icaoCodeAvialGTA.contains(icaoCode.toUpperCase()))
						&& (CF34.equalsIgnoreCase(pricingCatalogDates.getDisplayName()))
						&& PORTAL_CWC.equalsIgnoreCase(portalId)) {
					//remove the CF34 engine catalog if the user is supposed to see the CF34-8s engine instead
					continue;
				} else if (icaoCode.equalsIgnoreCase(MaterialsAppConstants.MMGE)
						&& (CF348S.equalsIgnoreCase(pricingCatalogDates.getDisplayName()))
						&& PORTAL_CWC.equalsIgnoreCase(portalId)) {
					//remove the CF34-8s engine catalog if the user is an MMGE user and should see the CF43 catalog and not the CF34-8s catalog
					continue;
				} else {
					price.setPlatform(pricingCatalogDates.getDisplayName());
					encPlatform = MaterialsAppUtil.Base64Encode(pricingCatalogDates.getType());
				}

				price.setEffDate(pricingCatalogDates.getEffectiveDate());
				price.setRevisionDate(pricingCatalogDates.getExcelRevDate());

				String encDocPdf = MaterialsAppUtil.Base64Encode(PDF);
				String encDocExcel = MaterialsAppUtil.Base64Encode(EXCEL);
				String encDocEffDate = MaterialsAppUtil.Base64Encode(pricingCatalogDates.getEffectiveDate());
				price.setPdfLink(materialsAppUtil.getApplicationURL(portalId) + MaterialsAppConstants.MATERIALURL
						+ encPlatform + MaterialsAppConstants.DOCTYPE + encDocPdf + MaterialsAppConstants.EFFDATE
						+ encDocEffDate);
				price.setExcelLink(materialsAppUtil.getApplicationURL(portalId) + MaterialsAppConstants.MATERIALURL
						+ encPlatform + MaterialsAppConstants.DOCTYPE + encDocExcel + MaterialsAppConstants.EFFDATE
						+ encDocEffDate);
				lstPrice.add(price);

			}
		}
		return lstPrice;
	}

	private List<Pricing> getPriceListForHonda(List<String> files, String portalId, List<Pricing> lstPrice) throws MaterialsException {
		List<String> filesProcessed = new ArrayList<String>();
		boolean isStart = true;
		
		for (String fileStr : files) {
			if (isStart || (!filesProcessed.isEmpty() && !(filesProcessed.contains(fileStr)))) {
				Pricing pric = new Pricing();
				String platformHonda = fileStr.substring(0, fileStr.indexOf("_"));
				String fileName = fileStr.substring(0, fileStr.indexOf("."));
				String fileExt = fileStr.substring(fileStr.indexOf("."), fileStr.length());
				String date = fileStr.substring(fileStr.indexOf("_") + 1, fileStr.indexOf("."));
				pric.setPlatform(platformHonda);
				String encPlatformHonda = MaterialsAppUtil.Base64Encode(fileName);
				String encDocPdf = MaterialsAppUtil.Base64Encode(fileExt);
				String encDocExcel = MaterialsAppUtil.Base64Encode(fileExt);
				if ((".pdf").equalsIgnoreCase(fileExt)) {
					pric.setEffDate(materialsAppUtil.convertDate(date.replaceAll("_", "-")));
					pric.setPdfLink(
							materialsAppUtil.getApplicationURL(portalId) + MaterialsAppConstants.MATERIALURL
									+ encPlatformHonda + MaterialsAppConstants.DOCTYPE + encDocPdf);
					filesProcessed.add(fileName + fileExt);
					if (files.contains(fileName + XLXS)) {
						encDocExcel = MaterialsAppUtil.Base64Encode(XLXS);
						pric.setRevisionDate(materialsAppUtil.convertDate(date.replaceAll("_", "-")));
						pric.setExcelLink(materialsAppUtil.getApplicationURL(portalId)
								+ MaterialsAppConstants.MATERIALURL + encPlatformHonda
								+ MaterialsAppConstants.DOCTYPE + encDocExcel);
						filesProcessed.add(fileName + XLXS);
					} else if (files.contains(fileName + ".xls")) {
						encDocExcel = MaterialsAppUtil.Base64Encode(".xls");
						pric.setRevisionDate(materialsAppUtil.convertDate(date.replaceAll("_", "-")));
						pric.setExcelLink(materialsAppUtil.getApplicationURL(portalId)
								+ MaterialsAppConstants.MATERIALURL + encPlatformHonda
								+ MaterialsAppConstants.DOCTYPE + encDocExcel);
						filesProcessed.add(fileName + ".xls");
					}
				} else {
					pric.setRevisionDate(materialsAppUtil.convertDate(date.replaceAll("_", "-")));
					pric.setExcelLink(
							materialsAppUtil.getApplicationURL(portalId) + MaterialsAppConstants.MATERIALURL
									+ encPlatformHonda + MaterialsAppConstants.DOCTYPE + encDocExcel);
					filesProcessed.add(fileName + fileExt);
					if (files.contains(fileName + ".pdf")) {
						encDocPdf = MaterialsAppUtil.Base64Encode(".pdf");
						pric.setEffDate(materialsAppUtil.convertDate(date.replaceAll("_", "-")));
						pric.setPdfLink(materialsAppUtil.getApplicationURL(portalId)
								+ MaterialsAppConstants.MATERIALURL + encPlatformHonda
								+ MaterialsAppConstants.DOCTYPE + encDocPdf);
						filesProcessed.add(fileName + ".pdf");
					}
				}
				lstPrice.add(pric);
				isStart = false;
			}
			if (files.isEmpty()) {
				break;
			}
		}
		return lstPrice;
	}

	@Override
	public Response getPricingCatalogDocBS(String platform, String docType, String strSSO, String portalId,
			String effDate) {
		String decPlatform = null;
		String decDocType = null;
		String decEffDate = null;
		log.info("Entered into getPricingCatalogDoc() method");
		String task = EMPTY_STRING;
		StopWatch watch = new StopWatch();
		task = "pricingCatalogDocDS";
		watch.start(task);
		int i = 0;
		String fileName = EMPTY_STRING;
		Response response = null;
		String icaoCode = EMPTY_STRING;
		String[] custIds = null;
		Platform platform1 = null;
		byte[] bytes = null;
		PricingCatalogDO pricingCatalogDO = null;
		String operatingUnitId = MaterialsAppConstants.EMPTY_STRING;
		List<CustomerBO> customerBOList = null;
		List<String> lstPlatform = null;
		MaterialsUserBO materialsUserBO = new MaterialsUserBO();
		MaterialsLoginResponse materialsLoginDetail = new MaterialsLoginResponse();
		if (!isNotNullandEmpty(strSSO)) {

			return htmlErrorResponse(ERR_SSO_NOT_FOUND);
		}
		if (!isNotNullandEmpty(portalId)) {
			return htmlErrorResponse(ERR_PORTAL_ID_NOT_FOUND);
		}
		if (!isNotNullandEmpty(platform)) {
			return htmlErrorResponse(ERR_PLATFORM_NOT_FOUND);
		}
		if (!isNotNullandEmpty(docType)) {
			return htmlErrorResponse(ERR_DOCTYPE_NOT_FOUND);
		}
		try {
			materialsLoginDetail = materialsLoginApp.requestMaterialsLogin(strSSO, portalId);
		} catch (MaterialsException e) {
			log.info(e);
			return htmlErrorResponse(e.getDescMsg());
		}
		materialsUserBO = materialsLoginDetail.getMaterialsUserBO();

		if (materialsUserBO.getCustomerBOList() != null && !materialsUserBO.getCustomerBOList().isEmpty()) {
			customerBOList = materialsUserBO.getCustomerBOList();
		}
		if (MaterialsAppUtil.isCollectionNotEmpty(customerBOList)) {
			custIds = new String[customerBOList.size()];
			for (CustomerBO customerBO : customerBOList) {
				custIds[i] = customerBO.getCustId();
				i++;
			}
		}

		if (isNotNullandEmpty(materialsUserBO.getOperatingUnitId()))
			operatingUnitId = materialsUserBO.getOperatingUnitId();
		if (isNotNullandEmpty(materialsUserBO.getIcaoCode()))
			icaoCode = materialsUserBO.getIcaoCode();
		// displaying all platforms for "GEAE" and "MMGE" users
		if (icaoCode.equalsIgnoreCase(MaterialsAppConstants.GEAE)
				|| (icaoCode.equalsIgnoreCase(MaterialsAppConstants.MMGE))) {
			platform1 = materialsDAO.getAllPricingCatalogDS(portalId, icaoCode, icaoCodeAvialGTA);
		} else {
			platform1 = materialsDAO.getPricingCatalogDS(strSSO, portalId, icaoCode, custIds, materialsUserBO.getRole(),
					operatingUnitId, icaoCodeGTA, icaoCodeAvialGTA);
		}
		if (portalId.equals(PORTAL_GEHONDA)) {
			try {
				decPlatform = MaterialsAppUtil.Base64Decode(platform);
				decDocType = MaterialsAppUtil.Base64Decode(docType);
				fileName = decPlatform + decDocType.toLowerCase();
				String path = MaterialsAppConstants.HONDA_PRICECATALOGS_PATH + fileName;
				Resource resource = new ClassPathResource(path);
				bytes = IOUtils.toByteArray(resource.getInputStream());
				response = buildResponse(bytes, decDocType, fileName);
				return response;

			} catch (TechnicalException | IOException e) {
				log.error(e);
				return htmlErrorResponse(MaterialsAppConstants.ERR_DOCUMENT_NOT_FOUND);
			}
		}
		decPlatform = MaterialsAppUtil.Base64Decode(platform);
		decDocType = MaterialsAppUtil.Base64Decode(docType);
		decEffDate = MaterialsAppUtil.Base64Decode(effDate);
		java.sql.Date effectiveDate = materialsAppUtil.getSQLDate(decEffDate);
		if (platform1 != null) {
			lstPlatform = platform1.getPlatform();
			if (lstPlatform.contains(decPlatform)) {
				if (icaoCode.equalsIgnoreCase(MaterialsAppConstants.GEAE)
						|| (icaoCode.equalsIgnoreCase(MaterialsAppConstants.MMGE))) {
					pricingCatalogDO = materialsDAO.getAllPDFExcelCatalogDS(decPlatform, decDocType, effectiveDate);
				} else {
					pricingCatalogDO = materialsDAO.getPDFExcelCatalogDS(decPlatform, decDocType, effectiveDate);
				}
				/*
				 * return type of this method is changed from byte[] to
				 * pricingCatalogDO
				 */
			}
			if (pricingCatalogDO.getDocConent() != null) {
				if (decDocType.equalsIgnoreCase(PDF)) {
					fileName = decPlatform + UNDERSCORE + materialsAppUtil.getAsString(effectiveDate) + PDF_EXTENSION;
				} else {
					fileName = decPlatform + UNDERSCORE
							+ materialsAppUtil.getAsString(pricingCatalogDO.getRevisionDate()) + XLS_EXTENSION;
				}
				watch.stop();
				log.info("MATL PERF : <Calling " + task + " method> END - " + watch.getLastTaskTimeMillis());
			}
			response = buildResponse(pricingCatalogDO.getDocConent(), decDocType, fileName);
		} else {
			return htmlErrorResponse(ERR_DOCUMENT_NOT_FOUND);
		}

		return response;
	}
	
	private Response htmlErrorResponse(String message) {
        ResponseBuilder rb = Response.noContent();
        rb = rb.type(MediaType.TEXT_HTML);
        rb = rb.status(Status.BAD_REQUEST);
        String finalMsg = HTML_MSG1 + message + HTML_MSG2;
        rb = rb.entity(finalMsg);
        return rb.build();
 }
 
 private Response buildResponse(final byte[] bytes, String doctype,
               String fileName) {
        log.info("filename"+fileName);
        StreamingOutput stream = null;
        stream = new StreamingOutput() {
               public void write(OutputStream out) throws IOException,
               WebApplicationException {
                     try {
                            out.write(bytes);
                     } catch (Exception e) {
                            log.error(e);
                            throw new WebApplicationException(e);
                     }
               }
        };
        if (bytes != null) {
               return Response
                            .ok(stream)
                            .header("content-disposition",
                                          "attachment; filename = " + fileName).build();
        } 
        else {

               return htmlErrorResponse(doctype+" "+ERR_DOCUMENT_NOT_FOUND);
        }
 }

 @Override
	public String getDisplayMessage(String message, String strSSO,
			String portalId) throws MaterialsException {
		String errMessage = EMPTY_STRING;
		String[] errorCode = materialsAppUtil.getErrorCdnMsg(message);
		errMessage = materialsExceptionUtil.getErrorMessage(errorCode[0]);
		if ((errorCode[0].equals(CONST_PRICE_MSG)
				|| errorCode[0].equals(PRICE_MSG_02)
				|| errorCode[0].equals(CONST_AVAIL_MSG) || errorCode[0]
					.equals(AVAIL_MSG_03))
				&& (message.contains(MaterialsAppConstants.TILDE))) {
			String[] displayMsg = message.split(MaterialsAppConstants.TILDE, 2);
			if (MaterialsAppUtil.isNotNullandEmpty(displayMsg[1])) {
				displayMsg[1] = displayMsg[1]
						.replaceAll(MaterialsAppConstants.TILDE,
								MaterialsAppConstants.PIPE);
				String pipedErrCode = displayMsg[1];
				CustomerAdminDetailsBO custAdminDetailsBO = getCustAdminDetailsBS(
						strSSO, portalId, pipedErrCode);
				List<CustAdmin> lstCustAdmin = custAdminDetailsBO
						.getCustAdmin();
				if (!lstCustAdmin.isEmpty()) {
					CustAdmin custAdmin = (CustAdmin) lstCustAdmin.get(0);
					errMessage += MaterialsAppConstants.SPACE
							+ custAdmin.getCustName();
					if (!custAdmin.getCustEmail().equals(EMPTY_STRING))
						errMessage += MaterialsAppConstants.COMMA
								+ MaterialsAppConstants.SPACE
								+ custAdmin.getCustEmail();
					if (!custAdmin.getCustPhone().equals(EMPTY_STRING))
						errMessage += MaterialsAppConstants.AND
								+ custAdmin.getCustPhone();
				}
			}
		}
		return errMessage;
	}

 @Override
	public OrderStatusBO addBulkPartDtls(String sso, String portalId,List<BulkAddPartBO> partsLst) throws MaterialsException {
		log.info("start addBulkPartDtls() method");
		Map<String, String> statusMsgmap = new HashMap<String, String>();
		OrderStatusBO orderStatusBO = new OrderStatusBO();
		PartsInputDO2 partsInputDO2=null;
		List<PartsInputDO2>partsInputDO2List = new ArrayList<PartsInputDO2>();
		List<PartBO> partLstRes=new ArrayList<PartBO>();
		List<OrderTemplateStatusBO> orderList = null; 
		CustLoginDetails custLoginDetails = null;
		for (BulkAddPartBO bulkpartBO : partsLst) {
		       PartBO partBO=new PartBO();
				partBO.setQuantity(Integer.parseInt(bulkpartBO.getQuantity()));
				partBO.setCustomerCode(bulkpartBO.getCustomerCode());
				partBO.setPartNumber(bulkpartBO.getPartNumber());
			partLstRes.add(partBO);
		 }
		partsInputDO2List = new ArrayList<PartsInputDO2>();
		for (PartBO partsBO : partLstRes) {
			partsInputDO2 = new PartsInputDO2(partsBO.getLineNumber(),partsBO.getPartNumber(),partsBO.getQuantity(),partsBO.getRequestedDate(),
					partsBO.getPriority(),partsBO.getCustomerCode(), partsBO.getRowNumber(),partsBO.getCustomerAccountId(),
					partsBO.getInventoryItemId(),partsBO.getSupplierCode(),partsBO.getPriceListId(),partsBO.getQuoteHeaderId(),
					partsBO.getQuoteLineId(),partsBO.getStatusMessage(),partsBO.getOrderLineESN());
			partsInputDO2List.add(partsInputDO2);
		}		
		try{
			custLoginDetails = materialsAppUtil.getCustLoginDetails(sso, portalId);
			orderList = materialsDAO.addBulkPrtDtlsDS(sso, custLoginDetails.getIcaoCode(), custLoginDetails.getCustIdList(),custLoginDetails.getRole(), custLoginDetails.getOperatingUnitId(), partsInputDO2List, orderStatusBO, statusMsgmap, orderList);
		}catch(TechnicalException e){
			materialsAppUtil.throwAsBusinessException(e);
		}
		if (orderList != null) {
			if (isNotNullandEmpty(orderStatusBO.getDisplayMessage())) {
				materialsAppUtil.throwERPMessage(orderStatusBO.getDisplayMessage());
			} else {
				for (OrderTemplateStatusBO orderTemplateStatusBO : orderList) {
					if (isNotNullandEmpty(statusMsgmap.get(orderTemplateStatusBO.getPoLineNumber()+ orderTemplateStatusBO.getPartNumber()))) {								
						orderTemplateStatusBO.setStatusMessage(getErrorCode(statusMsgmap.get(orderTemplateStatusBO.getPoLineNumber()+ orderTemplateStatusBO.getPartNumber()), sso, portalId,orderTemplateStatusBO.getPartNumber()));
					}
				}
				orderStatusBO.setTotalLines(Integer.toString(orderList.size()));
				orderStatusBO.setOrdrStatusBO(orderList);
			}
		}
		log.info("End addBulkPartDtls() method");
		return orderStatusBO;
	}

	@Override
	public List<BulkPartDetailsBO> getBulkSearchPartDtlBS(String strSSO, String portalId, String partNumbers) throws MaterialsException {
		log.info("Start getBulkSearchPartDtlBS() method");
		if (!isNotNullandEmpty(partNumbers)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8318, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8318),	ERR_PARTNUM_NOT_FOUND);
		}
		List<BulkPartDetailsBO> bulkPartLst = new ArrayList<BulkPartDetailsBO>();	
		List<BulkPartDetailsBO> bulkPartResultLst = new ArrayList<BulkPartDetailsBO>();
		String[] partNumArr = partNumbers.split("\\|");		
		String role = EMPTY_STRING;
		String icaoCode = EMPTY_STRING;
		String operatingUnitId = EMPTY_STRING;
		MaterialsLoginResponse materialsLoginDetail = null;
		MaterialsUserBO materialsUserBO = null;
		List<CustomerBO> customerBOList = null;
		materialsLoginDetail = materialsLoginApp.requestMaterialsLogin(strSSO, portalId);
		if (materialsLoginDetail.getMaterialsUserBO() != null) {
			materialsUserBO = materialsLoginDetail.getMaterialsUserBO();
		}
		if (isNotNullandEmpty(materialsUserBO.getIcaoCode())){
			icaoCode = materialsUserBO.getIcaoCode();
		}
		if (isNotNullandEmpty(materialsUserBO.getRole())){
			role = materialsUserBO.getRole();
		}
		if (materialsUserBO.getCustomerBOList() != null && !materialsUserBO.getCustomerBOList().isEmpty()) {
			customerBOList = materialsUserBO.getCustomerBOList();
		}
		if (isNotNullandEmpty(materialsUserBO.getOperatingUnitId())) {
			operatingUnitId = materialsUserBO.getOperatingUnitId();
		}
		try{
			bulkPartLst = materialsDAO.getBulkSearchPartDtlDS(strSSO, icaoCode, customerBOList, role, operatingUnitId, partNumArr);
		} catch (TechnicalException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}
		for (BulkPartDetailsBO bulkPartDetailsBO : bulkPartLst) {		
			if (MaterialsAppUtil.isNotNullandEmpty(bulkPartDetailsBO.getMessage())) {
				String displayMsg = getErrorCode(bulkPartDetailsBO.getMessage(), strSSO, portalId,
						bulkPartDetailsBO.getPartNumber());
				bulkPartDetailsBO.setMessage(displayMsg);
			}
			for(int i = 0; i < partNumArr.length; i++) {
				 if(partNumArr[i].equalsIgnoreCase(bulkPartDetailsBO.getPartNumber())){
					 bulkPartDetailsBO = getbulkPartDetailsBO(bulkPartDetailsBO,strSSO,portalId,role);
			    	 bulkPartResultLst.add(bulkPartDetailsBO);
				 }
			 }
		}
		log.info("End getBulkSearchPartDtlBS() method");
		return bulkPartLst;	
	}


	private BulkPartDetailsBO getbulkPartDetailsBO(BulkPartDetailsBO bulkPartDetailsBO, String strSSO, String portalId, String role)
			throws MaterialsException {

		if (MaterialsAppUtil.isNotNullandEmpty(bulkPartDetailsBO.getPartAvailMsg())) {
			String availMessage = getDisplayMessage(bulkPartDetailsBO.getPartAvailMsg(), strSSO, portalId);
			bulkPartDetailsBO.setPartAvailMsg(availMessage);
		}
		if (MaterialsAppUtil.isNotNullandEmpty(bulkPartDetailsBO.getDisplayMessage())) {
			String displayMsg = getErrorCode(bulkPartDetailsBO.getDisplayMessage(), strSSO, portalId,
					bulkPartDetailsBO.getPartNumber());
			bulkPartDetailsBO.setDisplayMessage(displayMsg);
		}
		if (MaterialsAppUtil.isNotNullandEmpty(bulkPartDetailsBO.getPricMessage())) {
			String pricingMessage = getDisplayMessage(bulkPartDetailsBO.getPricMessage(), strSSO, portalId);
			bulkPartDetailsBO.setPricMessage(pricingMessage);
		}
		if (MaterialsAppUtil.isNotNullandEmpty(bulkPartDetailsBO.getCriticalPartMessage())
				&& bulkPartDetailsBO.getCriticalPartMessage().equals(Y)) {
			if (role.equals(ROLE_GE)) {
				bulkPartDetailsBO.setCriticalPartMessage(MSG_CRITCL_GE_BUYER);
			} else if (role.equals(ROLE_BUYER)) {
				bulkPartDetailsBO.setCriticalPartMessage(MSG_CRITCL_GE_BUYER);
			} else if (role.equals(ROLE_CE)) {
				bulkPartDetailsBO.setCriticalPartMessage(MSG_CRITCL_CE);
			} else {
				bulkPartDetailsBO.setCriticalPartMessage(EMPTY_STRING);
			}
		}
		if (MaterialsAppUtil.isNotNullandEmpty(bulkPartDetailsBO.getDiscountMessage())) {
			String discountMsg = getErrorCode(bulkPartDetailsBO.getDiscountMessage(), strSSO, portalId,
					bulkPartDetailsBO.getPartNumber());
			bulkPartDetailsBO.setDiscountMessage(discountMsg);
		} else {
			bulkPartDetailsBO.setDiscountMessage(EMPTY_STRING);
		}
		return bulkPartDetailsBO;
	}

	public Response getRepairCatalogBS(String strSSO, String portalId, String fileName) throws MaterialsException {
		Response response = null;
		byte[] bytes = null;
		fileName = MaterialsAppUtil.Base64Decode(fileName);
		GridFSFile gridFSFile = materialsDAO.getFile(fileName);
		try {
			if (gridFSFile == null) {

				return Response.ok("Document not Found").type("text/html").build();
			} else {

				bytes = materialsDAO.getFileDataFully(gridFSFile.getObjectId(),"artifacts");

			}

		} catch (Exception e) {
			log.info(e);
			StringBuilder sb = new StringBuilder();
			sb.append("8340 :: ");
			sb.append(ERR_DOCUMENT_NOT_FOUND);
			log.info(sb.toString());
			;
		}
		if (bytes == null) {
			return Response.ok("Document not Found").type("text/html").build();
		}
		response = buildResponse(bytes, fileName);
		return response;
	}

	private Response buildResponse(final byte[] bytes, String fileName) {
		Response response = null;
		StreamingOutput stream = null;
		stream = new StreamingOutput() {
			public void write(OutputStream out) throws IOException, WebApplicationException {
				try {
					out.write(bytes);
				} catch (Exception e) {
					log.info(e);
					throw new WebApplicationException(e);
				}
			}
		};
		if (bytes != null) {
			response = Response.ok(stream).header("content-disposition", "attachment; filename = " + fileName).build();
		}
		return response;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public RepairCatalog getRepairCatalogListBS(MultivaluedMap<String, String> multiValmap, String strSSO,
			String portalId) throws MaterialsException {
		int sEcho = 0;
		int iDisplayStart = 0;
		int sortColumn = 0;
		int iDisplayLength = 0;
		String sortorder = null;
		String engineModel = null;
		String columnName = EMPTY_STRING;
		String order = EMPTY_STRING;
		HashMap filterSortList = new HashMap();
		RepairCatalog repairCatalog = new RepairCatalog();
		log.info("Entered into getPricingCatalog() method");
		List<RepairCatalogBO> repairCatalogBOList = new ArrayList<RepairCatalogBO>();
		RepairCatalogBO repairCatalogBO = null;

		Map<Object, Object> fileMap = materialsDAO.getFileList(portalId);
		Set<String> engineModelList = new HashSet<String>();
		for (Map.Entry<Object, Object> entry : fileMap.entrySet()) {
			String key = (String) entry.getKey();
			String[] fileNames1 = key.split(UNDERSCORE, 4);
			engineModel = fileNames1[2];
			engineModelList.add(engineModel);

		}
		for (String engModel : engineModelList) {
			repairCatalogBO = getRepairCatalogBO(fileMap, portalId, engineModel, engModel);
			repairCatalogBOList.add(repairCatalogBO);
		}

		// Reading multyValued map data table variables
		order = MaterialsAppConstants.ASC;
		try {
			filterSortList = getFilterSortList(multiValmap);
			
			if (null != multiValmap.get(MaterialsAppConstants.SSORTDIR_0)
					&& !("").equals(multiValmap.get(MaterialsAppConstants.SSORTDIR_0)))
				sortorder = multiValmap.get(MaterialsAppConstants.SSORTDIR_0).get(0);
			if (null != multiValmap.get(MaterialsAppConstants.IDISPLAY_START)
					&& !("").equals(multiValmap.get(MaterialsAppConstants.IDISPLAY_START)))
				iDisplayStart = Integer.parseInt(multiValmap.get(MaterialsAppConstants.IDISPLAY_START).get(0));
			if (null != multiValmap.get(MaterialsAppConstants.IDISPLAY_LENGTH)
					&& !("").equals(multiValmap.get(MaterialsAppConstants.IDISPLAY_LENGTH)))
				iDisplayLength = Integer.parseInt(multiValmap.get(MaterialsAppConstants.IDISPLAY_LENGTH).get(0));
			if (null != multiValmap.get(MaterialsAppConstants.SECHO)
					&& !("").equals(multiValmap.get(MaterialsAppConstants.SECHO)))
				sEcho = Integer.parseInt(multiValmap.get(MaterialsAppConstants.SECHO).get(0));
			if (null != multiValmap.get(MaterialsAppConstants.ISORTCOL_0)
					&& !("").equals(multiValmap.get(MaterialsAppConstants.ISORTCOL_0)))
				sortColumn = Integer.parseInt(multiValmap.get(MaterialsAppConstants.ISORTCOL_0).get(0));
			if (sortorder == null)
				sortorder = MaterialsAppConstants.ASC;

			columnName = (String) filterSortList.get(sortColumn);
			if (columnName == null)
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8310,
						materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8310),
						ERR_DATATABLE_ERROR_OCCURED);
		} catch (TechnicalException e) {
			log.info(e);
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8310,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8310),
					ERR_DATATABLE_ERROR_OCCURED);
		}
		repairCatalog.setiTotalRecords((double) repairCatalogBOList.size());
		repairCatalog.setiTotalDisplayRecords((double) repairCatalogBOList.size());
		repairCatalogBOList = getRepairCatalogSubList(repairCatalogBOList, iDisplayStart, iDisplayLength);
		repairCatalogBOList = getRepairCatalogBOListSort(columnName, order, repairCatalogBOList, sortorder);
		repairCatalog.setSuccess(true);
		repairCatalog.setsEcho(sEcho);
		repairCatalog.setRepaireCatalogs(repairCatalogBOList);
		return repairCatalog;
	}

	
	private List<RepairCatalogBO> getRepairCatalogBOListSort(String columnName, String order, List<RepairCatalogBO> repairCatalogBOList, String sortorder){
		if (columnName != null && columnName.equals(REVISION_DATE)) {
			if (sortorder != null && sortorder.equals(order))
				Collections.sort(repairCatalogBOList, new RepairRevDateAscComparator());
			else
				Collections.sort(repairCatalogBOList, new RepairRevDateDescComparator());
		} else if (columnName != null && columnName.equals(ENGINE_MODEL)) {
			if (sortorder != null && sortorder.equals(order))
				Collections.sort(repairCatalogBOList, new EngineModelAscComparator());
			else
				Collections.sort(repairCatalogBOList, new EngineModelDescComparator());
		} else if (columnName != null && columnName.equals(EFFECTIVE_DATE)) {
			if (sortorder != null && sortorder.equals(order))
				Collections.sort(repairCatalogBOList, new RepairEffectvieDateAscComparator());
			else
				Collections.sort(repairCatalogBOList, new RepairEffectiveDateDescComparator());
		}
		return repairCatalogBOList;
	}
	
	
	private List<RepairCatalogBO> getRepairCatalogSubList(List<RepairCatalogBO> repairCatalogBOList, int iDisplayStart, int iDisplayLength) throws MaterialsException{
		if (!(repairCatalogBOList.isEmpty()) && (iDisplayStart > repairCatalogBOList.size() - 1)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8316,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8316),
					ERR_DATATABLE_DISPLAY_ERROR_OCCURED);
		} else {
			int size = iDisplayStart + iDisplayLength;
			if (size >= repairCatalogBOList.size()) {
				size = repairCatalogBOList.size();
			}
			repairCatalogBOList = repairCatalogBOList.subList(iDisplayStart, size);
		}
		return repairCatalogBOList;
	}
	
	private RepairCatalogBO getRepairCatalogBO(Map<Object, Object> fileMap, String portalId, String engineModel, String engModel){
		RepairCatalogBO repairCatalogBO = new RepairCatalogBO();
		for (Map.Entry<Object, Object> entry : fileMap.entrySet()) {
			String fileName = (String) entry.getKey();
			String[] fileNames = fileName.split(UNDERSCORE, 4);
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
			String fileExtn = fileName.substring(fileName.lastIndexOf(DOT) + 1);
			engineModel = fileNames[2];
			if (engineModel.equalsIgnoreCase(engModel)) {
				repairCatalogBO.setEngineModel(fileNames[2]);
				if (fileExtn.equalsIgnoreCase(PDF)) {
					repairCatalogBO.setPdfCatalogLink(materialsAppUtil.getApplicationURL(portalId) + REPAIR_DOCS_URL
							+ MaterialsAppUtil.Base64Encode(fileName));

					String effectiveDate = sdf.format(entry.getValue());
					repairCatalogBO.setEffectiveDate(effectiveDate);
				} else {

					String revisionDate = sdf.format(entry.getValue());
					repairCatalogBO.setRevisionDate(revisionDate);
					repairCatalogBO.setExcelCatalogLink(materialsAppUtil.getApplicationURL(portalId)
							+ REPAIR_DOCS_URL + MaterialsAppUtil.Base64Encode(fileName));

				}
			}
		}
		return repairCatalogBO;
	}
	
	/**
	 * @param sso,portalid
	 * @returns CustGlobEnqDetails
	 * @throws MaterialsException
	 */
	@Override
	public CustGlobEnqDetails getGlobEnqCustIdList(String sso, String portalId) throws MaterialsException {
		if (!isNotNullandEmpty(sso)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8301,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND);
		}
		if (!isNotNullandEmpty(portalId)) {
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8302,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8302), ERR_PORTAL_ID_NOT_FOUND);
		}
		MaterialsLoginResponse materialsLoginDetail = new MaterialsLoginResponse();
		MaterialsUserBO materialsUserBO = new MaterialsUserBO();
		String role = MaterialsAppConstants.EMPTY_STRING;
		String icao = MaterialsAppConstants.EMPTY_STRING;
		String opUid = EMPTY_STRING;
		CustGlobEnqDetails custGlobEnqDetails = null;

		try {
			materialsLoginDetail = materialsLoginApp.requestMaterialsLogin(sso, portalId);
		} catch (MaterialsException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}
		materialsUserBO = materialsLoginDetail.getMaterialsUserBO();
		if (isNotNullandEmpty(materialsUserBO.getIcaoCode()))
			icao = materialsUserBO.getIcaoCode();
		if (isNotNullandEmpty(materialsUserBO.getRole()))
			role = materialsUserBO.getRole();
		if (isNotNullandEmpty(materialsUserBO.getOperatingUnitId()))
			opUid = materialsUserBO.getOperatingUnitId();
		if (isNotNullandEmpty(role) && role.equalsIgnoreCase(MaterialsAppConstants.ROLE_GE)) {
			List<Object> custGlobEnqCacheList = getCustGlobEnqData(sso, opUid, icao, role);
			if (MaterialsAppUtil.isCollectionNotEmpty(custGlobEnqCacheList)) {
				Object cachedObj = custGlobEnqCacheList.get(0);
				if (cachedObj instanceof CustGlobEnqDetails) {
					custGlobEnqDetails = (CustGlobEnqDetails) cachedObj;
				}

			}
		}
		return custGlobEnqDetails;
	}

	/**
	 * @param sso,
	 *            opUid, icao, role
	 * @returns CustGlobEnqDetails Object List
	 * @throws MaterialsException
	 */
	public List<Object> getCustGlobEnqData(final String sso, final String opUid, final String icao, final String role)
			throws MaterialsException {
		log.info("getCustGlobEnqData() : the target original method is called to get the custGlobEnq values.");
		List<Object> list = new ArrayList<Object>();
		CustGlobEnqDetails custGlobEnqDetails = null;
		try {
			custGlobEnqDetails = materialsDAO.getGlobEnqCustIdListDS(sso, opUid, icao, role);
		} catch (TechnicalException e) {
			log.error(e);
			materialsAppUtil.throwAsBusinessException(e);
		}
		if (null != custGlobEnqDetails && custGlobEnqDetails.isStatus()) {
			list.add(custGlobEnqDetails);
		}
		return list;

	}

}
