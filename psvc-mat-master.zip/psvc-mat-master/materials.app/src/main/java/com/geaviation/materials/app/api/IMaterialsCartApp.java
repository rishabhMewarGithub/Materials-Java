package com.geaviation.materials.app.api;

import java.util.List;

import com.geaviation.materials.entity.CartCountBS;
import com.geaviation.materials.entity.DeleteCartLineBO;
import com.geaviation.materials.entity.PurchasePOBO;
import com.geaviation.materials.entity.SaveCartRequestDetails;
import com.geaviation.materials.entity.SaveCartResponseDetails;
import com.geaviation.materials.entity.StatusBO;
import com.geaviation.materials.entity.TotalPurchaseOrderBO;
import com.geaviation.materials.exception.MaterialsException;

public interface IMaterialsCartApp {

	public TotalPurchaseOrderBO getCartBS(String strSSO, String portalId) throws MaterialsException;
	/**
	 * Returns Cart details as SaveCartResponse JSON object for the given SaveCartRequest JSON.
	 * If strSSO or portalId input is null then it throws MaterialsException.
	 * The SaveCartResponse contains the following fields  
	*  cartHeaderId				denotes the cartHeaderId that is saved.
	*  statusMessage			denotes the message from the procedure.
	*  orderLineMessageBOList	denotes list of SaveCartOrderLineMessageBO		
	*  
	*  
	 * @param saveCartRequestList   	valid input SaveCartRequest. can not be NULL.
	 * @param strSSO   				valid user SSO. can not be NULL.
	 * @param portalId				valid portal id. can not be NULL. 
	 * @return SaveCartResponse		SaveCartResponse object
	 * @throws MaterialsException	
	 */
	public List<SaveCartResponseDetails> saveCartBS(List<SaveCartRequestDetails> saveCartRequestList, String strSSO, String portalId) throws MaterialsException;
	public StatusBO  deleteCartBS(String strSSO,String portalId) throws MaterialsException;
	public CartCountBS getCartCountBS(String strSSO,String portalId) throws MaterialsException;
	public DeleteCartLineBO deleteCartLineBS(String strSSO,String portalId,String cartHeaderId,String cartLineId) throws MaterialsException;
	public StatusBO  addLineItemBS(String strSSO,String portalId,String inventoryItemId,String selectedCustomerId,
		     String selectedSupplierCode,String quantity,String pricingListId, String quoteHeaderId) throws MaterialsException;
    public List<PurchasePOBO> purchasePOBS(String strSSO,String portalId,String cartHeaderId,String orderType) throws MaterialsException;
}
