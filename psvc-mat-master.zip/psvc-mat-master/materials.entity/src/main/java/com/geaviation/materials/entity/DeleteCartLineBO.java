package com.geaviation.materials.entity;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
public class DeleteCartLineBO {
	@JsonProperty("success")
	private boolean success;
	private String p_msg;
	public String getP_msg() {
		return p_msg;
	}
	public void setP_msg(String p_msg) {
		this.p_msg = p_msg;
	}
	@JsonProperty("success")
	public boolean isSuccess() {
		return success;
	}
	@JsonProperty("success")
	public void setSuccess(boolean success) {
		this.success = success;
	}

}
