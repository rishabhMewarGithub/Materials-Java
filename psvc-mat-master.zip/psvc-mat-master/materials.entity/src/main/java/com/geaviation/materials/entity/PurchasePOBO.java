package com.geaviation.materials.entity;

import java.util.Map;
import java.util.Set;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({"cartHeaderId","purchaseOrderNumber","statusMessage","orderHeaderId","success","totalOrderValue","totalDiscount","OrderLineMessageBO"})
public class PurchasePOBO {
	@JsonProperty("cartHeaderId")
	private String cartHeaderId;
	
	@JsonProperty("purchaseOrderNumber")
	private String purchaseOrderNumber;
	
	@JsonProperty("statusMessage")
	private String statusMessage;
	
	@JsonProperty("orderHeaderId")
	private String orderHeaderId;
	
	@JsonProperty("success")
	private boolean success;
	
	@JsonProperty("totalOrderValue")
	private String totalOrderValue;
	
	@JsonProperty("totalDiscount")
	private String totalDiscount;
	
	private String pricingFlag;
	
	private Map addressMap;
	
	@JsonProperty("success")
	public boolean isSuccess() {
		return success;
	}
	@JsonProperty("success")
	public void setSuccess(boolean success) {
		this.success = success;
	}
	@JsonProperty("OrderLineMessageBO")
	private Set<OrderLineMessageBO> lstOrderLineMessageBO;

	@JsonProperty("cartHeaderId")
	public String getCartHeaderId() {
		return cartHeaderId;
	}
	@JsonProperty("purchaseOrderNumber")
	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}
	@JsonProperty("purchaseOrderNumber")
	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}
	
	@JsonProperty("orderHeaderId")
	public String getOrderHeaderId() {
		return orderHeaderId;
	}
	@JsonProperty("orderHeaderId")
	public void setOrderHeaderId(String orderHeaderId) {
		this.orderHeaderId = orderHeaderId;
	}
	@JsonProperty("cartHeaderId")
	public void setCartHeaderId(String cartHeaderId) {
		this.cartHeaderId = cartHeaderId;
	}
	public Set<OrderLineMessageBO> getLstOrderLineMessageBO() {
		return lstOrderLineMessageBO;
	}
	public void setLstOrderLineMessageBO(
			Set<OrderLineMessageBO> lstOrderLineMessageBO) {
		this.lstOrderLineMessageBO = lstOrderLineMessageBO;
	}
	@JsonProperty("statusMessage")
	public String getStatusMessage() {
		return statusMessage;
	}
	@JsonProperty("statusMessage")
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	@JsonProperty("totalOrderValue")
	public String getTotalOrderValue() {
		return totalOrderValue;
	}
	@JsonProperty("totalOrderValue")
	public void setTotalOrderValue(String totalOrderValue) {
		this.totalOrderValue = totalOrderValue;
	}
	@JsonProperty("totalDiscount")
	public String getTotalDiscount() {
		return totalDiscount;
	}
	@JsonProperty("totalDiscount")
	public void setTotalDiscount(String totalDiscount) {
		this.totalDiscount = totalDiscount;
	}
	
	@JsonIgnore
	public String getPricingFlag() {
		return pricingFlag;
	}
	public void setPricingFlag(String pricingFlag) {
		this.pricingFlag = pricingFlag;
	}
	
	@JsonIgnore
	public Map<String, String> getAddressMap() {
		return addressMap;
	}
	public void setAddressMap(Map<String, String> addressMap) {
		this.addressMap = addressMap;
	}
	
	
}
