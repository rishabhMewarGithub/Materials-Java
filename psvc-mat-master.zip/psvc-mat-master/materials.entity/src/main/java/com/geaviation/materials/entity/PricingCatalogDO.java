package com.geaviation.materials.entity;

public class PricingCatalogDO {
	private byte[] docConent;
	private String revisionDate;
	private String  effDt;
	public byte[] getDocConent() {
		return docConent;
	}
	public void setDocConent(byte[] docConent) {
		this.docConent = docConent;
	}
	public String getRevisionDate() {
		return revisionDate;
	}
	public void setRevisionDate(String revisionDate) {
		this.revisionDate = revisionDate;
	}
	public String getEffDt() {
		return effDt;
	}
	public void setEffDt(String effDt) {
		this.effDt = effDt;
	}

}
