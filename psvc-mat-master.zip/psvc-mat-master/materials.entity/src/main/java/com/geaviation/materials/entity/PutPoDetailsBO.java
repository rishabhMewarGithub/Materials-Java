/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     PutPoDetailsBO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@XmlRootElement(name = "putCartOrder", namespace = "urn:snecma:cfm")
public class PutPoDetailsBO {
	private static final Log LOG = LogFactory.getLog(PutPoBO.class);
	public PutPoDetailsBO(){
		LOG.info("PutPoDetailsBO Entity class");
	}
	public PutPoDetailsBO(String cartHeaderId,String orderType){
		this.cartHeaderId = cartHeaderId;
		this.orderType = orderType;
	}
	private String cartHeaderId;
	private String orderType;
	@XmlElement
	public String getOrderType() {
		return orderType;
	}
	@XmlElement
	public String getCartHeaderId() {
		return cartHeaderId;
	}
	public void setCartHeaderId(String cartHeaderId) {
		this.cartHeaderId = cartHeaderId;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

}
