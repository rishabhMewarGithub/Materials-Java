package com.geaviation.materials.entity;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
"success",
"sEcho",
"iTotalRecords",
"iTotalDisplayRecords",
"aaData"

})
public class RepairCatalog {
	@JsonProperty("iTotalRecords")
	private double iTotalRecords;
	@JsonProperty("success")
	private boolean success;
	@JsonProperty("sEcho")
	private int sEcho;
	@JsonProperty("iTotalDisplayRecords")
	private double iTotalDisplayRecords;
	@JsonProperty("aaData")	
	private List<RepairCatalogBO> repaireCatalogs = new ArrayList<RepairCatalogBO>();
	public Double getiTotalRecords() {
		return iTotalRecords;
	}
	public void setiTotalRecords(Double iTotalRecords) {
		this.iTotalRecords = iTotalRecords;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public int getsEcho() {
		return sEcho;
	}
	public void setsEcho(int sEcho) {
		this.sEcho = sEcho;
	}
	public Double getiTotalDisplayRecords() {
		return iTotalDisplayRecords;
	}
	public void setiTotalDisplayRecords(Double iTotalDisplayRecords) {
		this.iTotalDisplayRecords = iTotalDisplayRecords;
	}
	public List<RepairCatalogBO> getRepaireCatalogs() {
		return repaireCatalogs;
	}
	public void setRepaireCatalogs(List<RepairCatalogBO> repaireCatalogs) {
		this.repaireCatalogs = repaireCatalogs;
	}
}