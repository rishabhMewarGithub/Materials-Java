package com.geaviation.materials.entity;

import java.util.List;

import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;
@JsonPropertyOrder({"kitName","kitDesciption","kitAvailability","priceList","componentList"})
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class KitStructureBO {
	
	private String kitName;
	private String kitDesciption;
	private String kitAvailability;
	private List<PriceListBO> priceList;
	private List<KitComponentDetailsBO> componentList;
	private String p_msg;
	
	public String getKitName() {
		return kitName;
	}
	public void setKitName(String kitName) {
		this.kitName = kitName;
	}
	public String getKitDesciption() {
		return kitDesciption;
	}
	public void setKitDesciption(String kitDesciption) {
		this.kitDesciption = kitDesciption;
	}
	public String getKitAvailability() {
		return kitAvailability;
	}
	public void setKitAvailability(String kitAvailability) {
		this.kitAvailability = kitAvailability;
	}
	public List<PriceListBO> getPriceList() {
		return priceList;
	}
	public void setPriceList(List<PriceListBO> priceList) {
		this.priceList = priceList;
	}
	public List<KitComponentDetailsBO> getComponentList() {
		return componentList;
	}
	public void setComponentList(List<KitComponentDetailsBO> componentList) {
		this.componentList = componentList;
	}
	public String getP_msg() {
		return p_msg;
	}
	public void setP_msg(String p_msg) {
		this.p_msg = p_msg;
	}
}
