/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    		Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     ShippingAddressBO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.List;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({"shipAddressCode","shipAddressId","defaultShipToInd","customerId","shipAddress1","shipAddress2","shipAddress3","shipAddress4","shipCity","shipState","shipZip","shipCountry","addressList"})
public class ShippingAddressBO {
	@JsonProperty("shipAddressCode")
	private String shipAddressCode;
	@JsonProperty("shipAddressId")
	private String shipAddressId;
	@JsonProperty("customerId")
	private String customerId;
	@JsonProperty("shipAddress1")
	private String shipAddress1;
	
	//Added for JIRA 6094
	@JsonProperty("shipAddress2")
	private String shipAddress2;
	@JsonProperty("shipCity")
	private String shipCity;
	@JsonProperty("shipState")
	private String shipState;
	@JsonProperty("shipZip")
	private String shipZip;
	@JsonProperty("shipCountry")
	private String shipCountry;
	@JsonProperty("shipAddress3")		
	private String shipAddress3;
	@JsonProperty("shipAddress4")
	private String shipAddress4;
	
	//Added for JIRA 6293 
	@JsonProperty("defaultShipToInd")
	private boolean defaultShipToInd;
	
	public String getShipAddress1() {
		return shipAddress1;
	}
	public void setShipAddress1(String shipAddress1) {
		this.shipAddress1 = shipAddress1;
	}
	@JsonProperty("addressList")
	List<DeliveryAddressBO> addressList;
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getShipAddressCode() {
		return shipAddressCode;
	}
	public void setShipAddressCode(String shipAddressCode) {
		this.shipAddressCode = shipAddressCode;
	}
	public String getShipAddressId() {
		return shipAddressId;
	}

	public void setShipAddressId(String shipAddressId) {
		this.shipAddressId = shipAddressId;
	}
	public List<DeliveryAddressBO> getAddressList() {
		return addressList;
	}
	public void setAddressList(List<DeliveryAddressBO> addressList) {
		this.addressList = addressList;
	}
	public String getShipAddress2() {
		return shipAddress2;
	}
	public void setShipAddress2(String shipAddress2) {
		this.shipAddress2 = shipAddress2;
	}
	public String getShipCity() {
		return shipCity;
	}
	public void setShipCity(String shipCity) {
		this.shipCity = shipCity;
	}
	public String getShipState() {
		return shipState;
	}
	public void setShipState(String shipState) {
		this.shipState = shipState;
	}
	public String getShipZip() {
		return shipZip;
	}
	public void setShipZip(String shipZip) {
		this.shipZip = shipZip;
	}
	public String getShipCountry() {
		return shipCountry;
	}
	public void setShipCountry(String shipCountry) {
		this.shipCountry = shipCountry;
	}
	public String getShipAddress3() {
		return shipAddress3;
	}
	public void setShipAddress3(String shipAddress3) {
		this.shipAddress3 = shipAddress3;
	}
	public String getShipAddress4() {
		return shipAddress4;
	}
	public void setShipAddress4(String shipAddress4) {
		this.shipAddress4 = shipAddress4;
	}
	public boolean isDefaultShipToInd() {
		return defaultShipToInd;
	}
	public void setDefaultShipToInd(boolean defaultShipToInd) {
		this.defaultShipToInd = defaultShipToInd;
	}
	
}
