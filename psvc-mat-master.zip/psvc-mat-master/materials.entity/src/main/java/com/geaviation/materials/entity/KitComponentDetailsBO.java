package com.geaviation.materials.entity;

import java.util.List;

public class KitComponentDetailsBO {
	
	private String componentLevel;
	private String componentPartNumber;
	private String componentPartDescription;
	private String componentQuantity;
	private String componentAvailability;
	private List<KitPricingListBO> kitPricingList;
	
	public String getComponentLevel() {
		return componentLevel;
	}
	public void setComponentLevel(String componentLevel) {
		this.componentLevel = componentLevel;
	}
	public String getComponentPartNumber() {
		return componentPartNumber;
	}
	public void setComponentPartNumber(String componentPartNumber) {
		this.componentPartNumber = componentPartNumber;
	}
	public String getComponentPartDescription() {
		return componentPartDescription;
	}
	public void setComponentPartDescription(String componentPartDescription) {
		this.componentPartDescription = componentPartDescription;
	}
	public String getComponentQuantity() {
		return componentQuantity;
	}
	public void setComponentQuantity(String componentQuantity) {
		this.componentQuantity = componentQuantity;
	}
	public String getComponentAvailability() {
		return componentAvailability;
	}
	public void setComponentAvailability(String componentAvailability) {
		this.componentAvailability = componentAvailability;
	}
	public List<KitPricingListBO> getKitPricingList() {
		return kitPricingList;
	}
	public void setKitPricingList(List<KitPricingListBO> kitPricingList) {
		this.kitPricingList = kitPricingList;
	}

}
