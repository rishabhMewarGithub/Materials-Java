/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Nov 28, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     DisputeDocumentBO.java
 * 
 * History        :  	Nov 28, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

/**
 * @author 720053
 *
 */
public class DisputeDocumentBO {
	private byte[] fileData;
	private String fileName;
	
	public byte[] getFileData() {
		return fileData;
	}
	public void setFileData(byte[] fileData) {
		this.fileData = fileData;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
}
