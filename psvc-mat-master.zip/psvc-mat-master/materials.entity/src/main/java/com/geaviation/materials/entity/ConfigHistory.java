

package com.geaviation.materials.entity;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
	"inventoryItemId",
	"partNumber",
	"availability",
	"unitPrice",
	"upq",
	"serviceBulletin",
	"alt",
	"engineModel",
	"customerCode",
	"serviceBulletinDate",
	"interChangeabilityCode",
	"productLine",
	"engineFamily",
	"product",
	"altLevel",
	"originalPartNumber",
	"gekNumber",
	"techPubPlatform",
	"materialsSbLink"
})
public class ConfigHistory {

	@JsonProperty("inventoryItemId")
	private String inventoryItemId;

	@JsonProperty("partNumber")
	private String partNumber;

	@JsonProperty("engineModel")
	private String engineModel;

	@JsonProperty("unitPrice")
	private String unitPrice;

	@JsonProperty("availability")
	private String availability;

	@JsonProperty("upq")
	private String upq;

	@JsonProperty("serviceBulletin")
	private String serviceBulletin;

	@JsonProperty("alt")
	private String alt;
	
	@JsonProperty("customerCode")
	private String customerCode;

	@JsonProperty("serviceBulletinDate")
	private String serviceBulletinDate;
	
	@JsonProperty("interChangeabilityCode")
	private String interChangeabilityCode;
	
	@JsonProperty("productLine")
	private String productLine;
	
	@JsonProperty("engineFamily")
	private String engineFamily;
	
	@JsonProperty("product")
	private String product;
	
	@JsonProperty("altLevel")
	private String altLevel;
	
	@JsonProperty("originalPartNumber")
	private String originalPartNumber;
	
	@JsonProperty("gekNumber")
	private String gekNumber;
	
	@JsonProperty("techPubPlatform")
	private String techPubPlatform;
	
	@JsonProperty("materialsSbLink")
	private String materialsSbLink;

	@JsonProperty("inventoryItemId")
	public String getInventoryItemId() {
		return inventoryItemId;
	}

	@JsonProperty("inventoryItemId")
	public void setInventoryItemId(String inventoryItemId) {
		this.inventoryItemId = inventoryItemId;
	}

	@JsonProperty("partNumber")
	public String getPartNumber() {
		return partNumber;
	}

	@JsonProperty("partNumber")
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	@JsonProperty("engineModel")
	public String getEngineModel() {
		return engineModel;
	}

	@JsonProperty("engineModel")
	public void setEngineModel(String engineModel) {
		this.engineModel = engineModel;
	}

	@JsonProperty("unitPrice")
	public String getUnitPrice() {
		return unitPrice;
	}

	@JsonProperty("unitPrice")
	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	@JsonProperty("availability")
	public String getAvailability() {
		return availability;
	}

	@JsonProperty("availability")
	public void setAvailability(String availability) {
		this.availability = availability;
	}

	@JsonProperty("upq")
	public String getUpq() {
		return upq;
	}

	@JsonProperty("upq")
	public void setUpq(String upq) {
		this.upq = upq;
	}

	@JsonProperty("serviceBulletin")
	public String getServiceBulletin() {
		return serviceBulletin;
	}

	@JsonProperty("serviceBulletin")
	public void setServiceBulletin(String serviceBulletin) {
		this.serviceBulletin = serviceBulletin;
	}

	@JsonProperty("alt")
	public String getAlt() {
		return alt;
	}

	@JsonProperty("alt")
	public void setAlt(String alt) {
		this.alt = alt;
	}

	@JsonProperty("customerCode")
	public String getCustomerCode() {
		return customerCode;
	}
	@JsonProperty("customerCode")
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	@JsonProperty("serviceBulletinDate")
	public String getServiceBulletinDate() {
		return serviceBulletinDate;
	}

	@JsonProperty("serviceBulletinDate")
	public void setServiceBulletinDate(String serviceBulletinDate) {
		this.serviceBulletinDate = serviceBulletinDate;
	}

	@JsonProperty("interChangeabilityCode")
	public String getInterChangeabilityCode() {
		return interChangeabilityCode;
	}

	@JsonProperty("interChangeabilityCode")
	public void setInterChangeabilityCode(String interChangeabilityCode) {
		this.interChangeabilityCode = interChangeabilityCode;
	}

	@JsonProperty("productLine")
	public String getProductLine() {
		return productLine;
	}

	@JsonProperty("productLine")
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

	@JsonProperty("engineFamily")
	public String getEngineFamily() {
		return engineFamily;
	}

	@JsonProperty("engineFamily")
	public void setEngineFamily(String engineFamily) {
		this.engineFamily = engineFamily;
	}

	@JsonProperty("product")
	public String getProduct() {
		return product;
	}

	@JsonProperty("product")
	public void setProduct(String product) {
		this.product = product;
	}

	@JsonProperty("altLevel")
	public String getAltLevel() {
		return altLevel;
	}

	@JsonProperty("altLevel")
	public void setAltLevel(String altLevel) {
		this.altLevel = altLevel;
	}

	@JsonProperty("originalPartNumber")
	public String getOriginalPartNumber() {
		return originalPartNumber;
	}
	@JsonProperty("originalPartNumber")
	public void setOriginalPartNumber(String originalPartNumber) {
		this.originalPartNumber = originalPartNumber;
	}

	@JsonProperty("gekNumber")
	public String getGekNumber() {
		return gekNumber;
	}
	@JsonProperty("gekNumber")
	public void setGekNumber(String gekNumber) {
		this.gekNumber = gekNumber;
	}
	@JsonProperty("techPubPlatform")
	public String getTechPubPlatform() {
		return techPubPlatform;
	}
	@JsonProperty("techPubPlatform")
	public void setTechPubPlatform(String techPubPlatform) {
		this.techPubPlatform = techPubPlatform;
	}
	@JsonProperty("materialsSbLink")
	public String getMaterialsSbLink() {
		return materialsSbLink;
	}
	@JsonProperty("materialsSbLink")
	public void setMaterialsSbLink(String materialsSbLink) {
		this.materialsSbLink = materialsSbLink;
	}
	
}