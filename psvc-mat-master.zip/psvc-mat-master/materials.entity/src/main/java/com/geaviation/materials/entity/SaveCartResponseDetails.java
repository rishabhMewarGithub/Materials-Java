/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	May 28, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     SaveCartResponse.java
 * 
 * History        :  	May 28, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

/**
 * @author 720053
 *
 */
@XmlRootElement
@JsonPropertyOrder({"cartHeaderId","statusMessage","orderLineMessageBOList"})
public class SaveCartResponseDetails {
	
	@JsonProperty("cartHeaderId")
	private String cartHeaderId;
	
	@JsonProperty("statusMessage")
	private String statusMessage;
	
	@XmlElement
	private List<SaveCartOrderLineMessageBO> orderLineMessageBOList;

	public String getCartHeaderId() {
		return cartHeaderId;
	}

	public void setCartHeaderId(String cartHeaderId) {
		this.cartHeaderId = cartHeaderId;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	
	@JsonProperty("OrderLineMessageBO")
	public List<SaveCartOrderLineMessageBO> getOrderLineMessageBOList() {
		return orderLineMessageBOList;
	}

	public void setOrderLineMessageBOList(List<SaveCartOrderLineMessageBO> orderLineMessageBOList) {
		this.orderLineMessageBOList = orderLineMessageBOList;
	}
	
	

}
