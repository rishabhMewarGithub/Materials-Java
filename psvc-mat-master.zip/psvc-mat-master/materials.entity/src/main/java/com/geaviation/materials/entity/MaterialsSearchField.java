/******************************************************** 
 * Project        :     Repair : CWC Services 
 * Date		      :    	Oct 14, 2015  	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     RepairSearchField.java
 * 
 * History        :  	Oct 14, 2015                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

public class MaterialsSearchField {
	
	private String fieldName;
	private String filtervalues;
	
	public MaterialsSearchField(String fieldName, String filtervalues) {
		super();
		this.fieldName = fieldName;
		this.filtervalues = filtervalues;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFiltervalues() {
		return filtervalues;
	}

	public void setFiltervalues(String filtervalues) {
		this.filtervalues = filtervalues;
	}

	
}
