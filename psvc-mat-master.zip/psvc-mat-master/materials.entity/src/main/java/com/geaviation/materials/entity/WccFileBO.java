package com.geaviation.materials.entity;

/**
 * This class represents a file object that we retrieve from Oracle Web Center.
 * It contains the actual file contents, file name as stored in Web Center, status code that describes
 * whether the retrieval is successful or not, status message to go with status code.
 *
 */
public class WccFileBO {

	private byte[] fileContent;
	private String fileName;
	private int statusCode;
	private String statusMessage;
	public byte[] getFileContent() {
		return fileContent;
	}
	public void setFileContent(byte[] fileContent) {
		this.fileContent = fileContent;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}	
}
