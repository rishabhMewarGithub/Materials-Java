package com.geaviation.materials.entity;
import java.sql.Date;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Jun 26, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     SaveCartInputDO.java
 * 
 * History        :  	Jun 26, 2014                
   Date                           
 **********************************************************/

/**
 * @author 720053
 *
 */
public class SaveCartInputDO implements SQLData {
	
	/*QUOTE_HEADER_ID 				NUMBER,
	PURCHASE_ORDER_NUMBER           VARCHAR2(500),
	SHIP_TO_ADDRESS_ID 				NUMBER,
	DELIVER_TO_ADDRESS_ID 			NUMBER,
	HDR_REQUESTED_DATE              DATE,
	ORDER_PRIORITY 					VARCHAR2(50)*/
	
	
	private int quote_header_id;
	private String purchase_order_number;
	private String ship_to_address_id;
	private String deliver_to_address_id;
	private Date hdr_requested_date;
	private String order_priority;

	private String sqlType = "APPS.V_QUOTE_HEADER_DTL";
	
	
	
	public SaveCartInputDO(int quote_header_id,String purchase_order_number,String ship_to_address_id,String deliver_to_address_id,Date hdr_requested_date,String order_priority){
		this.quote_header_id = quote_header_id;
		this.purchase_order_number = purchase_order_number;
		this.ship_to_address_id = ship_to_address_id;
		this.deliver_to_address_id = deliver_to_address_id;
		this.hdr_requested_date = hdr_requested_date;
		this.order_priority = order_priority;
	}
	

	/* (non-Javadoc)
	 * @see java.sql.SQLData#getSQLTypeName()
	 */
	@Override
	public String getSQLTypeName() throws SQLException {
		return sqlType;
	}

	/* (non-Javadoc)
	 * @see java.sql.SQLData#readSQL(java.sql.SQLInput, java.lang.String)
	 */
	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		sqlType = typeName;
		quote_header_id = stream.readInt();
		purchase_order_number = stream.readString();
		ship_to_address_id = stream.readString();
		deliver_to_address_id = stream.readString();
		hdr_requested_date = stream.readDate();
		order_priority = stream.readString();
	}

	/* (non-Javadoc)
	 * @see java.sql.SQLData#writeSQL(java.sql.SQLOutput)
	 */
	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		stream.writeInt(quote_header_id);
	    stream.writeString(purchase_order_number);
	    stream.writeString(ship_to_address_id);
	    stream.writeString(deliver_to_address_id);
	    stream.writeDate(hdr_requested_date);
	    stream.writeString(order_priority);
	}
	
}
