/**
 * 
 */
package com.geaviation.materials.entity;

/**
 * @author 212589907
 *
 */
public class MaterialsConstants {
	
	
	public static final String MYCFM = "myCFM";
	public static final String CWC = "CWC";
	
	private MaterialsConstants() {
	}
	
}
