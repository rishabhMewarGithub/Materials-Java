/* Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016 
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     PutRatingPlugDetailsBO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@XmlRootElement(name = "putRatingPlugDetails", namespace = "urn:snecma:cfm")
public class PutRatingPlugDetailsBO {
	private static final Log LOG = LogFactory.getLog(PutRatingPlugDetailsBO.class);
	public PutRatingPlugDetailsBO()
	{
		LOG.info("PutRatingPlugDetailsBO Constructor");
	}
	public PutRatingPlugDetailsBO(String jsonData)
	{
		this.jsonData=jsonData;
	}
	private String jsonData;
	@XmlElement
	public String getJsonData() {
		return jsonData;
	}
	public void setJsonData(String jsonData) {
		this.jsonData = jsonData;
	}
}
