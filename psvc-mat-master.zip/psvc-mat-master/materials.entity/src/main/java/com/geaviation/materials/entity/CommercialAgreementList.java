/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016   
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     CommercialAgreementList.java
 * 
 * History        :  	May 28, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonPropertyOrder({
"commercialAgreementNumber",
"commercialAgreementName"
})
public class CommercialAgreementList {

@JsonProperty("commercialAgreementNumber")
private String commercialAgreementNumber;

@JsonProperty("commercialAgreementName")
private String commercialAgreementName;

public String getCommercialAgreementNumber() {
	return commercialAgreementNumber;
}

public void setCommercialAgreementNumber(String commercialAgreementNumber) {
	this.commercialAgreementNumber = commercialAgreementNumber;
}

public String getCommercialAgreementName() {
	return commercialAgreementName;
}

public void setCommercialAgreementName(String commercialAgreementName) {
	this.commercialAgreementName = commercialAgreementName;
}

}