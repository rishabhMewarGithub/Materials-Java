package com.geaviation.materials.entity;

public class PriceListBO {
	private String kitMessage;
	private String customerCode;
	private String price;
	
	public String getKitMessage() {
		return kitMessage;
	}
	public void setKitMessage(String kitMessage) {
		this.kitMessage = kitMessage;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}

}
