package com.geaviation.materials.entity;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class EmailContentInputBO {

	private String to;

	private String from;

	private String cc;

	private String subject;

	private String body;

	private String emailTemplateType;

	private String identityId;
	
	private String portalId;
	
	private List<String> attachmentName;
	
	private List<String> messageAttachment;

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getEmailTemplateType() {
		return emailTemplateType;
	}

	public void setEmailTemplateType(String emailTemplateType) {
		this.emailTemplateType = emailTemplateType;
	}

	public String getIdentityId() {
		return identityId;
	}

	public void setIdentityId(String identityId) {
		this.identityId = identityId;
	}

	public List<String> getAttachmentName() {
		return attachmentName;
	}

	public void setAttachmentName(List<String> attachmentName) {
		this.attachmentName = attachmentName;
	}

	public List<String> getMessageAttachment() {
		return messageAttachment;
	}

	public void setMessageAttachment(List<String> messageAttachment) {
		this.messageAttachment = messageAttachment;
	}

	public String getPortalId() {
		return portalId;
	}

	public void setPortalId(String portalId) {
		this.portalId = portalId;
	}
	
}
