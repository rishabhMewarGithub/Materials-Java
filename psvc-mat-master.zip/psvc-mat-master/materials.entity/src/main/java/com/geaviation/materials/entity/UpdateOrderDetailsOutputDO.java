/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     UpdateOrderDetailsOutputDO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.List;

public class UpdateOrderDetailsOutputDO {

	private List<UpdateOrderOutputDO> updateOrderList;
	
	private String procMessage;

	public List<UpdateOrderOutputDO> getUpdateOrderList() {
		return updateOrderList;
	}

	public void setUpdateOrderList(List<UpdateOrderOutputDO> updateOrderList) {
		this.updateOrderList = updateOrderList;
	}

	public String getProcMessage() {
		return procMessage;
	}

	public void setProcMessage(String procMessage) {
		this.procMessage = procMessage;
	}
	
	
}
