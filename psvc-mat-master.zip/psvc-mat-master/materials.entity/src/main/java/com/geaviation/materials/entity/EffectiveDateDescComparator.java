package com.geaviation.materials.entity;

import java.util.Comparator;

import com.geaviation.materials.entity.Pricing;

public class EffectiveDateDescComparator implements Comparator<Pricing> {
	 public int compare(Pricing pricingCatDO1, Pricing pricingCatDO2) {
		 boolean isStrDate0Empty = (pricingCatDO2.getEffDate() == null || pricingCatDO2.getEffDate().isEmpty());
		    boolean isStrDate1Empty = (pricingCatDO1.getEffDate() == null || pricingCatDO1.getEffDate().isEmpty());

		    if (isStrDate0Empty && isStrDate1Empty)
		        return 0;
		    // at least one of them is not empty    
		    if (isStrDate0Empty)
		        return -1;
		    if (isStrDate1Empty)
		        return 1;
		    //none of them is empty
		  return pricingCatDO2.getEffDate().compareTo(pricingCatDO1.getEffDate());
	    }
}
