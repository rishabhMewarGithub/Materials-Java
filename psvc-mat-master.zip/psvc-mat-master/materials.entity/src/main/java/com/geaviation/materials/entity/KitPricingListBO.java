package com.geaviation.materials.entity;

public class KitPricingListBO {
	
	private float unitPrice;
	private float extendedPrice;
	private String customerCode;
	
	public float getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(float unitPrice) {
		this.unitPrice = unitPrice;
	}
	public float getExtendedPrice() {
		return extendedPrice;
	}
	public void setExtendedPrice(float extendedPrice) {
		this.extendedPrice = extendedPrice;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

}
