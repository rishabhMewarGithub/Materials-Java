package com.geaviation.materials.entity;

import java.util.List;

public class OrderDO {
	private String message;
	private String orderNumber;
	private String orderDate;
	private String orderStatus;
	private String CustCode;
	private String CustName;
	private String custId;
	private List<OrderLineDO>  orderLineDOList;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<OrderLineDO> getOrderLineDOList() {
		return orderLineDOList;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public void setOrderLineDOList(List<OrderLineDO> orderLineDOList) {
		this.orderLineDOList = orderLineDOList;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getCustCode() {
		return CustCode;
	}
	public void setCustCode(String custCode) {
		CustCode = custCode;
	}
	public String getCustName() {
		return CustName;
	}
	public void setCustName(String custName) {
		CustName = custName;
	}
}
