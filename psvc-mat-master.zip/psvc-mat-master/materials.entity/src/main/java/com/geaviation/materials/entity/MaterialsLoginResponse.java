/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 12, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     MaterialsLoginResponse.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;

import com.geaviation.materials.entity.MaterialsUserBO;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "MaterialsLoginResponse")
public class MaterialsLoginResponse implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@XmlAttribute(name = "success")
	private boolean success;
	
	@XmlAttribute(name = "message")
	private String message;
	
	@XmlElement
	private MaterialsUserBO materialsUserBO;
	
	@JsonProperty("MaterialsUserBO")
	public MaterialsUserBO getMaterialsUserBO() {
		return materialsUserBO;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}
	
	@JsonIgnore
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setMaterialsUserBO(MaterialsUserBO materialsUserBO) {
		this.materialsUserBO = materialsUserBO;
	}
}
	