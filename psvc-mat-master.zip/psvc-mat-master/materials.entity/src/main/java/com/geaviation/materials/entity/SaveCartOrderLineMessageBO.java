/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	May 28, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     OrderLineMessageBO.java
 * 
 * History        :  	May 28, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

/**
 * @author 720053
 *
 */
@XmlRootElement(name = "OrderLineMessageBO")
@JsonPropertyOrder({"cartLineId","statusMessage","success","esnValidFlag","esnStatusMsg"})
public class SaveCartOrderLineMessageBO {
	
	@JsonProperty("cartLineId")
	private String cartLineId;
	
	@JsonProperty("statusMessage")
	private String statusMessage;
	
	@JsonProperty("success")
	private boolean success;
	
	@JsonProperty("esnValidFlag")
	private String esnValidFlag;
	
	@JsonProperty("esnStatusMsg")
	private String esnStatusMsg;

	public String getCartLineId() {
		return cartLineId;
	}

	public void setCartLineId(String cartLineId) {
		this.cartLineId = cartLineId;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getEsnValidFlag() {
		return esnValidFlag;
	}

	public void setEsnValidFlag(String esnValidFlag) {
		this.esnValidFlag = esnValidFlag;
	}

	public String getEsnStatusMsg() {
		return esnStatusMsg;
	}

	public void setEsnStatusMsg(String esnStatusMsg) {
		this.esnStatusMsg = esnStatusMsg;
	}	
	
}
