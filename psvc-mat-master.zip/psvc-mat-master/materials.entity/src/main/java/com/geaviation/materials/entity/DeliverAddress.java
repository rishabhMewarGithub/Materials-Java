package com.geaviation.materials.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "DeliverAddressListBO")

public class DeliverAddress {
	
	@XmlAttribute(name = "deliverAddressId")
	private String deliverAddressId;
	@XmlAttribute(name = "addressName")
	private String addressName;
	@XmlAttribute(name = "addressCode")
	private String addressCode;
	@XmlAttribute(name = "address1")
	private String address1;
	@XmlAttribute(name = "address2")
	private String address2;
	@XmlAttribute(name = "city")
	private String city;
	@XmlAttribute(name = "state")
	private String state;
	@XmlAttribute(name = "zip")
	private String zip;
	@XmlAttribute(name = "country")
	private String country;
	@XmlAttribute(name = "defaultInd")
	private String defaultInd;
	@XmlAttribute(name = "custId")
	private String  custId;
	@XmlAttribute(name = "address3")
	private String address3;
	@XmlAttribute(name = "address4")
	private String address4;

	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getAddress4() {
		return address4;
	}
	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getDefaultInd() {
		return defaultInd;
	}
	public void setDefaultInd(String defaultInd) {
		this.defaultInd = defaultInd;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getAddressName() {
		return addressName;
	}
	public void setAddressName(String addressName) {
		this.addressName = addressName;
	}
	public String getAddressCode() {
		return addressCode;
	}
	public void setAddressCode(String addressCode) {
		this.addressCode = addressCode;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDeliverAddressId() {
		return deliverAddressId;
	}
	public void setDeliverAddressId(String deliverAddressId) {
		this.deliverAddressId = deliverAddressId;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}


}
