/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :     Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     QuotationBO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
"rfqQuotation",
"orderedQuantity",
"quotationUpq",
"quotationCurrency",
"quotationLeadTime",
"quotationUnitPrice"
})
public class QuotationBO {
	@JsonProperty("rfqQuotation")
	private String rfqQuotation = "";
	
	@JsonProperty("orderedQuantity")
	private String orderedQuantity = "";
	
	@JsonProperty("quotationUpq")
	private String quotationUpq = "";
	
	@JsonProperty("quotationCurrency")
	private String quotationCurrency = "";
	
	@JsonProperty("quotationLeadTime")
	private String quotationLeadTime =  "";
	
	@JsonProperty("quotationUnitPrice")
	private String quotationUnitPrice = "";
	
	@JsonProperty("rfqQuotation")
	public String getRfqQuotation() {
		return rfqQuotation;
	}
	@JsonProperty("rfqQuotation")
	public void setRfqQuotation(String rfqQuotation) {
		this.rfqQuotation = rfqQuotation;
	}
	@JsonProperty("orderedQuantity")
	public String getOrderedQuantity() {
		return orderedQuantity;
	}
	@JsonProperty("orderedQuantity")
	public void setOrderedQuantity(String orderedQuantity) {
		this.orderedQuantity = orderedQuantity;
	}
	@JsonProperty("quotationUpq")
	public String getQuotationUpq() {
		return quotationUpq;
	}
	@JsonProperty("quotationUpq")
	public void setQuotationUpq(String quotationUpq) {
		this.quotationUpq = quotationUpq;
	}
	@JsonProperty("quotationCurrency")
	public String getQuotationCurrency() {
		return quotationCurrency;
	}
	@JsonProperty("quotationCurrency")
	public void setQuotationCurrency(String quotationCurrency) {
		this.quotationCurrency = quotationCurrency;
	}
	@JsonProperty("quotationLeadTime")
	public String getQuotationLeadTime() {
		return quotationLeadTime;
	}
	@JsonProperty("quotationLeadTime")
	public void setQuotationLeadTime(String quotationLeadTime) {
		this.quotationLeadTime = quotationLeadTime;
	}
	@JsonProperty("quotationUnitPrice")
	public String getQuotationUnitPrice() {
		return quotationUnitPrice;
	}
	@JsonProperty("quotationUnitPrice")
	public void setQuotationUnitPrice(String quotationUnitPrice) {
		this.quotationUnitPrice = quotationUnitPrice;
	}
	

}

