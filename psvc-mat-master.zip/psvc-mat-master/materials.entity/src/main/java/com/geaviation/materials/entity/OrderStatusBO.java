package com.geaviation.materials.entity;

import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class OrderStatusBO {
	
	private String totalLines;
	private String displayMessage;
	@JsonProperty("StatusBO")
	private List<OrderTemplateStatusBO> ordrStatusBO;
	
	
	public String getDisplayMessage() {
		return displayMessage;
	}
	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}
	public String getTotalLines() {
		return totalLines;
	}
	public void setTotalLines(String totalLines) {
		this.totalLines = totalLines;
	}
	public List<OrderTemplateStatusBO> getOrdrStatusBO() {
		return ordrStatusBO;
	}
	public void setOrdrStatusBO(List<OrderTemplateStatusBO> ordrStatusBO) {
		this.ordrStatusBO = ordrStatusBO;
	}
	
}
