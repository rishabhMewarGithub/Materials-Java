package com.geaviation.materials.entity;

import java.sql.Date;
public class PricingCatalogDates {
	private String effectiveDate;
	private String  excelRevDate;	
	private String displayName;
	private String type;
	private String platform;
	
	
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public String getExcelRevDate() {
		return excelRevDate;
	}
	public void setExcelRevDate(String excelRevDate) {
		this.excelRevDate = excelRevDate;
	}

	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPlatform() {
		return platform;
	}
	public void setPlatform(String platform) {
		this.platform = platform;
	}
	
	

	
}
