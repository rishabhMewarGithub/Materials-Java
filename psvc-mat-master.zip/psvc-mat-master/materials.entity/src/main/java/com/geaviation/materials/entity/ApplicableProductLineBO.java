package com.geaviation.materials.entity;

public class ApplicableProductLineBO{
	
	private String custCode;
	private String engineProductLine;
	
	public String getCustCode() {
		return custCode;
	}
	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	public String getEngineProductLine() {
		return engineProductLine;
	}
	public void setEngineProductLine(String engineProductLine) {
		this.engineProductLine = engineProductLine;
	}
	
	
}