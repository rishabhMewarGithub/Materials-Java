/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     UpdateOrderRequestDetails.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class UpdateOrderRequestDetails {

	@JsonProperty("headerId")
	private String headerId;
	
	@JsonProperty("lineId")
	private String lineId;
	
	@JsonProperty("custPOLineNumber")
	private String custPOLineNumber;
	
	@JsonProperty("orderedQuantity")
	private String orderedQuantity;
	
	@JsonProperty("shipmentPriorityCode")
	private String shipmentPriorityCode;
	
	@JsonProperty("shipToLocation")
	private String shipToLocation;
	
	@JsonProperty("deliverToLocation")
	private String deliverToLocation;
	
	@JsonProperty("requestDate")
	private String requestDate;
	
	//JIRA 8723
	@JsonProperty("orderLineESN")
	private String orderLineESN;

	@JsonProperty("shippingMethod")
	private String shippingMethod;
	@JsonProperty("specifiedShippingDate")
	private String specifiedShippingDate;
	
	@JsonProperty("orderLineWorkStopQuantity")
	private String orderLineWorkStopQuantity;
	
	@JsonProperty("orderLineWorkStopDate")
	private String orderLineWorkStopDate;
	
	public String getOrderLineWorkStopQuantity() {
		return orderLineWorkStopQuantity;
	}

	public void setOrderLineWorkStopQuantity(String orderLineWorkStopQuantity) {
		this.orderLineWorkStopQuantity = orderLineWorkStopQuantity;
	}

	public String getOrderLineWorkStopDate() {
		return orderLineWorkStopDate;
	}

	public void setOrderLineWorkStopDate(String orderLineWorkStopDate) {
		this.orderLineWorkStopDate = orderLineWorkStopDate;
	}

	public String getShippingMethod() {
		return shippingMethod;
	}

	public void setShippingMethod(String shippingMethod) {
		this.shippingMethod = shippingMethod;
	}

	public String getSpecifiedShippingDate() {
		return specifiedShippingDate;
	}

	public void setSpecifiedShippingDate(String specifiedShippingDate) {
		this.specifiedShippingDate = specifiedShippingDate;
	}
	public String getHeaderId() {
		return headerId;
	}

	public void setHeaderId(String headerId) {
		this.headerId = headerId;
	}

	public String getLineId() {
		return lineId;
	}

	public void setLineId(String lineId) {
		this.lineId = lineId;
	}

	public String getCustPOLineNumber() {
		return custPOLineNumber;
	}

	public void setCustPOLineNumber(String custPOLineNumber) {
		this.custPOLineNumber = custPOLineNumber;
	}

	public String getOrderedQuantity() {
		return orderedQuantity;
	}

	public void setOrderedQuantity(String orderedQuantity) {
		this.orderedQuantity = orderedQuantity;
	}

	public String getShipmentPriorityCode() {
		return shipmentPriorityCode;
	}

	public void setShipmentPriorityCode(String shipmentPriorityCode) {
		this.shipmentPriorityCode = shipmentPriorityCode;
	}

	public String getShipToLocation() {
		return shipToLocation;
	}

	public void setShipToLocation(String shipToLocation) {
		this.shipToLocation = shipToLocation;
	}

	public String getDeliverToLocation() {
		return deliverToLocation;
	}

	public void setDeliverToLocation(String deliverToLocation) {
		this.deliverToLocation = deliverToLocation;
	}

	public String getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public String getOrderLineESN() {
		return orderLineESN;
	}

	public void setOrderLineESN(String orderLineESN) {
		this.orderLineESN = orderLineESN;
	}
		
}
