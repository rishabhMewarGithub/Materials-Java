/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Jun 26, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     SaveCartMessageDO.java
 * 
 * History        :  	Jun 26, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

/**
 * @author 720053
 *
 */
public class SaveCartMessageOutputDO {
	
	private String cartHeaderId;
	private String  statusMessage;
	public String getCartHeaderId() {
		return cartHeaderId;
	}
	public void setCartHeaderId(String cartHeaderId) {
		this.cartHeaderId = cartHeaderId;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	

}
