/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016   
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     AdditionalLineInfo.java
 * 
 * History        :  	May 19, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

public class AdditionalLineInfo {
	private String commercialAgreementNumber;
	private String quotationNumber;
	private String ssmIncoterm;
	private String specifiedShippingDate;
	private String totalWeight;
	private String shippingMethod;
	private String deliverToAddress_6;
	private String deliverToAddress_7;
	private String acn;
	private String engineNumber;
	private String manufacturerCode;
	private String additionalCost;
	private String additionalCostLabel;
	private String additionalCostAmount;
	private String cashInAdvance;
	private String proformaInvoice;
	private String easaReference;
	private String shippingInvoice;
	private String boxNumber;
	private String partsReadyOnCfmSaDocks;
	private String cfmSaDockDeparture;
	private String deliveryToNamedPlaceOfDestination;
	private String carrier;
	private String orderComment;
	private String quotationTypeOfResponse;
	private String reasonPartNumberChange;
	
	public String getCommercialAgreementNumber() {
		return commercialAgreementNumber;
	}
	public void setCommercialAgreementNumber(String commercialAgreementNumber) {
		this.commercialAgreementNumber = commercialAgreementNumber;
	}
	public String getQuotationNumber() {
		return quotationNumber;
	}
	public void setQuotationNumber(String quotationNumber) {
		this.quotationNumber = quotationNumber;
	}
	public String getSsmIncoterm() {
		return ssmIncoterm;
	}
	public void setSsmIncoterm(String ssmIncoterm) {
		this.ssmIncoterm = ssmIncoterm;
	}
	public String getSpecifiedShippingDate() {
		return specifiedShippingDate;
	}
	public void setSpecifiedShippingDate(String specifiedShippingDate) {
		this.specifiedShippingDate = specifiedShippingDate;
	}
	public String getTotalWeight() {
		return totalWeight;
	}
	public void setTotalWeight(String totalWeight) {
		this.totalWeight = totalWeight;
	}
	public String getShippingMethod() {
		return shippingMethod;
	}
	public void setShippingMethod(String shippingMethod) {
		this.shippingMethod = shippingMethod;
	}
	public String getDeliverToAddress_6() {
		return deliverToAddress_6;
	}
	public void setDeliverToAddress_6(String deliverToAddress_6) {
		this.deliverToAddress_6 = deliverToAddress_6;
	}
	public String getDeliverToAddress_7() {
		return deliverToAddress_7;
	}
	public void setDeliverToAddress_7(String deliverToAddress_7) {
		this.deliverToAddress_7 = deliverToAddress_7;
	}
	public String getAcn() {
		return acn;
	}
	public void setAcn(String acn) {
		this.acn = acn;
	}
	public String getEngineNumber() {
		return engineNumber;
	}
	public void setEngineNumber(String engineNumber) {
		this.engineNumber = engineNumber;
	}
	public String getManufacturerCode() {
		return manufacturerCode;
	}
	public void setManufacturerCode(String manufacturerCode) {
		this.manufacturerCode = manufacturerCode;
	}
	public String getAdditionalCost() {
		return additionalCost;
	}
	public void setAdditionalCost(String additionalCost) {
		this.additionalCost = additionalCost;
	}
	public String getAdditionalCostLabel() {
		return additionalCostLabel;
	}
	public void setAdditionalCostLabel(String additionalCostLabel) {
		this.additionalCostLabel = additionalCostLabel;
	}
	public String getAdditionalCostAmount() {
		return additionalCostAmount;
	}
	public void setAdditionalCostAmount(String additionalCostAmount) {
		this.additionalCostAmount = additionalCostAmount;
	}
	public String getCashInAdvance() {
		return cashInAdvance;
	}
	public void setCashInAdvance(String cashInAdvance) {
		this.cashInAdvance = cashInAdvance;
	}
	public String getProformaInvoice() {
		return proformaInvoice;
	}
	public void setProformaInvoice(String proformaInvoice) {
		this.proformaInvoice = proformaInvoice;
	}
	public String getEasaReference() {
		return easaReference;
	}
	public void setEasaReference(String easaReference) {
		this.easaReference = easaReference;
	}
	public String getShippingInvoice() {
		return shippingInvoice;
	}
	public void setShippingInvoice(String shippingInvoice) {
		this.shippingInvoice = shippingInvoice;
	}
	public String getBoxNumber() {
		return boxNumber;
	}
	public void setBoxNumber(String boxNumber) {
		this.boxNumber = boxNumber;
	}
	public String getPartsReadyOnCfmSaDocks() {
		return partsReadyOnCfmSaDocks;
	}
	public void setPartsReadyOnCfmSaDocks(String partsReadyOnCfmSaDocks) {
		this.partsReadyOnCfmSaDocks = partsReadyOnCfmSaDocks;
	}
	public String getCfmSaDockDeparture() {
		return cfmSaDockDeparture;
	}
	public void setCfmSaDockDeparture(String cfmSaDockDeparture) {
		this.cfmSaDockDeparture = cfmSaDockDeparture;
	}
	public String getDeliveryToNamedPlaceOfDestination() {
		return deliveryToNamedPlaceOfDestination;
	}
	public void setDeliveryToNamedPlaceOfDestination(
			String deliveryToNamedPlaceOfDestination) {
		this.deliveryToNamedPlaceOfDestination = deliveryToNamedPlaceOfDestination;
	}
	public String getCarrier() {
		return carrier;
	}
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
	public String getOrderComment() {
		return orderComment;
	}
	public void setOrderComment(String orderComment) {
		this.orderComment = orderComment;
	}
	public String getQuotationTypeOfResponse() {
		return quotationTypeOfResponse;
	}
	public void setQuotationTypeOfResponse(String quotationTypeOfResponse) {
		this.quotationTypeOfResponse = quotationTypeOfResponse;
	}
	public String getReasonPartNumberChange() {
		return reasonPartNumberChange;
	}
	public void setReasonPartNumberChange(String reasonPartNumberChange) {
		this.reasonPartNumberChange = reasonPartNumberChange;
	}
	
	/*public String[] getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(String[] deliveryIdNew) {
		if (null != deliveryIdNew && deliveryIdNew.length > 0) {
			this.deliveryId = deliveryIdNew;
		}
	}
	public String[] getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String[] invoiceNumberNew) {
		if (null != invoiceNumberNew && invoiceNumberNew.length > 0) {
			this.invoiceNumber = invoiceNumberNew;
		}
	}
	public String[] getMsNumber() {
		return msNumber;
	}
	public void setMsNumber(String[] msNumberNew) {
		if (null != msNumberNew && msNumberNew.length > 0) {
			this.msNumber = msNumberNew;
		}
	}
	public String[] getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(String[] invoiceIdNew) {
		if (null != invoiceIdNew && invoiceIdNew.length > 0) {
			this.invoiceId = invoiceIdNew;
		}
	}*/

}
