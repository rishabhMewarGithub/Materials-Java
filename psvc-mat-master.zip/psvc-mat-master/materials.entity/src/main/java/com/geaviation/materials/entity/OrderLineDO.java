package com.geaviation.materials.entity;

public class OrderLineDO {
	private int lineID;
	 private String custPOLineNumber;
	 private String inventoryItemId;
	 private String partNumber;
	 private String partDesc;
	 private String partUPQ;
	 private String partKeyWd;
	 private String requestedQty;
	 private String shippdQty;
	 private String cnclQty;
	 private String orderLnSellPrc;
	 private String orderLnExtPrc;
	 private String orderLnListPrc;
/*	 private String orderLnDocs;*/
	 private String orderLnReqDt;
	 private String orderLnShipDt;
	 private String orderLnPromiseDt;
	 private String orderLnShipTocd;
	 private String orderLnShipTo1;
	 private String orderLnShipTo2;
	 private String orderLnShipTo3;
	 private String orderLnShipTo4;
	 private String orderLnShipTo5;
	 private String orderLnshipAddressID;
	 private String orderLnDeliverToCd;
	 private String orderLnDeliverTo1;
	 private String orderLnDeliverTo2;
	 private String orderLnDeliverTo3;
	 private String orderLnDeliverTo4;
	 private String orderLnDeliverTo5;
	 private String orderLndeliverAddressID;
	 private String orderLnPriority;
	 private String orderLnStatus;
	 private String orderLnCancelAllowed;
	 private String orderLnType;
	 private String oraLineNumber;
	 private String oraShipNumber;
	 private String oraCmpNumber;
	 private String OraOrderNumber;
	 private String paymentTerms;
	 private String warehouse;
	 private String salesRep;
	 private String shipIns;
	 private String packIns;
	 private String freightTerms;
	 private String shipSet;
	 private String itemType;
	 private String orderLnInvoice;
	 private String orderLnAWB;
	public String getPartUPQ() {
		return partUPQ;
	}
	public void setPartUPQ(String partUPQ) {
		this.partUPQ = partUPQ;
	}
	public int getLineID() {
		return lineID;
	}
	public void setLineID(int lineID) {
		this.lineID = lineID;
	}
	public String getCustPOLineNumber() {
		return custPOLineNumber;
	}
	public void setCustPOLineNumber(String custPOLineNumber) {
		this.custPOLineNumber = custPOLineNumber;
	}
	public String getInventoryItemId() {
		return inventoryItemId;
	}
	public void setInventoryItemId(String inventoryItemId) {
		this.inventoryItemId = inventoryItemId;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getPartDesc() {
		return partDesc;
	}
	public void setPartDesc(String partDesc) {
		this.partDesc = partDesc;
	}
	public String getPartKeyWd() {
		return partKeyWd;
	}
	public void setPartKeyWd(String partKeyWd) {
		this.partKeyWd = partKeyWd;
	}
	public String getRequestedQty() {
		return requestedQty;
	}
	public void setRequestedQty(String requestedQty) {
		this.requestedQty = requestedQty;
	}
	public String getShippdQty() {
		return shippdQty;
	}
	public void setShippdQty(String shippdQty) {
		this.shippdQty = shippdQty;
	}
	public String getCnclQty() {
		return cnclQty;
	}
	public void setCnclQty(String cnclQty) {
		this.cnclQty = cnclQty;
	}
	public String getOrderLnSellPrc() {
		return orderLnSellPrc;
	}
	public void setOrderLnSellPrc(String orderLnSellPrc) {
		this.orderLnSellPrc = orderLnSellPrc;
	}
	public String getOrderLnExtPrc() {
		return orderLnExtPrc;
	}
	public void setOrderLnExtPrc(String orderLnExtPrc) {
		this.orderLnExtPrc = orderLnExtPrc;
	}
	public String getOrderLnListPrc() {
		return orderLnListPrc;
	}
	public void setOrderLnListPrc(String orderLnListPrc) {
		this.orderLnListPrc = orderLnListPrc;
	}
	/*public String getOrderLnDocs() {
		return orderLnDocs;
	}
	public void setOrderLnDocs(String orderLnDocs) {
		this.orderLnDocs = orderLnDocs;
	}*/
	public String getOrderLnReqDt() {
		return orderLnReqDt;
	}
	public void setOrderLnReqDt(String orderLnReqDt) {
		this.orderLnReqDt = orderLnReqDt;
	}
	public String getOrderLnShipDt() {
		return orderLnShipDt;
	}
	public void setOrderLnShipDt(String orderLnShipDt) {
		this.orderLnShipDt = orderLnShipDt;
	}
	public String getOrderLnPromiseDt() {
		return orderLnPromiseDt;
	}
	public void setOrderLnPromiseDt(String orderLnPromiseDt) {
		this.orderLnPromiseDt = orderLnPromiseDt;
	}
	public String getOrderLnShipTocd() {
		return orderLnShipTocd;
	}
	public void setOrderLnShipTocd(String orderLnShipTocd) {
		this.orderLnShipTocd = orderLnShipTocd;
	}
	public String getOrderLnShipTo1() {
		return orderLnShipTo1;
	}
	public void setOrderLnShipTo1(String orderLnShipTo1) {
		this.orderLnShipTo1 = orderLnShipTo1;
	}
	public String getOrderLnShipTo2() {
		return orderLnShipTo2;
	}
	public void setOrderLnShipTo2(String orderLnShipTo2) {
		this.orderLnShipTo2 = orderLnShipTo2;
	}
	public String getOrderLnShipTo3() {
		return orderLnShipTo3;
	}
	public void setOrderLnShipTo3(String orderLnShipTo3) {
		this.orderLnShipTo3 = orderLnShipTo3;
	}
	public String getOrderLnShipTo4() {
		return orderLnShipTo4;
	}
	public void setOrderLnShipTo4(String orderLnShipTo4) {
		this.orderLnShipTo4 = orderLnShipTo4;
	}
	public String getOrderLnShipTo5() {
		return orderLnShipTo5;
	}
	public void setOrderLnShipTo5(String orderLnShipTo5) {
		this.orderLnShipTo5 = orderLnShipTo5;
	}
	public String getOrderLnDeliverToCd() {
		return orderLnDeliverToCd;
	}
	public void setOrderLnDeliverToCd(String orderLnDeliverToCd) {
		this.orderLnDeliverToCd = orderLnDeliverToCd;
	}
	public String getOrderLnDeliverTo1() {
		return orderLnDeliverTo1;
	}
	public void setOrderLnDeliverTo1(String orderLnDeliverTo1) {
		this.orderLnDeliverTo1 = orderLnDeliverTo1;
	}
	public String getOrderLnDeliverTo2() {
		return orderLnDeliverTo2;
	}
	public void setOrderLnDeliverTo2(String orderLnDeliverTo2) {
		this.orderLnDeliverTo2 = orderLnDeliverTo2;
	}
	public String getOrderLnDeliverTo3() {
		return orderLnDeliverTo3;
	}
	public void setOrderLnDeliverTo3(String orderLnDeliverTo3) {
		this.orderLnDeliverTo3 = orderLnDeliverTo3;
	}
	public String getOrderLnDeliverTo4() {
		return orderLnDeliverTo4;
	}
	public void setOrderLnDeliverTo4(String orderLnDeliverTo4) {
		this.orderLnDeliverTo4 = orderLnDeliverTo4;
	}
	public String getOrderLnDeliverTo5() {
		return orderLnDeliverTo5;
	}
	public void setOrderLnDeliverTo5(String orderLnDeliverTo5) {
		this.orderLnDeliverTo5 = orderLnDeliverTo5;
	}
	public String getOrderLnPriority() {
		return orderLnPriority;
	}
	public void setOrderLnPriority(String orderLnPriority) {
		this.orderLnPriority = orderLnPriority;
	}
	public String getOrderLnStatus() {
		return orderLnStatus;
	}
	public void setOrderLnStatus(String orderLnStatus) {
		this.orderLnStatus = orderLnStatus;
	}
	public String getOrderLnCancelAllowed() {
		return orderLnCancelAllowed;
	}
	public void setOrderLnCancelAllowed(String orderLnCancelAllowed) {
		this.orderLnCancelAllowed = orderLnCancelAllowed;
	}
	public String getOrderLnType() {
		return orderLnType;
	}
	public void setOrderLnType(String orderLnType) {
		this.orderLnType = orderLnType;
	}
	public String getOraLineNumber() {
		return oraLineNumber;
	}
	public void setOraLineNumber(String oraLineNumber) {
		this.oraLineNumber = oraLineNumber;
	}
	public String getOraShipNumber() {
		return oraShipNumber;
	}
	public void setOraShipNumber(String oraShipNumber) {
		this.oraShipNumber = oraShipNumber;
	}
	public String getOraCmpNumber() {
		return oraCmpNumber;
	}
	public void setOraCmpNumber(String oraCmpNumber) {
		this.oraCmpNumber = oraCmpNumber;
	}

	public String getOrderLnshipAddressID() {
		return orderLnshipAddressID;
	}
	public void setOrderLnshipAddressID(String orderLnshipAddressID) {
		this.orderLnshipAddressID = orderLnshipAddressID;
	}
	public String getOrderLndeliverAddressID() {
		return orderLndeliverAddressID;
	}
	public void setOrderLndeliverAddressID(String orderLndeliverAddressID) {
		this.orderLndeliverAddressID = orderLndeliverAddressID;
	}
	public String getOraOrderNumber() {
		return OraOrderNumber;
	}
	public void setOraOrderNumber(String oraOrderNumber) {
		OraOrderNumber = oraOrderNumber;
	}
	public String getPaymentTerms() {
		return paymentTerms;
	}
	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}
	public String getWarehouse() {
		return warehouse;
	}
	public void setWarehouse(String warehouse) {
		this.warehouse = warehouse;
	}
	public String getSalesRep() {
		return salesRep;
	}
	public void setSalesRep(String salesRep) {
		this.salesRep = salesRep;
	}
	public String getShipIns() {
		return shipIns;
	}
	public void setShipIns(String shipIns) {
		this.shipIns = shipIns;
	}
	public String getPackIns() {
		return packIns;
	}
	public void setPackIns(String packIns) {
		this.packIns = packIns;
	}
	public String getFreightTerms() {
		return freightTerms;
	}
	public void setFreightTerms(String freightTerms) {
		this.freightTerms = freightTerms;
	}
	public String getShipSet() {
		return shipSet;
	}
	public void setShipSet(String shipSet) {
		this.shipSet = shipSet;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public String getOrderLnInvoice() {
		return orderLnInvoice;
	}
	public void setOrderLnInvoice(String orderLnInvoice) {
		this.orderLnInvoice = orderLnInvoice;
	}
	public String getOrderLnAWB() {
		return orderLnAWB;
	}
	public void setOrderLnAWB(String orderLnAWB) {
		this.orderLnAWB = orderLnAWB;
	}
}
