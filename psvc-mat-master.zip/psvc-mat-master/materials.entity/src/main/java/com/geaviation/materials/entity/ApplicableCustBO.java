package com.geaviation.materials.entity;
import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
"inventoryItemId",
"custCode",
"supplierCode",
"custId",
"upq",
"priceListId"
})

public class ApplicableCustBO {
	@JsonProperty("inventoryItemId")
	private String inventoryItemId ;
	@JsonProperty("custCode")
	private String custCode ;
	@JsonProperty("supplierCode")
	private String supplierCode;
	@JsonProperty("custId")
	private String custId;
	@JsonProperty("upq")
	private String upq  ;
	@JsonProperty("pricingListId")
	private String pricingListId;
	@JsonProperty("inventoryItemId")
	public String getInventoryItemId() {
		return inventoryItemId;
	}
	@JsonProperty("inventoryItemId")
	public void setInventoryItemId(String inventoryItemId) {
		this.inventoryItemId = inventoryItemId;
	}
	@JsonProperty("upq")
	public String getUpq() {
		return upq;
	}
	@JsonProperty("upq")
	public void setUpq(String upq) {
		this.upq = upq;
	}
	@JsonProperty("pricingListId")
	public String getPricingListId() {
		return pricingListId;
	}
	@JsonProperty("pricingListId")
	public void setPricingListId(String pricingListId) {
		this.pricingListId = pricingListId;
	}
	@JsonProperty("custCode")
	public String getCustCode() {
		return custCode;
	}
	@JsonProperty("custCode")
	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	@JsonProperty("supplierCode")
	public String getSupplierCode() {
		return supplierCode;
	}
	@JsonProperty("supplierCode")
	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}
	@JsonProperty("custId")
	public String getCustId() {
		return custId;
	}
	@JsonProperty("custId")
	public void setCustId(String custId) {
		this.custId = custId;
	}

}
