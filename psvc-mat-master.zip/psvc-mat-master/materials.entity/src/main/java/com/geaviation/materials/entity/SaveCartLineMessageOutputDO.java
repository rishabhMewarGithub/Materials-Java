/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Jun 26, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     SaveCartLineMessageDO.java
 * 
 * History        :  	Jun 26, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;


/**
 * @author 720053
 *
 */
public class SaveCartLineMessageOutputDO {
	private String  cartHeaderId;
	private String  cartLineId;
	private String  statusMessage;	
	private String esnValidFlag;
	private String esnStatusMsg;
	
	public String getCartHeaderId() {
		return cartHeaderId;
	}
	public void setCartHeaderId(String cartHeaderId) {
		this.cartHeaderId = cartHeaderId;
	}
	public String getCartLineId() {
		return cartLineId;
	}
	public void setCartLineId(String cartLineId) {
		this.cartLineId = cartLineId;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	
	
	public String getEsnValidFlag() {
		return esnValidFlag;
	}
	public void setEsnValidFlag(String esnValidFlag) {
		this.esnValidFlag = esnValidFlag;
	}
	public String getEsnStatusMsg() {
		return esnStatusMsg;
	}
	public void setEsnStatusMsg(String esnStatusMsg) {
		this.esnStatusMsg = esnStatusMsg;
	}
	
}
