/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Sep 25, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     DisputeOrderStatusBO.java
 * 
 * History        :  	Sep 25, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author 720053
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
public class DisputeOrderStatusBO {
	private String disputeOrderNumber;
	private String disputeMessage;
	private String scrapOrReturn;
	private boolean disputeFlag;
	private String originalPONumber;
	private String originalPOLineNumber;
	private String orderValue;
	private String pMessage;
	private String statusMessage;
	private String disputeOrderHeaderId;
	private String disputeType;
	private String discrepancyReason;
	private String comments;
	private List<DocumentDownloadBO> downloadDocumentBOList;

	
	public String getDisputeOrderNumber() {
		return disputeOrderNumber;
	}

	public void setDisputeOrderNumber(String disputeOrderNumber) {
		this.disputeOrderNumber = disputeOrderNumber;
	}

	public boolean isDisputeFlag() {
		return disputeFlag;
	}

	public void setDisputeFlag(boolean disputeFlag) {
		this.disputeFlag = disputeFlag;
	}
	
	@JsonIgnore
	public String getScrapOrReturn() {
		return scrapOrReturn;
	}

	public void setScrapOrReturn(String scrapOrReturn) {
		this.scrapOrReturn = scrapOrReturn;
	}

	public String getOriginalPONumber() {
		return originalPONumber;
	}

	public void setOriginalPONumber(String originalPONumber) {
		this.originalPONumber = originalPONumber;
	}

	public String getOriginalPOLineNumber() {
		return originalPOLineNumber;
	}

	public void setOriginalPOLineNumber(String originalPOLineNumber) {
		this.originalPOLineNumber = originalPOLineNumber;
	}

	public String getOrderValue() {
		return orderValue;
	}

	public void setOrderValue(String orderValue) {
		this.orderValue = orderValue;
	}
	
	@JsonIgnore
	public String getpMessage() {
		return pMessage;
	}

	public void setpMessage(String pMessage) {
		this.pMessage = pMessage;
	}

	public String getDisputeMessage() {
		return disputeMessage;
	}
	
	public void setDisputeMessage(String disputeMessage) {
		this.disputeMessage = disputeMessage;
	}
	@JsonIgnore
	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	@JsonIgnore
	public String getDisputeOrderHeaderId() {
		return disputeOrderHeaderId;
	}

	public void setDisputeOrderHeaderId(String disputeOrderHeaderId) {
		this.disputeOrderHeaderId = disputeOrderHeaderId;
	}
	
	public String getDiscrepancyReason() {
		return discrepancyReason;
	}

	public void setDiscrepancyReason(String discrepancyReason) {
		this.discrepancyReason = discrepancyReason;
	}

	public String getDisputeType() {
		return disputeType;
	}

	public void setDisputeType(String disputeType) {
		this.disputeType = disputeType;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	@JsonProperty("DocumentDownloadBO")
	public List<DocumentDownloadBO> getDownloadDocumentBOList() {
		return downloadDocumentBOList;
	}

	public void setDownloadDocumentBOList(
			List<DocumentDownloadBO> downloadDocumentBOList) {
		this.downloadDocumentBOList = downloadDocumentBOList;
	}

	
}
