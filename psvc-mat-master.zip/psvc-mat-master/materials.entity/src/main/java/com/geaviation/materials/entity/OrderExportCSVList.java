package com.geaviation.materials.entity;

public class OrderExportCSVList {
	
	
	private String custId;
	private String purchaseOrder;
	private String customerLineNumber;
	private String partNumber;
	private String requestedQty;
	private String orderStatus;
	private String orderedDate;
	private String deliveryDate;
	private String requestDate;
	private String shipmentDate;
	private String cancelledQty;
	private String shippedQty;
	private String sellingPrice;
	private String listPrice;
	private String extendedPrice;
	private String invoicedQuantity;
	private String msNumber;
	private String engineFamily;
	private String engineModel;
	private String awbNumber;
	private String orderLineType;
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getPurchaseOrder() {
		return purchaseOrder;
	}
	public void setPurchaseOrder(String purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}
	public String getCustomerLineNumber() {
		return customerLineNumber;
	}
	public void setCustomerLineNumber(String customerLineNumber) {
		this.customerLineNumber = customerLineNumber;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getRequestedQty() {
		return requestedQty;
	}
	public void setRequestedQty(String requestedQty) {
		this.requestedQty = requestedQty;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getOrderedDate() {
		return orderedDate;
	}
	public void setOrderedDate(String orderedDate) {
		this.orderedDate = orderedDate;
	}
	public String getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}
	public String getShipmentDate() {
		return shipmentDate;
	}
	public void setShipmentDate(String shipmentDate) {
		this.shipmentDate = shipmentDate;
	}
	public String getCancelledQty() {
		return cancelledQty;
	}
	public void setCancelledQty(String cancelledQty) {
		this.cancelledQty = cancelledQty;
	}
	public String getShippedQty() {
		return shippedQty;
	}
	public void setShippedQty(String shippedQty) {
		this.shippedQty = shippedQty;
	}
	public String getSellingPrice() {
		return sellingPrice;
	}
	public void setSellingPrice(String sellingPrice) {
		this.sellingPrice = sellingPrice;
	}
	public String getListPrice() {
		return listPrice;
	}
	public void setListPrice(String listPrice) {
		this.listPrice = listPrice;
	}
	public String getExtendedPrice() {
		return extendedPrice;
	}
	public void setExtendedPrice(String extendedPrice) {
		this.extendedPrice = extendedPrice;
	}
	public String getInvoicedQuantity() {
		return invoicedQuantity;
	}
	public void setInvoicedQuantity(String invoicedQuantity) {
		this.invoicedQuantity = invoicedQuantity;
	}
	public String getMsNumber() {
		return msNumber;
	}
	public void setMsNumber(String msNumber) {
		this.msNumber = msNumber;
	}
	public String getEngineFamily() {
		return engineFamily;
	}
	public void setEngineFamily(String engineFamily) {
		this.engineFamily = engineFamily;
	}
	public String getEngineModel() {
		return engineModel;
	}
	public void setEngineModel(String engineModel) {
		this.engineModel = engineModel;
	}
	public String getAwbNumber() {
		return awbNumber;
	}
	public void setAwbNumber(String awbNumber) {
		this.awbNumber = awbNumber;
	}
	public String getOrderLineType() {
		return orderLineType;
	}
	public void setOrderLineType(String orderLineType) {
		this.orderLineType = orderLineType;
	}
	

	
	
}
