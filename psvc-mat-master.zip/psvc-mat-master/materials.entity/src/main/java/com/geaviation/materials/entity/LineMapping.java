package com.geaviation.materials.entity;

import java.util.HashMap;
import java.util.Map;


public class LineMapping {

	@SuppressWarnings("rawtypes")
	Map columnNameMap=null;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map getColumnNameMap() {
		columnNameMap=new HashMap();
		columnNameMap.put("LINE_ID","lineId");
		columnNameMap.put("ORG_ID","organisationId");
		columnNameMap.put("HEADER_ID","headerId");
		columnNameMap.put("LINE_NUMBER","lineNumber");
		columnNameMap.put("ORDERED_ITEM","orderedItem");
		columnNameMap.put("REQUEST_DATE","requestDate");
		columnNameMap.put("PROMISE_DATE","promiseDate");
		columnNameMap.put("SCHEDULE_ARRIVAL_DATE","scheduleArrivalDate");
		columnNameMap.put("SCHEDULE_SHIP_DATE","scheduleShipDate");
		columnNameMap.put("ORDER_QUANTITY_UOM","orderQuantityUnitOfMeasure");
		columnNameMap.put("CANCELLED_QUANTITY","canceledQuantity");
		columnNameMap.put("SHIPPED_QUANTITY","shippedQuantity");
		columnNameMap.put("ORDERED_QUANTITY","orderedQuantity");
		columnNameMap.put("FULFILLED_QUANTITY","fulfilledQuantity");
		columnNameMap.put("SHIPPING_QUANTITY","shippingQuantity");
		columnNameMap.put("TAX_EXEMPT_FLAG","taxExemptFlag");
		columnNameMap.put("TAX_EXEMPT_NUMBER","taxExemptNumber");
		columnNameMap.put("TAX_EXEMPT_REASON_CODE","taxExemptReasonCode");
		columnNameMap.put("CUST_PO_NUMBER","custPONumber");
		columnNameMap.put("SOLD_TO_ORG_ID","soldToOrgId");
		columnNameMap.put("SHIP_FROM_ORG_ID","shipFromOrgId");
		columnNameMap.put("SHIP_TO_ORG_ID","shipToOrgId");
		columnNameMap.put("DELIVER_TO_ORG_ID","deliverToOrgId");
		columnNameMap.put("INVOICE_TO_ORG_ID","invoiceToOrgId");
		columnNameMap.put("INVENTORY_ITEM_ID","inventoryItemId");
		columnNameMap.put("TAX_CODE","taxCode");
		columnNameMap.put("TAX_RATE","taxRate");
		columnNameMap.put("SCHEDULE_STATUS_CODE","scheduleStatusCode");
		columnNameMap.put("PRICE_LIST_ID","priceListId");
		columnNameMap.put("PRICING_DATE","pricingDate");
		columnNameMap.put("SHIPMENT_NUMBER","shipmentNumber");
		columnNameMap.put("SHIPMENT_PRIORITY_CODE","shipmentPriorityCode");
		columnNameMap.put("SHIPPING_METHOD","shippingMethod");
		columnNameMap.put("FREIGHT_TERMS_CODE","freightTermsCode");
		columnNameMap.put("FREIGHT_CARRIER_CODE","freightCarrierCode");
		columnNameMap.put("FOB_POINT","fobPoint");
		columnNameMap.put("PAYMENT_TERM_ID","paymentTermId");
		columnNameMap.put("RETURN_CONTEXT","returnContext");
		columnNameMap.put("COUNTRY_OF_ORIGIN","countryOfOrigin");
		columnNameMap.put("RETURN_ATTRIBUTE1","returnAttribute1");
		columnNameMap.put("RETURN_ATTRIBUTE2","returnAttribute2");
		columnNameMap.put("UNIT_SELLING_PRICE","unitSellingPrice");
		columnNameMap.put("UNIT_LIST_PRICE","unitListPrice");
		columnNameMap.put("EXT_PRICE","externalPrice");
		columnNameMap.put("TAX_VALUE","taxValue");
		columnNameMap.put("CREATION_DATE","creationDate");
		columnNameMap.put("CREATED_BY","createdBy");
		columnNameMap.put("LAST_UPDATE_DATE","lastUpdateDate");
		columnNameMap.put("LAST_UPDATED_BY","lastUpdatedBy");
		columnNameMap.put("ITEM_TYPE_CODE","itemTypeCode");
		columnNameMap.put("COMPONENT_NUMBER","componentNumber");
		columnNameMap.put("ACTUAL_SHIPMENT_DATE","actualShipmentDate");
		columnNameMap.put("LINE_TYPE","lineType");
		columnNameMap.put("PRICE_LIST","priceList");
		columnNameMap.put("PAYMENT_TERM","paymentTerm");
		columnNameMap.put("SOLD_TO","soldTo");
		columnNameMap.put("CUSTOMER_NUMBER","customerNumber");
		columnNameMap.put("SHIP_FROM","shipFrom");
		columnNameMap.put("SHIP_TO_LOCATION","shipToLocation");
		columnNameMap.put("SHIP_TO_ADDRESS1","shipToAddress1");
		columnNameMap.put("SHIP_TO_ADDRESS2","shipToAddress2");
		columnNameMap.put("SHIP_TO_ADDRESS3","shipToAddress3");
		columnNameMap.put("SHIP_TO_ADDRESS4","shipToAddress4");
		columnNameMap.put("SHIP_TO_ADDRESS5","shipToAddress5");
		columnNameMap.put("DELIVER_TO_LOCATION","deliverToLocation");
		columnNameMap.put("DELIVER_TO_ADDRESS1","deliverToAddress1");
		columnNameMap.put("DELIVER_TO_ADDRESS2","deliverToAddress2");
		columnNameMap.put("DELIVER_TO_ADDRESS3","deliverToAddress3");
		columnNameMap.put("DELIVER_TO_ADDRESS4","deliverToAddress4");
		columnNameMap.put("DELIVER_TO_ADDRESS5","deliverToAddress5");
		columnNameMap.put("INVOICE_TO_LOCATION","invoiceToLocation");
		columnNameMap.put("INVOICE_TO_ADDRESS1","invoiceToAddress1");
		columnNameMap.put("INVOICE_TO_ADDRESS2","invoiceToAddress2");
		columnNameMap.put("INVOICE_TO_ADDRESS3","invoiceToAddress3");
		columnNameMap.put("INVOICE_TO_ADDRESS4","invoiceToAddress4");
		columnNameMap.put("INVOICE_TO_ADDRESS5","invoiceToAddress5");
		columnNameMap.put("ORDER_NUMBER","orderNumber");
		columnNameMap.put("QUOTE_NUMBER","quoteNumber");
		columnNameMap.put("ORDER_TYPE_ID","orderTypeId");
		columnNameMap.put("ORDERED_DATE","orderedDate");
		columnNameMap.put("RETURN_REASON","returnReason");
		columnNameMap.put("SPLIT_FROM_LINE_ID","splitFromLineId");
		columnNameMap.put("SHIP_SET_ID","shipSetId");
		columnNameMap.put("PLANNING_PRIORITY","planningPriority");
		columnNameMap.put("SHIPPING_INSTRUCTIONS","shippingInstructions");
		columnNameMap.put("PACKING_INSTRUCTIONS","packingInstructions");
		columnNameMap.put("INVOICED_QUANTITY","invoicedQuantity");
		columnNameMap.put("FLOW_STATUS","flowStatus");
		columnNameMap.put("CUSTOMER_LINE_NUMBER","customerLineNumber");
		columnNameMap.put("ORIGINAL_ORDERED_ITEM","originalOrderedItem");
		columnNameMap.put("ORDER_SOURCE","orderSource");
		columnNameMap.put("KEYWORD","keyword");
		columnNameMap.put("PART_NOMEN","partNomenclature");
		columnNameMap.put("SALES_PERSON","salesPerson");
		columnNameMap.put("DELIVERY_ID","deliveryId");
		columnNameMap.put("INVOICE_NUMBER","invoiceNumber");
		columnNameMap.put("DISCOUNT_PERCENTAGE","discountPercent");
		columnNameMap.put("DISCOUNT_AMOUNT","discountAmount ");
		columnNameMap.put("INVOICE_DATE","invoiceDate");
		columnNameMap.put("INVOICE_VALUE","totalInvoiceValue");
		columnNameMap.put("ORIG_PO_FOR_RETURN","originalPOForReturn");
		columnNameMap.put("CANCEL_UPDATE_ALLOWED","cancelUpdateAllowed");
		columnNameMap.put("SHIPMENT_DISPUTE_ALLOWED","shipmentDisputeAllowed");
		columnNameMap.put("MS_NUMBER","msNumber");
		columnNameMap.put("SHIPPING_STATUS","shippingStatus");
		columnNameMap.put("SHIPMENT_QUANTITY","shipmentQuantity");
		columnNameMap.put("DIMENSIONS","dimensions");
		columnNameMap.put("GROSS_WEIGHT","grossWeight");
		columnNameMap.put("SERIAL_NUMBERS","serialNumbers");
		columnNameMap.put("LINK_TO_CARRIER","linkToCarrier");
		columnNameMap.put("RETURN_COO","returnCountryOfOrigin");
		columnNameMap.put("SHIP_TO_ADDRESS","shipToAddress");
		columnNameMap.put("DELIVER_TO_ADDRESS","deliverToAddress");
		columnNameMap.put("INVOICE_TO_ADDRESS","invoiceToAddress");
		columnNameMap.put("MYGEA_ESN","orderLineESN");
		return columnNameMap;

	}

	public void setColumnNameMap(Map columnNameMap) {
		this.columnNameMap = columnNameMap;
	}
	
}
