/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     PurchaseOrderEmailBodyBO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;


public class PurchaseOrderEmailBodyBO {
	
	private String firstName;
	
	private String lastName;
	
	private String purchaseOrderNumber;
	
	private String details;
	
	private String totalOrderValue;
	
	private String totalDiscount;
	
	private String partPricedFlag;
	
	private String shipAddress;
	
	private String deliverAddress;
	private String billToAddress;
	
	private Boolean CriticalPartMsgFlag;
	
	private String lineNumber;
	
	private String partNumber;
	
	private String statusMessage;
	
	private String requestedDate;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}

	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getTotalOrderValue() {
		return totalOrderValue;
	}

	public void setTotalOrderValue(String totalOrderValue) {
		this.totalOrderValue = totalOrderValue;
	}

	public String getTotalDiscount() {
		return totalDiscount;
	}
	
	public String getPartPricedFlag() {
		return partPricedFlag;
	}

	public void setPartPricedFlag(String partPricedFlag) {
		this.partPricedFlag = partPricedFlag;
	}

	public void setTotalDiscount(String totalDiscount) {
		this.totalDiscount = totalDiscount;
	}

	public String getShipAddress() {
		return shipAddress;
	}

	public void setShipAddress(String shipAddress) {
		this.shipAddress = shipAddress;
	}

	public String getDeliverAddress() {
		return deliverAddress;
	}

	public void setDeliverAddress(String deliverAddress) {
		this.deliverAddress = deliverAddress;
	}

	public String getBillToAddress() {
		return billToAddress;
	}

	public void setBillToAddress(String billToAddress) {
		this.billToAddress = billToAddress;
	}

	public Boolean getCriticalPartMsgFlag() {
		return CriticalPartMsgFlag;
	}
	
	public void setCriticalPartMsgFlag(Boolean criticalPartMsgFlag) {
		CriticalPartMsgFlag = criticalPartMsgFlag;
	}

	public String getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getRequestedDate() {
		return requestedDate;
	}

	public void setRequestedDate(String requestedDate) {
		this.requestedDate = requestedDate;
	}
	
	
}
