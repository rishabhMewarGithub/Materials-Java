/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Aug 7, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     LineDetailBO.java
 * 
 * History        :  	Aug 7, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.List;

/**
 * @author 720053
 *
 */
public class LineDetailBO {
	private String   displayMessage;
	private List<LineInfoBO> orderLineList;
	
	public String getDisplayMessage() {
		return displayMessage;
	}
	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}
	
	public List<LineInfoBO> getOrderLineList() {
		return orderLineList;
	}
	public void setOrderLineList(List<LineInfoBO> orderLineList) {
		this.orderLineList = orderLineList;
	}

}
