/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	May 28, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     CartCountBS.java
 * 
 * History        :  	May 28, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

/**
 * @author 720053
 *
 */
public class CartCountBS {
	
	private String itemCount;

	public String getItemCount() {
		return itemCount;
	}

	public void setItemCount(String itemCount) {
		this.itemCount = itemCount;
	}

}
