/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     ItemDtlHeaderBO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "ItemDtlHeaderBO")
public class ItemDtlHeaderBO {
	
	private int quoteHeaderId;
	private String type;
	
	public int getQuoteHeaderId() {
		return quoteHeaderId;
	}
	public void setQuoteHeaderId(int quoteHeaderId) {
		this.quoteHeaderId = quoteHeaderId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
}
