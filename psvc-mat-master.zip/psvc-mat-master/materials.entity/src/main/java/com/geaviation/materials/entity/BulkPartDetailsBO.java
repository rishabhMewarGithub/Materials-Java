package com.geaviation.materials.entity;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
	"inventoryItemId",
	"partNumber",
	"partDescription",
	"quantity",
	"unitPrice",
	"upq",
	"discountMessage",
	"discountPercent",
	"discountedPrice",
	"criticalPartMessage",
	"partAvailMsg",
	"displayMessage",
	"pricMessage",
	"leadTime",
	"Message"})
	
	
	
public class BulkPartDetailsBO {
	@JsonProperty("inventoryItemId")
	private String inventoryItemId;
	@JsonProperty("partNumber")
	private String partNumber;
	@JsonProperty("partDescription")
	private String partDescription;
	@JsonProperty("quantity")
	private String quantity;
	@JsonProperty("unitPrice")
	private String unitPrice;
	@JsonProperty("upq")
	private String upq;
	@JsonProperty("discountMessage")
	private String discountMessage = "";
	@JsonProperty("discountPercent")
	private String discountPercent;
	@JsonProperty("discountedPrice")
	private String discountedPrice;
	@JsonProperty("criticalPartMessage")
	private String criticalPartMessage = "";
	@JsonProperty("partAvailMsg")
	private String partAvailMsg = "";
	@JsonProperty("displayMessage")
	private String displayMessage = "";
	@JsonProperty("pricMessage")
	private String pricMessage= "";
	@JsonProperty("leadTime")
	private String leadTime;
	@JsonProperty("Message")
	private String Message;
	
	public String getInventoryItemId() {
		return inventoryItemId;
	}
	public void setInventoryItemId(String inventoryItemId) {
		this.inventoryItemId = inventoryItemId;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getPartDescription() {
		return partDescription;
	}
	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}
	public String getUpq() {
		return upq;
	}
	public void setUpq(String upq) {
		this.upq = upq;
	}
	public String getDiscountMessage() {
		return discountMessage;
	}
	public void setDiscountMessage(String discountMessage) {
		this.discountMessage = discountMessage;
	}
	public String getDiscountPercent() {
		return discountPercent;
	}
	public void setDiscountPercent(String discountPercent) {
		this.discountPercent = discountPercent;
	}
	public String getDiscountedPrice() {
		return discountedPrice;
	}
	public void setDiscountedPrice(String discountedPrice) {
		this.discountedPrice = discountedPrice;
	}
	public String getCriticalPartMessage() {
		return criticalPartMessage;
	}
	public void setCriticalPartMessage(String criticalPartMessage) {
		this.criticalPartMessage = criticalPartMessage;
	}
	public String getPartAvailMsg() {
		return partAvailMsg;
	}
	public void setPartAvailMsg(String partAvailMsg) {
		this.partAvailMsg = partAvailMsg;
	}
	public String getDisplayMessage() {
		return displayMessage;
	}
	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}
	public String getPricMessage() {
		return pricMessage;
	}
	public void setPricMessage(String pricMessage) {
		this.pricMessage = pricMessage;
	}
	public String getLeadTime() {
		return leadTime;
	}
	public void setLeadTime(String leadTime) {
		this.leadTime = leadTime;
	}
	public String getMessage() {
		return Message;
	}
	public void setMessage(String message) {
		Message = message;
	}
	
	

}
