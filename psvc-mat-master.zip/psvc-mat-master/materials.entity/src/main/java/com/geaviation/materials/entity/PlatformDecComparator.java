package com.geaviation.materials.entity;

import java.util.Comparator;

import com.geaviation.materials.entity.Pricing;

public class PlatformDecComparator implements Comparator<Pricing>{
	public int compare(Pricing pricingDO1, Pricing pricingDO2) {
		 boolean isStrDate0Empty = (pricingDO2.getPlatform() == null || pricingDO2.getPlatform().isEmpty());
		 boolean isStrDate1Empty = (pricingDO1.getPlatform() == null || pricingDO1.getPlatform().isEmpty());

		    if (isStrDate0Empty && isStrDate1Empty)
		        return 0;
		    // at least one of them is not empty    
		    if (isStrDate0Empty)
		        return -1;
		    if (isStrDate1Empty)
		        return 1;
		    //none of them is empty
		  return pricingDO2.getPlatform().compareTo(pricingDO1.getPlatform());
	    }
}
