package com.geaviation.materials.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "MappingAddressListBO")
public class MappingAddress {
	
	
	@XmlAttribute(name = "shipAddressCode")
	private String shipAddressCode;
	@XmlAttribute(name = "shipAddress1")
	private String shipAddress1;
	@XmlAttribute(name = "deliverAddressCode")
	private String deliverAddressCode;
	@XmlAttribute(name = "deliverAddress1")
	private String deliverAddress1;
	@XmlAttribute(name = "defaultInd")
	private String  defaultInd;
	@XmlAttribute(name = "shipAddressId")
	private String shipAddressId;
	@XmlAttribute(name = "deliverAddressId")
	private String deliverAddressId;
	@XmlAttribute(name = "custId")
	private String custId;

	public String getDefaultInd() {
		return defaultInd;
	}
	public void setDefaultInd(String defaultInd) {
		this.defaultInd = defaultInd;
	}
	public String getShipAddressCode() {
		return shipAddressCode;
	}
	public void setShipAddressCode(String shipAddressCode) {
		this.shipAddressCode = shipAddressCode;
	}
	public String getShipAddress1() {
		return shipAddress1;
	}
	public void setShipAddress1(String shipAddress1) {
		this.shipAddress1 = shipAddress1;
	}
	public String getDeliverAddressCode() {
		return deliverAddressCode;
	}
	public void setDeliverAddressCode(String deliverAddressCode) {
		this.deliverAddressCode = deliverAddressCode;
	}
	public String getDeliverAddress1() {
		return deliverAddress1;
	}
	public void setDeliverAddress1(String deliverAddress1) {
		this.deliverAddress1 = deliverAddress1;
	}
	
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getShipAddressId() {
		return shipAddressId;
	}
	public void setShipAddressId(String shipAddressId) {
		this.shipAddressId = shipAddressId;
	}
	public String getDeliverAddressId() {
		return deliverAddressId;
	}
	public void setDeliverAddressId(String deliverAddressId) {
		this.deliverAddressId = deliverAddressId;
	}
	
}
