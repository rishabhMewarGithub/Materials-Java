/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     UpdateOrderOutputDO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

public class UpdateOrderOutputDO {

	
	private String headerId;
	
	private String lineId;
	
	private String success;
	
	private String statusMessage;
	private String esnValidFlag;
	private String esnStatusMsg;

	public String getHeaderId() {
		return headerId;
	}

	public void setHeaderId(String headerId) {
		this.headerId = headerId;
	}

	public String getLineId() {
		return lineId;
	}

	public void setLineId(String lineId) {
		this.lineId = lineId;
	}

	
	public String getSuccess() {
		return success;
	}

	public void setSuccess(String success) {
		this.success = success;
	}

	/*public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}*/

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getEsnValidFlag() {
		return esnValidFlag;
	}

	public void setEsnValidFlag(String esnValidFlag) {
		this.esnValidFlag = esnValidFlag;
	}

	public String getEsnStatusMsg() {
		return esnStatusMsg;
	}

	public void setEsnStatusMsg(String esnStatusMsg) {
		this.esnStatusMsg = esnStatusMsg;
	}		
	
}
