
package com.geaviation.materials.entity;

import javax.annotation.Generated;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;


/**
* Properties correspond to datatable column mData names
* 
*/
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
"platform",
"effDt",
"pdfLink",
"excelLink",
"revisionDate"
})
public class Pricing {

/**
* 
* (Required)
* 
*/
@JsonProperty("platform")
private String platform;
/**
* 
* (Required)
* 
*/
@JsonProperty("effDt")
private String effDt;
/**
* 
* (Required)
* 
*/
@JsonProperty("pdfLink")
private String pdfLink;
/**
* 
* (Required)
* 
*/
@JsonProperty("excelLink")
private String excelLink;

@JsonProperty("revisionDate")
private String revisionDate;

/**
* 
* (Required)
* 
*/
@JsonProperty("platform")
public String getPlatform() {
return platform;
}

/**
* 
* (Required)
* 
*/
@JsonProperty("platform")
public void setPlatform(String platform) {
this.platform = platform;
}

/**
* 
* (Required)
* 
*/
@JsonProperty("effDt")
public String getEffDate() {
return effDt;
}

/**
* 
* (Required)
* 
*/
@JsonProperty("effDt")
public void setEffDate(String effDt) {
this.effDt = effDt;
}

/**
* 
* (Required)
* 
*/
@JsonProperty("pdfLink")
public String getPdfLink() {
return pdfLink;
}

/**
* 
* (Required)
* 
*/
@JsonProperty("pdfLink")
public void setPdfLink(String pdfLink) {
this.pdfLink = pdfLink;
}

/**
* 
* (Required)
* 
*/
@JsonProperty("excelLink")
public String getExcelLink() {
return excelLink;
}

/**
* 
* (Required)
* 
*/
@JsonProperty("excelLink")
public void setExcelLink(String excelLink) {
this.excelLink = excelLink;
}
@JsonProperty("revisionDate")
public String getRevisionDate() {
	return revisionDate;
}

public void setRevisionDate(String revisionDate) {
	this.revisionDate = revisionDate;
}


}

