/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     RepairCatalogBO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({"engineModel","pdfCatalogLink","excelCatalogLink","revisionDate","effectiveDate"})
public class RepairCatalogBO {
	@JsonProperty("engineModel")
	private String engineModel = "";
	@JsonProperty("excelCatalogLink")
	private String excelCatalogLink = "";
	@JsonProperty("revisionDate")
	private String revisionDate="";
	@JsonProperty("effectiveDate")
		private String effectiveDate = "";
	@JsonProperty("pdfCatalogLink")
	private String pdfCatalogLink = "";
	public String getEngineModel() {
		return engineModel;
	}
	public void setEngineModel(String engineModel) {
		this.engineModel = engineModel;
	}
	
	public String getRevisionDate() {
		return revisionDate;
	}
	public void setRevisionDate(String revisionDate) {
		this.revisionDate = revisionDate;
	}
	public String getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getPdfCatalogLink() {
		return pdfCatalogLink;
	}
	public void setPdfCatalogLink(String pdfCatalogLink) {
		this.pdfCatalogLink = pdfCatalogLink;
	}
	public String getExcelCatalogLink() {
		return excelCatalogLink;
	}
	public void setExcelCatalogLink(String excelCatalogLink) {
		this.excelCatalogLink = excelCatalogLink;
	}
	
	
	
}
