/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Aug 11, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     LineInfoBO.java
 * 
 * History        :  	Aug 11, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.Arrays;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 * @author 720053
 * 
 */
@Generated("org.jsonschema2pojo")
public class LineInfoBO extends AdditionalLineInfo {
	private final String DATE_TIME_FORMAT_STRING = "DateTime";
	// line_id
	private String lineId;
	// org_id
	private String organisationId;
	// header_id
	private String headerId;
	// line_number
	private String lineNumber;
	// ordered_item
	private String orderedItem;
	// request_date
	private String requestDate;
	// promise_date
	private String promiseDate;
	// schedule_arrival_date
	private String scheduleArrivalDate;
	// schedule_ship_date
	private String scheduleShipDate;
	// order_quantity_uom
	private String orderQuantityUnitOfMeasure;

	// cancelled_quantity
	private String canceledQuantity;
	// shipped_quantity
	private String shippedQuantity;
	// ordered_quantity
	private String orderedQuantity;
	// fulfilled_quantity
	private String fulfilledQuantity;
	// shipping_quantity
	private String shippingQuantity;
	// tax_exempt_flag
	private String taxExemptFlag;
	// tax_exempt_number
	private String taxExemptNumber;
	// tax_exempt_reason_code
	private String taxExemptReasonCode;
	// cust_po_number
	private String custPONumber;
	// sold_to_org_id
	private String soldToOrgId;

	// ship_from_org_id
	private String shipFromOrgId;
	// ship_to_org_id
	private String shipToOrgId;
	// deliver_to_org_id
	private String deliverToOrgId;
	// invoice_to_org_id
	private String invoiceToOrgId;
	// inventory_item_id
	private String inventoryItemId;
	// tax_code
	private String taxCode;
	// tax_rate
	private String taxRate;
	// schedule_status_code
	private String scheduleStatusCode;
	// price_list_id
	private String priceListId;
	// pricing_date
	private String pricingDate;

	// shipment_number
	private String shipmentNumber;
	// shipment_priority_code
	private String shipmentPriorityCode;
	// shipping_method
	private String shippingMethod;
	// freight_terms_code
	private String freightTermsCode;
	// freight_carrier_code
	private String freightCarrierCode;
	// fob_point
	private String fobPoint;
	// payment_term_id
	private String paymentTermId;
	// return_context
	private String returnContext;
	// country_of_origin
	private String[] countryOfOrigin;
	// return_attribute1
	private String returnAttribute1;

	// return_attribute2
	private String returnAttribute2;
	// unit_selling_price
	private String unitSellingPrice;
	// unit_list_price
	private String unitListPrice;
	// ext_price
	private String externalPrice;
	// tax_value
	private String taxValue;
	// creation_date
	private String creationDate;
	// created_by
	private String createdBy;
	// last_update_date
	private String lastUpdateDate;
	// last_updated_by
	private String lastUpdatedBy;
	// item_type_code
	private String itemTypeCode;

	// #51 component_number
	private String componentNumber;
	// #52 actual_shipment_date
	private String actualShipmentDate;
	// #53 line_type
	private String lineType;
	// #54 price_list
	private String priceList;
	// #55 payment_term
	private String paymentTerm;
	// #56 sold_to
	private String soldTo;
	// #57 customer_number
	private String customerNumber;
	// #58 ship_from
	private String shipFrom;
	// #59 ship_to_location
	private String shipToLocation;
	// #60 ship_to_address1
	private String shipToAddress1;

	// #61 ship_to_address2
	private String shipToAddress2;
	// #62 ship_to_address3
	private String shipToAddress3;
	// #63 ship_to_address4
	private String shipToAddress4;
	// #64 ship_to_address5
	private String shipToAddress5;
	// #65 deliver_to_location
	private String deliverToLocation;
	// #66 deliver_to_address1
	private String deliverToAddress1;
	// #67 deliver_to_address2
	private String deliverToAddress2;
	// #68 deliver_to_address3
	private String deliverToAddress3;
	// #69 deliver_to_address4
	private String deliverToAddress4;
	// #70 deliver_to_address5
	private String deliverToAddress5;

	// #71 invoice_to_location
	private String invoiceToLocation;
	// #72 invoice_to_address1
	private String invoiceToAddress1;
	// #73 invoice_to_address2
	private String invoiceToAddress2;
	// #74 invoice_to_address3
	private String invoiceToAddress3;
	// #75 invoice_to_address4
	private String invoiceToAddress4;
	// #76 invoice_to_address5
	private String invoiceToAddress5;
	// #77 order_number
	private String orderNumber;
	// #78 quote_number
	private String quoteNumber;
	// #79 order_type_id
	private String orderTypeId;
	// #80 ordered_date
	private String orderedDate;

	// #81 return_reason
	private String returnReason;
	// #82 split_from_line_id
	private String splitFromLineId;
	// #83 ship_set_id
	private String shipSetId;
	// #84 planning_priority
	private String planningPriority;
	// #85 shipping_instructions
	private String shippingInstructions;
	// #86 packing_instructions
	private String packingInstructions;
	// #87 invoiced_quantity
	private String invoicedQuantity;
	// #88 flow_status
	private String flowStatus;
	// #89 customer_line_number
	private String customerLineNumber;
	// #90 original_ordered_item
	private String originalOrderedItem;

	// #91 order_source
	private String orderSource;
	// #92 keyword
	private String keyword;
	// #93 part_nomen
	private String partNomenclature;
	// #94 sales_person
	private String salesPerson;
	// #95 delivery_id
	private String deliveryId;
	// #96 invoice_number
	private String invoiceNumber;
	// #97 discount_percentage
	private String discountPercent;
	// #98 discount_amount
	private String discountAmount;
	// #99 invoice_date
	private String invoiceDate;
	// #100 invoice_value
	private String totalInvoiceValue;

	// #101 orig_po_for_return
	private String originalPOForReturn;
	// #102 cancel_update_allowed
	private Boolean cancelUpdateAllowed;
	// #103 shipment_dispute_allowed
	private Boolean shipmentDisputeAllowed;
	// #104 ms_number
	private String msNumber;
	// #105 shipping_status
	private String[] shippingStatus;
	// #106 shipment_quantity
	private String shipmentQuantity;
	// #107 dimensions
	private String dimensions;
	// #108 gross_weight
	private String grossWeight;
	// 109 serial_numbers
	private String[] serialNumbers;
	// #110 link_to_carrier
	private String linkToCarrier;

	// #111 return_coo
	private String returnCountryOfOrigin;
	// #112 
	private String upq;
	// #113
	private String invoiceId;
	// #114
	private Boolean quantityUpdateAllowed;
	// #115
	private String shipToAddress;
	// #116
	private String deliverToAddress;
	// #117
	private String invoiceToAddress;
	
	private String shippingStatusStr;
	
	private String countryOfOriginStr;
	
	@JsonProperty("msNumberArray")
	private String[] msNumberArray;
	
	@JsonProperty("deliveryIdArray")
	private String[] deliveryIdArray;
	
	@JsonProperty("invoiceNumberArray")
	private String[] invoiceNumberArray;
	
	@JsonProperty("invoiceIdArray")
	private String[] invoiceIdArray;
	// Added for JIRA 8723
	private String orderLineESN;
	
	private String  proformaInvoice = "";
	private String  shippingInvoice = "";
	
	//Added for Rally US13541
	private Boolean criticalPartFlag;
	private Boolean disputeCreated;
	
	private String orderLineWorkStopDate;
	private String orderLineWorkStopQuantity;
	
	
	public String getOrderLineWorkStopDate() {
		return orderLineWorkStopDate;
	}

	public void setOrderLineWorkStopDate(String orderLineWorkStopDate) {
		this.orderLineWorkStopDate = orderLineWorkStopDate;
	}

	public String getOrderLineWorkStopQuantity() {
		return orderLineWorkStopQuantity;
	}

	public void setOrderLineWorkStopQuantity(String orderLineWorkStopQuantity) {
		this.orderLineWorkStopQuantity = orderLineWorkStopQuantity;
	}

	public Boolean getDisputeCreated() {
		return disputeCreated;
	}

	public void setDisputeCreated(Boolean disputeCreated) {
		this.disputeCreated = disputeCreated;
	}

	public String getLineId() {
		return lineId;
	}

	public void setLineId(String lineId) {
		this.lineId = lineId;
	}

	public String getOrganisationId() {
		return organisationId;
	}

	public void setOrganisationId(String organisationId) {
		this.organisationId = organisationId;
	}

	public String getHeaderId() {
		return headerId;
	}

	public void setHeaderId(String headerId) {
		this.headerId = headerId;
	}

	public String getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getOrderedItem() {
		return orderedItem;
	}

	public void setOrderedItem(String orderedItem) {
		this.orderedItem = orderedItem;
	}

	public String getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public String getPromiseDate() {
		return promiseDate;
	}

	public void setPromiseDate(String promiseDate) {
		this.promiseDate = promiseDate;
	}

	public String getScheduleArrivalDate() {
		return scheduleArrivalDate;
	}

	public void setScheduleArrivalDate(String scheduleArrivalDate) {
		this.scheduleArrivalDate = scheduleArrivalDate;
	}

	public String getScheduleShipDate() {
		return scheduleShipDate;
	}

	public void setScheduleShipDate(String scheduleShipDate) {
		this.scheduleShipDate = scheduleShipDate;
	}

	public String getOrderQuantityUnitOfMeasure() {
		return orderQuantityUnitOfMeasure;
	}

	public void setOrderQuantityUnitOfMeasure(String orderQuantityUnitOfMeasure) {
		this.orderQuantityUnitOfMeasure = orderQuantityUnitOfMeasure;
	}

	public String getCanceledQuantity() {
		return canceledQuantity;
	}

	public void setCanceledQuantity(String canceledQuantity) {
		this.canceledQuantity = canceledQuantity;
	}

	public String getShippedQuantity() {
		return shippedQuantity;
	}

	public void setShippedQuantity(String shippedQuantity) {
		this.shippedQuantity = shippedQuantity;
	}

	public String getOrderedQuantity() {
		return orderedQuantity;
	}

	public void setOrderedQuantity(String orderedQuantity) {
		this.orderedQuantity = orderedQuantity;
	}

	public String getFulfilledQuantity() {
		return fulfilledQuantity;
	}

	public void setFulfilledQuantity(String fulfilledQuantity) {
		this.fulfilledQuantity = fulfilledQuantity;
	}

	public String getShippingQuantity() {
		return shippingQuantity;
	}

	public void setShippingQuantity(String shippingQuantity) {
		this.shippingQuantity = shippingQuantity;
	}

	public String getTaxExemptFlag() {
		return taxExemptFlag;
	}

	public void setTaxExemptFlag(String taxExemptFlag) {
		this.taxExemptFlag = taxExemptFlag;
	}

	public String getTaxExemptNumber() {
		return taxExemptNumber;
	}

	public void setTaxExemptNumber(String taxExemptNumber) {
		this.taxExemptNumber = taxExemptNumber;
	}

	public String getTaxExemptReasonCode() {
		return taxExemptReasonCode;
	}

	public void setTaxExemptReasonCode(String taxExemptReasonCode) {
		this.taxExemptReasonCode = taxExemptReasonCode;
	}

	public String getCustPONumber() {
		return custPONumber;
	}

	public void setCustPONumber(String custPONumber) {
		this.custPONumber = custPONumber;
	}

	public String getSoldToOrgId() {
		return soldToOrgId;
	}

	public void setSoldToOrgId(String soldToOrgId) {
		this.soldToOrgId = soldToOrgId;
	}

	public String getShipFromOrgId() {
		return shipFromOrgId;
	}

	public void setShipFromOrgId(String shipFromOrgId) {
		this.shipFromOrgId = shipFromOrgId;
	}

	public String getShipToOrgId() {
		return shipToOrgId;
	}

	public void setShipToOrgId(String shipToOrgId) {
		this.shipToOrgId = shipToOrgId;
	}

	public String getDeliverToOrgId() {
		return deliverToOrgId;
	}

	public void setDeliverToOrgId(String deliverToOrgId) {
		this.deliverToOrgId = deliverToOrgId;
	}

	public String getInvoiceToOrgId() {
		return invoiceToOrgId;
	}

	public void setInvoiceToOrgId(String invoiceToOrgId) {
		this.invoiceToOrgId = invoiceToOrgId;
	}

	public String getInventoryItemId() {
		return inventoryItemId;
	}

	public void setInventoryItemId(String inventoryItemId) {
		this.inventoryItemId = inventoryItemId;
	}

	public String getTaxCode() {
		return taxCode;
	}

	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}

	public String getTaxRate() {
		return taxRate;
	}

	public void setTaxRate(String taxRate) {
		this.taxRate = taxRate;
	}

	public String getScheduleStatusCode() {
		return scheduleStatusCode;
	}

	public void setScheduleStatusCode(String scheduleStatusCode) {
		this.scheduleStatusCode = scheduleStatusCode;
	}

	public String getPriceListId() {
		return priceListId;
	}

	public void setPriceListId(String priceListId) {
		this.priceListId = priceListId;
	}

	public String getPricingDate() {
		return pricingDate;
	}

	public void setPricingDate(String pricingDate) {
		this.pricingDate = pricingDate;
	}

	public String getShipmentNumber() {
		return shipmentNumber;
	}

	public void setShipmentNumber(String shipmentNumber) {
		this.shipmentNumber = shipmentNumber;
	}

	public String getShipmentPriorityCode() {
		return shipmentPriorityCode;
	}

	public void setShipmentPriorityCode(String shipmentPriorityCode) {
		this.shipmentPriorityCode = shipmentPriorityCode;
	}

	public String getShippingMethod() {
		return shippingMethod;
	}

	public void setShippingMethod(String shippingMethod) {
		this.shippingMethod = shippingMethod;
	}

	public String getFreightTermsCode() {
		return freightTermsCode;
	}

	public void setFreightTermsCode(String freightTermsCode) {
		this.freightTermsCode = freightTermsCode;
	}

	public String getFreightCarrierCode() {
		return freightCarrierCode;
	}

	public void setFreightCarrierCode(String freightCarrierCode) {
		this.freightCarrierCode = freightCarrierCode;
	}

	public String getFobPoint() {
		return fobPoint;
	}

	public void setFobPoint(String fobPoint) {
		this.fobPoint = fobPoint;
	}

	public String getPaymentTermId() {
		return paymentTermId;
	}

	public void setPaymentTermId(String paymentTermId) {
		this.paymentTermId = paymentTermId;
	}

	public String getReturnContext() {
		return returnContext;
	}

	public void setReturnContext(String returnContext) {
		this.returnContext = returnContext;
	}

	public String[] getCountryOfOrigin() {
		return countryOfOrigin;
	}

	public void setCountryOfOrigin(String[] countryOfOriginNew) {
		if (null != countryOfOriginNew && countryOfOriginNew.length > 0) {
			this.countryOfOrigin = countryOfOriginNew;
		}
	}

	public String getReturnAttribute1() {
		return returnAttribute1;
	}

	public void setReturnAttribute1(String returnAttribute1) {
		this.returnAttribute1 = returnAttribute1;
	}

	public String getReturnAttribute2() {
		return returnAttribute2;
	}

	public void setReturnAttribute2(String returnAttribute2) {
		this.returnAttribute2 = returnAttribute2;
	}

	public String getUnitSellingPrice() {
		return unitSellingPrice;
	}

	public void setUnitSellingPrice(String unitSellingPrice) {
		this.unitSellingPrice = unitSellingPrice;
	}

	public String getUnitListPrice() {
		return unitListPrice;
	}

	public void setUnitListPrice(String unitListPrice) {
		this.unitListPrice = unitListPrice;
	}

	public String getExternalPrice() {
		return externalPrice;
	}

	public void setExternalPrice(String externalPrice) {
		this.externalPrice = externalPrice;
	}

	public String getTaxValue() {
		return taxValue;
	}

	public void setTaxValue(String taxValue) {
		this.taxValue = taxValue;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getItemTypeCode() {
		return itemTypeCode;
	}

	public void setItemTypeCode(String itemTypeCode) {
		this.itemTypeCode = itemTypeCode;
	}

	public String getComponentNumber() {
		return componentNumber;
	}

	public void setComponentNumber(String componentNumber) {
		this.componentNumber = componentNumber;
	}

	public String getActualShipmentDate() {
		return actualShipmentDate;
	}

	public void setActualShipmentDate(String actualShipmentDate) {
		this.actualShipmentDate = actualShipmentDate;
	}

	public String getLineType() {
		return lineType;
	}

	public void setLineType(String lineType) {
		this.lineType = lineType;
	}

	public String getPriceList() {
		return priceList;
	}

	public void setPriceList(String priceList) {
		this.priceList = priceList;
	}

	public String getPaymentTerm() {
		return paymentTerm;
	}

	public void setPaymentTerm(String paymentTerm) {
		this.paymentTerm = paymentTerm;
	}

	public String getSoldTo() {
		return soldTo;
	}

	public void setSoldTo(String soldTo) {
		this.soldTo = soldTo;
	}

	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	public String getShipFrom() {
		return shipFrom;
	}

	public void setShipFrom(String shipFrom) {
		this.shipFrom = shipFrom;
	}

	public String getShipToLocation() {
		return shipToLocation;
	}

	public void setShipToLocation(String shipToLocation) {
		this.shipToLocation = shipToLocation;
	}

	public String getShipToAddress1() {
		return shipToAddress1;
	}

	public void setShipToAddress1(String shipToAddress1) {
		this.shipToAddress1 = shipToAddress1;
	}

	public String getShipToAddress2() {
		return shipToAddress2;
	}

	public void setShipToAddress2(String shipToAddress2) {
		this.shipToAddress2 = shipToAddress2;
	}

	public String getShipToAddress3() {
		return shipToAddress3;
	}

	public void setShipToAddress3(String shipToAddress3) {
		this.shipToAddress3 = shipToAddress3;
	}

	public String getShipToAddress4() {
		return shipToAddress4;
	}

	public void setShipToAddress4(String shipToAddress4) {
		this.shipToAddress4 = shipToAddress4;
	}

	public String getShipToAddress5() {
		return shipToAddress5;
	}

	public void setShipToAddress5(String shipToAddress5) {
		this.shipToAddress5 = shipToAddress5;
	}

	public String getDeliverToLocation() {
		return deliverToLocation;
	}

	public void setDeliverToLocation(String deliverToLocation) {
		this.deliverToLocation = deliverToLocation;
	}

	public String getDeliverToAddress1() {
		return deliverToAddress1;
	}

	public void setDeliverToAddress1(String deliverToAddress1) {
		this.deliverToAddress1 = deliverToAddress1;
	}

	public String getDeliverToAddress2() {
		return deliverToAddress2;
	}

	public void setDeliverToAddress2(String deliverToAddress2) {
		this.deliverToAddress2 = deliverToAddress2;
	}

	public String getDeliverToAddress3() {
		return deliverToAddress3;
	}

	public void setDeliverToAddress3(String deliverToAddress3) {
		this.deliverToAddress3 = deliverToAddress3;
	}

	public String getDeliverToAddress4() {
		return deliverToAddress4;
	}

	public void setDeliverToAddress4(String deliverToAddress4) {
		this.deliverToAddress4 = deliverToAddress4;
	}

	public String getDeliverToAddress5() {
		return deliverToAddress5;
	}

	public void setDeliverToAddress5(String deliverToAddress5) {
		this.deliverToAddress5 = deliverToAddress5;
	}

	public String getInvoiceToLocation() {
		return invoiceToLocation;
	}

	public void setInvoiceToLocation(String invoiceToLocation) {
		this.invoiceToLocation = invoiceToLocation;
	}

	public String getInvoiceToAddress1() {
		return invoiceToAddress1;
	}

	public void setInvoiceToAddress1(String invoiceToAddress1) {
		this.invoiceToAddress1 = invoiceToAddress1;
	}

	public String getInvoiceToAddress2() {
		return invoiceToAddress2;
	}

	public void setInvoiceToAddress2(String invoiceToAddress2) {
		this.invoiceToAddress2 = invoiceToAddress2;
	}

	public String getInvoiceToAddress3() {
		return invoiceToAddress3;
	}

	public void setInvoiceToAddress3(String invoiceToAddress3) {
		this.invoiceToAddress3 = invoiceToAddress3;
	}

	public String getInvoiceToAddress4() {
		return invoiceToAddress4;
	}

	public void setInvoiceToAddress4(String invoiceToAddress4) {
		this.invoiceToAddress4 = invoiceToAddress4;
	}

	public String getInvoiceToAddress5() {
		return invoiceToAddress5;
	}

	public void setInvoiceToAddress5(String invoiceToAddress5) {
		this.invoiceToAddress5 = invoiceToAddress5;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getQuoteNumber() {
		return quoteNumber;
	}

	public void setQuoteNumber(String quoteNumber) {
		this.quoteNumber = quoteNumber;
	}

	public String getOrderTypeId() {
		return orderTypeId;
	}

	public void setOrderTypeId(String orderTypeId) {
		this.orderTypeId = orderTypeId;
	}

	public String getOrderedDate() {
		return orderedDate;
	}

	public void setOrderedDate(String orderedDate) {
		this.orderedDate = orderedDate;
	}

	public String getReturnReason() {
		return returnReason;
	}

	public void setReturnReason(String returnReason) {
		this.returnReason = returnReason;
	}

	public String getSplitFromLineId() {
		return splitFromLineId;
	}

	public void setSplitFromLineId(String splitFromLineId) {
		this.splitFromLineId = splitFromLineId;
	}

	public String getShipSetId() {
		return shipSetId;
	}

	public void setShipSetId(String shipSetId) {
		this.shipSetId = shipSetId;
	}

	public String getPlanningPriority() {
		return planningPriority;
	}

	public void setPlanningPriority(String planningPriority) {
		this.planningPriority = planningPriority;
	}

	public String getShippingInstructions() {
		return shippingInstructions;
	}

	public void setShippingInstructions(String shippingInstructions) {
		this.shippingInstructions = shippingInstructions;
	}

	public String getPackingInstructions() {
		return packingInstructions;
	}

	public void setPackingInstructions(String packingInstructions) {
		this.packingInstructions = packingInstructions;
	}

	public String getInvoicedQuantity() {
		return invoicedQuantity;
	}

	public void setInvoicedQuantity(String invoicedQuantity) {
		this.invoicedQuantity = invoicedQuantity;
	}

	public String getFlowStatus() {
		return flowStatus;
	}

	public void setFlowStatus(String flowStatus) {
		this.flowStatus = flowStatus;
	}

	public String getCustomerLineNumber() {
		return customerLineNumber;
	}

	public void setCustomerLineNumber(String customerLineNumber) {
		this.customerLineNumber = customerLineNumber;
	}

	public String getOriginalOrderedItem() {
		return originalOrderedItem;
	}

	public void setOriginalOrderedItem(String originalOrderedItem) {
		this.originalOrderedItem = originalOrderedItem;
	}

	public String getOrderSource() {
		return orderSource;
	}

	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getPartNomenclature() {
		return partNomenclature;
	}

	public void setPartNomenclature(String partNomenclature) {
		this.partNomenclature = partNomenclature;
	}

	public String getSalesPerson() {
		return salesPerson;
	}

	public void setSalesPerson(String salesPerson) {
		this.salesPerson = salesPerson;
	}

	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getDiscountPercent() {
		return discountPercent;
	}

	public void setDiscountPercent(String discountPercent) {
		this.discountPercent = discountPercent;
	}

	public String getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(String discountAmount) {
		this.discountAmount = discountAmount;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getTotalInvoiceValue() {
		return totalInvoiceValue;
	}

	public void setTotalInvoiceValue(String totalInvoiceValue) {
		this.totalInvoiceValue = totalInvoiceValue;
	}

	public String getOriginalPOForReturn() {
		return originalPOForReturn;
	}

	public void setOriginalPOForReturn(String originalPOForReturn) {
		this.originalPOForReturn = originalPOForReturn;
	}

	public Boolean getCancelUpdateAllowed() {
		return cancelUpdateAllowed;
	}

	public void setCancelUpdateAllowed(Boolean cancelUpdateAllowed) {
		this.cancelUpdateAllowed = cancelUpdateAllowed;
	}

	public Boolean getShipmentDisputeAllowed() {
		return shipmentDisputeAllowed;
	}

	public void setShipmentDisputeAllowed(Boolean shipmentDisputeAllowed) {
		this.shipmentDisputeAllowed = shipmentDisputeAllowed;
	}

	public String getMsNumber() {
		return msNumber;
	}

	public void setMsNumber(String msNumber) {
		this.msNumber = msNumber;
	}

	public String[] getShippingStatus() {
		return shippingStatus;
	}

	public void setShippingStatus(String[] shippingStatusNew) {
		if (null != shippingStatusNew && shippingStatusNew.length > 0) {
			this.shippingStatus = shippingStatusNew;
		}
	}

	public String getShipmentQuantity() {
		return shipmentQuantity;
	}

	public void setShipmentQuantity(String shipmentQuantity) {
		this.shipmentQuantity = shipmentQuantity;
	}

	public String getDimensions() {
		return dimensions;
	}

	public void setDimensions(String dimensions) {
		this.dimensions = dimensions;
	}

	public String getGrossWeight() {
		return grossWeight;
	}

	public void setGrossWeight(String grossWeight) {
		this.grossWeight = grossWeight;
	}

	public String[] getSerialNumbers() {
		return serialNumbers;
	}

	public void setSerialNumbers(String[] serialNumbersNew) {
		if (serialNumbersNew == null) {
			this.serialNumbers = new String[0];
		} else {
			this.serialNumbers = Arrays.copyOf(serialNumbersNew, serialNumbersNew.length);
		}
	}

	public String getLinkToCarrier() {
		return linkToCarrier;
	}

	public void setLinkToCarrier(String linkToCarrier) {
		this.linkToCarrier = linkToCarrier;
	}

	public String getReturnCountryOfOrigin() {
		return returnCountryOfOrigin;
	}

	public void setReturnCountryOfOrigin(String returnCountryOfOrigin) {
		this.returnCountryOfOrigin = returnCountryOfOrigin;
	}
	
	public String getUpq() {
		return upq;
	}

	public void setUpq(String upq) {
		this.upq = upq;
	}
	public String getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}

	public Boolean getQuantityUpdateAllowed() {
		return quantityUpdateAllowed;
	}

	public void setQuantityUpdateAllowed(Boolean quantityUpdateAllowed) {
		this.quantityUpdateAllowed = quantityUpdateAllowed;
	}

	public String getShipToAddress() {
		return shipToAddress;
	}

	public void setShipToAddress(String shipToAddress) {
		this.shipToAddress = shipToAddress;
	}

	public String getDeliverToAddress() {
		return deliverToAddress;
	}

	public void setDeliverToAddress(String deliverToAddress) {
		this.deliverToAddress = deliverToAddress;
	}

	public String getInvoiceToAddress() {
		return invoiceToAddress;
	}

	public void setInvoiceToAddress(String invoiceToAddress) {
		this.invoiceToAddress = invoiceToAddress;
	}
	@JsonIgnore
	public String getCountryOfOriginStr() {
		return countryOfOriginStr;
	}

	public void setCountryOfOriginStr(String countryOfOriginStr) {
		this.countryOfOriginStr = countryOfOriginStr;
	}
	@JsonIgnore
	public String getShippingStatusStr() {
		return shippingStatusStr;
	}

	public void setShippingStatusStr(String shippingStatusStr) {
		this.shippingStatusStr = shippingStatusStr;
	}
	
	//for sorting
	public String formatRequestDate() {
		return DATE_TIME_FORMAT_STRING;
	}
	public String formatPromiseDate() {
		return DATE_TIME_FORMAT_STRING;
	}
	public String formatScheduleArrivalDate() {
		return DATE_TIME_FORMAT_STRING;
	}
	public String formatScheduleShipDate() {
		return DATE_TIME_FORMAT_STRING;
	}
	public String formatPricingDate() {
		return DATE_TIME_FORMAT_STRING;
	}
	public String formatCreationDate() {
		return DATE_TIME_FORMAT_STRING;
	}
	public String formatLastUpdateDate() {
		return DATE_TIME_FORMAT_STRING;
	}
	public String formatActualShipmentDate() {
		return DATE_TIME_FORMAT_STRING;
	}
	public String formatOrderedDate() {
		return DATE_TIME_FORMAT_STRING;
	}
	public String formatInvoiceDate() {
		return DATE_TIME_FORMAT_STRING;
	}

	public String[] getMsNumberArray() {
		return msNumberArray;
	}
	
	public void setMsNumberArray(String[] msNumberArray) {
		if (null != msNumberArray && msNumberArray.length > 0) {
			this.msNumberArray = msNumberArray;
		}
	}

	public String[] getDeliveryIdArray() {
		return deliveryIdArray;
	}

	public void setDeliveryIdArray(String[] deliveryIdArray) {
		if (null != deliveryIdArray && deliveryIdArray.length > 0) {
			this.deliveryIdArray = deliveryIdArray;
		}
	}

	public String[] getInvoiceNumberArray() {
		return invoiceNumberArray;
	}

	public void setInvoiceNumberArray(String[] invoiceNumberArray) {
		if (null != invoiceNumberArray && invoiceNumberArray.length > 0) {
			this.invoiceNumberArray = invoiceNumberArray;
		}
	}
	
	public String[] getInvoiceIdArray() {
		return invoiceIdArray;
	}
	
	public void setInvoiceIdArray(String[] invoiceIdArray) {
		if (null != invoiceIdArray && invoiceIdArray.length > 0) {
			this.invoiceIdArray = invoiceIdArray;
		}
	}
	public String getOrderLineESN() {
		return orderLineESN;
	}

	public void setOrderLineESN(String orderLineESN) {
		this.orderLineESN = orderLineESN;
	}	
	
	public String getProformaInvoice() {
		return proformaInvoice;
	}

	public void setProformaInvoice(String proformaInvoice) {
		this.proformaInvoice = proformaInvoice;
	}

	public String getShippingInvoice() {
		return shippingInvoice;
	}

	public void setShippingInvoice(String shippingInvoice) {
		this.shippingInvoice = shippingInvoice;
	}

	public Boolean getCriticalPartFlag() {
		return criticalPartFlag;
	}
	
	public void setCriticalPartFlag(Boolean criticalPartFlag) {
		this.criticalPartFlag = criticalPartFlag;
	}
	
}
