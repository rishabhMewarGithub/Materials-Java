/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Aug 18, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     MaterialsSortField.java
 * 
 * History        :  	Aug 18, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.io.Serializable;

/**
 * @author 720053
 *
 */
public class MaterialsSortField implements Serializable{
	
	private String fieldName;

	private String sortOrder;

	public MaterialsSortField(String fieldName, String sortOrder) {
		this.fieldName = fieldName;
		this.sortOrder = sortOrder;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

}
