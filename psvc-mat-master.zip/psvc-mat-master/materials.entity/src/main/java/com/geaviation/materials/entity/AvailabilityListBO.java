package com.geaviation.materials.entity;
import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
"inventoryItemId",
"quantity",
"location"
})
public class AvailabilityListBO {

/**
* 
* (Required)
* 
*/
@JsonProperty("quantity")
private String quantity;
/**
* 
* (Required)
* 
*/
@JsonProperty("location")
private String location;

@JsonProperty("inventoryItemId")
private String inventoryItemId ;

@JsonProperty("inventoryItemId")
public String getinventoryItemId() {
	return inventoryItemId;
}
@JsonProperty("inventoryItemId")
public void setinventoryItemId(String inventoryItemId) {
	this.inventoryItemId = inventoryItemId;
}
public String getInventoryItemId() {
	return inventoryItemId;
}
public void setInventoryItemId(String inventoryItemId) {
	this.inventoryItemId = inventoryItemId;
}
@JsonProperty("location")
public String getLocation() {
return location;
}
@JsonProperty("quantity")
public String getQuantity() {
	return quantity;
}
@JsonProperty("quantity")
public void setQuantity(String quantity) {
	this.quantity = quantity;
}
/**
* 
* (Required)
* 
*/
@JsonProperty("location")
public void setLocation(String location) {
this.location = location;
}

}