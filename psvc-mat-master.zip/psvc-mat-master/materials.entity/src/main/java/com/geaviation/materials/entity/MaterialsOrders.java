/*******************************************************************
 * Project        :     Repair : CWC Services 
 * Date		      :    	October 13, 2015  	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     RepairOrders.java
 * 
 * History        :  	October 13, 2015                
   Date                           
 *******************************************************************/
package com.geaviation.materials.entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author 717826
 *
 */


@JsonPropertyOrder(value = {"customerNumber","purchaseOrderNumber","customerLineNumber","partNumber","requestedQty","orderStatus","orderedDate","awbNumber","cancelledQty","deliveryDate",
		"engineFamily","engineModel","extendedPrice","invoicedQuantity","listPrice","msNumber","requestDate","sellingPrice","shipmentDate","shippedQty","invoiceNumber"})
public class MaterialsOrders implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String customerNumber;
	private String purchaseOrderNumber;
	
	private String customerLineNumber;
	private String partNumber;
	private String requestedQty;
	private String orderStatus;
	private String orderedDate;
	private String awbNumber;
	private String cancelledQty;
	private String deliveryDate;
	private String engineFamily;
	private String engineModel;
	private String extendedPrice;
	private String invoicedQuantity;
	private String listPrice;
	private String msNumber;
	private String requestDate;
	private String sellingPrice;
	private String shipmentDate;
	private String shippedQty;
	private String invoiceNumber;
	private String orderLineType;
	
	@JsonProperty("Customer Number")
	public String getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	@JsonProperty("Purchase Order")
	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}
	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}
	
	@JsonProperty("Invoice Number")
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	@JsonProperty("Line Number")
	public String getCustomerLineNumber() {
		return customerLineNumber;
	}
	public void setCustomerLineNumber(String customerLineNumber) {
		this.customerLineNumber = customerLineNumber;
	}
	@JsonProperty("Part Number")
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
    @JsonProperty("Requested Quantity")
	public String getRequestedQty() {
		return requestedQty;
	}
	public void setRequestedQty(String requestedQty) {
		this.requestedQty = requestedQty;
	}
	@JsonProperty("Status")
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	@JsonProperty("Ordered Date")
	public String getOrderedDate() {
		return orderedDate;
	}
	public void setOrderedDate(String orderedDate) {
		this.orderedDate = orderedDate;
	}
	
	@JsonProperty("Delivery Date")
	public String getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	@JsonProperty("Request Date")
	public String getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}
	@JsonProperty("Shipment Date")
	public String getShipmentDate() {
		return shipmentDate;
	}
	public void setShipmentDate(String shipmentDate) {
		this.shipmentDate = shipmentDate;
	}
	@JsonProperty("Cancelled Quantity")
	public String getCancelledQty() {
		return cancelledQty;
	}
	public void setCancelledQty(String cancelledQty) {
		this.cancelledQty = cancelledQty;
	}
	@JsonProperty("Shipped Quantity")
	public String getShippedQty() {
		return shippedQty;
	}
	public void setShippedQty(String shippedQty) {
		this.shippedQty = shippedQty;
	}
	@JsonProperty("Selling Price")
	public String getSellingPrice() {
		return sellingPrice;
	}
	public void setSellingPrice(String sellingPrice) {
		this.sellingPrice = sellingPrice;
	}
	@JsonProperty("List Price")
	public String getListPrice() {
		return listPrice;
	}
	public void setListPrice(String listPrice) {
		this.listPrice = listPrice;
	}
	@JsonProperty("Extended Price")
	public String getExtendedPrice() {
		return extendedPrice;
	}
	public void setExtendedPrice(String extendedPrice) {
		this.extendedPrice = extendedPrice;
	}
	@JsonProperty("Invoiced Quantity")
	public String getInvoicedQuantity() {
		return invoicedQuantity;
	}
	public void setInvoicedQuantity(String invoicedQuantity) {
		this.invoicedQuantity = invoicedQuantity;
	}
	@JsonProperty("MS Number")
	public String getMsNumber() {
		return msNumber;
	}
	public void setMsNumber(String msNumber) {
		this.msNumber = msNumber;
	}
	@JsonProperty("Engine Family")
	public String getEngineFamily() {
		return engineFamily;
	}
	public void setEngineFamily(String engineFamily) {
		this.engineFamily = engineFamily;
	}
	@JsonProperty("Engine Model")
	public String getEngineModel() {
		return engineModel;
	}
	public void setEngineModel(String engineModel) {
		this.engineModel = engineModel;
	}
	@JsonProperty("AWB Number")
	public String getAwbNumber() {
		return awbNumber;
	}
	public void setAwbNumber(String awbNumber) {
		this.awbNumber = awbNumber;
	}
	@JsonIgnore
	public String getOrderLineType() {
		return orderLineType;
	}
	public void setOrderLineType(String orderLineType) {
		this.orderLineType = orderLineType;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}
