/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Jun 26, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     SaveCartOrderLineDO.java
 * 
 * History        :  	Jun 26, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.sql.Date;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

/**
 * @author 720053
 *
 */
public class SaveCartOrderLineInputDO implements SQLData {
	
	/*QUOTE_HEADER_ID 				NUMBER,
    QUOTE_LINE_ID 					NUMBER,
    CUST_PO_LINE_NUMBER             VARCHAR2(500),
    QTY 							NUMBER,
    ORDER_LINE_PRIORITY 			VARCHAR2(50),
    ORDER_LINE_REQUESTED_DATE       DATE*/
	
	private int quote_header_id;
	private int quote_line_id;
	private String cust_po_line_number;
	private String qty;
	private String order_line_priority;
	private Date order_line_requested_date;
	private String sqlType = "APPS.V_QUOTE_LINE_DTL";
	private String mygea_esn;
	private Date workstp_date;
	private int workstp_qty;
	
	public SaveCartOrderLineInputDO(int quote_header_id,int quote_line_id,String cust_po_line_number,String qty,String order_line_priority,Date order_line_requested_date,String mygea_esn, Date workstp_date, int workstp_qty){
		this.quote_header_id = quote_header_id;
		this.quote_line_id = quote_line_id;
		this.cust_po_line_number = cust_po_line_number;
		this.qty = qty;
		this.order_line_priority = order_line_priority;
		this.order_line_requested_date = order_line_requested_date;
		this.mygea_esn = mygea_esn;
		this.workstp_date = workstp_date;
		this.workstp_qty = workstp_qty;
	}
	
	
	/* (non-Javadoc)
	 * @see java.sql.SQLData#getSQLTypeName()
	 */
	@Override
	public String getSQLTypeName() throws SQLException {
		return sqlType;
	}

	/* (non-Javadoc)
	 * @see java.sql.SQLData#readSQL(java.sql.SQLInput, java.lang.String)
	 */
	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		sqlType = typeName;
		quote_header_id = stream.readInt();
		quote_line_id = stream.readInt();
		cust_po_line_number = stream.readString();
		qty = stream.readString();
		order_line_priority = stream.readString();
		order_line_requested_date = stream.readDate();
		mygea_esn = stream.readString();
		workstp_date = stream.readDate();
		workstp_qty = stream.readInt();
	}

	/* (non-Javadoc)
	 * @see java.sql.SQLData#writeSQL(java.sql.SQLOutput)
	 */
	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		stream.writeInt(quote_header_id);
	    stream.writeInt(quote_line_id);
	    stream.writeString(cust_po_line_number);
	    stream.writeString(qty);
	    stream.writeString(order_line_priority);
	    stream.writeDate(order_line_requested_date);
	    stream.writeString(mygea_esn);
	    stream.writeDate(workstp_date);
	    stream.writeInt(workstp_qty);
	}
	
}
