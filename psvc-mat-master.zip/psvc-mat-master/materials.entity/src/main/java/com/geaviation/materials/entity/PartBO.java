package com.geaviation.materials.entity;

import java.sql.Date;

public class PartBO {
	
	private String poNumber;
	private String lineNumber;
	private String partNumber ;
	private int quantity ;
	private Date requestedDate ;
	private String priority ;
	private String customerCode;
	private int rowNumber;
	private int customerAccountId;
	private int inventoryItemId;
	private String supplierCode;
	private int priceListId;
	private int quoteHeaderId;
	private int quoteLineId;
	private String statusMessage;
	private String orderLineESN;
	private Date orderLineWorkStopDate;
	private int orderLineWorkStopQuantity;
	
	

	public Date getOrderLineWorkStopDate() {
		return orderLineWorkStopDate;
	}
	public void setOrderLineWorkStopDate(Date orderLineWorkStopDate) {
		this.orderLineWorkStopDate = orderLineWorkStopDate;
	}
	public int getOrderLineWorkStopQuantity() {
		return orderLineWorkStopQuantity;
	}
	public void setOrderLineWorkStopQuantity(int orderLineWorkStopQuantity) {
		this.orderLineWorkStopQuantity = orderLineWorkStopQuantity;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public int getRowNumber() {
		return rowNumber;
	}
	public void setRowNumber(int rowNumber) {
		this.rowNumber = rowNumber;
	}
	public int getCustomerAccountId() {
		return customerAccountId;
	}
	public void setCustomerAccountId(int customerAccountId) {
		this.customerAccountId = customerAccountId;
	}
	public int getInventoryItemId() {
		return inventoryItemId;
	}
	public void setInventoryItemId(int inventoryItemId) {
		this.inventoryItemId = inventoryItemId;
	}
	public String getSupplierCode() {
		return supplierCode;
	}
	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}
	public int getPriceListId() {
		return priceListId;
	}
	public void setPriceListId(int priceListId) {
		this.priceListId = priceListId;
	}
	public int getQuoteHeaderId() {
		return quoteHeaderId;
	}
	public void setQuoteHeaderId(int quoteHeaderId) {
		this.quoteHeaderId = quoteHeaderId;
	}
	public int getQuoteLineId() {
		return quoteLineId;
	}
	public void setQuoteLineId(int quoteLineId) {
		this.quoteLineId = quoteLineId;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	
	public String getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Date getRequestedDate() {
		return requestedDate;
	}
	public void setRequestedDate(Date requestedDate) {
		this.requestedDate = requestedDate;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}	
	public String getOrderLineESN() {
		return orderLineESN;
	}
	public void setOrderLineESN(String orderLineESN) {
		this.orderLineESN = orderLineESN;
	}	
	
}
