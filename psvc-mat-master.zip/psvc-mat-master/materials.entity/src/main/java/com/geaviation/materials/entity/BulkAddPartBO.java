/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     BulkAddPartBO.java
 * 
 * History        :  	May 19, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

public class BulkAddPartBO {
	private String partNumber ;
	private String quantity ;
	private String customerCode;
	
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

}
