package com.geaviation.materials.entity;
import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
"currency",
"inventoryItemId",
"unitPrice",
"upq",
"leadTime",
"catalog",
"custCode",
"custId"
})
public class PricingListBO {

/**
* 
* (Required)
* 
*/
	
@JsonProperty("currency")
private String currency = "";

@JsonProperty("custCode")
private String custCode = "";

@JsonProperty("custId")
private String custId = "";
	
@JsonProperty("unitPrice")
private String unitPrice;
/**
* 
* (Required)
* 
*/
@JsonProperty("upq")
private String upq;
/**
* 
* (Required)
* 
*/
@JsonProperty("leadTime")
private String leadTime;
/**
* 
* (Required)
* 
*/
@JsonProperty("catalog")
private String catalog;

@JsonProperty("inventoryItemId")
private String inventoryItemId ;
@JsonProperty("inventoryItemId")
public String getInventoryItemId() {
	return inventoryItemId;
}
@JsonProperty("inventoryItemId")
public void setInventoryItemId(String inventoryItemId) {
	this.inventoryItemId = inventoryItemId;
}
@JsonProperty("unitPrice")
public String getUnitPrice() {
	return unitPrice;
}
@JsonProperty("unitPrice")
public void setUnitPrice(String unitPrice) {
	this.unitPrice = unitPrice;
}
@JsonProperty("upq")
public String getUpq() {
	return upq;
}
@JsonProperty("upq")
public void setUpq(String upq) {
	this.upq = upq;
}
/**
* 
* (Required)
* 
*/
@JsonProperty("leadTime")
public String getLeadTime() {
return leadTime;
}

/**
* 
* (Required)
* 
*/
@JsonProperty("leadTime")
public void setLeadTime(String leadTime) {
this.leadTime = leadTime;
}

/**
* 
* (Required)
* 
*/
@JsonProperty("catalog")
public String getCatalog() {
return catalog;
}

/**
* 
* (Required)
* 
*/
@JsonProperty("catalog")
public void setCatalog(String catalog) {
this.catalog = catalog;
}

@JsonProperty("currency")
public String getCurrency() {
	return currency;
}

@JsonProperty("currency")
public void setCurrency(String currency) {
	this.currency = currency;
}

@JsonProperty("custCode")
public String getCustCode() {
	return custCode;
}

@JsonProperty("custCode")
public void setCustCode(String custCode) {
	this.custCode = custCode;
}

@JsonProperty("custId")
public String getCustId() {
	return custId;
}

@JsonProperty("custId")
public void setCustId(String custId) {
	this.custId = custId;
}


}