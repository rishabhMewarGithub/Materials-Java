package com.geaviation.materials.entity;

import java.util.List;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({"displayMessage","orderHeaderInfoBO","columnGroupBO","MYGEAGroupBO","columnList","priorityBO"})
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class OrderHeaderDetails {
	
	private String displayMessage;
	
	@JsonProperty("OrderHeaderInfoBO")
	private OrderHeaderInfoBO orderHeaderInfoBO;
	
	@JsonProperty("ColumnGroupBO")
	private List<ColumnGroupBO> columnGroupBO;
	
	@JsonProperty("ColumnBO")
	private List<ColumnBO> columnList;
	
	private List<PriorityBO> priorityBO;
	
	@JsonProperty("MYGEAGroupBO")
	private List<MYGEAGroupBO> colMYGEAGrp;
	//Added for Snecma
	@JsonProperty("CommercialAgreementList")
	private List<CommercialAgreementList> commercialAgreementList;
		
	public List<MYGEAGroupBO> getColMYGEAGrp() {
		return colMYGEAGrp;
	}
	public void setColMYGEAGrp(List<MYGEAGroupBO> columnGEAGroupList) {
		this.colMYGEAGrp = columnGEAGroupList;
	}
	
	public List<CommercialAgreementList> getCommercialAgreementList() {
		return commercialAgreementList;
	}
	public void setCommercialAgreementList(
			List<CommercialAgreementList> commercialAgreementList) {
		this.commercialAgreementList = commercialAgreementList;
	}
	//Added for Snecma
	
	public List<PriorityBO> getPriorityBO() {
		return priorityBO;
	}
	public void setPriorityBO(List<PriorityBO> priorityBO) {
		this.priorityBO = priorityBO;
	}
	public List<ColumnGroupBO> getColumnGroupBO() {
		return columnGroupBO;
	}
	public void setColumnGroupBO(List<ColumnGroupBO> columnGroupBO) {
		this.columnGroupBO = columnGroupBO;
	}
	public String getDisplayMessage() {
		return displayMessage;
	}
	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}
	public OrderHeaderInfoBO getOrderHeaderInfoBO() {
		return orderHeaderInfoBO;
	}
	public void setOrderHeaderInfoBO(OrderHeaderInfoBO orderHeaderInfoBO) {
		this.orderHeaderInfoBO = orderHeaderInfoBO;
	}
	public List<ColumnBO> getColumnList() {
		return columnList;
	}
	public void setColumnList(List<ColumnBO> columnList) {
		this.columnList = columnList;
	}
	
}
