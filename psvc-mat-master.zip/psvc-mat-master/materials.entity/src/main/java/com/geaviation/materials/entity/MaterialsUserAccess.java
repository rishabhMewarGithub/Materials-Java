/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 11, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     MaterialsUserAccess.java
 * 
 * History        :  	Mar 11, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author 720053
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "MaterialsUserAccess")
public class MaterialsUserAccess {
	
	@XmlAttribute(name = "message")
	private String message;
	
	@XmlAttribute(name = "success")
	private boolean success;
	
	@XmlAttribute(name = "ouid")
	private String ouid;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getOuid() {
		return ouid;
	}
	public void setOuid(String ouid) {
		this.ouid = ouid;
	}

}
