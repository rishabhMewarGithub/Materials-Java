/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Aug 18, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     LineDetailDO.java
 * 
 * History        :  	Aug 18, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.List;

/**
 * @author 720053
 *
 */
public class LineDetailDO {
	private String message;
	private List<LineInfoDO> lineInfoDOList;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<LineInfoDO> getLineInfoDOList() {
		return lineInfoDOList;
	}
	public void setLineInfoDOList(List<LineInfoDO> lineInfoDOList) {
		this.lineInfoDOList = lineInfoDOList;
	}
	
}
