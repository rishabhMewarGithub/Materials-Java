package com.geaviation.materials.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "CustGTAListBO")
public class CustGTAListBO {
	
	@XmlAttribute(name = "gtaNumber")
	private String gtaNumber;
	@XmlAttribute(name = "custAccounts")
	private String custAccounts;
	@XmlAttribute(name = "startDt")
	private String startDt;
	@XmlAttribute(name = "expDt")
	private String expDt;
	@XmlAttribute(name = "contractProduct")
	private String contractProduct;
	@XmlAttribute(name = "custId")
	private String custId;
	public String getGtaNumber() {
		return gtaNumber;
	}
	public void setGtaNumber(String gtaNumber) {
		this.gtaNumber = gtaNumber;
	}
	public String getCustAccounts() {
		return custAccounts;
	}
	public void setCustAccounts(String custAccounts) {
		this.custAccounts = custAccounts;
	}
	public String getStartDt() {
		return startDt;
	}
	public void setStartDt(String startDt) {
		this.startDt = startDt;
	}

	public String getExpDt() {
		return expDt;
	}
	public void setExpDt(String expDt) {
		this.expDt = expDt;
	}
	public String getContractProduct() {
		return contractProduct;
	}
	public void setContractProduct(String contractProduct) {
		this.contractProduct = contractProduct;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	
	



}
