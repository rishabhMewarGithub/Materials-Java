/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	May 28, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     SaveCartRequest.java
 * 
 * History        :  	May 28, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author 720053
 *
 */
@XmlRootElement
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
@JsonPropertyOrder({"cartHeaderId","purchaseOrderNumber","shippingMethodId","shipAddressId","deliverAddressId","orderHeaderRequestedDate","orderHeaderPriority","commercialAgreementNumber","quotationNumber","orderLineBO"})
public class SaveCartRequestDetails {
	
	@JsonProperty("cartHeaderId")
	private String cartHeaderId;
	
	@JsonProperty("purchaseOrderNumber")
	private String purchaseOrderNumber;
	
	@JsonProperty("shipAddressId")
	private String shipAddressId;
	
	@JsonProperty("deliverAddressId")
	private String deliverAddressId;
	
	@JsonProperty("orderHeaderRequestedDate")
	private String orderHeaderRequestedDate;
	
	@JsonProperty("orderHeaderPriority")
	private String orderHeaderPriority;
	
	@JsonProperty("shippingMethodId")
	private String shippingMethodId;
	
	@JsonProperty("quotationNumber")
	private String quotationNumber;
	@JsonProperty("commercialAgreementNumber")
	private String commercialAgreementNumber;
	
	@XmlElement
	@JsonProperty("OrderLineBO")
	private List<SaveCartOrderLineBO> orderLineBO;
	
	public String getCommercialAgreementNumber() {
		return commercialAgreementNumber;
	}

	public void setCommercialAgreementNumber(String commercialAgreementNumber) {
		this.commercialAgreementNumber = commercialAgreementNumber;
	}

	public String getShippingMethodId() {
		return shippingMethodId;
	}

	public void setShippingMethodId(String shippingMethodId) {
		this.shippingMethodId = shippingMethodId;
	}


	public String getQuotationNumber() {
		return quotationNumber;
	}

	public void setQuotationNumber(String quotationNumber) {
		this.quotationNumber = quotationNumber;
	}

	public String getCartHeaderId() {
		return cartHeaderId;
	}

	public void setCartHeaderId(String cartHeaderId) {
		this.cartHeaderId = cartHeaderId;
	}

	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}

	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}

	public String getShipAddressId() {
		return shipAddressId;
	}

	public void setShipAddressId(String shipAddressId) {
		this.shipAddressId = shipAddressId;
	}

	public String getDeliverAddressId() {
		return deliverAddressId;
	}

	public void setDeliverAddressId(String deliverAddressId) {
		this.deliverAddressId = deliverAddressId;
	}

	public String getOrderHeaderRequestedDate() {
		return orderHeaderRequestedDate;
	}

	public void setOrderHeaderRequestedDate(String orderHeaderRequestedDate) {
		this.orderHeaderRequestedDate = orderHeaderRequestedDate;
	}

	public String getOrderHeaderPriority() {
		return orderHeaderPriority;
	}

	public void setOrderHeaderPriority(String orderHeaderPriority) {
		this.orderHeaderPriority = orderHeaderPriority;
	}
	
	public List<SaveCartOrderLineBO> getOrderLineBO() {
		return orderLineBO;
	}

	public void setOrderLineBO(List<SaveCartOrderLineBO> orderLineBO) {
		this.orderLineBO = orderLineBO;
	}
	
}
