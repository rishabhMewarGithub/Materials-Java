package com.geaviation.materials.entity;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

@XmlRootElement(name = "DeleteWishListBO")
@JsonPropertyOrder({"message"})
public class DeleteWishListBO {

	@JsonProperty("message")
	private String message;
	@JsonProperty("partNumber")
	private String partNumber;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	
}
