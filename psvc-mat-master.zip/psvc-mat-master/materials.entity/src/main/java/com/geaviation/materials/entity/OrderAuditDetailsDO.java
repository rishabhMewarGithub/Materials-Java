/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    May 20 ,2016   
 * Created By	  :		717826	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     May 20 ,2016   
 * Description    :     OrderAuditDetailsDO.java
 * 
 * History        :  	May 20 ,2016                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.List;

/**
 * @author 717826
 *
 */
public class OrderAuditDetailsDO {
	private String message;
	private String error_status;
	private List<OrderAuditDO> OrderAuditDOList;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<OrderAuditDO> getOrderAuditDOList() {
		return OrderAuditDOList;
	}
	public void setOrderAuditDOList(List<OrderAuditDO> orderAuditDOList) {
		OrderAuditDOList = orderAuditDOList;
	}
	public String getError_status() {
		return error_status;
	}
	public void setError_status(String error_status) {
		this.error_status = error_status;
	}
	
	
}
