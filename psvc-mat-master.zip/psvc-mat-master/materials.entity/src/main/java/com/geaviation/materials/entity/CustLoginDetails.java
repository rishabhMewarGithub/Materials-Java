package com.geaviation.materials.entity;
public class CustLoginDetails {
	String role;
	String icaoCode;
	String operatingUnitId;
	String[] custIdList;
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getIcaoCode() {
		return icaoCode;
	}
	public void setIcaoCode(String icaoCode) {
		this.icaoCode = icaoCode;
	}
	public String getOperatingUnitId() {
		return operatingUnitId;
	}
	public void setOperatingUnitId(String operatingUnitId) {
		this.operatingUnitId = operatingUnitId;
	}
	public String[] getCustIdList() {
		return custIdList;
	}
	public void setCustIdList(String[] custIdList) {
		this.custIdList = custIdList;
	}

}
