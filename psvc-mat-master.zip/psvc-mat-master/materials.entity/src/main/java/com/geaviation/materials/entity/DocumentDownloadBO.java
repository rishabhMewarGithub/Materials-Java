/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Nov 21, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     DocumentDownloadBO.java
 * 
 * History        :  	Nov 21, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

/**
 * @author 720053
 *
 */
public class DocumentDownloadBO {
	private String linkName;
	private String url;
	public String getLinkName() {
		return linkName;
	}
	public void setLinkName(String linkName) {
		this.linkName = linkName;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	public DocumentDownloadBO(String linkName, String url) {
		this.linkName = linkName;
		this.url = url;
	}
	
	

}
