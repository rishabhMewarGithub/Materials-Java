/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Jun 26, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     SaveCartDetailsDO.java
 * 
 * History        :  	Jun 26, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.List;

/**
 * @author 720053
 *
 */
public class SaveCartDetailsOutputDO {
	
	private List<SaveCartMessageOutputDO> saveCartDOList;
	private List<SaveCartLineMessageOutputDO> saveCartOrderLineDOList;
	private String  procMessage;
	
	public List<SaveCartMessageOutputDO> getSaveCartDOList() {
		return saveCartDOList;
	}
	public void setSaveCartDOList(List<SaveCartMessageOutputDO> saveCartDOList) {
		this.saveCartDOList = saveCartDOList;
	}
	public List<SaveCartLineMessageOutputDO> getSaveCartOrderLineDOList() {
		return saveCartOrderLineDOList;
	}
	public void setSaveCartOrderLineDOList(
			List<SaveCartLineMessageOutputDO> saveCartOrderLineDOList) {
		this.saveCartOrderLineDOList = saveCartOrderLineDOList;
	}
	public String getProcMessage() {
		return procMessage;
	}
	public void setProcMessage(String procMessage) {
		this.procMessage = procMessage;
	}
	
	
	
	

}
