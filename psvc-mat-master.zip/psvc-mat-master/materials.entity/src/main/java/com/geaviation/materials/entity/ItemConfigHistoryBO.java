
package com.geaviation.materials.entity;


import java.util.List;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
public class ItemConfigHistoryBO {

	@JsonProperty("displayMessage")
	private String displayMessage = "";

	private String message;

	@JsonProperty("configHistoryList")
	private List<ConfigHistory> configHistoryList;

	public List<ConfigHistory> getConfigHistoryList() {
		return configHistoryList;
	}
	public void setConfigHistoryList(List<ConfigHistory> configHistoryList) {
		this.configHistoryList = configHistoryList;
	}
	@JsonIgnore
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	public String getDisplayMessage() {
		return displayMessage;
	}

	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}

}

