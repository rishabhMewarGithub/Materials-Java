/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 12, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     MaterialsUserBO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "MaterialsUserBO")
public class MaterialsUserBO implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@XmlAttribute(name = "role")
	private String role;
	
	@XmlAttribute(name = "sso")
	private String sso;
	
	@XmlAttribute(name = "icaoCode")
	private String icaoCode;
	
	@XmlAttribute(name = "operatingUnitId")
	private String operatingUnitId;
	
	@XmlAttribute(name = "message")
	private String message;
	
	@JsonIgnore
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@XmlElement
	private List<CustomerBO> customerBOList;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getSso() {
		return sso;
	}

	public void setSso(String sso) {
		this.sso = sso;
	}

	public String getIcaoCode() {
		return icaoCode;
	}

	public void setIcaoCode(String icaoCode) {
		this.icaoCode = icaoCode;
	}

	public String getOperatingUnitId() {
		return operatingUnitId;
	}

	public void setOperatingUnitId(String operatingUnitId) {
		this.operatingUnitId = operatingUnitId;
	}
	
	@JsonProperty("CustomerBO")
	public List<CustomerBO> getCustomerBOList() {
		return customerBOList;
	}

	public void setCustomerBOList(List<CustomerBO> customerBOList) {
		this.customerBOList = customerBOList;
	}

}
