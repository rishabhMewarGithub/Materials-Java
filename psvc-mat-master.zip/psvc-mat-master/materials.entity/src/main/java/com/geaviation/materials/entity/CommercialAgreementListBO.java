/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016   
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     CommercialAgreementListBO.java
 * 
 * History        :  	May 28, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;
import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
"commercialAgreementNumber",
"commercialAgreementName",
"remainingQuantity",
"discountPercent",
"discountedPrice",
"upq",
"leadTime",
"currency"
})
public class CommercialAgreementListBO {


@JsonProperty("commercialAgreementNumber")
private String commercialAgreementNumber = "";


@JsonProperty("commercialAgreementName")
private String commercialAgreementName = "";

@JsonProperty("remainingQuantity")
private String remainingQuantity = "";

@JsonProperty("discountPercent")
private String discountPercent = "";

@JsonProperty("upq")
private String upq = "";

@JsonProperty("leadTime")
private String leadTime = "";

@JsonProperty("currency")
private String currency = "";

@JsonProperty("commercialAgreementNumber")
public String getCommercialAgreementNumber() {
	return commercialAgreementNumber;
}

@JsonProperty("commercialAgreementNumber")
public void setCommercialAgreementNumber(String commercialAgreementNumber) {
	this.commercialAgreementNumber = commercialAgreementNumber;
}

@JsonProperty("commercialAgreementName")
public String getCommercialAgreementName() {
	return commercialAgreementName;
}

@JsonProperty("commercialAgreementName")
public void setCommercialAgreementName(String commercialAgreementName) {
	this.commercialAgreementName = commercialAgreementName;
}

@JsonProperty("remainingQuantity")
public String getRemainingQuantity() {
	return remainingQuantity;
}

@JsonProperty("remainingQuantity")
public void setRemainingQuantity(String remainingQuantity) {
	this.remainingQuantity = remainingQuantity;
}

@JsonProperty("discountPercent")
public String getDiscountPercent() {
	return discountPercent;
}

@JsonProperty("discountPercent")
public void setDiscountPercent(String discountPercent) {
	this.discountPercent = discountPercent;
}

@JsonProperty("upq")
public String getUpq() {
	return upq;
}

@JsonProperty("upq")
public void setUpq(String upq) {
	this.upq = upq;
}

@JsonProperty("leadTime")
public String getLeadTime() {
	return leadTime;
}

@JsonProperty("leadTime")
public void setLeadTime(String leadTime) {
	this.leadTime = leadTime;
}

@JsonProperty("currency")
public String getCurrency() {
	return currency;
}

@JsonProperty("currency")
public void setCurrency(String currency) {
	this.currency = currency;
}

}