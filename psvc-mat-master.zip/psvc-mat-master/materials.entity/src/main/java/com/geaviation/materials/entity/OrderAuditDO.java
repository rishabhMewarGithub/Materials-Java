/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    May 20 ,2016   
 * Created By	  :		717826	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     May 20 ,2016   
 * Description    :     OrderAuditDetailsDO.java
 * 
 * History        :  	May 20 ,2016                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;
/*
 * @author 717826
 * 
 */
public class OrderAuditDO {

	private String lineNumber;
	
	private String attrName;

	private String oldValue;

	private String newValue;

	private String changeDate;

	private String updatedBy;

	public String getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getAttrName() {
		return attrName;
	}

	public void setAttrName(String attrName) {
		this.attrName = attrName;
	}

	public String getOldValue() {
		return oldValue;
	}

	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}

	public String getNewValue() {
		return newValue;
	}

	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	public String getChangeDate() {
		return changeDate;
	}

	public void setChangeDate(String changeDate) {
		this.changeDate = changeDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	
}
