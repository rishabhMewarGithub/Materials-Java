package com.geaviation.materials.entity;

import java.util.List;


public class PurchasePODO {
	
	private List<LineMessageDO> lstLineMessageDO;
	private List<CartMessageDO> lstCartMessageDO;
	private String  p_msg;

	public List<LineMessageDO> getLstLineMessageDO() {
		return lstLineMessageDO;
	}
	public void setLstLineMessageDO(List<LineMessageDO> lstLineMessageDO) {
		this.lstLineMessageDO = lstLineMessageDO;
	}
	public String getP_msg() {
		return p_msg;
	}
	public void setP_msg(String p_msg) {
		this.p_msg = p_msg;
	}
	public List<CartMessageDO> getLstCartMessageDO() {
		return lstCartMessageDO;
	}

	public void setLstCartMessageDO(List<CartMessageDO> lstCartMessageDO) {
		this.lstCartMessageDO = lstCartMessageDO;
	}

}
