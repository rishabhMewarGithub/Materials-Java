/******************************************************** 
 * Project        :     Repair : CWC Services 
 * Date		      :    	Oct 15, 2015
 * Created By	  :		502335049	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     RepairOrderListResponse.java
 * 
 * History        :  	Oct 15, 2015               
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "MaterialsOrderListResponse")
public class OrderCFMListResponse implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	private String status;
	private List<MaterialsOrdersCFM> ordersList;
	private int totalRecords;
	
	@XmlElement(name = "status")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	@XmlElement(name = "MaterialsOrdersList")
	public List<MaterialsOrdersCFM> getOrdersList() {
		return ordersList;
	}
	public void setOrdersList(List<MaterialsOrdersCFM> ordersList) {
		this.ordersList = ordersList;
	}

	@XmlElement(name = "TotalRecords")
	public int getTotalRecords() {
		return totalRecords;
	}
	
	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}
	
	
		
}
