/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     ItemDetailHeaderInputDO.java
 * 
 * History        :  	Jun 26, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

/**
 * @author 720053
 *
 */
public class ItemDetailHeaderInputDO implements SQLData {
	
	
	
	private int quote_header_id;
	private String type;
	private String sqlType = "APPS.V_CART_HDR_BO";
	
	
	public ItemDetailHeaderInputDO(int quote_header_id,String type){
		this.quote_header_id = quote_header_id;
		this.type = type;
	}
	
	
	/* (non-Javadoc)
	 * @see java.sql.SQLData#getSQLTypeName()
	 */
	@Override
	public String getSQLTypeName() throws SQLException {
		return sqlType;
	}

	/* (non-Javadoc)
	 * @see java.sql.SQLData#readSQL(java.sql.SQLInput, java.lang.String)
	 */
	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		sqlType = typeName;
		quote_header_id = stream.readInt();
		type = stream.readString();
	}

	/* (non-Javadoc)
	 * @see java.sql.SQLData#writeSQL(java.sql.SQLOutput)
	 */
	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		stream.writeInt(quote_header_id);
	    stream.writeString(type);
	   
	}
	
}
