/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     PutCartAddItemBO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


@XmlRootElement(name = "putCartAddItem", namespace = "urn:snecma:cfm")
public class PutCartAddItemBO {
	
	private static final Log LOG = LogFactory.getLog(PutCartAddItemBO.class);
	private String inventoryItemId;
	private String selectedCustomerId;
	private String selectedSupplierCode;
	private String quantity;
	private String priceListId;
	private String commercialAgreementNumber;
	private String quotationNumber;
	private String quickOrder;
	
	public PutCartAddItemBO(){
		LOG.info("PutCartAddItemBO Constructor");
	}
	
	public PutCartAddItemBO(String inventoryItemId, String selectedCustomerId, String selectedSupplierCode, String quantity, String priceListId,
			String commercialAgreementNumber, String quotationNumber, String quickOrder) {
        this.inventoryItemId = inventoryItemId;
        this.selectedCustomerId = selectedCustomerId;
        this.selectedSupplierCode = selectedSupplierCode;
        this.quantity = quantity;
        this.priceListId = priceListId;
        this.commercialAgreementNumber = commercialAgreementNumber;
        this.quotationNumber = quotationNumber;
        this.quickOrder = quickOrder;
    }
	
	@XmlElement
	public String getInventoryItemId() {
		return inventoryItemId;
	}
	public void setInventoryItemId(String inventoryItemId) {
		this.inventoryItemId = inventoryItemId;
	}
	@XmlElement
	public String getSelectedCustomerId() {
		return selectedCustomerId;
	}
	public void setSelectedCustomerId(String selectedCustomerId) {
		this.selectedCustomerId = selectedCustomerId;
	}
	@XmlElement
	public String getSelectedSupplierCode() {
		return selectedSupplierCode;
	}
	public void setSelectedSupplierCode(String selectedSupplierCode) {
		this.selectedSupplierCode = selectedSupplierCode;
	}
	@XmlElement
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	@XmlElement
	public String getPriceListId() {
		return priceListId;
	}
	public void setPriceListId(String priceListId) {
		this.priceListId = priceListId;
	}
	@XmlElement
	public String getCommercialAgreementNumber() {
		return commercialAgreementNumber;
	}
	public void setCommercialAgreementNumber(String commercialAgreementNumber) {
		this.commercialAgreementNumber = commercialAgreementNumber;
	}
	@XmlElement
	public String getQuotationNumber() {
		return quotationNumber;
	}
	public void setQuotationNumber(String quotationNumber) {
		this.quotationNumber = quotationNumber;
	}
	@XmlElement
	public String getQuickOrder() {
		return quickOrder;
	}
	public void setQuickOrder(String quickOrder) {
		this.quickOrder = quickOrder;
	}
	
	
}
