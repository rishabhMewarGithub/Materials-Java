/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     PartsInputDO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.sql.Date;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class PartsInputDO2  implements SQLData{



	/******************************************************** 
	 * Project        :     Materials: CWC Services 
	 * Date		      :    	Jun 26, 2014  
	 * Created By	  :		720053	
	 * Security       :     GE Confidential 
	 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
	 *                      Copyright(C) 2014 GE 
	 *                      All rights reserved 
	 * Description    :     SaveCartDO.java
	 * 
	 * History        :  	Jun 26, 2014                
	   Date                           
	 **********************************************************/

	/**
	 * @author 720053
	 *
	 */
	/*                             	LINE_NUMBER VARCHAR2(50),
                                    PART_NUMBER VARCHAR2(40),
                                    QUANTITY NUMBER,
                                    REQUESTED_DATE DATE,
                                    PRIORITY VARCHAR2(30),
                                    CUSTOMER_CODE VARCHAR2(30),
                                    ROW_NUM NUMBER,
                                    CUST_ACCOUNT_ID NUMBER,
                                    INVENTORY_ITEM_ID NUMBER,
                                    SUPPLIER_CODE VARCHAR2(240),
                                    PRICE_LIST_ID NUMBER,
                                    QUOTE_HEADER_ID NUMBER,
                                    QUOTE_LINE_ID NUMBER,
                                    STS_MSG VARCHAR2(500)
*/
		
		private String line_Number;
		private String part_Number ;
		private int quantity ;
		private Date requested_Date ;
		private String priority ;
		private String customer_Code;
		private int row_Num;
		private int cust_Account_Id;
		private int inventory_Item_Id;
		private String supplier_Code;
		private int price_List_Id;
		private int quote_Header_Id;
		private int quote_Line_Id;
		private String sts_Msg;
		private String mygea_esn;

		private String sqlType = "APPS.V_BULK_CART_LINE_BO"; 
		
	
		public PartsInputDO2(String line_Number, String part_Number, int quantity,  Date requested_Date, String priority,
				String customer_Code, int row_Num, int cust_Account_Id, int inventory_Item_Id, String supplier_Code,int price_List_Id,
				int quote_Header_Id, int quote_Line_Id, String sts_Msg,String mygea_esn){
			
			this.line_Number = line_Number;
			this.part_Number = part_Number;
			this.quantity = quantity;
			this.requested_Date = requested_Date;
			this.priority =  priority;
			this.customer_Code = customer_Code;
			this.row_Num = row_Num;
			this.cust_Account_Id = cust_Account_Id;
			this.inventory_Item_Id = inventory_Item_Id;
			this.supplier_Code = supplier_Code;
			this.price_List_Id = price_List_Id;
			this.quote_Header_Id = quote_Header_Id;
			this.quote_Line_Id = quote_Line_Id;
			this.sts_Msg = sts_Msg;
			this.mygea_esn = mygea_esn;
		}
		

		/* (non-Javadoc)
		 * @see java.sql.SQLData#getSQLTypeName()
		 */
		@Override
		public String getSQLTypeName() throws SQLException {
			return sqlType;
		}

		/* (non-Javadoc)
		 * @see java.sql.SQLData#readSQL(java.sql.SQLInput, java.lang.String)
		 */
		@Override
		public void readSQL(SQLInput stream, String typeName) throws SQLException {
			sqlType = typeName;
			
			line_Number = stream.readString();
			part_Number = stream.readString();
			quantity = stream.readInt();
			requested_Date = stream.readDate();
			priority = stream.readString();
			customer_Code = stream.readString();
			row_Num = stream.readInt();
			cust_Account_Id = stream.readInt();
			inventory_Item_Id = stream.readInt();
			supplier_Code = stream.readString();
			price_List_Id = stream.readInt();
			quote_Header_Id = stream.readInt();
			quote_Line_Id = stream.readInt();
			sts_Msg = stream.readString();
			mygea_esn = stream.readString();
		}

		/* (non-Javadoc)
		 * @see java.sql.SQLData#writeSQL(java.sql.SQLOutput)
		 */
		@Override
		public void writeSQL(SQLOutput stream) throws SQLException {
			
			stream.writeString(line_Number);
		    stream.writeString(part_Number);
		    stream.writeInt(quantity);
		    stream.writeDate(requested_Date);
		    stream.writeString(priority);
		    stream.writeString(customer_Code);
		    stream.writeInt(row_Num);
		    stream.writeInt(cust_Account_Id);
		    stream.writeInt(inventory_Item_Id);
		    stream.writeString(supplier_Code);
		    stream.writeInt(price_List_Id);
		    stream.writeInt(quote_Header_Id);
		    stream.writeInt(quote_Line_Id);
		    stream.writeString(sts_Msg);
		    stream.writeString(mygea_esn);
		    
		}
		
	}



