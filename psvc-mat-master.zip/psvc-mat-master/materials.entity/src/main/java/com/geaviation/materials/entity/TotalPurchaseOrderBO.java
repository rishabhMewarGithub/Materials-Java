/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     TotalPurchaseOrderBO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonProperty;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "totalPurchaseOrderValue")
public class TotalPurchaseOrderBO {
	
	@JsonProperty("totalPurchaseOrderValue")
	private String totalPurchaseOrderValue;

	@JsonProperty("CartBO")
	private List<CartBO> cartBO = null;

	@JsonProperty("PriorityBO")
	private List<PriorityBO> priorityBO = null;

	public String getTotalPurchaseOrderValue() {
		return totalPurchaseOrderValue;
	}

	public void setTotalPurchaseOrderValue(String totalPurchaseOrderValue) {
		this.totalPurchaseOrderValue = totalPurchaseOrderValue;
	}
	
	public List<PriorityBO> getPriorityBO() {
		return priorityBO;
	}

	public void setPriorityBO(List<PriorityBO> priorityBO) {
		this.priorityBO = priorityBO;
	}

	public List<CartBO> getCartBO() {
		return cartBO;
	}

	public void setCartBO(List<CartBO> cartBO) {
		this.cartBO = cartBO;
	}
	
}
