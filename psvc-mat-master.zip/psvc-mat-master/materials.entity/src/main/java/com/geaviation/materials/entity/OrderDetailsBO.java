package com.geaviation.materials.entity;

import java.util.List;
import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlElement;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({"orderNumber","orderDt","orderStatus","custId","custCode","custName","headerId",
	"mappingAddressListBO","priorityBO"})
public class OrderDetailsBO {
	@JsonProperty("orderNumber")
	private String orderNumber;
	@JsonProperty("orderDt")
	private String orderDt;
	@JsonProperty("orderStatus")
	private String orderStatus;
	@JsonProperty("custId")
	private String custId;
	@JsonProperty("custCode")
	private String custCode;
	@JsonProperty("custName")
	private String custName;
	@JsonProperty("headerId")
	private String headerId;
	@XmlElement
	private List<PriorityBO> priorityBO;

	public String getHeaderId() {
		return headerId;
	}
	public void setHeaderId(String headerId) {
		this.headerId = headerId;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getOrderDt() {
		return orderDt;
	}
	public void setOrderDt(String orderDt) {
		this.orderDt = orderDt;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getCustCode() {
		return custCode;
	}
	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	@JsonProperty("PriorityBO")
	public List<PriorityBO> getPriorityBO() {
		return priorityBO;
	}
	public void setPriorityBO(List<PriorityBO> priorityBO) {
		this.priorityBO = priorityBO;
	}
	
	
}

