package com.geaviation.materials.entity;

public class EmailBodyBO {
	
	private String firstName;
	
	private String lastName;
	
	private String mailMessage;
	
	//Sales order number
	private String rma;
	
	private String originalPurchaseOrder;
	
	private String originalPurchaseOrderLine;
	
	private String disputeType;
	
	private String discrepancyReason;
	
	private String orderValue;
	
	private String orderType;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMailMessage() {
		return mailMessage;
	}

	public void setMailMessage(String mailMessage) {
		this.mailMessage = mailMessage;
	}

	public String getRma() {
		return rma;
	}

	public void setRma(String rma) {
		this.rma = rma;
	}

	public String getOriginalPurchaseOrder() {
		return originalPurchaseOrder;
	}

	public void setOriginalPurchaseOrder(String originalPurchaseOrder) {
		this.originalPurchaseOrder = originalPurchaseOrder;
	}

	public String getOriginalPurchaseOrderLine() {
		return originalPurchaseOrderLine;
	}

	public void setOriginalPurchaseOrderLine(String originalPurchaseOrderLine) {
		this.originalPurchaseOrderLine = originalPurchaseOrderLine;
	}

	public String getDisputeType() {
		return disputeType;
	}

	public void setDisputeType(String disputeType) {
		this.disputeType = disputeType;
	}

	public String getDiscrepancyReason() {
		return discrepancyReason;
	}

	public void setDiscrepancyReason(String discrepancyReason) {
		this.discrepancyReason = discrepancyReason;
	}

	public String getOrderValue() {
		return orderValue;
	}

	public void setOrderValue(String orderValue) {
		this.orderValue = orderValue;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
}
