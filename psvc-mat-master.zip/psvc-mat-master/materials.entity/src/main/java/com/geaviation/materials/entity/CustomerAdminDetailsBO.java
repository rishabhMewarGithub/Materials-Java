/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     CustomerAdminDetailsBO.java
 * 
 * History        :  	May 28, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;



@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"materialsUserBO","shipAddressList","deliverAddressBOList","mappingAddressList","CustAdmin","custGTAListBO"})
public class CustomerAdminDetailsBO {
	@XmlElement
	private List<ShipAddress> shipAddressList;
	@XmlElement
	private List<DeliverAddress> deliverAddressBOList;
	@XmlElement
	private List<MappingAddress> mappingAddressList;
	@XmlElement
	private List<CustAdmin> CustAdmin;
	@XmlElement
	private MaterialsUserBO materialsUserBO ;
	
	@JsonProperty("CustDetailsBO")
	public MaterialsUserBO getMaterialsUserBO() {
		return materialsUserBO;
	}

	public void setMaterialsUserBO(MaterialsUserBO materialsUserBO) {
		this.materialsUserBO = materialsUserBO;
	}
	private List<CustGTAListBO> custGTAListBO;
	
	@XmlAttribute(name = "message")
	private String message;
	@JsonIgnore
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@JsonProperty("CustGTAListBO")
	public List<CustGTAListBO> getCustGTAListBO() {
		return custGTAListBO;
	}
	public void setCustGTAListBO(List<CustGTAListBO> custGTAListBO) {
		this.custGTAListBO = custGTAListBO;
	}
	
	@JsonProperty("ShipAddressBO")
	public List<ShipAddress> getShipAddressList() {
		return shipAddressList;
	}
	public void setShipAddressList(List<ShipAddress> shipAddressList) {
		this.shipAddressList = shipAddressList;
	}
	
	@JsonProperty("DeliverAddressBO")
	public List<DeliverAddress> getDeliverAddressBOList() {
		return deliverAddressBOList;
	}
	public void setDeliverAddressBOList(List<DeliverAddress> deliverAddressBOList) {
		this.deliverAddressBOList = deliverAddressBOList;
	}
	
	@JsonProperty("MappingAddressListBO")
	public List<MappingAddress> getMappingAddressList() {
		return mappingAddressList;
	}
	public void setMappingAddressList(List<MappingAddress> mappingAddressList) {
		this.mappingAddressList = mappingAddressList;
	}
	
	@JsonProperty("CustAdminBO")
	public List<CustAdmin> getCustAdmin() {
		return CustAdmin;
	}
	
	public void setCustAdmin(List<CustAdmin> custAdmin) {
		CustAdmin = custAdmin;
	}

}
