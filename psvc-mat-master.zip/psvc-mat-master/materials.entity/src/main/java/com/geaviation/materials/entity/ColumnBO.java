package com.geaviation.materials.entity;

public class ColumnBO {

		private String columnId;
		public String getColumnId() {
			return columnId;
		}
		public void setColumnId(String columnId) {
			this.columnId = columnId;
		}
		public String getColumnName() {
			return columnName;
		}
		public void setColumnName(String columnName) {
			this.columnName = columnName;
		}
		private String columnName;

	}

