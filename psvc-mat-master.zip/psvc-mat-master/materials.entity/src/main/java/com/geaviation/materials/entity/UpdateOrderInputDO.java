/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     UpdateOrderInputDO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.sql.Date;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class UpdateOrderInputDO implements SQLData{

	private String header_id;
	private String line_id;
	private String customer_line_number;
	private String ordered_quantity;
	private String shipment_priority_code;
	private String ship_to_location_id;
	private String dlvr_to_location_id;
	private Date request_date;
	private String mygea_esn;
	private Date workstp_date;
	private int workstp_qty;

	private String sqlType = "APPS.V_ORDER_LINE_UPD_BO";
	
	

	public UpdateOrderInputDO(String header_id, String line_id,
			String customer_line_number, String ordered_quantity,
			String shipment_priority_code, String ship_to_location_id,
			String dlvr_to_location_id, Date request_date,String mygea_esn, Date workstp_date, int workstp_qty) {
	
		this.header_id = header_id;
		this.line_id = line_id;
		this.customer_line_number = customer_line_number;
		this.ordered_quantity = ordered_quantity;
		this.shipment_priority_code = shipment_priority_code;
		this.ship_to_location_id = ship_to_location_id;
		this.dlvr_to_location_id = dlvr_to_location_id;
		this.request_date = request_date;
		this.mygea_esn = mygea_esn;
		this.workstp_date = workstp_date;
		this.workstp_qty = workstp_qty;
		
	}

	@Override
	public String getSQLTypeName() throws SQLException {
		// TODO Auto-generated method stub
		return sqlType;
	}

	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		
		sqlType = typeName;
		
		header_id = stream.readString();
		line_id = stream.readString();
		customer_line_number = stream.readString();
		ordered_quantity = stream.readString();
		shipment_priority_code = stream.readString();
		ship_to_location_id = stream.readString();
		dlvr_to_location_id =stream.readString();
		request_date = stream.readDate();
		mygea_esn = stream.readString();
		workstp_date = stream.readDate();
		workstp_qty = stream.readInt();
	}

	
	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {

		 stream.writeString(header_id);
		 stream.writeString(line_id);
		 stream.writeString(customer_line_number);
		 stream.writeString(ordered_quantity);
		 stream.writeString(shipment_priority_code);
		 stream.writeString(ship_to_location_id);
		 stream.writeString(dlvr_to_location_id);
		 stream.writeDate(request_date);
		 stream.writeString(mygea_esn);
		 stream.writeDate(workstp_date);
		 stream.writeInt(workstp_qty);
		 
	}
	
}
