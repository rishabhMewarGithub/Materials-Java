/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     PartDetailsBO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;


/**
* Part Details
* <p>
* 
* 
*/
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "PartDetailsBO")
@JsonPropertyOrder({
"orderQuantityUnitOfMeasure",
"availability",
"displayMessage",
"partAvailMsg",
"partPricMsg",
"inventoryItemId",
"partNumber",
"partDescription",
"pricingIndicator",
"AvailabilityListBO",
"PricingListBO",
"ApplicableCustBO",
"kitIndicator",
"discountMessage",
"criticalPartMessage",
"AvailableDiscountList",
"isOrderable",
"CommercialAgreementListBO",
"QuotationBO"
})

public class PartDetailsBO {

	@JsonProperty("orderQuantityUnitOfMeasure")
	private String orderQuantityUnitOfMeasure = "";
	
	@JsonProperty("availability")
	private String availability = "";
	
	@JsonProperty("displayMessage")
	private String displayMessage = "";
	@JsonProperty("partAvailMsg")
	private String partAvailMsg = "";
	//declaring one more new attribute isOrderable as requested for AreoDp ( added newly )
	@JsonProperty("isOrderable")
	private String isOrderable = "";
	@JsonProperty("isOrderable")
	public String getIsOrderable() {
		return isOrderable;
	}
	@JsonProperty("isOrderable")
	public void setIsOrderable(String isOrderable) {
		this.isOrderable = isOrderable;
	}
	@JsonProperty("partPricMsg")
	private String partPricMsg= "";
	private String message;
	
	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("inventoryItemId")
	private String inventoryItemId;
	@JsonProperty("partNumber")
	private String partNumber;
	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("partDescription")
	private String partDescription;
	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("pricingIndicator")
	private String pricingIndicator;
	//added for discount
	@JsonProperty("discountMessage")
	private String discountMessage = "";
	@JsonProperty("criticalPartMessage")
	private String criticalPartMessage = "";
	@JsonProperty("AvailableDiscountList")
	private List<AvailableDiscounts> availableDiscountList = new ArrayList<AvailableDiscounts>();
	
	@JsonProperty("ApplicableProductLineBO")
	private List<ApplicableProductLineBO> applicableProductLineBO = new ArrayList<ApplicableProductLineBO>();
	
	@JsonProperty("CommercialAgreementList")
	private List<CommercialAgreementListBO>  commercialAgreementListBOs= new ArrayList<CommercialAgreementListBO>();
	
	@JsonProperty("QuotationBO")
	private List<QuotationBO>  quotationBO= new ArrayList<QuotationBO>();
	
	
	@JsonProperty("AvailabilityListBO")
	private List<AvailabilityListBO> availabilityList = new ArrayList<AvailabilityListBO>();
	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("PricingListBO")
	private List<PricingListBO> pricingList = new ArrayList<PricingListBO>();
	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("ApplicableCustBO")
	private List<ApplicableCustBO> applicableCust = new ArrayList<ApplicableCustBO>();
	
	public List<ApplicableProductLineBO> getApplicableProductLineBO() {
		return applicableProductLineBO;
	}
	public void setApplicableProductLineBO(
			List<ApplicableProductLineBO> applicableProductLineBO) {
		this.applicableProductLineBO = applicableProductLineBO;
	}
	public List<AvailableDiscounts> getAvailableDiscountList() {
		return availableDiscountList;
	}
	public void setAvailableDiscountList(
			List<AvailableDiscounts> availableDiscountList) {
		this.availableDiscountList = availableDiscountList;
	}
	public String getDiscountMessage() {
		return discountMessage;
	}
	public void setDiscountMessage(String discountMessage) {
		this.discountMessage = discountMessage;
	}
	public String getCriticalPartMessage() {
		return criticalPartMessage;
	}
	public void setCriticalPartMessage(String criticalPartMessage) {
		this.criticalPartMessage = criticalPartMessage;
	}
	public String getPricingIndicator() {
		return pricingIndicator;
	}
	public void setPricingIndicator(String pricingIndicator) {
		this.pricingIndicator = pricingIndicator;
	}
	@JsonIgnore
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@JsonProperty("displayMessage")
	public String getDisplayMessage() {
		return displayMessage;
	}
	@JsonProperty("displayMessage")
	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}
	
	@JsonProperty("orderQuantityUnitOfMeasure")
	public String getOrderQuantityUnitOfMeasure() {
		return orderQuantityUnitOfMeasure;
	}
	
	@JsonProperty("orderQuantityUnitOfMeasure")
	public void setOrderQuantityUnitOfMeasure(String orderQuantityUnitOfMeasure) {
		this.orderQuantityUnitOfMeasure = orderQuantityUnitOfMeasure;
	}
	
	@JsonProperty("availability")
	public String getAvailability() {
		return availability;
	}
	
	@JsonProperty("availability")
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	
	@JsonProperty("kitIndicator")
	private boolean kitIndicator;
	
	@JsonProperty("partAvailMsg")
	public String getPartAvailMsg() {
		return partAvailMsg;
	}
	@JsonProperty("partAvailMsg")
	public void setPartAvailMsg(String partAvailMsg) {
		this.partAvailMsg = partAvailMsg;
	}
	@JsonProperty("partPricMsg")
	public String getPartPricMsg() {
		return partPricMsg;
	}
	@JsonProperty("partPricMsg")
	public void setPartPricMsg(String partPricMsg) {
		this.partPricMsg = partPricMsg;
	}
	@JsonProperty("inventoryItemId")
	public String getInventoryItemId() {
		return inventoryItemId;
	}
	@JsonProperty("inventoryItemId")
	public void setInventoryItemId(String inventoryItemId) {
		this.inventoryItemId = inventoryItemId;
	}
	@JsonProperty("ApplicableCustBO")
	public List<ApplicableCustBO> getApplicableCust() {
		return applicableCust;
	}
	@JsonProperty("ApplicableCustBO")
	public void setApplicableCust(List<ApplicableCustBO> applicableCust) {
		this.applicableCust = applicableCust;
	}
	@JsonProperty("partNumber")
	public String getPartNumber() {
		return partNumber;
	}

	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("partNumber")
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	@JsonProperty("partDescription")
	public String getPartDescription() {
		return partDescription;
	}
	@JsonProperty("partDescription")
	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}
	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("AvailabilityListBO")
	public List<AvailabilityListBO> getAvailabilityList() {
		return availabilityList;
	}

	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("AvailabilityListBO")
	public void setAvailabilityList(List<AvailabilityListBO> availabilityList) {
		this.availabilityList = availabilityList;
	}

	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("PricingListBO")
	public List<PricingListBO> getPricingList() {
		return pricingList;
	}

	/**
	 * 
	 * (Required)
	 * 
	 */
	@JsonProperty("PricingListBO")
	public void setPricingList(List<PricingListBO> pricingList) {
		this.pricingList = pricingList;
	}
	
	@JsonProperty("CommercialAgreementList")
	public List<CommercialAgreementListBO> getCommercialAgreementListBOs() {
		return commercialAgreementListBOs;
	}
	
	
	public void setCommercialAgreementListBOs(
			List<CommercialAgreementListBO> commercialAgreementListBOs) {
		this.commercialAgreementListBOs = commercialAgreementListBOs;
	}
	
	@JsonProperty("QuotationBO")
	public List<QuotationBO> getQuotationBO() {
		return quotationBO;
	}
	public void setQuotationBO(List<QuotationBO> quotationBO) {
		this.quotationBO = quotationBO;
	}
	
	
	@JsonProperty("kitIndicator")
	public boolean isKitIndicator() {
		return kitIndicator;
	}
	@JsonProperty("kitIndicator")
	public void setKitIndicator(boolean kitIndicator) {
		this.kitIndicator = kitIndicator;
	}
}