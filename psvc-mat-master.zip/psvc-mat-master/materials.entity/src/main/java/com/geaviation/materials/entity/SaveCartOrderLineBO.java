/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	May 28, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     SaveCartOrderLineBO.java
 * 
 * History        :  	May 28, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author 720053
 *
 */
@XmlRootElement(name = "OrderLineBO")
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
@JsonPropertyOrder({"lineDeliverTo","lineShipTo","priceListId","ratingPlugId","lineShippingMethod","cartLineId","customerPurchaseOrderLineNumber","quantity","orderLinePriority","orderLineRequestedDate","orderLineESN","engineNumber","orderRemarks"})
public class SaveCartOrderLineBO {
	
	@JsonProperty("cartLineId")
	private String cartLineId;
	
	@JsonProperty("customerPurchaseOrderLineNumber")
	private String customerPurchaseOrderLineNumber;
	
	@JsonProperty("quantity")
	private String quantity;
	
	@JsonProperty("orderLinePriority")
	private String orderLinePriority;
	
	@JsonProperty("orderLineRequestedDate")
	private String orderLineRequestedDate;
	
	@JsonProperty("orderLineESN")
	private String orderLineESN;
	

	@JsonProperty("lineDeliverTo")
	private String lineDeliverTo;
	
	@JsonProperty("lineShipTo")
	private String lineShipTo;
	@JsonProperty("priceListId")
	private String priceListId;
	@JsonProperty("ratingPlugId")
	private String ratingPlugId;
	@JsonProperty("lineShippingMethod")
	private String lineShippingMethod;
	@JsonProperty("engineNumber")
	private String engineNumber;
	@JsonProperty("orderRemarks")
	private String orderRemarks;
	
	@JsonProperty("orderLineWorkStopQuantity")
	private String orderLineWorkStopQuantity;
	
	@JsonProperty("orderLineWorkStopDate")
	private String orderLineWorkStopDate;
	
	public String getOrderLineWorkStopQuantity() {
		return orderLineWorkStopQuantity;
	}
	public void setOrderLineWorkStopQuantity(String orderLineWorkStopQuantity) {
		this.orderLineWorkStopQuantity = orderLineWorkStopQuantity;
	}
	public String getOrderLineWorkStopDate() {
		return orderLineWorkStopDate;
	}
	public void setOrderLineWorkStopDate(String orderLineWorkStopDate) {
		this.orderLineWorkStopDate = orderLineWorkStopDate;
	}
	public String getCartLineId() {
		return cartLineId;
	}
	public void setCartLineId(String cartLineId) {
		this.cartLineId = cartLineId;
	}
	public String getCustomerPurchaseOrderLineNumber() {
		return customerPurchaseOrderLineNumber;
	}
	public void setCustomerPurchaseOrderLineNumber(
			String customerPurchaseOrderLineNumber) {
		this.customerPurchaseOrderLineNumber = customerPurchaseOrderLineNumber;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getOrderLinePriority() {
		return orderLinePriority;
	}

	public void setOrderLinePriority(String orderLinePriority) {
		this.orderLinePriority = orderLinePriority;
	}

	public String getOrderLineRequestedDate() {
		return orderLineRequestedDate;
	}

	public void setOrderLineRequestedDate(String orderLineRequestedDate) {
		this.orderLineRequestedDate = orderLineRequestedDate;
	}

	public String getOrderLineESN() {
		return orderLineESN;
	}

	public void setOrderLineESN(String orderLineESN) {
		this.orderLineESN = orderLineESN;
	}		
	public String getLineDeliverTo() {
		return lineDeliverTo;
	}

	public void setLineDeliverTo(String lineDeliverTo) {
		this.lineDeliverTo = lineDeliverTo;
	}

	public String getLineShipTo() {
		return lineShipTo;
	}

	public void setLineShipTo(String lineShipTo) {
		this.lineShipTo = lineShipTo;
	}

	public String getPriceListId() {
		return priceListId;
	}

	public void setPriceListId(String priceListId) {
		this.priceListId = priceListId;
	}

	public String getRatingPlugId() {
		return ratingPlugId;
	}

	public void setRatingPlugId(String ratingPlugId) {
		this.ratingPlugId = ratingPlugId;
	}

	public String getLineShippingMethod() {
		return lineShippingMethod;
	}

	public void setLineShippingMethod(String lineShippingMethod) {
		this.lineShippingMethod = lineShippingMethod;
	}

	public String getEngineNumber() {
		return engineNumber;
	}

	public void setEngineNumber(String engineNumber) {
		this.engineNumber = engineNumber;
	}

	public String getOrderRemarks() {
		return orderRemarks;
	}

	public void setOrderRemarks(String orderRemarks) {
		this.orderRemarks = orderRemarks;
	}

}
