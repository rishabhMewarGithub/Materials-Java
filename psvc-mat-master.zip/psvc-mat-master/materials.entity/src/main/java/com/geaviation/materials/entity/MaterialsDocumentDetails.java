package com.geaviation.materials.entity;

public class MaterialsDocumentDetails {
	private String docVersion;
	private String docNumber;
	private String storagePathText;
	private String docTypeCd;
	public String getDocVersion() {
		return docVersion;
	}
	public void setDocVersion(String docVersion) {
		this.docVersion = docVersion;
	}
	public String getDocNumber() {
		return docNumber;
	}
	public void setDocNumber(String docNumber) {
		this.docNumber = docNumber;
	}
	public String getStoragePathText() {
		return storagePathText;
	}
	public void setStoragePathText(String storagePathText) {
		this.storagePathText = storagePathText;
	}
	public String getDocTypeCd() {
		return docTypeCd;
	}
	public void setDocTypeCd(String docTypeCd) {
		this.docTypeCd = docTypeCd;
	}
}
