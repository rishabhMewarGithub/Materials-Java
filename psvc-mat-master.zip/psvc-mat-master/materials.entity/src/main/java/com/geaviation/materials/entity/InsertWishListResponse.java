package com.geaviation.materials.entity;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

@XmlRootElement(name = "InsertWishListResponse")
@JsonPropertyOrder({"message"})
public class InsertWishListResponse {


	@JsonProperty("message")
	private String message;
	@JsonProperty("success")
	private String p_message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getP_message() {
		return p_message;
	}

	public void setP_message(String p_message) {
		this.p_message = p_message;
	}
	
}
