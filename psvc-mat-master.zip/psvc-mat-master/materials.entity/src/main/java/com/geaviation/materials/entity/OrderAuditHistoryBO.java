/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	May 20 2016   
 * Created By	  :		717826	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :    June 01 2016
 * Description    :     OrderAuditHistoryBO.java
 * 
 * History        :  	May 20, 2016                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;

/**
 * @author 720053
 *
 */
public class OrderAuditHistoryBO {
	private String   displayMessage;
	private String statusMessage;
	@JsonProperty("auditHistoryData")
	private List<OrderAuditBO> orderAuditBOList;
	
	public String getDisplayMessage() {
		return displayMessage;
	}
	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}
	public List<OrderAuditBO> getOrderAuditBOList() {
		return orderAuditBOList;
	}
	public void setOrderAuditBOList(List<OrderAuditBO> orderAuditBOList) {
		this.orderAuditBOList = orderAuditBOList;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	


}
