package com.geaviation.materials.entity;

public class MaterialsOrderRequest {

/*
	private String dateFrom;
	private String dateTo;
	
	private String dateFilterName;
	private String locationId;
	private String customerName;
	private String engineFamily;
	private String engineModel;
	private String esn;
	private String customerFlag;
	private String startLength;
	//private String endLength;
	private String sortColumn;
	private String sortType;
	private String filterDateName;*/
	private String icaoCode;
	private String custCode;
	private String requestDateFrom;
	private String requestDateTo;
	private String orderedDateFrom;
	private String orderedDateTo;
	private String deliveryDateFrom;
	private String deliveryDateTo;
	private String shipmentDateFrom;
	private String shipmentDateTo;
	private String customerNumber;
	private String customerNumberValue;
	private String purchaseOrder;
	private String purchareOrderValue;
	private String invoiceNumber;
	private String invoiceNumberValue;
	private String customerLineNumber;
	private String customerLineNumberValue;
	private String partNumber;
	private String partNumberValue;
	private String requestedQty;
	private String requestedQtyValue;
	private String orderStatus;
	private String orderStatusValue;
	private String cancelledQty;
	private String cancelledQtyValue;
	private String shippedQty;
	private String shippedQtyValue;
	private String sellingPrice;
	private String sellingPriceValue;
	private String listPrice;
	private String listPriceValue;
	private String extendedPrice;
	private String extendedPriceValue;
	private String  invoicedQuantity;
	private String  invoicedQuantityValue;
	private String msNumber;
	private String msNumberValue;
	private String engineFamily;
	private String engineFamilyValue;
	private String engineModel;
	private String engineModelValue;
	private String awbNumber;
	private String awbNumberValue;

	private String orderLineType;
	private String orderLineTypeValue;
	private String orderedDate;
	private String requestedDate;
	private String deliveryDate;
	private String shippmentDate;
	private String orderByColumn;
	private String sortType;
	
	public String getIcaoCode() {
		return icaoCode;
	}
	public void setIcaoCode(String icaoCode) {
		this.icaoCode = icaoCode;
	}
	public String getCustCode() {
		return custCode;
	}
	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	public String getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	public String getCustomerNumberValue() {
		return customerNumberValue;
	}
	public void setCustomerNumberValue(String customerNumberValue) {
		this.customerNumberValue = customerNumberValue;
	}
	public String getPurchaseOrder() {
		return purchaseOrder;
	}
	public void setPurchaseOrder(String purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}
	public String getPurchareOrderValue() {
		return purchareOrderValue;
	}
	public void setPurchareOrderValue(String purchareOrderValue) {
		this.purchareOrderValue = purchareOrderValue;
	}
	
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getInvoiceNumberValue() {
		return invoiceNumberValue;
	}
	public void setInvoiceNumberValue(String invoiceNumberValue) {
		this.invoiceNumberValue = invoiceNumberValue;
	}
	public String getCustomerLineNumber() {
		return customerLineNumber;
	}
	public void setCustomerLineNumber(String customerLineNumber) {
		this.customerLineNumber = customerLineNumber;
	}
	public String getCustomerLineNumberValue() {
		return customerLineNumberValue;
	}
	public void setCustomerLineNumberValue(String customerLineNumberValue) {
		this.customerLineNumberValue = customerLineNumberValue;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getPartNumberValue() {
		return partNumberValue;
	}
	public void setPartNumberValue(String partNumberValue) {
		this.partNumberValue = partNumberValue;
	}
	public String getRequestedQty() {
		return requestedQty;
	}
	public void setRequestedQty(String requestedQty) {
		this.requestedQty = requestedQty;
	}
	public String getRequestedQtyValue() {
		return requestedQtyValue;
	}
	public void setRequestedQtyValue(String requestedQtyValue) {
		this.requestedQtyValue = requestedQtyValue;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getOrderStatusValue() {
		return orderStatusValue;
	}
	public void setOrderStatusValue(String orderStatusValue) {
		this.orderStatusValue = orderStatusValue;
	}

	public String getRequestDateFrom() {
		return requestDateFrom;
	}
	public void setRequestDateFrom(String requestDateFrom) {
		this.requestDateFrom = requestDateFrom;
	}
	public String getRequestDateTo() {
		return requestDateTo;
	}
	public void setRequestDateTo(String requestDateTo) {
		this.requestDateTo = requestDateTo;
	}
	public String getOrderedDateFrom() {
		return orderedDateFrom;
	}
	public void setOrderedDateFrom(String orderedDateFrom) {
		this.orderedDateFrom = orderedDateFrom;
	}
	public String getOrderedDateTo() {
		return orderedDateTo;
	}
	public void setOrderedDateTo(String orderedDateTo) {
		this.orderedDateTo = orderedDateTo;
	}
	public String getDeliveryDateFrom() {
		return deliveryDateFrom;
	}
	public void setDeliveryDateFrom(String deliveryDateFrom) {
		this.deliveryDateFrom = deliveryDateFrom;
	}
	public String getDeliveryDateTo() {
		return deliveryDateTo;
	}
	public void setDeliveryDateTo(String deliveryDateTo) {
		this.deliveryDateTo = deliveryDateTo;
	}
	public String getShipmentDateFrom() {
		return shipmentDateFrom;
	}
	public void setShipmentDateFrom(String shipmentDateFrom) {
		this.shipmentDateFrom = shipmentDateFrom;
	}
	public String getShipmentDateTo() {
		return shipmentDateTo;
	}
	public void setShipmentDateTo(String shipmentDateTo) {
		this.shipmentDateTo = shipmentDateTo;
	}
	public String getCancelledQty() {
		return cancelledQty;
	}
	public void setCancelledQty(String cancelledQty) {
		this.cancelledQty = cancelledQty;
	}
	public String getCancelledQtyValue() {
		return cancelledQtyValue;
	}
	public void setCancelledQtyValue(String cancelledQtyValue) {
		this.cancelledQtyValue = cancelledQtyValue;
	}
	public String getShippedQty() {
		return shippedQty;
	}
	public void setShippedQty(String shippedQty) {
		this.shippedQty = shippedQty;
	}
	public String getShippedQtyValue() {
		return shippedQtyValue;
	}
	public void setShippedQtyValue(String shippedQtyValue) {
		this.shippedQtyValue = shippedQtyValue;
	}
	public String getSellingPrice() {
		return sellingPrice;
	}
	public void setSellingPrice(String sellingPrice) {
		this.sellingPrice = sellingPrice;
	}
	public String getSellingPriceValue() {
		return sellingPriceValue;
	}
	public void setSellingPriceValue(String sellingPriceValue) {
		this.sellingPriceValue = sellingPriceValue;
	}
	public String getListPrice() {
		return listPrice;
	}
	public void setListPrice(String listPrice) {
		this.listPrice = listPrice;
	}
	public String getListPriceValue() {
		return listPriceValue;
	}
	public void setListPriceValue(String listPriceValue) {
		this.listPriceValue = listPriceValue;
	}
	public String getExtendedPrice() {
		return extendedPrice;
	}
	public void setExtendedPrice(String extendedPrice) {
		this.extendedPrice = extendedPrice;
	}
	public String getExtendedPriceValue() {
		return extendedPriceValue;
	}
	public void setExtendedPriceValue(String extendedPriceValue) {
		this.extendedPriceValue = extendedPriceValue;
	}
	public String getMsNumber() {
		return msNumber;
	}
	public void setMsNumber(String msNumber) {
		this.msNumber = msNumber;
	}
	public String getMsNumberValue() {
		return msNumberValue;
	}
	public void setMsNumberValue(String msNumberValue) {
		this.msNumberValue = msNumberValue;
	}
	public String getEngineFamily() {
		return engineFamily;
	}
	public void setEngineFamily(String engineFamily) {
		this.engineFamily = engineFamily;
	}
	public String getEngineFamilyValue() {
		return engineFamilyValue;
	}
	public void setEngineFamilyValue(String engineFamilyValue) {
		this.engineFamilyValue = engineFamilyValue;
	}
	public String getEngineModel() {
		return engineModel;
	}
	public void setEngineModel(String engineModel) {
		this.engineModel = engineModel;
	}
	public String getEngineModelValue() {
		return engineModelValue;
	}
	public void setEngineModelValue(String engineModelValue) {
		this.engineModelValue = engineModelValue;
	}
	public String getAwbNumber() {
		return awbNumber;
	}
	public void setAwbNumber(String awbNumber) {
		this.awbNumber = awbNumber;
	}
	public String getAwbNumberValue() {
		return awbNumberValue;
	}
	public void setAwbNumberValue(String awbNumberValue) {
		this.awbNumberValue = awbNumberValue;
	}
	public String getOrderLineType() {
		return orderLineType;
	}
	public void setOrderLineType(String orderLineType) {
		this.orderLineType = orderLineType;
	}
	public String getOrderLineTypeValue() {
		return orderLineTypeValue;
	}
	public void setOrderLineTypeValue(String orderLineTypeValue) {
		this.orderLineTypeValue = orderLineTypeValue;
	}
	public String getInvoicedQuantity() {
		return invoicedQuantity;
	}
	public void setInvoicedQuantity(String invoicedQuantity) {
		this.invoicedQuantity = invoicedQuantity;
	}
	public String getInvoicedQuantityValue() {
		return invoicedQuantityValue;
	}
	public void setInvoicedQuantityValue(String invoicedQuantityValue) {
		this.invoicedQuantityValue = invoicedQuantityValue;
	}
	public String getOrderedDate() {
		return orderedDate;
	}
	public void setOrderedDate(String orderedDate) {
		this.orderedDate = orderedDate;
	}
	public String getRequestedDate() {
		return requestedDate;
	}
	public void setRequestedDate(String requestedDate) {
		this.requestedDate = requestedDate;
	}
	public String getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getShippmentDate() {
		return shippmentDate;
	}
	public void setShippmentDate(String shippmentDate) {
		this.shippmentDate = shippmentDate;
	}
	public String getOrderByColumn() {
		return orderByColumn;
	}
	public void setOrderByColumn(String orderByColumn) {
		this.orderByColumn = orderByColumn;
	}
	public String getSortType() {
		return sortType;
	}
	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

	
}
