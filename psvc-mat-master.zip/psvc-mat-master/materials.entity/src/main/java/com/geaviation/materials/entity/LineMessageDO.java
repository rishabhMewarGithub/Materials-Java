package com.geaviation.materials.entity;


public class LineMessageDO {
   private String  cartLineId;
	private String  statusMessage;
	private String  cartHeaderId;
	private String orderLineId;
	public String getStatusMessage() {
		return statusMessage;
	}
	public String getCartHeaderId() {
		return cartHeaderId;
	}
	public void setCartHeaderId(String cartHeaderId) {
		this.cartHeaderId = cartHeaderId;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getCartLineId() {
		return cartLineId;
	}
	public void setCartLineId(String cartLineId) {
		this.cartLineId = cartLineId;
	}
	public String getOrderLineId() {
		return orderLineId;
	}
	public void setOrderLineId(String orderLineId) {
		this.orderLineId = orderLineId;
	}


}
