package com.geaviation.materials.entity;
public class MsFaaDocStatusBS {
	private String displayMessage;

	public String getDisplayMessage() {
		return displayMessage;
	}

	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}


}
