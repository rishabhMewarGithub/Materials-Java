/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Nov 21, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     ReturnLabelDO.java
 * 
 * History        :  	Nov 21, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

/**
 * @author 720053
 *
 */
public class ReturnLabelDO {
	
	private String rmaNumber;
	private String poNumber;
	private String partNumber;
	private String quantity;
	private String reason;
	private String countryOfOrigin;
	private String pMessage;
	
	public String getRmaNumber() {
		return rmaNumber;
	}
	public void setRmaNumber(String rmaNumber) {
		this.rmaNumber = rmaNumber;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getCountryOfOrigin() {
		return countryOfOrigin;
	}
	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}
	public String getpMessage() {
		return pMessage;
	}
	public void setpMessage(String pMessage) {
		this.pMessage = pMessage;
	}

}
