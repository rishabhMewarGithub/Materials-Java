package com.geaviation.materials.entity;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({"defaultIndicator","deliverAddress1","deliverAddress2","deliverAddress3","deliverAddress4","deliverCity","deliverState","deliverZip","deliverCountry","deliverAddressCode","deliverAddressId"})
public class DeliveryAddressBO {
	@JsonProperty("deliverAddressCode")
	private String deliverAddressCode;
	@JsonProperty("deliverAddress1")
	private String deliverAddress1;
	@JsonProperty("defaultIndicator")
	private boolean defaultIndicator;
	@JsonProperty("deliverAddressId")
	private String deliverAddressId;
	
	//Added for JIRA 6094
	@JsonProperty("deliverAddress2")
	private String deliverAddress2;
	@JsonProperty("deliverCity")
	private String deliverCity;
	@JsonProperty("deliverState")
	private String deliverState;
	@JsonProperty("deliverZip")
	private String deliverZip;
	@JsonProperty("deliverCountry")
	private String deliverCountry;
	@JsonProperty("deliverAddress3")
	private String deliverAddress3;
	@JsonProperty("deliverAddress4")
	private String deliverAddress4;
	
	public String getDeliverAddressCode() {
		return deliverAddressCode;
	}
	public void setDeliverAddressCode(String deliverAddressCode) {
		this.deliverAddressCode = deliverAddressCode;
	}
	public String getDeliverAddress1() {
		return deliverAddress1;
	}
	public void setDeliverAddress1(String deliverAddress1) {
		this.deliverAddress1 = deliverAddress1;
	}
	public boolean isDefaultIndicator() {
		return defaultIndicator;
	}
	public void setDefaultIndicator(boolean defaultIndicator) {
		this.defaultIndicator = defaultIndicator;
	}
	public String getDeliverAddressId() {
		return deliverAddressId;
	}
	public void setDeliverAddressId(String deliverAddressId) {
		this.deliverAddressId = deliverAddressId;
	}
	public String getDeliverAddress2() {
		return deliverAddress2;
	}
	public void setDeliverAddress2(String deliverAddress2) {
		this.deliverAddress2 = deliverAddress2;
	}
	public String getDeliverCity() {
		return deliverCity;
	}
	public void setDeliverCity(String deliverCity) {
		this.deliverCity = deliverCity;
	}
	public String getDeliverState() {
		return deliverState;
	}
	public void setDeliverState(String deliverState) {
		this.deliverState = deliverState;
	}
	public String getDeliverZip() {
		return deliverZip;
	}
	public void setDeliverZip(String deliverZip) {
		this.deliverZip = deliverZip;
	}
	public String getDeliverCountry() {
		return deliverCountry;
	}
	public void setDeliverCountry(String deliverCountry) {
		this.deliverCountry = deliverCountry;
	}
	public String getDeliverAddress3() {
		return deliverAddress3;
	}
	public void setDeliverAddress3(String deliverAddress3) {
		this.deliverAddress3 = deliverAddress3;
	}
	public String getDeliverAddress4() {
		return deliverAddress4;
	}
	public void setDeliverAddress4(String deliverAddress4) {
		this.deliverAddress4 = deliverAddress4;
	}	
	
	
}
