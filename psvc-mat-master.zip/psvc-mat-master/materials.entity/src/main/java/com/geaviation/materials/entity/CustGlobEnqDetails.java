package com.geaviation.materials.entity;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;

import com.geaviation.materials.entity.CustomerBO;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "CustGlobEnqDetails")
public class CustGlobEnqDetails {
	
	@XmlAttribute(name = "status")
	private boolean status;
	
	@XmlElement
	private List<CustomerBO> customerBOList;
		
	public void setCustomerBOList(List<CustomerBO> customerBOList) {
		this.customerBOList = customerBOList;
	}
	
	@JsonProperty("CustomerBO")
	public List<CustomerBO> getCustomerBOList() {
		return customerBOList;
	}

	@JsonIgnore
	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	

}
