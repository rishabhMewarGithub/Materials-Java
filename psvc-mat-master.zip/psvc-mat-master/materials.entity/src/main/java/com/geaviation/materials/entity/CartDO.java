/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     CartDO.java
 * 
 * History        :  	May 28, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;
import java.util.List;

import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlAttribute;

import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({"purchaseOrderValue"})
public class CartDO {
	private String p_msg;
	private String po_total;
	@XmlAttribute(name = "OrderLineBO")
	private List<PartDO> partDO = null;
	@XmlAttribute(name = "CartDO")
	private List<CartHDRInfoDO> cartDO = null;
	public String getP_msg() {
		return p_msg;
	}
	public void setP_msg(String p_msg) {
		this.p_msg = p_msg;
	}
	public String getPo_total() {
		return po_total;
	}
	public void setPo_total(String po_total) {
		this.po_total = po_total;
	}
	public List<PartDO> getPartDO() {
		return partDO;
	}
	public void setPartDO(List<PartDO> partDO) {
		this.partDO = partDO;
	}
	public List<CartHDRInfoDO> getCartDO() {
		return cartDO;
	}
	public void setCartDO(List<CartHDRInfoDO> cartDO) {
		this.cartDO = cartDO;
	}
	
}
