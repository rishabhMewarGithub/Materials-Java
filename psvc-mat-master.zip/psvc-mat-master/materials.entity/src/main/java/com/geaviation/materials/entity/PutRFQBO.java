/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016 
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     PutRFQBO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@XmlRootElement(name = "putRFQ", namespace = "urn:snecma:cfm")
public class PutRFQBO {
	private static final Log LOG = LogFactory.getLog(PutRFQBO.class);
	public PutRFQBO()
	{
		LOG.info("PutRFQBO Constructor");
	}
	public PutRFQBO(String CustomerCode,String rfqClientNumber,String rfqSubmittedDate,String rfqPriorityCode,String partNumber,String orderedQuantity,String rfqConditionCode,String rfqCustomerRemarks)
	{
		this.CustomerCode = CustomerCode;
		this.rfqClientNumber = rfqClientNumber;
		this.rfqSubmittedDate = rfqSubmittedDate;
		this.rfqPriorityCode = rfqPriorityCode;
		this.partNumber = partNumber;
		this.orderedQuantity = orderedQuantity;
		this.rfqConditionCode = rfqConditionCode;
		this.rfqCustomerRemarks = rfqCustomerRemarks;	
	}
	private String CustomerCode;
	
	private String rfqClientNumber;
	private String rfqSubmittedDate;
	private String rfqPriorityCode;
	private String partNumber;
	private String orderedQuantity;
	private String rfqConditionCode;
	private String rfqCustomerRemarks;
	public String getCustomerCode() {
		return CustomerCode;
	}
	public void setCustomerCode(String customerCode) {
		CustomerCode = customerCode;
	}
	public String getRfqClientNumber() {
		return rfqClientNumber;
	}
	public void setRfqClientNumber(String rfqClientNumber) {
		this.rfqClientNumber = rfqClientNumber;
	}
	public String getRfqSubmittedDate() {
		return rfqSubmittedDate;
	}
	public void setRfqSubmittedDate(String rfqSubmittedDate) {
		this.rfqSubmittedDate = rfqSubmittedDate;
	}
	public String getRfqPriorityCode() {
		return rfqPriorityCode;
	}
	public void setRfqPriorityCode(String rfqPriorityCode) {
		this.rfqPriorityCode = rfqPriorityCode;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getOrderedQuantity() {
		return orderedQuantity;
	}
	public void setOrderedQuantity(String orderedQuantity) {
		this.orderedQuantity = orderedQuantity;
	}
	public String getRfqConditionCode() {
		return rfqConditionCode;
	}
	public void setRfqConditionCode(String rfqConditionCode) {
		this.rfqConditionCode = rfqConditionCode;
	}
	public String getRfqCustomerRemarks() {
		return rfqCustomerRemarks;
	}
	public void setRfqCustomerRemarks(String rfqCustomerRemarks) {
		this.rfqCustomerRemarks = rfqCustomerRemarks;
	}


}
