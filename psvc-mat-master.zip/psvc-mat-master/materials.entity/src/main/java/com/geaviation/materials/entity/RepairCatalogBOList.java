package com.geaviation.materials.entity;
import java.util.List;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
@Generated("org.jsonschema2pojo")
public class RepairCatalogBOList {
	@JsonProperty("RepairCatalogBOList")
	private List<RepairCatalogBO> repairCatalogBoList;

	public List<RepairCatalogBO> getRepairCatalogBoList() {
		return repairCatalogBoList;
	}

	public void setRepairCatalogBoList(List<RepairCatalogBO> repairCatalogBoList) {
		this.repairCatalogBoList = repairCatalogBoList;
	}

}
