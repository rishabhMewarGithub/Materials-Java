package com.geaviation.materials.entity;

public class AvailableDiscounts {
	private String customerCode;
	private String discountName;
	private String discountPercent;
	private String discountedPrice;
	private String eligibileQuantiy;
	private String remainQuantity;
	private String  expiryDate;
	private String  qualifierId;
	public String getQualifierId() {
		return qualifierId;
	}
	public void setQualifierId(String qualifierId) {
		this.qualifierId = qualifierId;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getDiscountName() {
		return discountName;
	}
	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}
	public String getDiscountPercent() {
		return discountPercent;
	}
	public void setDiscountPercent(String discountPercent) {
		this.discountPercent = discountPercent;
	}
	public String getDiscountedPrice() {
		return discountedPrice;
	}
	public void setDiscountedPrice(String discountedPrice) {
		this.discountedPrice = discountedPrice;
	}
	public String getEligibileQuantiy() {
		return eligibileQuantiy;
	}
	public void setEligibileQuantiy(String eligibileQuantiy) {
		this.eligibileQuantiy = eligibileQuantiy;
	}
	public String getRemainQuantity() {
		return remainQuantity;
	}
	public void setRemainQuantity(String remainQuantity) {
		this.remainQuantity = remainQuantity;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	

}
