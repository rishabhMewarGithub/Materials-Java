/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     MYGEAGroupBO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.List;

public class MYGEAGroupBO {
	private String groupName;
	private List<String> columnIds;

	public List<String> getColumnIds() {
		return columnIds;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public void setColumnIds(List<String> columnIds) {
		this.columnIds = columnIds;
	}
	
}
