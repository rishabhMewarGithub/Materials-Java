package com.geaviation.materials.entity;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "userID", "userName", "givenName", "middleName", "familyName", "emailId",
		"secEmailId", "address", "userProperty", "orgProperty" })
@XmlRootElement(name = "user")
public class User implements Comparable<User> {

	@XmlElement(required = true)
	protected String userID;
	protected String userName;
	protected String givenName;
	protected String middleName;
	protected String familyName;
	protected String emailId;
	protected String secEmailId;
	protected String address;

	@XmlElement
	protected List<Property> userProperty;
	@XmlElement
	protected List<Property> orgProperty;

	/*
	 *Empty Constructor 
	 */
	public User() {
		/*
		 *Empty Constructor 
		 */
	}

	public String getAddress() {
		return address;
	}

	/**
	 * Gets the value of the emailId property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * Gets the value of the familyName property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getFamilyName() {
		return familyName;
	}

	/**
	 * Gets the value of the givenName property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getGivenName() {
		return givenName;
	}

	/**
	 * Gets the value of the middleName property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMiddleName() {
		return middleName;
	}

	public List<Property> getOrgProperty() {
		if (orgProperty == null) {
			orgProperty = new ArrayList<>();
		}
		return orgProperty;
	}

	/**
	 * Gets the value of the secEmailId property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSecEmailId() {
		return secEmailId;
	}

	public String getUserID() {
		return userID;
	}

	/**
	 * Gets the value of the userName property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getUserName() {
		return userName;
	}

	public List<Property> getUserProperty() {
		if (userProperty == null) {
			userProperty = new ArrayList<>();
		}
		return userProperty;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * Sets the value of the emailId property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setEmailId(final String value) {
		this.emailId = value;
	}

	/**
	 * Sets the value of the familyName property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setFamilyName(final String value) {
		this.familyName = value;
	}

	/**
	 * Sets the value of the givenName property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setGivenName(final String value) {
		this.givenName = value;
	}

	/**
	 * Sets the value of the middleName property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setMiddleName(final String value) {
		this.middleName = value;
	}

	public void setOrgProperty(List<Property> orgProperty) {
		this.orgProperty = orgProperty;
	}

	/**
	 * Sets the value of the secEmailId property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setSecEmailId(final String value) {
		this.secEmailId = value;
	}

	public void setUserID(String userID) {
		this.userID = userID;

	}

	/**
	 * Sets the value of the userName property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setUserName(final String value) {
		this.userName = value;
	}

	public void setUserProperty(List<Property> userProperty) {
		this.userProperty = userProperty;
	}

	@Override
	public int compareTo(User user) {
		return this.userName.compareToIgnoreCase(user.userName);
	}

	@Override
	public boolean equals(Object other) {
		if (!(other instanceof User))
			return false;

		if (other == this)
			return true;

		User otherUser = (User) other;
		return new EqualsBuilder().append(this.getUserName(), otherUser.getUserName()).isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder(17, 31).append(this.getUserName()).toHashCode();
	}

}