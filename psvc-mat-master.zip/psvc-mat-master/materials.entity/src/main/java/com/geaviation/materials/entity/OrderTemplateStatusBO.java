package com.geaviation.materials.entity;

public class OrderTemplateStatusBO {
	
	private String poNumber;
	private String poLineNumber;
	private String partNumber ;
	private int quantity ;
	private String success ;
	private String statusMessage ;
	private String esnValidFlag;
	private String esnStatusMsg;
	private String requestedQuantity;
	
	
	public String getPoLineNumber() {
		return poLineNumber;
	}
	public void setPoLineNumber(String poLineNumber) {
		this.poLineNumber = poLineNumber;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getSuccess() {
		return success;
	}
	public void setSuccess(String success) {
		this.success = success;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getEsnValidFlag() {
		return esnValidFlag;
	}
	public void setEsnValidFlag(String esnValidFlag) {
		this.esnValidFlag = esnValidFlag;
	}
	public String getEsnStatusMsg() {
		return esnStatusMsg;
	}
	public void setEsnStatusMsg(String esnStatusMsg) {
		this.esnStatusMsg = esnStatusMsg;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public String getRequestedQuantity() {
		return requestedQuantity;
	}
	public void setRequestedQuantity(String requestedQuantity) {
		this.requestedQuantity = requestedQuantity;
	}
	
	

}
