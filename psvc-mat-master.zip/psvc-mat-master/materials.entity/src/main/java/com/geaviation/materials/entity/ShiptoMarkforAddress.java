package com.geaviation.materials.entity;

import java.util.List;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
public class ShiptoMarkforAddress {
	@JsonProperty("MappingAddressListBO")
	List<ShippingAddressBO> lstShppingAddressBO =null;

	public List<ShippingAddressBO> getLstShppingAddressBO() {
		return lstShppingAddressBO;
	}

	public void setLstShppingAddressBO(List<ShippingAddressBO> lstShppingAddressBO) {
		this.lstShppingAddressBO = lstShppingAddressBO;
	}

	}


