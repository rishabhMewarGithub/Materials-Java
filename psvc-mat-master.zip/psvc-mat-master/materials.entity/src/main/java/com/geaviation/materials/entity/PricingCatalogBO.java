package com.geaviation.materials.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import org.codehaus.jackson.annotate.JsonAnyGetter;
import org.codehaus.jackson.annotate.JsonAnySetter;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;


/**
* Materials Pricing Catalog List
* <p>
* 
* 
*/
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
"success",
"sEcho",
"iTotalRecords",
"iTotalDisplayRecords",
"aaData"

})
public class PricingCatalogBO {

/**
* List of objects used to populate the table list.
* (Required)
* 
*/
@JsonProperty("aaData")	
private List<Pricing> Response = new ArrayList<Pricing>();
/**
* Total number of records being returned after filtering.
* (Required)
* 
*/
@JsonProperty("iTotalDisplayRecords")
private Double iTotalDisplayRecords;

/**
* Total number of records in database.
* (Required)
* 
*/
@JsonProperty("iTotalRecords")
private Double iTotalRecords;
/**
* Echo the input field of the same name
* (Required)
* 
*/
@JsonProperty("success")
private boolean success;
@JsonProperty("success")
public boolean isSuccess() {
	return success;
}
public void setSuccess(boolean success) {
	this.success = success;
}

@JsonProperty("sEcho")
private int sEcho;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* List of objects used to populate the table list.
* (Required)
* 
*/
@JsonProperty("aaData")
public List<Pricing> getResponse() {
return Response;
}

/**
* List of objects used to populate the table list.
* (Required)
* 
*/
@JsonProperty("aaData")
public void setResponse(List<Pricing> Response) {
this.Response = Response;
}

/**
* Total number of records being returned after filtering.
* (Required)
* 
*/
@JsonProperty("iTotalDisplayRecords")
public Double getITotalDisplayRecords() {
return iTotalDisplayRecords;
}

/**
* Total number of records being returned after filtering.
* (Required)
* 
*/
@JsonProperty("iTotalDisplayRecords")
public void setITotalDisplayRecords(Double iTotalDisplayRecords) {
this.iTotalDisplayRecords = iTotalDisplayRecords;
}

/**
* Total number of records in database.
* (Required)
* 
*/
@JsonProperty("iTotalRecords")
public Double getITotalRecords() {
return iTotalRecords;
}

/**
* Total number of records in database.
* (Required)
* 
*/
@JsonProperty("iTotalRecords")
public void setITotalRecords(Double iTotalRecords) {
this.iTotalRecords = iTotalRecords;
}

/**
* Echo the input field of the same name
* (Required)
* 
*/
@JsonProperty("sEcho")
public int getSEcho() {
return sEcho;
}

/**
* Echo the input field of the same name
* (Required)
* 
*/
@JsonProperty("sEcho")
public void setSEcho(int sEcho) {
this.sEcho = sEcho;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}