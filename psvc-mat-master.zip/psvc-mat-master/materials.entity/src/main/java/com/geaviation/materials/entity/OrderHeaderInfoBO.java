package com.geaviation.materials.entity;

import java.util.List;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class OrderHeaderInfoBO {
	private String msLink = "";
	private String faaLink = "";
	private String awbLink = "";
	private String returnServiceProvider;
	private String warehouse ;
	private String shipToLocation ;
	private String shipToAddress_1 ;
	private String shipToAddress_2 ;
	private String shipToAddress_3 ;
	private String shipToAddress_4 ;
	private String shipToAddress_5 ;
	private String deliverToLocation ;
	private String deliverToAddress_1 ;
	private String deliverToAddress_2 ;
	private String deliverToAddress_3 ;
	private String deliverToAddress_4 ;
	private String deliverToAddress_5 ;
	private String airWayBillNumber ;
	private String invoiceNumber ;
	private String invoiceDate ;
	private String invoiceLink = "" ;
	private String invoiceTotalAmount;
	private String customerCode;
	private String customerName;
	private String orderedDate;
	private String orderType;
	private String orderStatus;
	private String customerPONumber;
	private String supplierCode;
	private String shipmentDate;
	private String billOfLadding;
	private String warehouseCode;
	private String invoiceToLocation;
	private String invoiceToAddress_1;
	private String invoiceToAddress_2;
	private String invoiceToAddress_3;
	private String invoiceToAddress_4;
	private String invoiceToAddress_5;
	private String customerId;
	private String invoiceId;
	private List<DocumentDownloadBO> downloadDocumentBOList;
	private String totalOrderValue;
	private String totalDiscount;
	
	public String getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getMsLink() {
		return msLink;
	}
	public void setMsLink(String msLink) {
		this.msLink = msLink;
	}
	public String getFaaLink() {
		return faaLink;
	}
	public void setFaaLink(String faaLink) {
		this.faaLink = faaLink;
	}
	public String getAwbLink() {
		return awbLink;
	}
	public void setAwbLink(String awbLink) {
		this.awbLink = awbLink;
	}
	public String getReturnServiceProvider() {
		return returnServiceProvider;
	}
	public void setReturnServiceProvider(String returnServiceProvider) {
		this.returnServiceProvider = returnServiceProvider;
	}
	public String getWarehouse() {
		return warehouse;
	}
	public void setWarehouse(String warehouse) {
		this.warehouse = warehouse;
	}
	public String getShipToLocation() {
		return shipToLocation;
	}
	public void setShipToLocation(String shipToLocation) {
		this.shipToLocation = shipToLocation;
	}
	public String getShipToAddress_1() {
		return shipToAddress_1;
	}
	public void setShipToAddress_1(String shipToAddress_1) {
		this.shipToAddress_1 = shipToAddress_1;
	}
	public String getShipToAddress_2() {
		return shipToAddress_2;
	}
	public void setShipToAddress_2(String shipToAddress_2) {
		this.shipToAddress_2 = shipToAddress_2;
	}
	public String getShipToAddress_3() {
		return shipToAddress_3;
	}
	public void setShipToAddress_3(String shipToAddress_3) {
		this.shipToAddress_3 = shipToAddress_3;
	}
	public String getShipToAddress_4() {
		return shipToAddress_4;
	}
	public void setShipToAddress_4(String shipToAddress_4) {
		this.shipToAddress_4 = shipToAddress_4;
	}
	public String getShipToAddress_5() {
		return shipToAddress_5;
	}
	public void setShipToAddress_5(String shipToAddress_5) {
		this.shipToAddress_5 = shipToAddress_5;
	}
	public String getDeliverToLocation() {
		return deliverToLocation;
	}
	public void setDeliverToLocation(String deliverToLocation) {
		this.deliverToLocation = deliverToLocation;
	}
	public String getDeliverToAddress_1() {
		return deliverToAddress_1;
	}
	public void setDeliverToAddress_1(String deliverToAddress_1) {
		this.deliverToAddress_1 = deliverToAddress_1;
	}
	public String getDeliverToAddress_2() {
		return deliverToAddress_2;
	}
	public void setDeliverToAddress_2(String deliverToAddress_2) {
		this.deliverToAddress_2 = deliverToAddress_2;
	}
	public String getDeliverToAddress_3() {
		return deliverToAddress_3;
	}
	public void setDeliverToAddress_3(String deliverToAddress_3) {
		this.deliverToAddress_3 = deliverToAddress_3;
	}
	public String getDeliverToAddress_4() {
		return deliverToAddress_4;
	}
	public void setDeliverToAddress_4(String deliverToAddress_4) {
		this.deliverToAddress_4 = deliverToAddress_4;
	}
	public String getDeliverToAddress_5() {
		return deliverToAddress_5;
	}
	public void setDeliverToAddress_5(String deliverToAddress_5) {
		this.deliverToAddress_5 = deliverToAddress_5;
	}
	public String getAirWayBillNumber() {
		return airWayBillNumber;
	}
	public void setAirWayBillNumber(String airWayBillNumber) {
		this.airWayBillNumber = airWayBillNumber;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getInvoiceLink() {
		return invoiceLink;
	}
	public void setInvoiceLink(String invoiceLink) {
		this.invoiceLink = invoiceLink;
	}
	public String getInvoiceTotalAmount() {
		return invoiceTotalAmount;
	}
	public void setInvoiceTotalAmount(String invoiceTotalAmount) {
		this.invoiceTotalAmount = invoiceTotalAmount;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getOrderedDate() {
		return orderedDate;
	}
	public void setOrderedDate(String orderedDate) {
		this.orderedDate = orderedDate;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getCustomerPONumber() {
		return customerPONumber;
	}
	public void setCustomerPONumber(String customerPONumber) {
		this.customerPONumber = customerPONumber;
	}
	public String getSupplierCode() {
		return supplierCode;
	}
	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}
	public String getShipmentDate() {
		return shipmentDate;
	}
	public void setShipmentDate(String shipmentDate) {
		this.shipmentDate = shipmentDate;
	}
	public String getBillOfLadding() {
		return billOfLadding;
	}
	public void setBillOfLadding(String billOfLadding) {
		this.billOfLadding = billOfLadding;
	}
	public String getWarehouseCode() {
		return warehouseCode;
	}
	public void setWarehouseCode(String warehouseCode) {
		this.warehouseCode = warehouseCode;
	}
	public String getInvoiceToLocation() {
		return invoiceToLocation;
	}
	public void setInvoiceToLocation(String invoiceToLocation) {
		this.invoiceToLocation = invoiceToLocation;
	}
	public String getInvoiceToAddress_1() {
		return invoiceToAddress_1;
	}
	public void setInvoiceToAddress_1(String invoiceToAddress_1) {
		this.invoiceToAddress_1 = invoiceToAddress_1;
	}
	public String getInvoiceToAddress_2() {
		return invoiceToAddress_2;
	}
	public void setInvoiceToAddress_2(String invoiceToAddress_2) {
		this.invoiceToAddress_2 = invoiceToAddress_2;
	}
	public String getInvoiceToAddress_3() {
		return invoiceToAddress_3;
	}
	public void setInvoiceToAddress_3(String invoiceToAddress_3) {
		this.invoiceToAddress_3 = invoiceToAddress_3;
	}
	public String getInvoiceToAddress_4() {
		return invoiceToAddress_4;
	}
	public void setInvoiceToAddress_4(String invoiceToAddress_4) {
		this.invoiceToAddress_4 = invoiceToAddress_4;
	}
	public String getInvoiceToAddress_5() {
		return invoiceToAddress_5;
	}
	public void setInvoiceToAddress_5(String invoiceToAddress_5) {
		this.invoiceToAddress_5 = invoiceToAddress_5;
	}
	@JsonProperty("DocumentDownloadBO")
	public List<DocumentDownloadBO> getDownloadDocumentBOList() {
		return downloadDocumentBOList;
	}
	public void setDownloadDocumentBOList(
			List<DocumentDownloadBO> downloadDocumentBOList) {
		this.downloadDocumentBOList = downloadDocumentBOList;
	}
	
	@JsonProperty("totalOrderValue")
	public String getTotalOrderValue() {
		return totalOrderValue;
	}
	@JsonProperty("totalOrderValue")
	public void setTotalOrderValue(String totalOrderValue) {
		this.totalOrderValue = totalOrderValue;
	}
	@JsonProperty("totalDiscount")
	public String getTotalDiscount() {
		return totalDiscount;
	}
	@JsonProperty("totalDiscount")
	public void setTotalDiscount(String totalDiscount) {
		this.totalDiscount = totalDiscount;
	}

}
