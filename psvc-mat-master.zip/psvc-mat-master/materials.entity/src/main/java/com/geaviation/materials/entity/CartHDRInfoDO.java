package com.geaviation.materials.entity;

import org.codehaus.jackson.annotate.JsonProperty;

public class CartHDRInfoDO {
	@JsonProperty("cartHeaderId")
	private String cartHeaderId;
	@JsonProperty("purchaseOrderNumber")
	private String purchaseOrderNumber;
	@JsonProperty("requestedDaysToAdd")
	private String requestedDaysToAdd;
	@JsonProperty("customerId")
	private String customerId;
	@JsonProperty("customerCode")
	private String customerCode;
	@JsonProperty("supplierDescription")
	private String supplierDescription;
	@JsonProperty("supplierCode")
	private String supplierCode;
	@JsonProperty("purchaseOrderValue")
	private String purchaseOrderValue;
	//Added to fix JIRA 8480
	@JsonProperty("orderHeaderDate")
	private String orderHeaderDate;
	@JsonProperty("orderPriority")
	private String orderPriority;
	public String getPurchaseOrderValue() {
		return purchaseOrderValue;
	}
	public void setPurchaseOrderValue(String purchaseOrderValue) {
		this.purchaseOrderValue = purchaseOrderValue;
	}
	public String getCartHeaderId() {
		return cartHeaderId;
	}
	public void setCartHeaderId(String cartHeaderId) {
		this.cartHeaderId = cartHeaderId;
	}
	public String getPurchaseOrderNumber() {
		return purchaseOrderNumber;
	}
	public void setPurchaseOrderNumber(String purchaseOrderNumber) {
		this.purchaseOrderNumber = purchaseOrderNumber;
	}
	public String getRequestedDaysToAdd() {
		return requestedDaysToAdd;
	}
	public void setRequestedDaysToAdd(String requestedDaysToAdd) {
		this.requestedDaysToAdd = requestedDaysToAdd;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getSupplierDescription() {
		return supplierDescription;
	}
	public void setSupplierDescription(String supplierDescription) {
		this.supplierDescription = supplierDescription;
	}
	public String getSupplierCode() {
		return supplierCode;
	}
	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}
	public String getOrderHeaderDate() {
		return orderHeaderDate;
	}
	public void setOrderHeaderDate(String orderHeaderDate) {
		this.orderHeaderDate = orderHeaderDate;
	}
	public String getOrderPriority() {
		return orderPriority;
	}
	public void setOrderPriority(String orderPriority) {
		this.orderPriority = orderPriority;
	}

}
