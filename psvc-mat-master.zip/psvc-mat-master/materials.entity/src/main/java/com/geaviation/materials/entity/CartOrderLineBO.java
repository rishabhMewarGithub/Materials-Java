package com.geaviation.materials.entity;
import javax.annotation.Generated;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({"cartLineId","partNumber","quantity","upq","leadTime","partDescription","unitPrice",
	"extendedPrice","inventoryItemId","customerPurchaseOrderLineNumber","orderLinePriority","orderLineRequestedDate","discountPrice","netPrice","kitIndicator","orderLineESN"})
public class CartOrderLineBO {
	@JsonProperty("cartLineId")
	private String cartLineId;
	@JsonProperty("partNumber")
	private String partNumber;
	@JsonProperty("quantity")
	private String quantity;
	@JsonProperty("upq")
	private String upq;
	@JsonProperty("leadTime")
	private String leadTime;
	@JsonProperty("partDescription")
	private String partDescription;
	@JsonProperty("unitPrice")
	private String unitPrice;
	@JsonProperty("extendedPrice")
	private String extendedPrice;
	@JsonProperty("inventoryItemId")
	private String inventoryItemId;
	@JsonProperty("customerPurchaseOrderLineNumber")
	private String customerPurchaseOrderLineNumber;
	@JsonProperty("orderLinePriority")
	private String orderLinePriority;
	@JsonProperty("orderLineRequestedDate")
	private String orderLineRequestedDate;
	
	//Added for JIRA 5952
	@JsonProperty("discountPrice")
	private String discountPrice;
	@JsonProperty("netPrice")
	private String netPrice;
	//Added to fix JIRA 6162
	@JsonProperty("kitIndicator")
	private String kitIndicator;
	//Added JIRA 8723
	@JsonProperty("orderLineESN")
	private String orderLineESN;
	
	@JsonProperty("orderLineWorkStopDate")
	private String orderLineWorkStopDate;
	
	@JsonProperty("orderLineWorkStopQuantity")
	private String orderLineWorkStopQuantity;
		
	public String getOrderLineWorkStopDate() {
		return orderLineWorkStopDate;
	}
	public void setOrderLineWorkStopDate(String orderLineWorkStopDate) {
		this.orderLineWorkStopDate = orderLineWorkStopDate;
	}
	public String getOrderLineWorkStopQuantity() {
		return orderLineWorkStopQuantity;
	}
	public void setOrderLineWorkStopQuantity(String orderLineWorkStopQuantity) {
		this.orderLineWorkStopQuantity = orderLineWorkStopQuantity;
	}
	public String getOrderLineRequestedDate() {
		return orderLineRequestedDate;
	}
	public void setOrderLineRequestedDate(String orderLineRequestedDate) {
		this.orderLineRequestedDate = orderLineRequestedDate;
	}
	public String getOrderLinePriority() {
		return orderLinePriority;
	}
	public void setOrderLinePriority(String orderLinePriority) {
		this.orderLinePriority = orderLinePriority;
	}
	public String getCustomerPurchaseOrderLineNumber() {
		return customerPurchaseOrderLineNumber;
	}
	public void setCustomerPurchaseOrderLineNumber(
			String customerPurchaseOrderLineNumber) {
		this.customerPurchaseOrderLineNumber = customerPurchaseOrderLineNumber;
	}
	public String getInventoryItemId() {
		return inventoryItemId;
	}
	public void setInventoryItemId(String inventoryItemId) {
		this.inventoryItemId = inventoryItemId;
	}
	public String getCartLineId() {
		return cartLineId;
	}
	public void setCartLineId(String cartLineId) {
		this.cartLineId = cartLineId;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getUpq() {
		return upq;
	}
	public void setUpq(String upq) {
		this.upq = upq;
	}
	public String getLeadTime() {
		return leadTime;
	}
	public void setLeadTime(String leadTime) {
		this.leadTime = leadTime;
	}
	public String getPartDescription() {
		return partDescription;
	}
	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}
	public String getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}
	public String getExtendedPrice() {
		return extendedPrice;
	}
	public void setExtendedPrice(String extendedPrice) {
		this.extendedPrice = extendedPrice;
	}
	public String getDiscountPrice() {
		return discountPrice;
	}
	public void setDiscountPrice(String discountPrice) {
		this.discountPrice = discountPrice;
	}
	public String getNetPrice() {
		return netPrice;
	}
	public void setNetPrice(String netPrice) {
		this.netPrice = netPrice;
	}
	public String getKitIndicator() {
		return kitIndicator;
	}
	public void setKitIndicator(String kitIndicator) {
		this.kitIndicator = kitIndicator;
	}
	public String getOrderLineESN() {
		return orderLineESN;
	}
	public void setOrderLineESN(String orderLineESN) {
		this.orderLineESN = orderLineESN;
	}	
}
