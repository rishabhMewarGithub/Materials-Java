/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016   
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     DisputeOrderInput.java
 * 
 * History        :  	Sep 25, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.entity;

import java.util.Arrays;

/**
 * @author 720053
 *
 */
public class DisputeOrderInput {
	private String orderHeaderId;
	private String lineId;
	private String disputeReason;
	private String serialNumberSelectedSerialNumber;
	private String serialNumberReceivedSerialNumber;
	private String discrepancyPartNumberReceived;
	private String discrepancyQuantityReceived;
	private Boolean addToCartFlag;
	private String addToCartFlagString;
	private String underShipmentQuantityReceived;
	private String overShipmentQuantityReceived;
	private String buyBackRequestedBy;
	private String buyBackRequestedQuantity;
	private String buyBackValue;
	private String pricingErrorExpectedUnitPrice;
	private String disputeComments;
	private String disputeRequestDays;
	private String fileName;
	private byte[] fileData;
	private String customerId;
	
	private String sso;
	private String portalId;
	private String icao;
	private String[] custIdArray;
	private String role;
	private String operatingUnitId;
	public String getOrderHeaderId() {
		return orderHeaderId;
	}
	public void setOrderHeaderId(String orderHeaderId) {
		this.orderHeaderId = orderHeaderId;
	}
	public String getLineId() {
		return lineId;
	}
	public void setLineId(String lineId) {
		this.lineId = lineId;
	}
	public String getDisputeReason() {
		return disputeReason;
	}
	public void setDisputeReason(String disputeReason) {
		this.disputeReason = disputeReason;
	}
	
	public String getSerialNumberSelectedSerialNumber() {
		return serialNumberSelectedSerialNumber;
	}
	public void setSerialNumberSelectedSerialNumber(
			String serialNumberSelectedSerialNumber) {
		this.serialNumberSelectedSerialNumber = serialNumberSelectedSerialNumber;
	}
	public String getSerialNumberReceivedSerialNumber() {
		return serialNumberReceivedSerialNumber;
	}
	public void setSerialNumberReceivedSerialNumber(
			String serialNumberReceivedSerialNumber) {
		this.serialNumberReceivedSerialNumber = serialNumberReceivedSerialNumber;
	}
	public String getDiscrepancyPartNumberReceived() {
		return discrepancyPartNumberReceived;
	}
	public void setDiscrepancyPartNumberReceived(
			String discrepancyPartNumberReceived) {
		this.discrepancyPartNumberReceived = discrepancyPartNumberReceived;
	}
	public String getDiscrepancyQuantityReceived() {
		return discrepancyQuantityReceived;
	}
	public void setDiscrepancyQuantityReceived(String discrepancyQuantityReceived) {
		this.discrepancyQuantityReceived = discrepancyQuantityReceived;
	}
	public Boolean getAddToCartFlag() {
		return addToCartFlag;
	}
	public void setAddToCartFlag(Boolean addToCartFlag) {
		this.addToCartFlag = addToCartFlag;
	}
	
	public String getAddToCartFlagString() {
		return addToCartFlagString;
	}
	public void setAddToCartFlagString(String addToCartFlagString) {
		this.addToCartFlagString = addToCartFlagString;
	}
	public String getUnderShipmentQuantityReceived() {
		return underShipmentQuantityReceived;
	}
	public void setUnderShipmentQuantityReceived(
			String underShipmentQuantityReceived) {
		this.underShipmentQuantityReceived = underShipmentQuantityReceived;
	}
	public String getOverShipmentQuantityReceived() {
		return overShipmentQuantityReceived;
	}
	public void setOverShipmentQuantityReceived(String overShipmentQuantityReceived) {
		this.overShipmentQuantityReceived = overShipmentQuantityReceived;
	}
	public String getBuyBackRequestedBy() {
		return buyBackRequestedBy;
	}
	public void setBuyBackRequestedBy(String buyBackRequestedBy) {
		this.buyBackRequestedBy = buyBackRequestedBy;
	}
	public String getBuyBackRequestedQuantity() {
		return buyBackRequestedQuantity;
	}
	public void setBuyBackRequestedQuantity(String buyBackRequestedQuantity) {
		this.buyBackRequestedQuantity = buyBackRequestedQuantity;
	}
	public String getBuyBackValue() {
		return buyBackValue;
	}
	public void setBuyBackValue(String buyBackValue) {
		this.buyBackValue = buyBackValue;
	}
	public String getPricingErrorExpectedUnitPrice() {
		return pricingErrorExpectedUnitPrice;
	}
	public void setPricingErrorExpectedUnitPrice(
			String pricingErrorExpectedUnitPrice) {
		this.pricingErrorExpectedUnitPrice = pricingErrorExpectedUnitPrice;
	}
	public String getDisputeComments() {
		return disputeComments;
	}
	public void setDisputeComments(String disputeComments) {
		this.disputeComments = disputeComments;
	}
	public String getDisputeRequestDays() {
		return disputeRequestDays;
	}
	public void setDisputeRequestDays(String disputeRequestDays) {
		this.disputeRequestDays = disputeRequestDays;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getSso() {
		return sso;
	}
	public void setSso(String sso) {
		this.sso = sso;
	}
	public String getPortalId() {
		return portalId;
	}
	public void setPortalId(String portalId) {
		this.portalId = portalId;
	}
	public String getIcao() {
		return icao;
	}
	public void setIcao(String icao) {
		this.icao = icao;
	}
	public String[] getCustIdArray() {
		return custIdArray;
	}
	public void setCustIdArray(String[] custIdArrayNew) {
		if (custIdArrayNew == null) {
			this.custIdArray = new String[0];
		} else {
			this.custIdArray = Arrays.copyOf(custIdArrayNew, custIdArrayNew.length);
		}
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getOperatingUnitId() {
		return operatingUnitId;
	}
	public void setOperatingUnitId(String operatingUnitId) {
		this.operatingUnitId = operatingUnitId;
	}
	public byte[] getFileData() {
		return fileData;
	}
	public void setFileData(byte[] fileData) {
		this.fileData = fileData;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	
	
}
