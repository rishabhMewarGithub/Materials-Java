package com.geaviation.materials.entity;

import java.util.Comparator;

import com.geaviation.materials.entity.Pricing;

public class RevisionDateDescComparator implements Comparator<Pricing> {
	 public int compare(Pricing pricingCatDO1, Pricing pricingCatDO2) {
		 boolean isStrDate0Empty = (pricingCatDO2.getRevisionDate() == null || pricingCatDO2.getRevisionDate().isEmpty());
		    boolean isStrDate1Empty = (pricingCatDO1.getRevisionDate() == null || pricingCatDO1.getRevisionDate().isEmpty());

		    if (isStrDate0Empty && isStrDate1Empty)
		        return 0;
		    // at least one of them is not empty    
		    if (isStrDate0Empty)
		        return -1;
		    if (isStrDate1Empty)
		        return 1;
		    //none of them is empty
		  return pricingCatDO2.getRevisionDate().compareTo(pricingCatDO1.getRevisionDate());
	    }
}
