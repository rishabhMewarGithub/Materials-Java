package com.geaviation.materials.entity;

import javax.annotation.Generated;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;
import org.codehaus.jackson.map.annotate.JsonSerialize;
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({"cartLineId","statusMessage","lineNumber","partNumber","keyword","orderedQuantity","requestDate","unitListPrice","discountPercent","externalPrice"})
public class OrderLineMessageBO {
	private int id;
	@JsonProperty("cartLineId")
	private String  cartLineId;
	@JsonProperty("statusMessage")
	private String  statusMessage;
	
	@JsonProperty("lineNumber")
	private String lineNumber;
	
	@JsonProperty("partNumber")
	private String partNumber;
	
	@JsonProperty("keyword")
	private String keyword;
	
	@JsonProperty("orderedQuantity")
	private String orderedQuantity;
	
	@JsonProperty("criticalPartFlag")
	private Boolean criticalPartFlag;
	@JsonProperty("requestDate")
	private String requestDate;

	@JsonProperty("unitListPrice")
	private String unitListPrice;
	
	@JsonProperty("discountPercent")
	private String discountPercent;
	
	@JsonProperty("unitSellingPrice")
	private String unitSellingPrice;
	
	@JsonProperty("externalPrice")
	private String externalPrice;
	
/*	@JsonProperty("success")
	private boolean  success;*/
	@JsonProperty("statusMessage")
	public String getStatusMessage() {
		return statusMessage;
	}
	@JsonProperty("statusMessage")
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	/*@JsonProperty("success")
	public boolean isSuccess() {
		return success;
	}
	@JsonProperty("success")
	public void setSuccess(boolean success) {
		this.success = success;
	}*/
	@JsonProperty("cartLineId")
	public String getCartLineId() {
		return cartLineId;
	}
	@JsonProperty("cartLineId")
	public void setCartLineId(String cartLineId) {
		this.cartLineId = cartLineId;
	}
	   @Override
	    public boolean equals(Object obj) {
	         if (obj == this){
	            return true;
	        }
	        if (obj == null || obj.getClass() != this.getClass()){
	            return false;
	        }

	        OrderLineMessageBO orderLineMessageBO = (OrderLineMessageBO) obj;
	        return id == orderLineMessageBO.id
	                 &&(cartLineId == orderLineMessageBO.cartLineId
	                     || (cartLineId != null && cartLineId.equals(orderLineMessageBO.getCartLineId())))
	                 &&(statusMessage == orderLineMessageBO.statusMessage
	                     || (statusMessage != null && statusMessage .equals(orderLineMessageBO.getStatusMessage())));
	    }
	  @Override 
	  public int hashCode() {
	         final int prime = 31;
	        int result = 1;
	        result = prime * result
	                + ((cartLineId == null) ? 0 : cartLineId.hashCode());
	        result = prime * result + id;
	         result = prime * result
	                + ((statusMessage == null)? 0 : statusMessage.hashCode());
	        return result;
	     }
	@JsonProperty("lineNumber")
	public String getLineNumber() {
		return lineNumber;
	}
	@JsonProperty("lineNumber")
	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}
	@JsonProperty("partNumber")
	public String getPartNumber() {
		return partNumber;
	}
	@JsonProperty("partNumber")
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	@JsonProperty("keyword")
	public String getKeyword() {
		return keyword;
	}
	@JsonProperty("keyword")
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	@JsonProperty("orderedQuantity")
	public String getOrderedQuantity() {
		return orderedQuantity;
	}
	@JsonProperty("orderedQuantity")
	public void setOrderedQuantity(String orderedQuantity) {
		this.orderedQuantity = orderedQuantity;
	}
	@JsonProperty("requestDate")
	public String getRequestDate() {
		return requestDate;
	}
	@JsonProperty("requestDate")
	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}
	@JsonProperty("unitListPrice")
	public String getUnitListPrice() {
		return unitListPrice;
	}
	@JsonProperty("unitListPrice")
	public void setUnitListPrice(String unitListPrice) {
		this.unitListPrice = unitListPrice;
	}
	@JsonProperty("unitSellingPrice")
	public String getUnitSellingPrice() {
		return unitSellingPrice;
	}
	@JsonProperty("unitSellingPrice")
	public void setUnitSellingPrice(String unitSellingPrice) {
		this.unitSellingPrice = unitSellingPrice;
	}
	@JsonProperty("discountPercent")
	public String getDiscountPercent() {
		return discountPercent;
	}
	@JsonProperty("discountPercent")
	public void setDiscountPercent(String discountPercent) {
		this.discountPercent = discountPercent;
	}
	@JsonProperty("externalPrice")
	public String getExternalPrice() {
		return externalPrice;
	}
	@JsonProperty("externalPrice")
	public void setExternalPrice(String externalPrice) {
		this.externalPrice = externalPrice;
	}
	public Boolean getCriticalPartFlag() {
		return criticalPartFlag;
	}
	public void setCriticalPartFlag(Boolean criticalPartFlag) {
		this.criticalPartFlag = criticalPartFlag;
	}
	  
}
