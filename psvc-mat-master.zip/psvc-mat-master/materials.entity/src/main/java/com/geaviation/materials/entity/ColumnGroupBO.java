package com.geaviation.materials.entity;

import java.util.List;

public class ColumnGroupBO {
	
	private String groupName;
	private List<String> columnIds;

	public List<String> getColumnIds() {
		return columnIds;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public void setColumnIds(List<String> columnIds) {
		this.columnIds = columnIds;
	}
	

}
