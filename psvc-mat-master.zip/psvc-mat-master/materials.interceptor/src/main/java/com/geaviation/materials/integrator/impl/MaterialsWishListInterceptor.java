package com.geaviation.materials.integrator.impl;

import java.util.List;

import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.geaviation.materials.app.api.IMaterialsWishListApp;
import com.geaviation.materials.entity.BulkAddPartBO;
import com.geaviation.materials.entity.DeleteWishListBO;
import com.geaviation.materials.entity.InsertWishListResponse;
import com.geaviation.materials.entity.OrderStatusBO;
import com.geaviation.materials.entity.WishListDetailsBO;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.integrator.api.IMaterialsWishListInterceptor;

@Component
public class MaterialsWishListInterceptor implements IMaterialsWishListInterceptor {

	private static final Log log = LogFactory.getLog(MaterialsInterceptor.class);
	
	@Autowired
	private IMaterialsWishListApp materialsWishListApp;
	
	@Override
	public Response insertWishListBS( String strSSO,
			String portalId,String partNumber) throws MaterialsException {
		log.info("Start ..  insert WishList");

		InsertWishListResponse insertWishListResponse = null;


		insertWishListResponse =  materialsWishListApp.insertWishListBS(strSSO, portalId,partNumber);
		return Response.ok(insertWishListResponse).build();
	}

	@Override
	public Response getWishListDetailsBS(String strSSO, String portalId) throws MaterialsException{
		List<WishListDetailsBO> wishListDetailsBO = null;


		wishListDetailsBO =  materialsWishListApp.getWishListDetailsBS( strSSO, portalId);
	return Response.ok(wishListDetailsBO).build();
	}

	@Override
	public Response deleteWishListBS(String strSSO, String portalId,String partNumber)
			throws MaterialsException {
	//	WishListStatusBO statusBO = null;
		List<DeleteWishListBO> deleteWishListBO = null;


		deleteWishListBO =  materialsWishListApp.deleteWishListBS(strSSO, portalId,partNumber);
		return Response.ok(deleteWishListBO).build();
	}

	@Override
	public Response wishLstToSaveLstBS(String strSSO, String portalId,
			List<BulkAddPartBO> partnumberLst) throws MaterialsException {
		  OrderStatusBO orderStatusBO = null;
		  orderStatusBO  = materialsWishListApp.wishLstToSaveLstBS(strSSO, portalId, partnumberLst);
		  return Response.ok(orderStatusBO).build();
		 
	}

}
