/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Feb 24, 2016
 * Description    :     MaterialsInterceptorConstants.java
 * 
 * History        :  	Aug 18, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.integrator.impl.util;

public class MaterialsInterceptorConstants {
	
	public static final String  DESC_MESSAGE = "Problem occured while calling the Snecma SOAP web service : ";
	public static final String  INC_DESC_MESSAGE = "This functionality is not available for INC user";
	public static final String  SNECMA_DESC_MESSAGE = "This functionality is not available for Snecma user";
	public static final String SA_INC_ATTR_MESSAGE = "SA and INC attribute missing";
	public static final String PORTAL_SERVICE_IS_NOT_AVAILABLE = "Portal service is not available";
	public static final String ERR_FOLDER_DOES_NOT_EXIST = "Folder does not exist";
	public static final String ERR_DOCUMENT_NOT_FOUND = "Document not Found";
	public static final String  DESC_ATTIVIO_ACCESS = "Attivio Access not found for Materials";
	
	public static final String ERR_MESSAGE_RB = "errorMessage";
	public static final String EMPTY_STRING = "";
	public static final String UNKNOWN_ERROR = "UNKNOWN_ERROR";
	public static final String AOC = "AOC";
	public static final String AOC_PLACEHOLDER = "##AOC##";
	public static final String  BUYER = "Buyer";
	public static final String  GLOBAL_ENQUIRY = "Global Enquiry";
	public static final String  CUST_ENQUIRY = "Cust Enquiry";
	public static final String  CFM_BUYER = "MYCFMMATPUR";
	public static final String  CFM_ENQUIRY = "MYCFMMATREQ";
	
	public static final String MATERIAL_URL = "/services/materials/getPricingCatalogDocBS?platform=";
	public static final String DOC_TYPE = "&docType=";
	public static final String ASC = "asc";
	public static final String MDATA_PROP= "mDataProp_";
	public static final String SSORTDIR_0 = "sSortDir_0";
	public static final String IDISPLAY_START = "iDisplayStart";
	public static final String IDISPLAY_LENGTH = "iDisplayLength";
	public static final String SECHO = "sEcho";
	public static final String ISORTCOL_0 = "iSortCol_0";
	public static final String PLATFORM = "platform";
	public static final String EFFDATE = "effDt";
	public static final String REVISION_DATE = "revisionDate";
	public static final String CATALOG_LINK = "catalogLink";
	public static final String ENGINE_MODEL = "engineModel";
	public static final String SA_PRICECATALOGS_PATH ="/SAPriceCatalogs/";
	
	public static final String RATING_PLUG_DETAILS = "v1/getRatingPlugDetails";
	public static final String COMMERCIAL_AGREEMENT = "omcustomerdata/v1/getAgreementPart";
	public static final String GET_PO_QUOTATIONS = "podetails/v1/getPoQuotations";
	public static final String KIT_STRUCTURE = "ompartdetails/v1/getKitDetails";
	public static final String DELETE_PO_LINE = "podetails/v1/deletePoLine";
	public static final String MATERIALS_DOCUMENT = "podetails/v1/getPoDocument";
	public static final String GET_PO_DETAILS = "podetails/v1/getPoDetails";
	public static final String DELETE_CART = "omcart/v1/deleteCart";
	public static final String DELETE_CART_LINE = "omcart/v1/deleteCartLine";
	public static final String GET_ORDER_TEMPLATE = "omcart/soapatt/v1";
	public static final String GET_LINE_STATUS_HISTORY = "podetails/v1/getPoLineStatusHistory";
	public static final String GET_LINE_DETAILS = "podetails/v1/getPoLineDetails";
	public static final String UPDATE_ORDER = "podetails/v1/putPoDetails";
	public static final String GET_BULK_BUY = "omcart/soapatt/v1";
	
	public static final String SHIP_TO_MART_FOR_ADDRESS = "omcustomerdata/v1/getAddress";
	public static final String GET_COMMERCIAL_AGGREMENT = "omcustomerdata/v1/getAgreements";
	public static final String GET_COMMERCIAL_AGGREMENT_PART = "omcustomerdata/v1/getAgreementPart";
	public static final String RATING_PLUGIN = "rfqidp/v1/getRatingPlugDetails";
	public static final String GET_RATING_PLUGIN_FORM = "rfqidp/v1/getRatingPlugDetailsView";
	public static final String GET_RFQ = "rfqidp/v1/getRFQ";
	public static final String GET_RFQ_DETAILS = "rfqidp/v1/getRFQDetails";
	public static final String LIST_RFQ = "rfqidp/v1/getRFQView";
	public static final String CREATYE_RATING_PLUGIN = "rfqidp/v1/putRatingPlugDetails";
	public static final String CREATE_RFQ = "rfqidp/v1/putRFQ";
	
	public static final String GET_PART_CONF = "ompartdetails/v1/getPartConf";
	public static final String GET_PART_DETAILS = "ompartdetails/v1/getPartDetails";
	public static final String GET_CART_CONTENTS = "omcart/v1/getCartContents";
	public static final String GET_CART_COUNT = "omcart/v1/getCartCount";
	public static final String PUT_CART_ADD_ITEM = "omcart/v1/putCartAddItem";
	public static final String PUT_CART_ORDER = "omcart/v1/putCartOrder";
	public static final String GET_PO_LIST = "ompolist/v1/getPoList";
	public static final String GET_AUTHENTIFICATION = "userinfo/v1/getAuthentification";
	public static final String GET_CUSTOMER_DETAILS = "omcustomerdata/v1/getCustomerDetails";
	public static final String SAVE_CART = "omcart/v1/putCartSave";
	public static final String UPLOAD_ORDER_TEMPLATE = "omcart/v1/putBulkBuy";
	public static final String GET_COMPANYINFO = "TpaCompanyInfoService/v1/getCompanyInfo";
	

    public static final String ERR_DATATABLE_ERROR_OCCURED = "Error occured while reading datatable values";
    public static final String ERR_DATATABLE_DISPLAY_ERROR_OCCURED = "iDisplayStart should be less than total number of records";
    public static final String ERR_DOCUMENTS_NOT_FOUND = "Documents not Found";

    public static final String HTML_MSG1 = " <html> <head> <meta charset='UTF-8'> <meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'> <meta name='viewport' content='width=device-width'> <title>myGEAviation Customer Portal | Simple. Effective. Yours.</title> <link id='theme' href='../../portal/static/ge_ux/css/iids.min.css' rel='stylesheet'> <link href='../../custom-login/cwcbb-custom-login.css' rel='stylesheet'> <script type='text/javascript' src='../../portal/static/ge.com.2013/components/jquery/jquery.min.js'></script> <script language=javascript> function window_onload() { var numRand = Math.floor(Math.random()*6)+1; $('#login-header').css('background', 'url(\"../../custom-login/img/login-bg-'+numRand+'-cropped.jpg\") no-repeat');} </script> </head> <body onload='javascript:window_onload();'> <div class='container maincontent'> <div id='login-header'> <div class='navbar'> <div class='masthead navbar-inner'> <div class='container'> <a class='brand' href='#'> <span class='ge-logo ge-logo-large'>General Electric</span> <div class='pull-left'><h2><span class='text-info'>my</span>GEAviation</h2> Simple. Effective. Yours.</div></a></div></div></div></div><div id='content' class='container'><div class='page-header'><h1 class='voice voice-brand' id='error_title'>Uh oh!</h1> <p id='error_message'>";
    public static final String HTML_MSG2 = "</p></div> <table id='help'> <thead><h2 class='voice-brand'>Contact Information</h2></thead> <tbody class='voice-brand'><tr><td> <h3>Aviation Operations Center - Cincinnati</h3><h3>Toll-free: +1 (877) 432-3272</h3> <h3>Phone: +1 (513) 552-3272</h3><h3>Email: <a href='mailto:geae.aoc@ge.com'>geae.aoc@ge.com</a></h3></td><td><h3>Aviation Operations Center - Shanghai</h3><h3>Phone: +86-400-820-6208</h3><h3>Fax: +86-21-38777666</h3><h3>Email: <a href='mailto:geae.choc@ge.com'>geae.choc@ge.com</a></h3></td><td><h3>Bizjet Operations Center</h3><h3>Toll-free: +1 (877) 456-JETS (5387)</h3><h3>Phone: +1 (513) 552-JETS (5387)</h3><h3>Email: <a href='mailto:bizjetops@ge.com'>bizjetops@ge.com</a></h3></td> </tr> </tbody></table></div><div class='navbar'><div class='masthead navbar-inner'><div class='container'><div class='brand logo'><span class='ge-logo'>General Electric</span> GE Aviation</div><div class='footer-links'><a data-toggle='modal' href='#cookies-modal'>Read about how we use cookies</a></div>    </div>    <div class='container'><h6>THIS SITE CONTAINS GE PROPRIETARY INFORMATION</h6>    <p>WARNING: The information contained in this site is GE proprietary information and is disclosed in confidence. It is the property of GE and shall not be used, disclosed to others or reproduced without the express written consent of GE, including, but without limitation, it is not to be used in the creation, manufacture, development, or derivation of any repairs, modifications, spare parts, designs, or configuration changes or to obtain FAA or any other government or regulatory approval to do so. If consent is given for reproduction in whole or in part, this notice and the notice set forth on each page of this site shall appear in any such reproduction in whole or in part. The information contained in this site may also be controlled by the U.S. export control laws. Unauthorized export or re-export is prohibited.</p>    </div></div></div></div> <!-- /outer container -->    <div id='cookies-modal' class='modal hide fade' style='display: none;'><div class='modal-header'><button type='button' class='close' data-dismiss='modal'>&times;</button><h3>Cookie Information</h3></div><div class='modal-body'><p>The Privacy and Electronic Communications (EC Directive) Regulations 2003 (the Regulations) cover theuse of cookies and similar technologies for storing information, and accessing information stored, on auserÃ¢â‚¬â„¢s equipment such as their computer or mobile.</p><p>A cookie is a small file, typically of letters and numbers, downloaded on to a device when the useraccesses certain websites. Cookies are then sent back to originating website on each subsequent visit.Cookies are useful because they allow a website to recognize a userÃ¢â‚¬â„¢s device. The Regulations apply tocookies and also to similar technologies for storing information. For more information see:<a href='http://www.allaboutcookies.org'>http://www.allaboutcookies.org</a></p><p>Web Ã¢â‚¬Å“CookiesÃ¢â‚¬ï¿½ are also used within myGEAviation. Session cookies are used to establish the ability to accessmyGEAviation after logging into the website and are used to identify and maintain the user session within myGEAviation. Athird cookie is used to ensure a secure third-party can collect the user data as indicated above.</p></div><div class='modal-footer'><a href='#' class='btn btn-primary' data-dismiss='modal'>Close</a></div>        </div>      </body></html>";
    public static final String ERR_SSO_NOT_FOUND = "SSO ID not found";
	public static final String ERR_PORTAL_ID_NOT_FOUND = "Portal ID not found";
	public static final String ERR_PLATFORM_NOT_FOUND ="No Valid Input to Service-platForm not found";
	public static final String ERR_DOCTYPE_NOT_FOUND="No Valid Input to Service-docType not found";
	public static final String ERR_NO_PLATFORM_AVAIL = "There is no platform available";
	public static final String ERR_ICAOCODE_NOT_FOUND = "ICAO code not found";
	public static final String ERR_DOC_NAME_NOT_FOUND = "Doc name not found";
	
	public static final String  ERROR_CODE_8450 = "8450";
	public static final String  ERROR_CODE_8451 = "8451";
	public static final String  ERROR_CODE_8452 = "8452";
	public static final String  ERROR_CODE_8453 = "8453";
	public static final String  ERROR_CODE_8454 = "8454";
	public static final String  ERROR_CODE_8455 = "8455";
    public static final String  ERROR_CODE_8456 = "8456";
    public static final String  ERROR_CODE_8457 = "8457";
    public static final String  ERROR_CODE_8458 = "8458";
    public static final String  ERROR_CODE_8459 = "8459";
    public static final String  ERROR_CODE_8460 = "8460";
    public static final String  ERROR_CODE_8461 = "8461";
    
    public static final String  ERROR_CODE_8462 = "8462";
    public static final String  ERROR_CODE_8463 = "8463";
    public static final String  ERROR_CODE_8464 = "8464";
    public static final String ERR_COMPANYINFO_INFO_NOT_FOUND = "CompanyInfo not found";
    public static final String ERR_ATTACHMENT_DATA = "Error occurred while fetching Attachment";
    public static final String ISGEAEUSER = "isGEAE User==>";
    public static final String AUTHORIZATION = "Authorization";
    public static final String SMSSO = "SM_SSO";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String CONTENT_ID = "Content-ID";
    public static final String TEXT_XML =  "text/xml";
    public static final String JSON_PATTERN =    "\\{(.*)\\}";
    
    public static final String RETURN = "return";
    public static final String JSON_DATA = "jsonData";
    public static final String HTTP_CODE = "httpCode";
    public static final String CART_HEADER_ID = "cartHeaderId";
    public static final String MS_NUMBER = "msNumber";
    public static final String DELIVERY_ID = "deliveryId";
    public static final String ORDER_HEADER_ID = "orderHeaderId";
    public static final String INVOICE_HEADER_ID = "invoiceHeaderId";
    public static final String INVENTORY_ITEM_ID = "inventoryItemId";
    public static final String XLXS = ".xlsx";
    
    public static final String CONTENT_DISPOSITION =  "content-disposition";
    public static final String ATTACHMENT = "attachment";
    public static final String FILENAME = "filename";
    
   
    
    
    
  
 
	
	private MaterialsInterceptorConstants() {
		
	}
	
}
