/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Aug 18, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Dec 11, 2015
 * Description    :     MaterialsDataTable.java
 * 
 * History        :  	Aug 18, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.integrator.impl.util;

import java.io.Serializable;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * @author 720053
 *
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class MaterialsDataTable<T> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String displayMessage;
	private Integer iTotalDisplayRecords;
	private Integer iTotalRecords;
	private String sEcho;
	private transient List<T> aaData;
	
	
	public String getDisplayMessage() {
		return displayMessage;
	}
	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}
	public Integer getiTotalDisplayRecords() {
		return iTotalDisplayRecords;
	}
	public void setiTotalDisplayRecords(Integer iTotalDisplayRecords) {
		this.iTotalDisplayRecords = iTotalDisplayRecords;
	}
	public Integer getiTotalRecords() {
		return iTotalRecords;
	}
	public void setiTotalRecords(Integer iTotalRecords) {
		this.iTotalRecords = iTotalRecords;
	}
	public String getsEcho() {
		return sEcho;
	}
	public void setsEcho(String sEcho) {
		this.sEcho = sEcho;
	}
	public List<T> getAaData() {
		return aaData;
	}
	public void setAaData(List<T> type) {
		this.aaData = type;
	}
}
