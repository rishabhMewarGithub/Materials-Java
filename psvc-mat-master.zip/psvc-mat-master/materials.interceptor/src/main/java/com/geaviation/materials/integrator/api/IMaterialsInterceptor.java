package com.geaviation.materials.integrator.api;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import com.geaviation.materials.entity.RepairCatalog;
import com.geaviation.materials.exception.MaterialsException;

public interface IMaterialsInterceptor {
	public Response getLineDetailBS(String strSSO, String portalId, MultivaluedMap<String,String> inMap) throws MaterialsException;
     public Response getLineStatusHistoryBS(String strSSO,
                   String portalId,MultivaluedMap<String, String> multiValmap) throws MaterialsException;
     public Response getPricingCatalog(MultivaluedMap<String, String> multiValmap,String strSSO,String portalId) throws MaterialsException;
     public Response getPricingCatalogDocBS(String platform, String doctype,String strSSO,String portalId,String effDate) throws MaterialsException;
     /**
      * Returns Purchase order quotation Details
      * @param strSSO
      * @param portalId
      * @param multiValmap
      * @return Response
      * @throws MaterialsException
      */
      public Response getPoQuotations(String strSSO, String portalId, MultivaluedMap<String, String> multiValmap) throws MaterialsException;
      public Response getShiptoMarkforAddressBS(String strSSO, String portalId,String customerId,String custCode) throws MaterialsException ;
  	 public Response getCustAdminDetailsBS(String strSSO,String portalId,String custId) throws MaterialsException ;

	/**
	 * Get Commercial Agreement
	 * @param strSSO
	 * @param portalId
	 * @param map
	 * @return Response
	 * @throws MaterialsException
	 */
	public Response getCommercialAgreementBS(String strSSO, String portalId, MultivaluedMap<String, String> map)
			throws MaterialsException;

	/**
	 * Get Commercial Agreement Part
	 * @param strSSO
	 * @param portalId
	 * @param multiValmap
	 * @return Response
	 * @throws MaterialsException
	 */
	public Response getCommercialAgreementPartBS(String strSSO, String portalId,
			MultivaluedMap<String, String> multiValmap) throws MaterialsException;

	/**
	 * Get Rating PLug
	 * @param strSSO
	 * @param portalId
	 * @param multiValmap
	 * @return Response
	 * @throws MaterialsException
	 */
	public Response getRatingPlugBS(String strSSO, String portalId, MultivaluedMap<String, String> multiValmap)
			throws MaterialsException;

	/**
	 * Create Rating Plug Form
	 * @param strSSO
	 * @param portalId
	 * @param ratingPlugDetails
	 * @return Response
	 * @throws MaterialsException
	 */
	public Response createRatingPlugFormBS(String strSSO, String portalId, String ratingPlugDetails)
			throws MaterialsException;

	/**
	 * Get Rating Plug Form
	 * @param strSSO
	 * @param portalId
	 * @param map
	 * @return Response
	 * @throws MaterialsException
	 */
	public Response getRatingPlugFormBS(String strSSO, String portalId, MultivaluedMap<String, String> map)
			throws MaterialsException;
    /**
     * @param strSSO
     * @param portalId
     * @param engineModel
     * @return document file as Response
     * @throws MaterialsException
     */
    public Response getRepairCatalogBS(String strSSO,String portalId,String engineModel) throws MaterialsException;
    
    /**
     * @param multiValmap
     * @param strSSO
     * @param portalId
     * @return list of documents file as Response
     * @throws MaterialsException
     */
    public RepairCatalog getRepairCatalogListBS(MultivaluedMap<String, String> multiValmap,String strSSO,String portalId) throws MaterialsException;

}
