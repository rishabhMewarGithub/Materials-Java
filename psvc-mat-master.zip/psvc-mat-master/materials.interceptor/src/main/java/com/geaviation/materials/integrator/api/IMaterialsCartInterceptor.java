package com.geaviation.materials.integrator.api;

import java.util.List;

import javax.ws.rs.core.Response;

import com.geaviation.materials.entity.SaveCartRequestDetails;
import com.geaviation.materials.exception.MaterialsException;

public interface IMaterialsCartInterceptor {

	public Response getCartBS(String strSSO,String portalId,String cartHeaderId) throws MaterialsException;
	public Response deleteCartBS(String strSSO,String portalId,String cartHeaderId) throws MaterialsException;
	public Response getCartCountBS(String strSSO,String portalId) throws MaterialsException;
	public Response deleteCartLineBS(String strSSO,String portalId,String cartHeaderId,String cartLineId) throws MaterialsException;
	public Response saveCartBS(List<SaveCartRequestDetails> saveCartRequestList, String strSSO, String portalId) throws MaterialsException;
	public Response addLineItemBS(String strSSO, String portalId, String inventoryItemId, String selectedCustomerId,
			String selectedSupplierCode, String quantity, String pricingListId, String commercialAgreementNumber,
			String quotationNumber, String quickOrder, String quoteHeaderId) throws MaterialsException;
	/**
     * Returns PurchasePO Details
     * @param strSSO
     * @param portalId
     * @param cartHeaderId
     * @param orderType
     * @return Response
     * @throws MaterialsException
     */
     public Response purchasePOBS(String strSSO, String portalId, String cartHeaderId,String orderType) throws MaterialsException;

}
