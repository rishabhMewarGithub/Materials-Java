package com.geaviation.materials.integrator.impl;

import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8450;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8451;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8457;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ATTACHMENT;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.AUTHORIZATION;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CONTENT_DISPOSITION;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CONTENT_ID;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CONTENT_TYPE;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.DELIVERY_ID;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8450;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8451;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.FILENAME;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.HTTP_CODE;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.INVOICE_HEADER_ID;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ISGEAEUSER;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.JSON_DATA;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.JSON_PATTERN;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.MS_NUMBER;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ORDER_HEADER_ID;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.RETURN;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.SMSSO;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.TEXT_XML;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorUtil.isNotNullandEmpty;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.activation.DataHandler;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.methods.DeleteMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.app.api.IMaterialsOrdersApp;
import com.geaviation.materials.app.api.IMaterialsShipmentApp;
import com.geaviation.materials.entity.DeleteOrderLineBO;
import com.geaviation.materials.entity.DisputeDocumentBO;
import com.geaviation.materials.entity.DisputeOrderInput;
import com.geaviation.materials.entity.DisputeOrderStatusBO;
import com.geaviation.materials.entity.InvoiceDocDO;
import com.geaviation.materials.entity.MaterialsConstants;
import com.geaviation.materials.entity.OrderHeaderDetails;
import com.geaviation.materials.entity.OrderStatusBO;
import com.geaviation.materials.entity.PutPoBO;
import com.geaviation.materials.entity.StatusBO;
import com.geaviation.materials.entity.UpdateOrderRequestDetails;
import com.geaviation.materials.entity.UpdateOrderResponseDetails;
import com.geaviation.materials.entity.UpdateShipmentBO;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsOrdersInterceptor;
import com.geaviation.materials.integrator.impl.util.InMemoryOutputStream;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorUtil;

@Configuration
@ConfigurationProperties
@EnableAutoConfiguration(exclude = DataSourceAutoConfiguration.class)
@Component
public class MaterialsOrdersInterceptor implements IMaterialsOrdersInterceptor {

	@Autowired
	private MaterialsInterceptorUtil materialsInterceptorUtil;

	@Autowired
	MaterialsExceptionUtil materialsExceptionUtil;

	@Autowired
	private IMaterialsOrdersApp materialsOrdersApp;

	@Value("${CFM.URL}")
	private String cfmURL;

	@Value("${AUTHORIZATION}")
	private String authorization;

	@Autowired
	private IMaterialsShipmentApp materialsShipmentApp;

	@Value("${ATTIVIOORDERS}")
	private String attivioOrders;

	public static final String PARAMETERS_STRING = "parameters";
	public static final String SSO_PATH_PARAMETER = "{sso}";

	private static final Log log = LogFactory.getLog(MaterialsOrdersInterceptor.class);

	@Override
	public Response deleteOrderLineBS(String strSSO, String portalId, String headerId, String lineId)
			throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = materialsInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		// As is flow for GEAE user, else call snecma web service
		if (isGEAEIncUser) {
			DeleteOrderLineBO deleteOrderLineBO = materialsOrdersApp.deleteOrderLineBS(strSSO, portalId, headerId,
					lineId);
			return Response.ok(deleteOrderLineBO).build();
		} else {
			// call snecma webservice
			String response = "";
			Object obj = null;
			int httpCode = 0;
			try {
				String url = cfmURL + MaterialsInterceptorConstants.DELETE_PO_LINE;
				Map<String, String> map = new HashMap<String, String>();
				map.put("headerId", headerId);
				map.put("lineId", lineId);
				log.info("deleteOrderLineBS_inputpassed " + map);
				url = materialsInterceptorUtil.appendParamstoURL(url, map);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				DeleteMethod method = new DeleteMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				log.info("deleteOrderLineBS_outputreceived :: " + obj);
				if (isNotNullandEmpty(response)) {
					Pattern myPattern = Pattern.compile(JSON_PATTERN);
					Matcher m = myPattern.matcher(response);
					while (m.find()) {
						response = m.group(0);
					}
				}
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("deleteOrderLineBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCode != 200) {
				return Response.status(httpCode).entity(obj.toString()).build();
			}
			return Response.ok(obj).build();
		}
	}

	public UpdateShipmentBO updateShipmentDetailsBS(String sso, String portalId, String updateType,
			String existingContent, String updatedContent, String customerId) throws MaterialsException {

		boolean isGEAEIncUser = true;
		isGEAEIncUser = materialsInterceptorUtil.isGEAEUser(sso, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		UpdateShipmentBO updateShipmentBO = null;
		if (isGEAEIncUser) {
			updateShipmentBO = materialsOrdersApp.updateShipmentDetailsBS(sso, portalId, updateType, existingContent,
					updatedContent, customerId);
		} else {
			throw new MaterialsException(ERROR_8451, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),
					MaterialsInterceptorConstants.SNECMA_DESC_MESSAGE);
		}
		return updateShipmentBO;
	}

	public DisputeDocumentBO downloadDisputeDocBS(String strSSO, String portalId, String orderHeaderId, String lineId,
			String docType) throws MaterialsException {

		boolean isGEAEIncUser = true;
		isGEAEIncUser = materialsInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		DisputeDocumentBO disputeDocumentBO = null;
		if (isGEAEIncUser) {
			disputeDocumentBO = materialsShipmentApp.downloadDisputeDocBS(strSSO, portalId, orderHeaderId, lineId,
					docType);
		} else {
			throw new MaterialsException(ERROR_8451, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),
					MaterialsInterceptorConstants.SNECMA_DESC_MESSAGE);
		}
		return disputeDocumentBO;
	}

	@Override
	public Response uploadOrderTemplateBS(String strSSO, String portalId, String custCode,
			List<Attachment> orderTemplate) throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = materialsInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			OrderStatusBO orderStatusBO = materialsOrdersApp.uploadOrderTemplateBS(strSSO, portalId, custCode,
					orderTemplate);
			return Response.ok(orderStatusBO).build();
		} else {
			DataHandler handler = null;
			int httpCode = 0;
			String response = null;
			String fileName = "";
			String jsonData = "";
			String decodejsonData = null;
			try {
				SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
				SOAPConnection soapConnection = soapConnectionFactory.createConnection();
				String url = cfmURL + MaterialsInterceptorConstants.GET_ORDER_TEMPLATE; 
					// Same Akana url is used for getordertemplate & uploadordertemplate
				for (org.apache.cxf.jaxrs.ext.multipart.Attachment attr : orderTemplate) {
					handler = attr.getDataHandler();
					String[] contentDisposition = attr.getHeaders().getFirst(CONTENT_DISPOSITION).split(";");

					for (String name : contentDisposition) {
						if (name.trim().startsWith("filename")) {
							fileName = getFileName(name);
						}
					}
				}
				SOAPMessage soapResponse = soapConnection.call(createSOAPRequest(handler, strSSO, fileName), url);
				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				soapResponse.writeTo(outputStream);
				response = new String(outputStream.toByteArray());
				httpCode = Integer.parseInt(response
						.substring(response.indexOf("<httpCode>") + 10, response.indexOf("</httpCode>")).trim());
				jsonData = response.substring(response.indexOf("<jsonData>") + 10, response.indexOf("</jsonData>"))
						.trim();
				decodejsonData = StringEscapeUtils.unescapeXml(jsonData);
			} catch (Exception e) {
				log.info("uploadOrderTemplateBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCode != 200) {
				return Response.status(httpCode).entity(decodejsonData).build();
			}
			return Response.ok(decodejsonData).build();
		}
	}

	private SOAPMessage createSOAPRequest(DataHandler dh, String strSSO, String fileName) throws MaterialsException {
		SOAPMessage soapMessage = null;
		try {
			MessageFactory messageFactory = MessageFactory.newInstance();
			soapMessage = messageFactory.createMessage();
			SOAPPart soapPart = soapMessage.getSOAPPart();
			String serverURI = "urn:snecma:cfm";
			SOAPEnvelope envelope = soapPart.getEnvelope();
			SOAPHeader header = soapMessage.getSOAPHeader();
			header.addNamespaceDeclaration("urn", serverURI);
			SOAPElement headerElement = header.addChildElement("portalName", "urn");
			headerElement.addTextNode("MYCFM");
			envelope.addNamespaceDeclaration("urn", serverURI);
			envelope.addNamespaceDeclaration("snec", serverURI);
			SOAPBody soapBody = envelope.getBody();
			SOAPElement soapBodyElem = soapBody.addChildElement("putBulkBuy", "urn");
			SOAPElement soapBodyParameter = soapBodyElem.addChildElement("requestParameters");
			AttachmentPart attachmentPart = soapMessage.createAttachmentPart(dh);
			attachmentPart.setContentId("1227542058253");
			log.info("createSOAPRequest_filename " + fileName);
			attachmentPart.setContentType("application/octet-stream;  name=" + fileName);
			attachmentPart.setMimeHeader(CONTENT_DISPOSITION,
					ATTACHMENT + "; name=" + fileName + ";" + FILENAME + "=" + fileName);
			SOAPElement soapBodyAttachmentParam = soapBodyParameter.addChildElement(ATTACHMENT);
			SOAPElement xop = soapBodyAttachmentParam.addChildElement("Include", "inc",
					"http://www.w3.org/2004/08/xop/include");
			xop.addAttribute(envelope.createName("href"), "cid:1227542058253");
			soapMessage.addAttachmentPart(attachmentPart);
			MimeHeaders headers = soapMessage.getMimeHeaders();
			headers.addHeader("SOAPAction", serverURI);
			headers.addHeader(AUTHORIZATION, authorization);
			headers.addHeader(SMSSO, strSSO);
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			soapMessage.writeTo(outputStream);
			soapMessage.saveChanges();
		} catch (Exception e) {
			log.info("createSOAPRequest_exceptionblock" + e);
		}
		return soapMessage;
	}

	private String getFileName(String filename) {
		String fileNameOut;
		String[] name = filename.split("=");
		fileNameOut = name[1].substring(name[1].trim().lastIndexOf("\\") + 1, name[1].length()).replaceAll("\"", "")
				.replaceAll("|", "");
		return fileNameOut;
	}

	public DisputeOrderStatusBO createDisputeOrderBS(String sso, String portalId, DisputeOrderInput disputeOrderInput,
			List<Attachment> attachment) throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = materialsInterceptorUtil.isGEAEUser(sso, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		DisputeOrderStatusBO disputeOrderStatusBO = null;
		if (isGEAEIncUser) {
			disputeOrderStatusBO = materialsShipmentApp.createDisputeOrderBS(sso, portalId, disputeOrderInput,
					attachment);
		} else {
			throw new MaterialsException(ERROR_8451, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),
					MaterialsInterceptorConstants.SNECMA_DESC_MESSAGE);
		}
		return disputeOrderStatusBO;
	}

	/**
	 * @param strSSO
	 * @param portalId
	 * @param multiValmap
	 * @param contentType
	 * @param icaoCode
	 * @return Response object
	 * @throws MaterialsException
	 */
	@Override
	public Response getOrders(String strSSO, String portalId, MultivaluedMap<String, String> multiValmap,
			String contentType, String icaoCode) throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = materialsInterceptorUtil.isGEAEUser(strSSO, portalId);
		String url = "";
		String response = "";
		Response res;
		Object obj = null;
		JSONObject resobj = null;
		JSONObject jsondata = null;
		int httpCode = 0;
		if (isGEAEIncUser) {
			url = attivioOrders;
			try {
				Map inputMap = new HashMap<String, String>();
				inputMap.putAll(multiValmap);
				log.info("getOrders_inputpassed " + inputMap);
				url = materialsInterceptorUtil.appendParamstoURL(url, inputMap);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader("sm_ssoid", strSSO);
				method.addRequestHeader("portal_id", portalId);
				method.addRequestHeader("icao_code", icaoCode);
				if (MaterialsInterceptorUtil.isNotNullandEmpty(contentType)) {
					method.setRequestHeader("Accept", "text/csv; utf-8");
					client.executeMethod(method);
					response = method.getResponseBodyAsString();
					res = Response.ok(response)
							.header(CONTENT_DISPOSITION, ATTACHMENT + ";" + FILENAME + " = " + "orderHistory.csv")
							.header(CONTENT_TYPE, "text/csv;charset=utf-8").build();
				} else {
					client.executeMethod(method);
					response = method.getResponseBodyAsString();
					res = Response.ok(response).build();
				}
			} catch (Exception e) {
				log.error("Exception--" + e);
				throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
						e.getMessage());
			}
		} else {
			String childContentType = null;
			String prntContentType = null;
			try {

				Map inputMap = new HashMap<String, String>();
				inputMap.putAll(multiValmap);
				url = cfmURL + MaterialsInterceptorConstants.GET_PO_LIST;
				url = materialsInterceptorUtil.appendParamstoURL(url, inputMap);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if (headers != null && headers.length > 0) {
					for (Header header : headers) {
						if (CONTENT_TYPE.equals(header.getName())) {
							prntContentType = header.getValue();
						}
					}
				}

				if (null != response && "" != response && response.contains(CONTENT_TYPE)
						&& response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex, contIdIndex);
					childContentType = contTypeSubString.substring(14, contTypeSubString.length());
				}
				log.info("getOrders_outputreceived :: " + response);
				resobj = new JSONObject(response);
				jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();

			} catch (Exception e) {
				log.info("getOrders_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCode != 200) {
				if (null != childContentType) {
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
				} else {
					return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
				}
			}
			if (null != childContentType) {
				res = Response.ok(obj).type(childContentType).build();
			} else {
				res = Response.ok(obj).type(prntContentType).build();
			}
		}
		return res;
	}

	/**
	 * @param smssoid
	 * @param portalid
	 * @param msNumber
	 * @param deliveryId
	 * @param orderHeaderId
	 * @param invoiceHeaderId
	 * @return Response object
	 * @throws MaterialsException
	 */
	@Override
	public Response getHeaderDetailBS(String strSSO, String portalId, String msNumber, String deliveryId,
			String orderHeaderId, String invoiceHeaderId) throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = materialsInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		// As is flow for GEAE user, else call snecma web service
		if (isGEAEIncUser) {
			OrderHeaderDetails orderHeaderDetails = materialsOrdersApp.getHeaderDetailBS(strSSO, portalId, msNumber,
					deliveryId, orderHeaderId, invoiceHeaderId);
			return Response.ok(orderHeaderDetails).build();
		} else {
			// call snecma webservice
			String response = "";
			String childContentType = null;
			String prntContentType = null;
			Object obj = null;
			int httpCode = 0;
			try {
				String url = cfmURL + MaterialsInterceptorConstants.GET_PO_DETAILS;
				Map<String, String> map = new HashMap<String, String>();
				if (MaterialsInterceptorUtil.isNotNullandEmpty(msNumber)) {
					map.put(MS_NUMBER, msNumber);
				}
				if (MaterialsInterceptorUtil.isNotNullandEmpty(deliveryId)) {
					map.put(DELIVERY_ID, deliveryId);
				}
				if (MaterialsInterceptorUtil.isNotNullandEmpty(orderHeaderId)) {
					map.put(ORDER_HEADER_ID, orderHeaderId);
				}
				if (MaterialsInterceptorUtil.isNotNullandEmpty(invoiceHeaderId)) {
					map.put(INVOICE_HEADER_ID, invoiceHeaderId);
				}
				log.info("getHeaderDetailBS_inputpassed" + "msNumber: " + msNumber + "deliveryId: " + deliveryId
						+ "orderHeaderId: " + orderHeaderId + "invoiceHeaderId: " + invoiceHeaderId);
				url = materialsInterceptorUtil.appendParamstoURL(url, map);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if (headers != null && headers.length > 0) {
					for (Header header : headers) {
						if ((CONTENT_TYPE).equals(header.getName())) {
							prntContentType = header.getValue();
						}
					}
				}
				if (null != response && "" != response && response.contains(CONTENT_TYPE)
						&& response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex, contIdIndex);
					childContentType = contTypeSubString.substring(14, contTypeSubString.length());
				}
				log.info("getHeaderDetailBS_outputreceived :: " + obj);
				if (MaterialsInterceptorUtil.isNotNullandEmpty(response)) {
					Pattern myPattern = Pattern.compile(JSON_PATTERN);
					Matcher m = myPattern.matcher(response);
					while (m.find()) {
						response = m.group(0);
					}
				}
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("getHeaderDetailBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCode != 200) {
				if (null != childContentType) {
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
				} else {
					return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
				}

			}
			if (null != childContentType) {
				return Response.ok(obj).type(childContentType).build();
			} else {
				return Response.ok(obj).type(prntContentType).build();
			}
		}
	}

	/**
	 * @param strSSO
	 * @param portalId
	 * @return Response object
	 * @throws MaterialsException
	 */
	@Override
	public Response getOrderTemplateBS(String strSSO, String portalId) throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = materialsInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			return materialsOrdersApp.getOrderTemplateBS(strSSO, portalId);
		} else {
			ResponseBuilder response = null;
			try(InMemoryOutputStream outStream =new InMemoryOutputStream()) {
				SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
				SOAPConnection soapConnection = soapConnectionFactory.createConnection();
				String url = cfmURL + MaterialsInterceptorConstants.GET_ORDER_TEMPLATE;
				SOAPMessage soapResponse = soapConnection
						.call(MaterialsInterceptorUtil.createSOAPRequest(strSSO, authorization), url);
				Iterator attachments = soapResponse.getAttachments();
				// Process all attachments
				while (attachments.hasNext()) {
					AttachmentPart attachment = (AttachmentPart) attachments.next();
					InputStream inStream = null;
					inStream = attachment.getRawContent();
					byte[] buffer = new byte[4096];
					int count = -1;
					while ((count = inStream.read(buffer)) != -1) {
						outStream.write(buffer, 0, count);
					}
				}
				response = Response.ok(outStream.getContent());
				response.header(CONTENT_DISPOSITION,
						ATTACHMENT + ";" + FILENAME + "=" + portalId + "_Bulk_Order_Template.xls");
				response.type("application/vnd.ms-excel");
			} catch (Exception e) {
				log.info("getOrderTemplateBS_exceptionblock" + e);
			}
			
			return response.build();
		}
	}

	/**
	 * @param strSSO
	 * @param portalId
	 * @param updateOrderRequestList
	 * @return Response object
	 * @throws MaterialsException
	 */
	@SuppressWarnings("deprecation")
	@Override
	public Response updateOrderBS(String strSSO, String portalId,
			List<UpdateOrderRequestDetails> updateOrderRequestList) throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = materialsInterceptorUtil.isGEAEUser(strSSO, portalId);
		// As is flow for GEAE user, else call snecma web service
		if (isGEAEIncUser) {
			List<UpdateOrderResponseDetails> lstUpdateOrderResponseDetails = materialsOrdersApp.updateOrderBS(strSSO,
					portalId, updateOrderRequestList);
			return Response.ok(lstUpdateOrderResponseDetails).build();
		} else {
			// call snecma webservice
			String jsonData = null;
			String response = "";
			Object obj = null;
			ObjectMapper mapper = new ObjectMapper();
			StringWriter writer = new StringWriter();
			int httpCode = 0;
			try {
				// Convert object to JSON string
				String payload = "";
				jsonData = mapper.writeValueAsString(updateOrderRequestList);
				log.info("updateOrderBS_jsonString  :: " + jsonData);
				String url = cfmURL + MaterialsInterceptorConstants.UPDATE_ORDER;
				PutPoBO putPoBO = new PutPoBO(jsonData);
				JAXBContext context = JAXBContext.newInstance(putPoBO.getClass());
				Marshaller marshaller = context.createMarshaller();
				marshaller.marshal(putPoBO, writer);
				payload = writer.toString();
				log.info("updateOrderBS_inputpassed " + payload);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				PutMethod method = new PutMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				method.setRequestHeader(CONTENT_TYPE, TEXT_XML);
				method.setRequestBody(payload);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				log.info("updateOrderBS_outputreceived :: " + response);
				if (MaterialsInterceptorUtil.isNotNullandEmpty(response)) {
					Pattern myPattern = Pattern.compile(JSON_PATTERN);
					Matcher m = myPattern.matcher(response);
					while (m.find()) {
						response = m.group(0);
					}
				}
				JSONObject resobj = new JSONObject(response);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				if (httpCode != 200) {
					JSONObject jsonObj = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
					obj = jsonObj.toString();
					return Response.status(httpCode).entity(obj.toString()).build();
				}
				JSONArray jsondata = resobj.getJSONObject(RETURN).getJSONArray(JSON_DATA);
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("updateOrderBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}

			return Response.ok(obj).build();
		}
	}

	
	@Override
	public Response getMaterialsDocumentBS(String strSSO, String portalId, String msNumber, String docType, String deliveryId,String invoiceHeaderId, 
			String proformaInvoiceId, String commercialInvoiceId,String notificationFlag) throws MaterialsException{
		if (!isNotNullandEmpty(strSSO)) {
          	 return materialsInterceptorUtil.htmlErrorResponse(MaterialsInterceptorConstants.ERR_SSO_NOT_FOUND);
   		}
   		if (!isNotNullandEmpty(portalId)) {
   			 return materialsInterceptorUtil.htmlErrorResponse(MaterialsInterceptorConstants.ERR_PORTAL_ID_NOT_FOUND);
   		}
		boolean isGEAEIncUser = true;
		isGEAEIncUser = materialsInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER  + isGEAEIncUser);
		// As is flow for GEAE user, else call snecma web service
		if (isGEAEIncUser) {
			if(MaterialsConstants.MYCFM.equalsIgnoreCase(portalId) && isNotNullandEmpty(invoiceHeaderId))
			{
				InvoiceDocDO invoiceDocDO = null;
				StatusBO statusBo = new StatusBO();
				invoiceDocDO = materialsOrdersApp.getInvoiceDocBS(strSSO,portalId,invoiceHeaderId);
				statusBo.setSuccess(invoiceDocDO.getStatusMessage());
				return Response.ok(statusBo).build();	
			}else
			{
				return materialsOrdersApp.getMaterialsDocumentBS(strSSO,portalId,msNumber, docType,deliveryId,invoiceHeaderId,notificationFlag);
			}
		}else{
			//call snecma webservice
			Response resp = null;
			int httpCode = 0;
			InputStream inStream = null;
			byte[] buffer = null;
			String filename  = "File.pdf";
			String responseBody = "";
			JSONObject jsondata = null;
			try(InMemoryOutputStream outStream = new InMemoryOutputStream()) {
				String url = cfmURL+MaterialsInterceptorConstants.MATERIALS_DOCUMENT;
				Map<String, String> map = new HashMap<String, String>();
				map.put("msNumber", msNumber);
				map.put("deliveryId", deliveryId);
				map.put("invoiceHeaderId", invoiceHeaderId);
				map.put("proformaInvoice", proformaInvoiceId);
				map.put("commercialInvoiceId", commercialInvoiceId);
				map.put("docType", docType);
				log.info("getMaterialsDocumentBS_inputpassed " +map);
				url = materialsInterceptorUtil.appendParamstoURL(url, map);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				responseBody = method.getResponseBodyAsString();
				if (isNotNullandEmpty(responseBody)) {
					Pattern myPattern = Pattern.compile(JSON_PATTERN);
					Matcher m = myPattern.matcher(responseBody);
					while (m.find()) {
						responseBody = m.group(0);
						if(null != responseBody){
							break;
						}
					}
				}
				log.info("getMaterialsDocumentBS_Response_from_Akana"+responseBody);
                JSONObject resBody = new JSONObject(responseBody);
                jsondata =  resBody.getJSONObject(RETURN).getJSONObject(JSON_DATA);
                filename =  jsondata.get("fileName").toString();
                httpCode =  Integer.parseInt(resBody.getJSONObject(RETURN).getString(HTTP_CODE));
                if(null == resBody.getJSONObject(RETURN).optJSONObject(ATTACHMENT)){
                	throw new MaterialsException(ERROR_8457,materialsExceptionUtil.getErrorMessage(ERROR_8457), jsondata.get("displayMessage").toString());
                }
				String s1 = "\r\n\r\n";
				String s2 = "\r\n--";
				byte[] boundary1 = s1.getBytes("UTF-8");
				byte[] boundary2 = s2.getBytes("UTF-8");
				byte[] data = method.getResponseBody();
				byte[] output = materialsInterceptorUtil.getAttachmentData(data,boundary1, boundary2);
				inStream = new  ByteArrayInputStream(output);
				buffer = new byte[4096];
				int count = -1;
				while ((count = inStream.read(buffer)) != -1) {
					outStream.write(buffer, 0, count);
				}
				resp = Response.ok(outStream.getContent()).header(CONTENT_DISPOSITION,ATTACHMENT+";"+ FILENAME+ "= " + filename ).build();
			} catch (TechnicalException | IOException e) {
				log.info("getMaterialsDocument_exceptionblock"+e);
				if(responseBody == null)
				{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE +e.getMessage());
				}
				else{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + responseBody);
				}
			}
			if(httpCode != 200)
			{
				return Response.status(httpCode).entity(responseBody.toString()).build();
			}
			return resp;	
		}
	}
	
	
}
