package com.geaviation.materials.integrator.impl;

import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8450;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8451;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.AUTHORIZATION;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CONTENT_ID;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CONTENT_TYPE;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8450;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8451;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.HTTP_CODE;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ISGEAEUSER;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.JSON_DATA;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.RETURN;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.SMSSO;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.TEXT_XML;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.geaviation.materials.entity.PutRFQBO;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsRfqInterceptor;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorUtil;


@Component
public class MaterialsRfqInterceptor implements IMaterialsRfqInterceptor {

	private static final Log log = LogFactory.getLog(MaterialsRfqInterceptor.class);

	@Autowired
	MaterialsExceptionUtil materialsExceptionUtil;

	@Autowired
	private MaterialsInterceptorUtil mateInterceptorUtil;


	@Value("${CFM.URL}")
	private String cfmURL;
	@Value("${AUTHORIZATION}")
	private String authorization;
	@Value("${CFM_MATERIALS_URL}")
	private String cfmMaterialsDevUrl;

		
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Response listRFQBS(String strSSO, String portalId,
			MultivaluedMap<String, String> map) throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		// As is flow for GEAE user, else call snecma web service
		if (isGEAEIncUser) {

			throw new MaterialsException(ERROR_8451,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),  MaterialsInterceptorConstants.INC_DESC_MESSAGE);

		} else {
			//call snecma webservice
			String response = "";
			Object obj = null;
			String childContentType = null;
			String prntContentType = null;
			int httpCode = 0; 
			try {
				String url = cfmURL+MaterialsInterceptorConstants.LIST_RFQ;
				Map inputMap = new HashMap<String, String>();
				inputMap.putAll(map);
				log.info("listRFQBS_inputpassed " +inputMap);
				url = mateInterceptorUtil.appendParamstoURL(url, inputMap);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if(headers != null && headers.length > 0){
				for (Header header : headers) {
					if(CONTENT_TYPE.equals(header.getName())){
					prntContentType = header.getValue();
					}
				}
				}
				if(null != response && "" != response && response.contains(CONTENT_TYPE) && response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex,contIdIndex);
					childContentType = contTypeSubString.substring(14,contTypeSubString.length());
					}
				log.info("getCommercialAgreementBS_outputreceived"+response);
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata =  resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode =  Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
				
			} catch (Exception e) {
				log.info("listRFQBS_exceptionblock"+e);
				if(response == null)
				{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE +e.getMessage());
				}
				else{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if(httpCode != 200)
			{
				if(null != childContentType){
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
					}
					else{
						return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
					}
			}
			if(null != childContentType){
				return Response.ok(obj).type(childContentType).build();
				}
				else{
					return Response.ok(obj).type(prntContentType).build();
				}
		}

	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Response getRFQDetailBS(String strSSO, String portalId, MultivaluedMap<String,String> form) throws MaterialsException{
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO,portalId);
		log.info(ISGEAEUSER +isGEAEIncUser);
		//As is flow for GEAE user, else call snecma web service
		if(isGEAEIncUser){
			throw new MaterialsException(ERROR_8451,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451), MaterialsInterceptorConstants.INC_DESC_MESSAGE);
		}else{
			//call snecma webservice
			String response = "";
			String childContentType = null;
			String prntContentType = null;
			Object obj = null;
			int httpCode = 0;
			try {
				String url = cfmURL+MaterialsInterceptorConstants.GET_RFQ_DETAILS;
				Map inputMap = new HashMap<String, String>();
				inputMap.putAll(form);
				log.info("getRFQDetailBS_inputpassed " +inputMap);
				url = mateInterceptorUtil.appendParamstoURL(url, inputMap);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if(headers != null && headers.length > 0){
				for (Header header : headers) {
					if(CONTENT_TYPE.equals(header.getName())){
					prntContentType = header.getValue();
					}
				}
				}
				if(null != response && "" != response && response.contains(CONTENT_TYPE) && response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex,contIdIndex);
					childContentType = contTypeSubString.substring(14,contTypeSubString.length());
					}
				log.info("getRFQDetailBS_outputreceived"+response);
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata =  resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode =  Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("getRFQDetailBS_exceptionblock"+e);
				if(response == null)
				{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE +e.getMessage());
				}
				else{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if(httpCode != 200)
			{
				if(null != childContentType){
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
					}
					else{
						return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
					}
			}
			if(null != childContentType){
				return Response.ok(obj).type(childContentType).build();
				}
				else{
					return Response.ok(obj).type(prntContentType).build();
				}
		}
	}
	
	@Override
	public Response getRFQBS(String strSSO, String portalId,MultivaluedMap<String, String> multiValmap) throws MaterialsException {

		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			throw new MaterialsException(ERROR_8451,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451), MaterialsInterceptorConstants.INC_DESC_MESSAGE);
		} else {
			String response = "";
			String childContentType = null;
			String prntContentType = null;
			Object obj = null;
			int httpCode = 0;
			try {
				String url = cfmURL+MaterialsInterceptorConstants.GET_RFQ;
				Map inputMap = new HashMap<String, String>();
				inputMap.putAll(multiValmap);
				log.info("getRFQBS_inputpassed " + inputMap);
				url = mateInterceptorUtil.appendParamstoURL(url, inputMap);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if(headers != null && headers.length > 0){
				for (Header header : headers) {
					if(CONTENT_TYPE.equals(header.getName())){
					prntContentType = header.getValue();
					}
				}
				}
				if(null != response && "" != response && response.contains(CONTENT_TYPE) && response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex,contIdIndex);
					childContentType = contTypeSubString.substring(14,contTypeSubString.length());
					}
				log.info("getRFQBS_outputreceived :: "+response);
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata =  resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode =  Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("getRFQBS_exceptionblock"+e);
				if(response == null)
				{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE +e.getMessage());
				}
				else{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if(httpCode != 200)
			{
				if(null != childContentType){
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
					}
					else{
						return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
					}
			}
			if(null != childContentType){
				return Response.ok(obj).type(childContentType).build();
				}
				else{
					return Response.ok(obj).type(prntContentType).build();
				}
		}
	}
	@Override
    public Response createRFQBS(String customerCode,String rfqClientNumber,String rfqSubmittedDate,String rfqPriorityCode,String partNumber,String orderedQuantity,String rfqConditionCode,String rfqCustomerRemarks,String strSSO, String portalId) throws MaterialsException {
           // check null here itself to avoid unnecesaary calls
           // CFM changes - START
           boolean isGEAEIncUser = true;
           isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
           log.info(ISGEAEUSER + isGEAEIncUser);
           // As is flow for GEAE user, else call snecma web service
           if (isGEAEIncUser) {
                  throw new MaterialsException(ERROR_8451,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451), MaterialsInterceptorConstants.INC_DESC_MESSAGE);
           } else {
                  //call snecma webservice
                  String response = "";
                  Object obj = null;
                  StringWriter writer = new StringWriter();
                  int httpCode = 0;
                  try {
                        String url = cfmURL+MaterialsInterceptorConstants.CREATE_RFQ;
                        String payload;
                        PutRFQBO putRFQBO = new PutRFQBO(customerCode, rfqClientNumber, rfqSubmittedDate, rfqPriorityCode, partNumber, orderedQuantity, rfqConditionCode, rfqCustomerRemarks);
                        PutRFQBO putRFQBO1 = new PutRFQBO();
                        JAXBContext context = JAXBContext.newInstance(putRFQBO1.getClass());
                        Marshaller marshaller = context.createMarshaller();
                        marshaller.marshal(putRFQBO, writer);
                        payload = writer.toString();
                    	log.info("createRFQBS_inputpassed "  +payload);
                        HttpClient client = new HttpClient();
                        URI uri = new URI(url, false);
        				PutMethod method = new PutMethod(uri.getEscapedURI());
                        method.addRequestHeader(AUTHORIZATION, authorization);
                        method.addRequestHeader(SMSSO, strSSO);
                        method.setRequestHeader(CONTENT_TYPE, TEXT_XML);
                        method.setRequestBody(payload);
                        client.executeMethod(method);
                        response = method.getResponseBodyAsString();           
                        log.info("createRFQBS_outputreceived :: "+response);
                        JSONObject resobj = new JSONObject(response);
                        JSONObject jsondata =  resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
                        httpCode =  Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
                        obj = jsondata.toString();
                  } catch (Exception e) {
      				log.info("createRFQBS_exceptionblock"+e);
      				if(response == null)
      				{
      					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
      							MaterialsInterceptorConstants.DESC_MESSAGE +e.getMessage());
      				}
      				else{
      					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
      							MaterialsInterceptorConstants.DESC_MESSAGE + response);
      				}
      			}
      			if(httpCode != 200)
      			{
      				return Response.status(httpCode).entity(obj.toString()).build();
      			}
                  return Response.ok(obj).build();
           }
    }

}
