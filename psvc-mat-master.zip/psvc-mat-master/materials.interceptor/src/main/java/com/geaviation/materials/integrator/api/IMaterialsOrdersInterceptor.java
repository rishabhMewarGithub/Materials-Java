package com.geaviation.materials.integrator.api;

import java.util.List;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;

import com.geaviation.materials.entity.DisputeDocumentBO;
import com.geaviation.materials.entity.DisputeOrderInput;
import com.geaviation.materials.entity.DisputeOrderStatusBO;
import com.geaviation.materials.entity.UpdateShipmentBO;
import com.geaviation.materials.entity.UpdateOrderRequestDetails;
import com.geaviation.materials.exception.MaterialsException;

public interface IMaterialsOrdersInterceptor {
	
	/**
	 * @param strSSO
	 * @param portalId
	 * @param headerId
	 * @param lineId
	 * @return Object
	 * @throws MaterialsException, MaterialsSnecmaException
	 */
	public Response deleteOrderLineBS(String strSSO,String portalId,String headerId,String lineId) throws MaterialsException;
	public UpdateShipmentBO updateShipmentDetailsBS(String sso, String portalId, String updateType, String existingContent, String updatedContent, String customerId) throws MaterialsException;
	public DisputeDocumentBO downloadDisputeDocBS(String strSSO,String portalId,String orderHeaderId,String lineId,String docType) throws MaterialsException;
	public Response uploadOrderTemplateBS(String strSSO, String portalId,String custCode,List<Attachment> orderTemplate) throws MaterialsException;
	public DisputeOrderStatusBO createDisputeOrderBS(String sso, String portalId, DisputeOrderInput disputeOrderInput, List<Attachment> serialNumberPhotoAttachment) throws MaterialsException;
	
	public Response getOrders(String strSSO, String portalId, MultivaluedMap<String, String> multiValmap, String contentType,String icaoCode) throws MaterialsException;
	
	public Response getHeaderDetailBS(String smssoid, String portalid, String msNumber, String deliveryId, String orderHeaderId, String invoiceHeaderId) throws MaterialsException;
	
	public Response getOrderTemplateBS(String strSSO, String portalId) throws MaterialsException;
	
	public Response updateOrderBS(String strSSO,String portalId,List<UpdateOrderRequestDetails> updateOrderRequestList) throws MaterialsException;
	/**
	 * @param strSSO
	 * @param portalId
	 * @param updateOrderRequestList
	 * @return Object
	 * @throws MaterialsException, MaterialsSnecmaException
	 */
	public Response getMaterialsDocumentBS(String strSSO, String portalId, String msNumber, String docType, String deliveryId,String invoiceId, 
			String proformaInvoiceId, String commercialInvoiceId,String notificationFlag) throws MaterialsException;
	

}
