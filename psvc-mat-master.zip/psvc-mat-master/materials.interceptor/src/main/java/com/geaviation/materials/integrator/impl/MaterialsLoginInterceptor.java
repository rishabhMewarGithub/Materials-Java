/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Feb 24, 2016
 * Description    :     MaterialsInterceptor.java
 * 
 * History        :  	Mar 12, 2014                
        
                    
 **********************************************************/
package com.geaviation.materials.integrator.impl;

import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8450;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8464;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.AUTHORIZATION;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8450;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8464;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ISGEAEUSER;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.JSON_DATA;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.RETURN;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.SMSSO;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.geaviation.materials.app.api.IMaterialsLoginApp;
import com.geaviation.materials.entity.MaterialsLoginResponse;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsLoginInterceptor;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorUtil;

@Configuration
@ConfigurationProperties
@EnableAutoConfiguration(exclude = DataSourceAutoConfiguration.class)
@Component
public class MaterialsLoginInterceptor implements IMaterialsLoginInterceptor {

	@Autowired
	private MaterialsInterceptorUtil mateInterceptorUtil;
	@Autowired
	MaterialsExceptionUtil materialsExceptionUtil;
	@Value("${CFM.URL}")
	private String cfmURL;
	@Value("${AUTHORIZATION}")
	private String authorization;
	@Autowired
	private IMaterialsLoginApp materialsLoginApp;


	public static final String PARAMETERS_STRING = "parameters";
	public static final String SSO_PATH_PARAMETER = "{sso}";
	private static final Log log = LogFactory.getLog(MaterialsLoginInterceptor.class);

	@Override
	public Object requestMaterialsLogin(String strSSO, String portalId) throws MaterialsException {
		boolean isGEAEUser = true;
		isGEAEUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEUser);
		if (isGEAEUser) {
			return materialsLoginApp.requestMaterialsLogin(strSSO, portalId);

		} else {
			String response = null;
			Object obj = "";
			try {
				String url = cfmURL + MaterialsInterceptorConstants.GET_AUTHENTIFICATION;
				Map<String, String> map = new HashMap<String, String>();
				log.info("requestMaterialsLogin_inputpassed " + map);
				url = mateInterceptorUtil.appendParamstoURL(url, map);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				log.info("requestMaterialsLogin_outputreceived :: " + response);
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("requestMaterialsLogin_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			return obj;
		}
	}

	public Object roleConversion(Object loginResponse, String strSSO, String portalId) throws MaterialsException {
		try {
			if (mateInterceptorUtil.isGEAEUser(strSSO, portalId) && null != loginResponse) {
				MaterialsLoginResponse materialsLoginResponse = (MaterialsLoginResponse) loginResponse;
				loginResponse = mateInterceptorUtil.roleConversion(materialsLoginResponse);
			}
		} catch (Exception e) {
			log.error(e);
		}
		return loginResponse;
	}

	@Override
	public Object requestMaterialsLoginAttivio(String strSSO, String portalId) throws MaterialsException {
		boolean isGEAEUser = true;
		isGEAEUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEUser);
		if (isGEAEUser) {
			return materialsLoginApp.requestMaterialsLogin(strSSO, portalId);

		} else {
			log.info("logmsg :This service is only for INC user");
			throw new MaterialsException(ERROR_8464, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8464),
					MaterialsInterceptorConstants.DESC_ATTIVIO_ACCESS);
		}
	}
}
