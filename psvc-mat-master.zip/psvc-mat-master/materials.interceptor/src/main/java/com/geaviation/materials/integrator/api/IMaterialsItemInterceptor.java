package com.geaviation.materials.integrator.api;

import javax.ws.rs.core.Response;

import com.geaviation.materials.exception.MaterialsException;

public interface IMaterialsItemInterceptor {

    public Response getItemAvailPricDtlBS(String strSSO,String portalId,String invontoryItemId, String custCode, String custId,String partNumber) throws MaterialsException;
	
	public Response getKitStructureBS(String sso, String portalId, String inventoryItemId) throws MaterialsException;
	
	public Response getItemConfigHistoryBS(String strSSO, String portalId, String inventoryItemId,String partNumber) throws MaterialsException;
	
	public Response getRepUsedItemConfigHistory(String strSSO, String portalId, String partNumber) throws MaterialsException;
}
