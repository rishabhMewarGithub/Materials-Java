package com.geaviation.materials.integrator.impl;

import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8450;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.AUTHORIZATION;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CART_HEADER_ID;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CONTENT_ID;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CONTENT_TYPE;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8450;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.HTTP_CODE;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ISGEAEUSER;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.JSON_DATA;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.JSON_PATTERN;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.RETURN;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.SMSSO;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.TEXT_XML;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorUtil.isNotNullandEmpty;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.methods.DeleteMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.geaviation.materials.app.api.IMaterialsCartApp;
import com.geaviation.materials.entity.CartCountBS;
import com.geaviation.materials.entity.DeleteCartLineBO;
import com.geaviation.materials.entity.PurchasePOBO;
import com.geaviation.materials.entity.PutCartAddItemBO;
import com.geaviation.materials.entity.PutCartSaveBO;
import com.geaviation.materials.entity.PutPoDetailsBO;
import com.geaviation.materials.entity.SaveCartRequestDetails;
import com.geaviation.materials.entity.SaveCartResponseDetails;
import com.geaviation.materials.entity.StatusBO;
import com.geaviation.materials.entity.TotalPurchaseOrderBO;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsCartInterceptor;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorUtil;

@Configuration
@Component
public class MaterialsCartInterceptor implements IMaterialsCartInterceptor {
	@Value("${AUTHORIZATION}")
	private String authorization;
	@Value("${CFM.URL}")
	private String cfmURL;

	@Autowired
	private IMaterialsCartApp materialsCartApp;

	@Autowired
	MaterialsExceptionUtil materialsExceptionUtil;

	@Autowired
	private MaterialsInterceptorUtil mateInterceptorUtil;

	private static final Log log = LogFactory.getLog(MaterialsCartInterceptor.class);

	@Override
	public Response getCartBS(String strSSO, String portalId, String cartHeaderId) throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			TotalPurchaseOrderBO totalPurchaseOrderBO = null;
			totalPurchaseOrderBO = materialsCartApp.getCartBS(strSSO, portalId);
			return Response.ok(totalPurchaseOrderBO).build();
		} else {
			String response = "";
			String jsonData = "";
			Object obj = null;
			int httpCode = 0;
			Header[] headers = null;
			try {
				String url = cfmURL + MaterialsInterceptorConstants.GET_CART_CONTENTS;
				Map<String, String> map = new HashMap<String, String>();
				if (isNotNullandEmpty(cartHeaderId)) {
					map.put(CART_HEADER_ID, cartHeaderId);
				}
				log.info("getCartBS_inputpassed " + map);
				url = mateInterceptorUtil.appendParamstoURL(url, map);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				log.info("getCartBS_inputpassed" + "strSSO: " + strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				headers = method.getResponseHeaders();
				log.info("getCartBS_outputreceived :: " + response);
				jsonData = getJsonData(response);
				JSONObject resobj = new JSONObject(jsonData);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("getCartBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			return getFormattedResponse(response, httpCode, obj, headers);
		}
	}

	private String getJsonData(String response) {

		String result = "";
		if (isNotNullandEmpty(response)) {
			Pattern myPattern = Pattern.compile(JSON_PATTERN);
			Matcher m = myPattern.matcher(response);
			while (m.find()) {
				result = m.group(0);
			}
		}
		return result;
	}

	private Response getFormattedResponse(String response, int httpCode, Object obj, Header[] headers) {

		String childContentType = null;
		String prntContentType = null;

		if (headers != null && headers.length > 0) {
			for (Header header : headers) {
				if (CONTENT_TYPE.equals(header.getName())) {
					prntContentType = header.getValue();
					break;
				}
			}
		}

		if (null != response && "" != response && response.contains(CONTENT_TYPE) && response.contains(CONTENT_ID)) {
			int contTypeIndex = response.indexOf(CONTENT_TYPE);
			int contIdIndex = response.indexOf(CONTENT_ID);
			String contTypeSubString = response.substring(contTypeIndex, contIdIndex);
			childContentType = contTypeSubString.substring(14, contTypeSubString.length());
		}
		if (httpCode != 200) {
			if (null != childContentType) {
				return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
			} else {
				return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
			}
		}
		if (null != childContentType) {
			return Response.ok(obj).type(childContentType).build();
		} else {
			return Response.ok(obj).type(prntContentType).build();
		}

	}

	@Override
	public Response getCartCountBS(String strSSO, String portalId) throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			CartCountBS cartCountBS = materialsCartApp.getCartCountBS(strSSO, portalId);
			return Response.ok(cartCountBS).build();
		} else {
			String response = "";
			String childContentType = null;
			String prntContentType = null;
			Object obj = null;
			int httpCode = 0;
			try {
				String url = cfmURL + MaterialsInterceptorConstants.GET_CART_COUNT;
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				log.info("getCartCountBS_inputpassed" + "strSSO: " + strSSO + "portalId: " + portalId);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if (headers != null && headers.length > 0) {
					for (Header header : headers) {
						if (CONTENT_TYPE.equals(header.getName())) {
							prntContentType = header.getValue();
						}
					}
				}
				if (null != response && "" != response && response.contains(CONTENT_TYPE)
						&& response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex, contIdIndex);
					childContentType = contTypeSubString.substring(14, contTypeSubString.length());
				}
				log.info("getCartCountBS_outputreceived :: " + response);
				if (isNotNullandEmpty(response)) {
					Pattern myPattern = Pattern.compile(JSON_PATTERN);
					Matcher m = myPattern.matcher(response);
					while (m.find()) {
						response = m.group(0);
					}
				}
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();

			} catch (Exception e) {
				log.info("getCartCountBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCode != 200) {
				if (null != childContentType) {
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
				} else {
					return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
				}
			}
			if (null != childContentType) {
				return Response.ok(obj).type(childContentType).build();
			} else {
				return Response.ok(obj).type(prntContentType).build();
			}
		}
	}

	@Override
	public Response deleteCartBS(String strSSO, String portalId, String cartHeaderId) throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		// As is flow for GEAE user, else call snecma web service
		if (isGEAEIncUser) {
			StatusBO statusBO = materialsCartApp.deleteCartBS(strSSO, portalId);
			return Response.ok(statusBO).build();
		} else {
			// call snecma webservice
			String response = "";
			Object obj = null;
			int httpCode = 0;
			try {
				String url = cfmURL + MaterialsInterceptorConstants.DELETE_CART;
				Map<String, String> map = new HashMap<String, String>();
				if (isNotNullandEmpty(cartHeaderId)) {
					map.put(CART_HEADER_ID, cartHeaderId);
				}
				log.info("deleteCartBS_inputpassed" + "cartHeaderId: " + cartHeaderId);
				url = mateInterceptorUtil.appendParamstoURL(url, map);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				DeleteMethod method = new DeleteMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				log.info("deleteCartBS_outputreceived :: " + response);
				if (isNotNullandEmpty(response)) {
					Pattern myPattern = Pattern.compile(JSON_PATTERN);
					Matcher m = myPattern.matcher(response);
					while (m.find()) {
						response = m.group(0);
					}
				}
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();

			} catch (Exception e) {
				log.info("deleteCartBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCode != 200) {
				return Response.status(httpCode).entity(obj.toString()).build();
			}
			return Response.ok(obj).build();
		}

	}

	@Override
	public Response deleteCartLineBS(String strSSO, String portalId, String cartHeaderId, String cartLineId)
			throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			DeleteCartLineBO deleteCartLineBO = materialsCartApp.deleteCartLineBS(strSSO, portalId, cartHeaderId,
					cartLineId);
			return Response.ok(deleteCartLineBO).build();
		} else {
			String response = "";
			Object obj = null;
			int httpCode = 0;
			try {
				String url = cfmURL + MaterialsInterceptorConstants.DELETE_CART_LINE;
				Map<String, String> map = new HashMap<String, String>();
				map.put(CART_HEADER_ID, cartHeaderId);
				map.put("cartLineId", cartLineId);
				log.info("deleteCartLineBS_inputpassed " + map);
				url = mateInterceptorUtil.appendParamstoURL(url, map);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				DeleteMethod method = new DeleteMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				log.info("deleteCartLineBS_outputreceived" + response);
				if (isNotNullandEmpty(response)) {
					Pattern myPattern = Pattern.compile(JSON_PATTERN);
					Matcher m = myPattern.matcher(response);
					while (m.find()) {
						response = m.group(0);
					}
				}
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();

			} catch (Exception e) {
				log.info("deleteCartLineBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCode != 200) {
				return Response.status(httpCode).entity(obj.toString()).build();
			}
			return Response.ok(obj).build();
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public Response saveCartBS(List<SaveCartRequestDetails> saveCartRequestList, String strSSO, String portalId)
			throws MaterialsException {
		log.info("Start ..  save Cart");
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			List<SaveCartResponseDetails> saveCartResponseDetails = materialsCartApp.saveCartBS(saveCartRequestList,
					strSSO, portalId);
			return Response.ok(saveCartResponseDetails).build();
		} else {
			String response = "";
			Object obj = null;
			JSONObject resobj = null;
			JSONArray jsondata = null;
			ObjectMapper mapper = new ObjectMapper();
			StringWriter writer = new StringWriter();
			int httpCode = 0;
			try {
				String jsonInString = mapper.writeValueAsString(saveCartRequestList);
				log.info("saveCartBS_jsonInput  :: " + jsonInString);
				String url = cfmURL + MaterialsInterceptorConstants.SAVE_CART;
				String payload;
				PutCartSaveBO putCartSaveBO = new PutCartSaveBO(jsonInString);
				JAXBContext context = JAXBContext.newInstance(putCartSaveBO.getClass());
				Marshaller marshaller = context.createMarshaller();
				marshaller.marshal(putCartSaveBO, writer);
				payload = writer.toString();
				log.info("saveCartBS_inputpassed " + payload);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				PutMethod method = new PutMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				method.setRequestHeader(CONTENT_TYPE, "text/xml");
				method.setRequestBody(payload);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				log.info("saveCartBS_outputreceived :: " + response);
				if (isNotNullandEmpty(response)) {
					Pattern myPattern = Pattern.compile(JSON_PATTERN);
					Matcher m = myPattern.matcher(response);
					while (m.find()) {
						response = m.group(0);
					}
				}
				resobj = new JSONObject(response);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				if (httpCode != 200) {
					JSONObject jsonObj = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
					obj = jsonObj.toString();
					return Response.status(httpCode).entity(obj.toString()).build();
				}
				jsondata = resobj.getJSONObject(RETURN).getJSONArray(JSON_DATA);
				obj = jsondata.toString();

			} catch (Exception e) {
				log.info("saveCartBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			return Response.ok(obj).build();
		}

	}

	@Override
	public Response addLineItemBS(String strSSO, String portalId, String inventoryItemId, String selectedCustomerId,
			String selectedSupplierCode, String quantity, String pricingListId, String commercialAgreementNumber,
			String quotationNumber, String quickOrder, String quoteHeaderId) throws MaterialsException {

		boolean isGEAEUser = true;
		isGEAEUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEUser);
		if (isGEAEUser) {
			StatusBO statusBO = materialsCartApp.addLineItemBS(strSSO, portalId, inventoryItemId, selectedCustomerId,
					selectedSupplierCode, quantity, pricingListId, quoteHeaderId);
			return Response.ok(statusBO).build();
		} else {
			String response = "";
			Object obj = null;
			int httpCode = 0;
			try {
				String payload;
				StringWriter writer = new StringWriter();
				String url = cfmURL + MaterialsInterceptorConstants.PUT_CART_ADD_ITEM;
				PutCartAddItemBO putCartAddItemBO = new PutCartAddItemBO(inventoryItemId, selectedCustomerId,
						selectedSupplierCode, quantity, pricingListId, commercialAgreementNumber, quotationNumber,
						quickOrder);
				log.info("addLineItemBS_inputpassed" + "inventoryItemId: " + inventoryItemId + "selectedCustomerId: "
						+ selectedCustomerId + "selectedSupplierCode: " + selectedSupplierCode + "quantity: " + quantity
						+ "pricingListId: " + pricingListId + "commercialAgreementNumber: " + commercialAgreementNumber
						+ "quotationNumber: " + quotationNumber + "quickOrder: " + quickOrder);
				JAXBContext context = JAXBContext.newInstance(putCartAddItemBO.getClass());
				Marshaller marshaller = context.createMarshaller();
				marshaller.marshal(putCartAddItemBO, writer);
				payload = writer.toString();
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				PutMethod method = new PutMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				method.setRequestHeader(CONTENT_TYPE, TEXT_XML);
				method.setRequestBody(payload);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				log.info("addLineItemBS_outputreceived :: " + response);
				if (isNotNullandEmpty(response)) {
					Pattern myPattern = Pattern.compile(JSON_PATTERN);
					Matcher m = myPattern.matcher(response);
					while (m.find()) {
						response = m.group(0);
					}
				}
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("addLineItemBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCode != 200) {
				return Response.status(httpCode).entity(obj.toString()).build();
			}
			return Response.ok(obj).build();
		}
	}

	@Override
	public Response purchasePOBS(String strSSO, String portalId, String cartHeaderId, String orderType)
			throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			//List<PurchasePOBO> purchasePOBOs = materialsCartApp.purchasePOBS(strSSO, portalId, cartHeaderId, orderType);
			List<PurchasePOBO> purchasePOBOs = materialsCartApp.purchasePOBS( strSSO,  portalId,  cartHeaderId,  orderType);
			return Response.ok(purchasePOBOs).build();
		} else {
			String response = "";
			Object obj = null;
			int httpCode = 0;
			try {
				String url = cfmURL + MaterialsInterceptorConstants.PUT_CART_ORDER;
				String payload;
				StringWriter writer = new StringWriter();
				PutPoDetailsBO putPoDetailsBO = new PutPoDetailsBO(cartHeaderId, orderType);
				JAXBContext context = JAXBContext.newInstance(putPoDetailsBO.getClass());
				Marshaller marshaller = context.createMarshaller();
				marshaller.marshal(putPoDetailsBO, writer);
				payload = writer.toString();
				log.info("purchasePOBS_inputpassed " + payload);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				PutMethod method = new PutMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				method.setRequestHeader(CONTENT_TYPE, "text/xml");
				method.setRequestBody(payload);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				log.info("purchasePOBS_outputreceived" + response);
				if (isNotNullandEmpty(response)) {
					Pattern myPattern = Pattern.compile(JSON_PATTERN);
					Matcher m = myPattern.matcher(response);
					while (m.find()) {
						response = m.group(0);
					}
				}
				JSONObject resobj = new JSONObject(response);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				if (httpCode != 200) {
					JSONObject jsonObj = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
					obj = jsonObj.toString();
					return Response.status(httpCode).entity(obj.toString()).build();
				}
				JSONArray jsondata = resobj.getJSONObject(RETURN).getJSONArray(JSON_DATA);
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("purchasePOBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}

			return Response.ok(obj).build();
		}
	}

}
