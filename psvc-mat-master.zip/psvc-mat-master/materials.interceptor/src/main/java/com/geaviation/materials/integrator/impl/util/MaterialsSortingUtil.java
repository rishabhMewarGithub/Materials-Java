/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Feb 24, 2016
 * Description    :     MaterialsSortingUtil.java
 * 
 * History        :  	Aug 18, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.integrator.impl.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.geaviation.materials.entity.MaterialsSortField;

/**
 * @author 720053
 *
 */
public class MaterialsSortingUtil {
	private MaterialsSortingUtil()
	{
		
	}
	final static String SORT_DIR = "sSortDir";
	final static String SORT_COL = "iSortCol_";
	private static final Log LOG = LogFactory.getLog(MaterialsInterceptorUtil.class);
	private static Map<String,String> getQueryParams(UriInfo ui) {
		Map<String, String> queryParams = new HashMap<String,String>();  
	    for (Entry<String, List<String>> entry : ui.getQueryParameters().entrySet()) {
	    	queryParams.put(entry.getKey(), entry.getValue().get(0));
	    }
	    return queryParams;
	}
	
	private static int getQueryParamInt(Map<String,String> queryParams,String param, int defaultInt) {
		try {
			defaultInt = Integer.parseInt(queryParams.get(param));
		}
		catch (NumberFormatException e) {	
			LOG.error(" Exception  :: "+e);	
		}	
		return defaultInt;
	}
	
	private static int getQueryParamIntFromForm(MultivaluedMap<String,String> queryParams,String param, int defaultInt) {
		try {
			defaultInt = Integer.parseInt(queryParams.getFirst(param));
		}
		catch (NumberFormatException e) {	
			LOG.error(" Exception  :: "+e);	
		}	
		return defaultInt;
	}
	
	public static List<MaterialsSortField> getSortFields(UriInfo ui) {
		Map<String, String> queryParams = getQueryParams(ui);
		List<MaterialsSortField> sortParamsList = new ArrayList<MaterialsSortField>();
		
		for (int i = 0; i < getQueryParamInt(queryParams,"iColumns",0); i++) {
		   if (queryParams.get(SORT_COL + i) != null) {
			   String sortColumn = queryParams.get("mDataProp_" + queryParams.get(SORT_COL + i));
			   if (sortColumn != null) {
				   sortParamsList.add(new MaterialsSortField(sortColumn, ("desc".equalsIgnoreCase(queryParams.get(SORT_DIR + "_" + i))?"desc":"asc")));
			   }
		   }
		}
		return sortParamsList;
	}
	
	public static List<MaterialsSortField> getSortFieldsFromForm(MultivaluedMap<String, String> form) {
		
		List<MaterialsSortField> sortParamsList = new ArrayList<MaterialsSortField>();
		for (int i = 0; i < getQueryParamIntFromForm(form,"iColumns",0); i++) {
		   if (form.getFirst(SORT_COL + i) != null) {
			   String sortColumn = form.getFirst("mDataProp_" + form.getFirst(SORT_COL + i));
			   if (sortColumn != null) {
				   sortParamsList.add(new MaterialsSortField(sortColumn, ("desc".equalsIgnoreCase(form.getFirst(SORT_DIR + "_" + i))?"desc":"asc")));
			   }
		   }
		}
		return sortParamsList;
	}

}
