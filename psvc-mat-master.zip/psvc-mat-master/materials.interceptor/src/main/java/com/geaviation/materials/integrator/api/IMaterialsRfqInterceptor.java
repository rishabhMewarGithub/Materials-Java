package com.geaviation.materials.integrator.api;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import com.geaviation.materials.exception.MaterialsException;

public interface IMaterialsRfqInterceptor {
	 public Response listRFQBS(String strSSO, String portalId,MultivaluedMap<String, String> map) throws MaterialsException;	
  	 public Response getRFQDetailBS(String strSSO, String portalId, MultivaluedMap<String, String> multiValmap) throws MaterialsException;
  	 public Response getRFQBS(String strSSO, String portalId,MultivaluedMap<String, String> map) throws MaterialsException;
  	 public Response createRFQBS(String customerCode,String rfqClientNumber,String rfqSubmittedDate,String rfqPriorityCode,String partNumber,String orderedQuantity,String rfqConditionCode,String rfqCustomerRemarks,String strSSO, String portalId) throws MaterialsException;

}
