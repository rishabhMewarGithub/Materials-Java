/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016   
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2015 GE, 
 *                      All rights reserved 
 * Code Review    :     Feb 24, 2016
 * Description    :     MaterialsInterceptorUtil.java
 * 
 * History        :  	Apr 29, 2015                
   Date                           
 **********************************************************/
package com.geaviation.materials.integrator.impl.util;

import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8452;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8453;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8463;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.AUTHORIZATION;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.BUYER;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CFM_BUYER;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CFM_ENQUIRY;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CUST_ENQUIRY;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.EMPTY_STRING;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8452;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8453;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.GLOBAL_ENQUIRY;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.SMSSO;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.entity.MaterialsConstants;
import com.geaviation.materials.entity.MaterialsLoginResponse;
import com.geaviation.materials.entity.MaterialsUserBO;
import com.geaviation.materials.entity.Property;
import com.geaviation.materials.entity.User;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;


@Component
public class MaterialsInterceptorUtil {
	
	private static final Log LOG = LogFactory.getLog(MaterialsInterceptorUtil.class);
	
	@Autowired
	private MaterialsExceptionUtil materialsExceptionUtil;
	
	@Value("${AUTHORIZATION}")
	private String authorization;
	
	@Value("${PORTAL.URL}")
	private String portalBaseUrl;
	
	public static final String PARAMETERS_STRING = "parameters";
	public static final String SSO_PATH_PARAMETER ="{sso}";
	
	/**
	 * Returns true if the given string is null or empty
	 * @param strData
	 * @return boolean
	 */	
	public static boolean isNullOrEmpty(final String strData) {
		boolean isValid = false;
		if (null==strData || ("").equals(strData.trim())) {
			isValid = true;
		}
		return isValid;
	}
	
	/**
	 * Convert JSON String into JSON Object
	 * @param jsonString
	 * @return Object
	 */
	public Object getAsJSON(String jsonString){
		 Object json = null;
		 ObjectMapper mapper = new ObjectMapper();
		 try {
			 json = mapper.readValue(jsonString, Object.class);	
		} catch (Exception e) {
			LOG.info(e);
		}
		 return json;
	}
	
	/**
	 * Return JSON string from Object
	 * @param obj
	 * @return String
	 */
	public String getJsonFromJavaObject(Object obj)
	{
		String json = "";
		 ObjectMapper mapper = new ObjectMapper();
		  try
	      {
	         json = mapper.writeValueAsString(obj);
	      } catch (Exception e)
	      {
	    	LOG.info(e);
	      }
		return json;
		
	}
	

	/**
	 * Returns true if the given string is not null and not empty
	 * @param strData
	 * @return boolean
	 */
	public static boolean isNotNullandEmpty(final String strData) {
		boolean isValid = false;
		if (null!=strData && !strData.trim().equals(EMPTY_STRING)) {
			isValid = true;
		}
		return isValid;
	}

	/**
	 * This will build URL with query parameters
	 * @param url
	 * @param map
	 * @return String
	 * @throws MaterialsException
	 */
	public String appendParamstoURL(String url, Map<String, String> map)
			throws  MaterialsException {
		String cfmUrl = url;
		if (isNotNullandEmpty(cfmUrl)) {
			Map inputMap = new HashMap<String, String>();
			inputMap.putAll(map);
			int size = inputMap.size();
			int i = 1;
			if (!inputMap.isEmpty()) {
				cfmUrl = cfmUrl.concat("?");
				Iterator iterator = inputMap.entrySet().iterator();
				while (iterator.hasNext()) {
					String mapval = "";
					StringBuilder mapvalBuilder = new StringBuilder();
					Entry thisEntry = (Entry) iterator.next();
					if (thisEntry.getValue() instanceof List && (List<String>) thisEntry.getValue() != null) {
						List<String> value = (List<String>) thisEntry.getValue();
							for (String val : value) {
								mapvalBuilder.append(val);
							}
							 mapval = mapvalBuilder.toString();
							cfmUrl = cfmUrl.concat((String) thisEntry.getKey()).concat("=");
							cfmUrl = cfmUrl.concat(mapval);
					} else {
						cfmUrl = cfmUrl.concat((String) thisEntry.getKey()).concat("=");
						mapval = (String) thisEntry.getValue();
						if (mapval != null) {
							cfmUrl = cfmUrl.concat(mapval);
						}
					}
					if (i < size) {
						cfmUrl = cfmUrl.concat("&");
					}
					i++;
				}
			}
		}
		return cfmUrl;
	}
	
	public Object roleConversion(MaterialsLoginResponse loginResponse) throws MaterialsException{
		MaterialsLoginResponse materialsLoginResp = null;
		MaterialsUserBO materialsUserBO = null;
		materialsLoginResp = new MaterialsLoginResponse();
		materialsUserBO = new MaterialsUserBO();
		try{		
			materialsUserBO.setCustomerBOList(loginResponse.getMaterialsUserBO().getCustomerBOList());
			materialsUserBO.setRole(loginResponse.getMaterialsUserBO().getRole());
			materialsUserBO.setSso(loginResponse.getMaterialsUserBO().getSso());
			materialsUserBO.setIcaoCode(loginResponse.getMaterialsUserBO().getIcaoCode());
			materialsUserBO.setOperatingUnitId(loginResponse.getMaterialsUserBO().getOperatingUnitId());
			materialsLoginResp.setMaterialsUserBO(materialsUserBO);
			materialsLoginResp.setMessage(loginResponse.getMessage());
			materialsLoginResp.setSuccess(loginResponse.isSuccess());
			if(null != materialsUserBO){
				if((BUYER).equals(materialsUserBO.getRole())){
					materialsUserBO.setRole(CFM_BUYER);
				}
				else if((GLOBAL_ENQUIRY).equals(materialsUserBO.getRole()) || (CUST_ENQUIRY).equals(materialsUserBO.getRole())){
					materialsUserBO.setRole(CFM_ENQUIRY);
				}
			}
		}
		catch(Exception e){
			LOG.error(" Exception  :: "+e);
		}
			 return materialsLoginResp;
	 }
	
	public static String  Base64Encode(String value)
	{
		byte[] encodedBytes = Base64.encodeBase64(value.getBytes());
	    return new String(encodedBytes);
	}
	
	public static String Base64Decode(String value)
	{
    	byte[] decodedBytes = Base64.decodeBase64(value.getBytes());
    	return  new String(decodedBytes);
	}	
	
	/**
	 * @param date
	 * @return string
	 * @throws MaterialsException
	 */
	public String convertDate(String date) throws MaterialsException {
			SimpleDateFormat sdf = new SimpleDateFormat("dd-mm-yyyy");
		    SimpleDateFormat output = new SimpleDateFormat("yyyy-mm-dd");
		    String dateFrmt = EMPTY_STRING;
		try {
			if(isNotNullandEmpty(date)) {
				 Date data = sdf.parse(date);
				 dateFrmt = output.format(data);
			}
		} catch (Exception e) {
			LOG.info(e);
		}
		return dateFrmt;
	}
	
	
	/**
	 * Returns True if GEAE user
	 * @param sso
	 * @param portalId
	 * @return boolean
	 * @throws MaterialsException
	 */
	public boolean isGEAEUser(String sso, String portalId) throws MaterialsException {
		boolean flag = true;
		if (MaterialsConstants.MYCFM.equalsIgnoreCase(portalId)) {
			LOG.info("portalId==> " + portalId);
			LOG.info("calling potal service to get the user type... ");
			String userType = getUserType(sso, portalId);
			LOG.info("got userType==> " + userType);
			if (("SA").equalsIgnoreCase(userType)) {
				flag = false;
			}
		}
		return flag;
	}
	
	/**
	 * @param sso
	 * @param portalId
	 * @return string
	 * @throws MaterialsException
	 */
	public String getUserType(String sso, String portalId) throws MaterialsException {
		String userType = ""; 
		try {
			User userBO = getUserDetails(sso, portalId,"user/");
			if(null != userBO){
				List<Property> userProperty = userBO.getUserProperty();
				for(Property property : userProperty){
					if("user.currentorgzone".equalsIgnoreCase(property.getPropName())){
						userType = property.getPropValue();
					}
						
				}
				if(userType.isEmpty()){
					throw new MaterialsException(ERROR_8452,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8452), MaterialsInterceptorConstants.SA_INC_ATTR_MESSAGE);
				}
			}
			else{
				throw new MaterialsException(ERROR_8453,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8453), MaterialsInterceptorConstants.PORTAL_SERVICE_IS_NOT_AVAILABLE);
			}
		} catch (TechnicalException e) {
			LOG.error(e);
		} 
		return userType;
	}
	
	/**
	 * Return the User object based on SSO and Portal Id
	 * @param sso
	 * @param portalId
	 * @param path
	 * @return User object
	 */
	public User getUserDetails(String sso, String portalId, String path){
		User userBO = null;
		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.set("sm_ssoid", sso);
			headers.set("Authorization", authorization);
			headers.set("portal_id", portalId);
			HttpEntity<String> entity = new HttpEntity<>(PARAMETERS_STRING,headers);
			String url = portalBaseUrl + path + SSO_PATH_PARAMETER;
			Map<String, String> uriParams = new HashMap<>();
			uriParams.put("sso", sso);
			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url);
		 	SimpleClientHttpRequestFactory rf = (SimpleClientHttpRequestFactory) restTemplate.getRequestFactory();
		 	rf.setConnectTimeout(Integer.parseInt("5000"));
			userBO = restTemplate.exchange(builder.buildAndExpand(uriParams).toUri(), HttpMethod.GET,
					entity, User.class).getBody();
		}

		 catch (Exception e) {
			 LOG.error("Exception inside getUserDetails: " + e.getMessage(), e);
			} 

		return userBO;
	}

	
	/**
	 * This will build a soap message
	 * @param strSSO
	 * @param authorization
	 * @return SOAPMessage
	 * @throws Exception
	 */
	public static  SOAPMessage createSOAPRequest(String strSSO,String authorization) throws Exception {
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = messageFactory.createMessage();
        SOAPPart soapPart = soapMessage.getSOAPPart();
        String serverURI = "urn:snecma:cfm";
        SOAPEnvelope envelope = soapPart.getEnvelope();
        envelope.addNamespaceDeclaration("urn", serverURI);
        //SOAPBody soapBody = envelope.getBody();
        //SOAPElement soapBodyElem = soapBody.addChildElement("getBulkBuyTemplate", "urn");
        MimeHeaders headers = soapMessage.getMimeHeaders();
        headers.addHeader("SOAPAction", serverURI  + "getBulkBuyTemplate");
        headers.addHeader(AUTHORIZATION, authorization);
        headers.addHeader(SMSSO, strSSO);
        soapMessage.saveChanges();
        return soapMessage;
 }
	
	
	public Response htmlErrorResponse(String message) {
		ResponseBuilder rb = Response.noContent();
		rb = rb.type(javax.ws.rs.core.MediaType.TEXT_HTML);
		rb = rb.status(Status.BAD_REQUEST);
		String finalMsg = MaterialsInterceptorConstants.
				HTML_MSG1 + message + MaterialsInterceptorConstants.HTML_MSG2;
		rb = rb.entity(finalMsg);
		return rb.build();
	}
	

	public byte[] getAttachmentData(byte[] data, byte[] boundary1,
			byte[] boundary2) throws MaterialsException {
		
		byte[] byteArray = new byte[0];
		
		if (data == null || boundary1 == null || boundary2 == null) {
			return byteArray;
		}
		int i = 0, j = 0, k = 0, startIndex = 0; 
		long endIndex = data.length;
		boolean match = false;
		int boundary1Pos = 0, boundary2Pos = 0;
		while (!match) {
			startIndex = i;
			match = true;
			for (j = 0; j < boundary1.length; j++) {

				if (data[startIndex] != boundary1[j]) {
					match = false;
					break;
				} else if (startIndex < data.length) {
					startIndex++;
				}
			}

			if (match) {
				boundary1Pos = startIndex - boundary1.length;
				k++;
				match = false;
				if (k == 2) {
					match = true;
				}
			}
			i++;
		}
		i = 0;
		match = false;
		while (!match) {
			endIndex = data.length - i;
			match = true;
			for (j = 0; j < boundary2.length; j++) {
				if (data[toIntExact(endIndex) - 1] != boundary2[boundary2.length - j - 1]) {
					match = false;
					break;
				} else if (endIndex < data.length) {
					endIndex--;
				}
			}
			if (match) {
				boundary2Pos = toIntExact(endIndex);
			}
			i++;
		}
		int pos1 = boundary1Pos + boundary1.length;
		int pos2 = boundary2Pos;
		pos2 = toIntExact(endIndex);
		long length = pos2 - pos1;
		try {
			byte[] output = new byte[toIntExact(length)];
			System.arraycopy(data, pos1, output, 0, toIntExact(length));
			return output;
		} catch (TechnicalException e) {
			LOG.error(e);
			throw new MaterialsException(ERROR_8463,
					materialsExceptionUtil.getErrorMessage(ERROR_8463), MaterialsInterceptorConstants.ERR_ATTACHMENT_DATA);
		}
	}
	
	
	public static int toIntExact(long value) {
	    if ((int)value != value) {
	        throw new ArithmeticException("integer overflow");
	    }
	    return (int)value;
	}
	
}
