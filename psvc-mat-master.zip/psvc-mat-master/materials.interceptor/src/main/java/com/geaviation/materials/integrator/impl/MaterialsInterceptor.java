package com.geaviation.materials.integrator.impl;

import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8450;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8451;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8454;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8455;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8456;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8457;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8458;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8459;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8460;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8461;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8462;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ATTACHMENT;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.AUTHORIZATION;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CONTENT_DISPOSITION;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CONTENT_ID;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CONTENT_TYPE;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8450;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8451;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8454;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8455;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8456;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8457;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8458;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8459;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8460;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8461;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8462;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.FILENAME;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.HTTP_CODE;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ISGEAEUSER;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.JSON_DATA;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.JSON_PATTERN;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.RETURN;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.SMSSO;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.TEXT_XML;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.XLXS;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorUtil.isNotNullandEmpty;

import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.StreamingOutput;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.app.api.IMaterialsApp;
import com.geaviation.materials.app.impl.util.MaterialsAppConstants;
import com.geaviation.materials.entity.CustomerAdminDetailsBO;
import com.geaviation.materials.entity.EffectiveDateAscComparator;
import com.geaviation.materials.entity.EffectiveDateDescComparator;
import com.geaviation.materials.entity.LineDetailBO;
import com.geaviation.materials.entity.LineInfoBO;
import com.geaviation.materials.entity.MaterialsSortField;
import com.geaviation.materials.entity.PlatformAscComparator;
import com.geaviation.materials.entity.PlatformDecComparator;
import com.geaviation.materials.entity.Pricing;
import com.geaviation.materials.entity.PricingCatalogBO;
import com.geaviation.materials.entity.PutRatingPlugDetailsBO;
import com.geaviation.materials.entity.RepairCatalog;
import com.geaviation.materials.entity.RevisionDateAscComparator;
import com.geaviation.materials.entity.RevisionDateDescComparator;
import com.geaviation.materials.entity.ShiptoMarkforAddress;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsInterceptor;
import com.geaviation.materials.integrator.api.IMaterialsLoginInterceptor;
import com.geaviation.materials.integrator.impl.util.MaterialsDataTable;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorUtil;
import com.geaviation.materials.integrator.impl.util.MaterialsSortingUtil;


@Component
public class MaterialsInterceptor implements IMaterialsInterceptor {

	private static final Log log = LogFactory.getLog(MaterialsInterceptor.class);

	@Autowired
	private IMaterialsApp materialsApp;

	@Autowired
	MaterialsExceptionUtil materialsExceptionUtil;

	@Autowired
	private MaterialsInterceptorUtil mateInterceptorUtil;

	@Autowired
	private IMaterialsLoginInterceptor materialsLoginInterceptor;

	@Value("${CFM.URL}")
	private String cfmURL;
	@Value("${AUTHORIZATION}")
	private String authorization;
	@Value("${COLLAB_APP_CODE}")
	private String collabAppCode;
	@Value("${CFM_MATERIALS_URL}")
	private String cfmMaterialsDevUrl;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Response getLineDetailBS(String strSSO, String portalId, MultivaluedMap<String, String> map)
			throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			String msNumber = map.getFirst("msNumber");
			String deliveryId = map.getFirst("deliveryId");
			String orderHeaderId = map.getFirst("orderHeaderId");
			String invoiceHeaderId = map.getFirst("invoiceHeaderId");
			String sEcho = map.getFirst("sEcho");
			Integer start = Integer.parseInt(map.getFirst("iDisplayStart"));
			Integer limit = Integer.parseInt(map.getFirst("iDisplayLength"));
			List<MaterialsSortField> sortFields = MaterialsSortingUtil.getSortFieldsFromForm(map);
			LineDetailBO lineDetailBO = null;
			lineDetailBO = materialsApp.getLineDetailBS(strSSO, portalId, msNumber, deliveryId, orderHeaderId,
					invoiceHeaderId, sortFields, start, limit);
			return Response.ok(buildLineInfoDatatable(lineDetailBO, sEcho)).build();
		} else {
			String response = "";
			Object obj = null;
			String childContentType = null;
			String prntContentType = null;
			int httpCode = 0;
			try {
				String url = cfmURL + MaterialsInterceptorConstants.GET_LINE_DETAILS;
				Map inputMap = new HashMap<String, String>();
				inputMap.putAll(map);
				log.info("getLineDetailBS_inputpassed " + inputMap);
				url = mateInterceptorUtil.appendParamstoURL(url, inputMap);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if (headers != null && headers.length > 0) {
					for (Header header : headers) {
						if (CONTENT_TYPE.equals(header.getName())) {
							prntContentType = header.getValue();
						}
					}
				}
				log.info("getLineDetailBS_outputreceived :: " + response);
				if (null != response && "" != response && response.contains(CONTENT_TYPE)
						&& response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex, contIdIndex);
					childContentType = contTypeSubString.substring(14, contTypeSubString.length());
				}
				if (isNotNullandEmpty(response)) {
					Pattern myPattern = Pattern.compile(JSON_PATTERN);
					Matcher m = myPattern.matcher(response);
					while (m.find()) {
						response = m.group(0);
					}
				}
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("getLineDetailBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCode != 200) {
				if (null != childContentType) {
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
				} else {
					return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
				}

			}
			if (null != childContentType) {
				return Response.ok(obj).type(childContentType).build();
			} else {
				return Response.ok(obj).type(prntContentType).build();
			}
		}
	}

	private MaterialsDataTable<LineInfoBO> buildLineInfoDatatable(LineDetailBO lineDetailBO, String sEcho) {
		MaterialsDataTable<LineInfoBO> dataTable = new MaterialsDataTable<LineInfoBO>();
		dataTable.setDisplayMessage(lineDetailBO.getDisplayMessage());
		dataTable.setiTotalDisplayRecords(materialsApp.fetchResultSize());
		dataTable.setiTotalRecords(materialsApp.fetchResultSize());
		dataTable.setsEcho(sEcho);
		dataTable.setAaData(lineDetailBO.getOrderLineList());
		return dataTable;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
    public Response getLineStatusHistoryBS(String strSSO,
                  String portalId,MultivaluedMap<String, String> multiValmap) throws MaterialsException {
           boolean isGEAEIncUser = true;
           isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
           log.info(ISGEAEUSER + isGEAEIncUser);
           if (isGEAEIncUser) {
                  throw new MaterialsException(ERROR_8451,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451), MaterialsInterceptorConstants.INC_DESC_MESSAGE);
           } else {
                  String response = "";
                  String childContentType = null;
                  String prntContentType = null;
                  Object obj = null;
                  int httpCode = 0;
                  try {
                        String url = cfmURL+MaterialsInterceptorConstants.GET_LINE_STATUS_HISTORY;
                        Map inputMap = new HashMap<String, String>();
                        inputMap.putAll(multiValmap);
                        log.info("getLineStatusHistoryBS_inputpassed " +inputMap);
                        url = mateInterceptorUtil.appendParamstoURL(url, inputMap);
                        HttpClient client = new HttpClient();
                        URI uri = new URI(url, false);
                        GetMethod method = new GetMethod(uri.getEscapedURI());
                        method.addRequestHeader(AUTHORIZATION, authorization);
                        method.addRequestHeader(SMSSO, strSSO);
                        client.executeMethod(method);
                        response = method.getResponseBodyAsString();
                        Header[] headers = method.getResponseHeaders();
                        if(headers != null && headers.length > 0){
                        for (Header header : headers) {
                               if(CONTENT_TYPE.equals(header.getName())){
                               prntContentType = header.getValue();
                                }
                        }
                        }
                        if(null != response && "" != response && response.contains(CONTENT_TYPE) && response.contains(CONTENT_ID)) {
                               int contTypeIndex = response.indexOf(CONTENT_TYPE);
                               int contIdIndex = response.indexOf(CONTENT_ID);
                               String contTypeSubString = response.substring(contTypeIndex,contIdIndex);
                               childContentType = contTypeSubString.substring(14,contTypeSubString.length());
                               }
                        log.info("getLineStatusHistoryBS_outputreceived :: "+response);
                        if(isNotNullandEmpty(response)){
                               Pattern myPattern = Pattern.compile(JSON_PATTERN);
                      Matcher m = myPattern.matcher(response);
                      while (m.find()) {
                          response = m.group(0);   
                      }
                        }
                        JSONObject resobj = new JSONObject(response);
                        JSONObject jsondata =  resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
                        httpCode =  Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
                        obj = jsondata.toString();
                  } catch (Exception e) {
                        log.info("getLineStatusHistoryBS_exceptionblock"+e);
                        if(response == null)
                        {
                               throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
                                             MaterialsInterceptorConstants.DESC_MESSAGE +e.getMessage());
                        }
                        else{
                               throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
                                             MaterialsInterceptorConstants.DESC_MESSAGE + response);
                        }
                  }
                  if(httpCode != 200)
                  {
                        if(null != childContentType){
                               return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
                               }
                               else{
                                      return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
                               }
                  }
                  if(null != childContentType){
                        return Response.ok(obj).type(childContentType).build();
                        }
                        else{
                               return Response.ok(obj).type(prntContentType).build();
                        }
           }
    }
    
	public Response getPricingCatalog(MultivaluedMap<String, String> multiValmap, String strSSO, String portalId)
			throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		PricingCatalogBO pricingCatalogBO = null;
		log.info("getPricingCatalog_inputpassed" + "multiValmap: " + multiValmap);
		if (isGEAEIncUser) {
			pricingCatalogBO = materialsApp.getPricingCatalog(multiValmap, strSSO, portalId);
			return Response.ok(pricingCatalogBO).build();
		} else {
			List<Pricing> lstPrice = new ArrayList<Pricing>();
			String icaoCode = "";
			String url = "";
			String response = "";
			int httpCode = 0;
			if (!isNotNullandEmpty(strSSO)) {
				throw new MaterialsException(ERROR_8458, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8458),
						MaterialsInterceptorConstants.ERR_SSO_NOT_FOUND);
			}
			if (!isNotNullandEmpty(portalId)) {
				throw new MaterialsException(ERROR_8459, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8459),
						MaterialsInterceptorConstants.ERR_PORTAL_ID_NOT_FOUND);
			}
			try {
				Object loginObj = materialsLoginInterceptor.requestMaterialsLogin(strSSO, portalId);
				JSONObject loginobject = new JSONObject(loginObj.toString());
				JSONObject materialsUserObj = loginobject.optJSONObject("MaterialsUserBO");
				if (materialsUserObj != null) {
					// Check if user is valid materials user.
					icaoCode = materialsUserObj.optString("icaoCode"); 
						// Get GE ICAO code - MYJIRATEST-14900
				}
				log.info("SA_ICAO_Code_IN_getPricingCatalogBS--" + icaoCode);
				Map<String, String> map = new HashMap<String, String>();
				if (isNotNullandEmpty(icaoCode)) {
					map.put("geIcaoCode", icaoCode);
				} else {
					throw new MaterialsException(ERROR_8461, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8461),
							MaterialsInterceptorConstants.ERR_ICAOCODE_NOT_FOUND);
				}
				map.put("collabAppCode", collabAppCode);
				url = cfmURL + MaterialsInterceptorConstants.GET_COMPANYINFO;
				url = mateInterceptorUtil.appendParamstoURL(url, map);
				HttpClient client = new HttpClient();
				GetMethod method = new GetMethod(url);
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				httpCode = method.getStatusCode();
				if (httpCode == 200) {
					if (isNotNullandEmpty(response)) {
						Pattern myPattern = Pattern.compile(JSON_PATTERN);
						Matcher m = myPattern.matcher(response);
						while (m.find()) {
							response = m.group(0);
						}
					}
					JSONObject resobj = new JSONObject(response);
					JSONObject returnObj = resobj.optJSONObject(RETURN);
					String assetConstraint = getAssetConstraint(returnObj);
					List<String> listOfFiles = new ArrayList<String>();

					try {
						PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
						Resource[] resources = resolver
								.getResources(MaterialsInterceptorConstants.SA_PRICECATALOGS_PATH + "*");
						for (Resource resource : resources) {
							listOfFiles.add(resource.getFilename());
						}

					} catch (IOException e) {
						throw new MaterialsException(ERROR_8454,
								materialsExceptionUtil.getErrorMessage(ERROR_CODE_8454),
								MaterialsInterceptorConstants.ERR_FOLDER_DOES_NOT_EXIST);
					}
					if (listOfFiles.size() > 0) {						
						lstPrice = getListPriceObject(listOfFiles,assetConstraint,lstPrice);
						pricingCatalogBO = getPricingCatalogBO(multiValmap,lstPrice);
						} else {
						throw new MaterialsException(ERROR_8457,
								materialsExceptionUtil.getErrorMessage(ERROR_CODE_8457),
								MaterialsInterceptorConstants.ERR_DOCUMENTS_NOT_FOUND);
					}

				} else {
					throw new MaterialsException(ERROR_8462, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8462),
							MaterialsInterceptorConstants.ERR_COMPANYINFO_INFO_NOT_FOUND);
				}
			} catch (TechnicalException e) {
				log.info(e);
			} catch (HttpException e) {
				log.info(e);
			} catch (IOException e) {
				log.info(e);
			}
		}
		return Response.ok(pricingCatalogBO).build();
	}
    
	private String getAssetConstraint(JSONObject returnObj) throws MaterialsException {
		String assetConstraint = "";
		JSONArray asset = null;
		if (null != returnObj) {
			JSONObject jsondata = returnObj.optJSONObject(JSON_DATA);
			if (null != jsondata) {
				JSONObject content = jsondata.optJSONObject("content");
				if (null != content) {
					JSONObject collabChannel = content.optJSONObject("collabChannel");
					if (null != collabChannel) {
						JSONArray collabApp = collabChannel.optJSONArray("collabApp");
						if (null != collabApp) {
							asset = collabApp.optJSONObject(0).optJSONArray("asset");
						}
					}
				}
			}
		}
		if (asset != null) {
			String assetValues = asset.join("|");
			if (assetValues.contains("CFM") && assetValues.contains("LEAP")) {
				assetConstraint = "BOTH";
			} else if (assetValues.contains("CFM")) {
				assetConstraint = "CFM";
			} else if (assetValues.contains("LEAP")) {
				assetConstraint = "LEAP";
			}
		} else {
			throw new MaterialsException(ERROR_8460,
					materialsExceptionUtil.getErrorMessage(ERROR_CODE_8460),
					MaterialsInterceptorConstants.ERR_NO_PLATFORM_AVAIL);
		}
		return assetConstraint;
	}

	private PricingCatalogBO getPricingCatalogBO(MultivaluedMap<String, String> multiValmap, List<Pricing> lstPrice) throws MaterialsException {
		
		int sEcho = 0;
		int iDisplayStart = 0;
		int sortColumn = 0;
		int iDisplayLength = 0;
		String icaoCode = "";
		String sortorder = null;
		String columnName = "";
		HashMap filterSortList = null;
		PricingCatalogBO pricingCatalogBO = new PricingCatalogBO();
		String order = MaterialsInterceptorConstants.ASC;
		
		try {
			
			filterSortList = getFilterSortList(multiValmap);
			if (null != multiValmap.get(MaterialsInterceptorConstants.SSORTDIR_0)
					&& !("").equals(multiValmap.get(MaterialsInterceptorConstants.SSORTDIR_0)))
				sortorder = multiValmap.get(MaterialsInterceptorConstants.SSORTDIR_0).get(0);
			if (null != multiValmap.get(MaterialsInterceptorConstants.IDISPLAY_START)
					&& !("").equals(multiValmap.get(MaterialsInterceptorConstants.IDISPLAY_START)))
				iDisplayStart = Integer
						.parseInt(multiValmap.get(MaterialsInterceptorConstants.IDISPLAY_START).get(0));
			if (null != multiValmap.get(MaterialsInterceptorConstants.IDISPLAY_LENGTH)
					&& !("").equals(multiValmap.get(MaterialsInterceptorConstants.IDISPLAY_LENGTH)))
				iDisplayLength = Integer.parseInt(
						multiValmap.get(MaterialsInterceptorConstants.IDISPLAY_LENGTH).get(0));
			if (null != multiValmap.get(MaterialsInterceptorConstants.SECHO)
					&& !("").equals(multiValmap.get(MaterialsInterceptorConstants.SECHO)))
				sEcho = Integer.parseInt(multiValmap.get(MaterialsInterceptorConstants.SECHO).get(0));
			if (null != multiValmap.get(MaterialsInterceptorConstants.ISORTCOL_0)
					&& !("").equals(multiValmap.get(MaterialsInterceptorConstants.ISORTCOL_0)))
				sortColumn = Integer
						.parseInt(multiValmap.get(MaterialsInterceptorConstants.ISORTCOL_0).get(0));
			if (sortorder == null)
				sortorder = MaterialsInterceptorConstants.ASC;

			columnName = (String) filterSortList.get(sortColumn);
			if (columnName == null)
				throw new MaterialsException(ERROR_8455,
						materialsExceptionUtil.getErrorMessage(ERROR_CODE_8455),
						MaterialsInterceptorConstants.ERR_DATATABLE_ERROR_OCCURED);
		} catch (TechnicalException e) {
			log.info(e);
			throw new MaterialsException(ERROR_8455,
					materialsExceptionUtil.getErrorMessage(ERROR_CODE_8455),
					MaterialsInterceptorConstants.ERR_DATATABLE_ERROR_OCCURED);
		}
		if (iDisplayStart > lstPrice.size() - 1) {
			throw new MaterialsException(ERROR_8456,
					materialsExceptionUtil.getErrorMessage(ERROR_CODE_8456),
					MaterialsInterceptorConstants.ERR_DATATABLE_DISPLAY_ERROR_OCCURED);
		} else {
			int size = iDisplayStart + iDisplayLength;
			if (size >= lstPrice.size()) {
				size = lstPrice.size();
			}
			lstPrice = lstPrice.subList(iDisplayStart, size);
		}
		pricingCatalogBO.setITotalRecords((double) lstPrice.size());
		pricingCatalogBO.setITotalDisplayRecords((double) lstPrice.size());
		pricingCatalogBO.setSuccess(true);
		pricingCatalogBO.setSEcho(sEcho);
		pricingCatalogBO.setResponse(getSortedListPrice(columnName,order,lstPrice,sortorder));
		return pricingCatalogBO;
	}

	private List<Pricing> getSortedListPrice(String columnName, String order, List<Pricing> lstPrice,
			String sortorder) {
		
		if (columnName.equals(MaterialsInterceptorConstants.PLATFORM)) {
			if (sortorder.equals(order))
				Collections.sort(lstPrice, new PlatformAscComparator());
			else

				Collections.sort(lstPrice, new PlatformDecComparator());
		} else if (columnName.equals(MaterialsInterceptorConstants.EFFDATE)) {
			if (sortorder.equals(order))
				Collections.sort(lstPrice, new EffectiveDateAscComparator());
			else
				Collections.sort(lstPrice, new EffectiveDateDescComparator());
		} else if (columnName.equals(MaterialsInterceptorConstants.REVISION_DATE)) {
			if (sortorder.equals(order))
				Collections.sort(lstPrice, new RevisionDateAscComparator());
			else
				Collections.sort(lstPrice, new RevisionDateDescComparator());
		}
		return lstPrice;
	}

	private HashMap getFilterSortList(MultivaluedMap<String, String> multiValmap) {
		HashMap filterSortList = new HashMap();
		for (int k = 0; k < multiValmap.size(); k++) {
			filterSortList.put(k, null);
		}
		Set set = multiValmap.entrySet();
		Iterator it = set.iterator();
		while (it.hasNext()) {
			Map.Entry<String, List<String>> entry = (Entry) it.next();
			List<String> value = entry.getValue();
			String val = value.get(0);
			if (entry.getKey().contains(MaterialsInterceptorConstants.MDATA_PROP)) {
				String position = entry.getKey().replace(MaterialsInterceptorConstants.MDATA_PROP, "").trim();
				int positionVal = 0;
				if (!("").equals(position))
					positionVal = Integer.parseInt(position);
				filterSortList.put(positionVal, val);
			}
		}
		return filterSortList;
	}

	private List<Pricing> getListPriceObject(List<String> listOfFiles, String assetConstraint, List<Pricing> lstPrice) throws MaterialsException {
		List<String> files = null;
		List<String> filesProcessed = null;
		boolean isStart = true;
		
		files = new ArrayList<String>();
		filesProcessed = new ArrayList<String>();
		for (String file : listOfFiles) {
			if ("BOTH".equalsIgnoreCase(assetConstraint)
					&& (file.contains("CFM") || file.contains("LEAP"))) {
				files.add(file);
			} else if ("CFM".equalsIgnoreCase(assetConstraint) && file.contains("CFM")) {
				files.add(file);
			} else if ("LEAP".equalsIgnoreCase(assetConstraint) && file.contains("LEAP")) {
				files.add(file);
			}
		}

		for (String fileStr : files) {
			if (isStart || (!filesProcessed.isEmpty() && !(filesProcessed.contains(fileStr)))) {
				Pricing pric = new Pricing();
				String platform = fileStr.substring(0, fileStr.indexOf("_"));
				String fileName = fileStr.substring(0, fileStr.indexOf("."));
				String fileExt = fileStr.substring(fileStr.indexOf("."), fileStr.length());
				String date = fileStr.substring(fileStr.indexOf("_") + 1, fileStr.indexOf("."));
				pric.setPlatform(platform);
				String encPlatform = MaterialsInterceptorUtil.Base64Encode(fileName);
				String encDocPdf = MaterialsInterceptorUtil.Base64Encode(fileExt);
				String encDocExcel = MaterialsInterceptorUtil.Base64Encode(fileExt);
				if ((".pdf").equalsIgnoreCase(fileExt)) {
					pric.setEffDate(mateInterceptorUtil.convertDate(date.replaceAll("_", "-")));
					pric.setPdfLink(cfmMaterialsDevUrl + MaterialsInterceptorConstants.MATERIAL_URL
							+ encPlatform + MaterialsInterceptorConstants.DOC_TYPE + encDocPdf);
					filesProcessed.add(fileName + fileExt);
					if (files.contains(fileName + XLXS)) {
						encDocExcel = MaterialsInterceptorUtil.Base64Encode(XLXS);
						pric.setRevisionDate(
								mateInterceptorUtil.convertDate(date.replaceAll("_", "-")));
						pric.setExcelLink(cfmMaterialsDevUrl
								+ MaterialsInterceptorConstants.MATERIAL_URL + encPlatform
								+ MaterialsInterceptorConstants.DOC_TYPE + encDocExcel);
						filesProcessed.add(fileName + XLXS);
					} else if (files.contains(fileName + ".xls")) {
						encDocExcel = MaterialsInterceptorUtil.Base64Encode(".xls");
						pric.setRevisionDate(
								mateInterceptorUtil.convertDate(date.replaceAll("_", "-")));
						pric.setExcelLink(cfmMaterialsDevUrl
								+ MaterialsInterceptorConstants.MATERIAL_URL + encPlatform
								+ MaterialsInterceptorConstants.DOC_TYPE + encDocExcel);
						filesProcessed.add(fileName + ".xls");
					}
				} else {
					pric.setRevisionDate(mateInterceptorUtil.convertDate(date.replaceAll("_", "-")));
					pric.setExcelLink(cfmMaterialsDevUrl + MaterialsInterceptorConstants.MATERIAL_URL
							+ encPlatform + MaterialsInterceptorConstants.DOC_TYPE + encDocExcel);
					filesProcessed.add(fileName + fileExt);
					if (files.contains(fileName + ".pdf")) {
						encDocPdf = MaterialsInterceptorUtil.Base64Encode(".pdf");
						pric.setEffDate(mateInterceptorUtil.convertDate(date.replaceAll("_", "-")));
						pric.setPdfLink(cfmMaterialsDevUrl + MaterialsInterceptorConstants.MATERIAL_URL
								+ encPlatform + MaterialsInterceptorConstants.DOC_TYPE + encDocPdf);
						filesProcessed.add(fileName + ".pdf");
					}
				}
				lstPrice.add(pric);
				isStart = false;
			}
			if (files.isEmpty()) {
				break;
			}
		}
		return lstPrice;
	}

	@Override
	public Response getPricingCatalogDocBS(String platform, String doctype, String strSSO, String portalId,
			String effDate) throws MaterialsException {
		Response response = null;
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		if (isGEAEIncUser) {
			response = materialsApp.getPricingCatalogDocBS(platform, doctype, strSSO, portalId, effDate);
		} else {
			String url = "";
			String jsonResponse = "";
			String icaoCode = "";
			int httpCode = 0;
			if (!isNotNullandEmpty(platform)) {
				return htmlErrorResponse(MaterialsInterceptorConstants.ERR_PLATFORM_NOT_FOUND);
			}
			if (!isNotNullandEmpty(doctype)) {
				return htmlErrorResponse(MaterialsInterceptorConstants.ERR_DOCTYPE_NOT_FOUND);
			}
			if (!isNotNullandEmpty(strSSO)) {
				return htmlErrorResponse(MaterialsInterceptorConstants.ERR_SSO_NOT_FOUND);
			}
			if (!isNotNullandEmpty(portalId)) {
				return htmlErrorResponse(MaterialsInterceptorConstants.ERR_PORTAL_ID_NOT_FOUND);
			}
			try {
				Object loginObj = materialsLoginInterceptor.requestMaterialsLogin(strSSO, portalId);
				JSONObject loginobject = new JSONObject(loginObj.toString());
				JSONObject materialsUserObj = loginobject.optJSONObject("MaterialsUserBO");
				if (materialsUserObj != null) { // Check if user is valid
												// materials user.
					icaoCode = materialsUserObj.optString("icaoCode"); // Get GE
																		// ICAO
																		// code
																		// -
																		// MYJIRATEST-14900
				}
				log.info("SA_ICAO_Code_IN_getPricingCatalogBS" + icaoCode);
				Map<String, String> map = new HashMap<String, String>();
				if (isNotNullandEmpty(icaoCode)) {
					map.put("geIcaoCode", icaoCode);
				} else {
					return htmlErrorResponse(MaterialsInterceptorConstants.ERR_ICAOCODE_NOT_FOUND);
				}
				map.put("collabAppCode", collabAppCode);
				url = cfmURL + MaterialsInterceptorConstants.GET_COMPANYINFO;
				url = mateInterceptorUtil.appendParamstoURL(url, map);
				HttpClient client = new HttpClient();
				GetMethod method = new GetMethod(url);
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				httpCode = method.getStatusCode();
				if (httpCode == 200) {
					jsonResponse = method.getResponseBodyAsString();
					response = getResponseObject(jsonResponse,doctype,platform);
				} else {
					throw new MaterialsException(ERROR_8462, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8462),
							MaterialsInterceptorConstants.ERR_COMPANYINFO_INFO_NOT_FOUND);
				}
			} catch (TechnicalException | IOException e) {
				log.info(e);
				return htmlErrorResponse(MaterialsInterceptorConstants.ERR_DOCUMENTS_NOT_FOUND);
			}
		}
		return response;
	}
    private Response getResponseObject(String jsonResponse, String doctype, String platform) {
    	Response response = null;
    	String decPlatform = null;
		String decDocType = null;
		String fileName = null;
		JSONArray jsondata = null;
		byte[] bytes = null;
		boolean isUserAccess = false;
		
    	if (isNotNullandEmpty(jsonResponse)) {
			Pattern myPattern = Pattern.compile(JSON_PATTERN);
			Matcher m = myPattern.matcher(jsonResponse);
			while (m.find()) {
				jsonResponse = m.group(0);
			}
		}
		JSONObject resobj = new JSONObject(jsonResponse);
		String assetConstraint = "";
		jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA).getJSONObject("content")
				.getJSONObject("collabChannel").getJSONArray("collabApp").getJSONObject(0)
				.getJSONArray("asset");
		if (jsondata != null) {
			String assetValues = jsondata.join("|");
			if (assetValues.contains("CFM") && assetValues.contains("LEAP")) {
				assetConstraint = "BOTH";
			} else if (assetValues.contains("CFM")) {
				assetConstraint = "CFM";
			} else if (assetValues.contains("LEAP")) {
				assetConstraint = "LEAP";
			}
		} else {
			return htmlErrorResponse(MaterialsInterceptorConstants.ERR_NO_PLATFORM_AVAIL);
		}
		decPlatform = MaterialsInterceptorUtil.Base64Decode(platform);
		if ("BOTH".equalsIgnoreCase(assetConstraint)
				&& (decPlatform.contains("CFM") || decPlatform.contains("LEAP"))) {
			isUserAccess = true;
		} else if ("CFM".equalsIgnoreCase(assetConstraint) && decPlatform.contains("CFM")) {
			isUserAccess = true;
		} else if ("LEAP".equalsIgnoreCase(assetConstraint) && decPlatform.contains("LEAP")) {
			isUserAccess = true;
		}
		if (isUserAccess) {
			decDocType = MaterialsInterceptorUtil.Base64Decode(doctype);
			fileName = decPlatform + decDocType.toLowerCase();
			try {
				String path = "";
				path = MaterialsInterceptorConstants.SA_PRICECATALOGS_PATH + fileName;
				Resource resource = new ClassPathResource(path);
				bytes = IOUtils.toByteArray(resource.getInputStream());
				response = buildResponse(bytes, decDocType, fileName);

			} catch (TechnicalException | IOException e) {
				log.info(e);
				return htmlErrorResponse(MaterialsAppConstants.ERR_DOCUMENT_NOT_FOUND);
			}

		} else {
			return htmlErrorResponse(MaterialsInterceptorConstants.ERR_DOCUMENT_NOT_FOUND);
		}
		return response;
	}

	private Response htmlErrorResponse(String message) {
        ResponseBuilder rb = Response.noContent();
        rb = rb.type(MediaType.TEXT_HTML);
        rb = rb.status(Status.BAD_REQUEST);
        String finalMsg = MaterialsInterceptorConstants.
                     HTML_MSG1 + message + MaterialsInterceptorConstants.HTML_MSG2;
        rb = rb.entity(finalMsg);
        return rb.build();
 }
 
 private Response buildResponse(final byte[] bytes, String doctype,
               String fileName) {
        StreamingOutput stream = null;
        stream = new StreamingOutput() {
               public void write(OutputStream out) throws IOException,
               WebApplicationException {
                     try {
                            out.write(bytes);
                     } catch (Exception e) {
                            log.error(e);
                            throw new WebApplicationException(e);
                     }
               }
        };
        if (bytes != null) {
               return Response
                            .ok(stream)
                            .header(CONTENT_DISPOSITION,
                                          ATTACHMENT+";"+ FILENAME+" = " + fileName).build();
        } 
        else {
               return htmlErrorResponse(doctype+" "+MaterialsInterceptorConstants.ERR_DOCUMENT_NOT_FOUND);
        }
 }

	public Response getPoQuotations(String strSSO, String portalId, MultivaluedMap<String, String> multiValmap)
			throws MaterialsException {

		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			throw new MaterialsException(ERROR_8451, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),
					MaterialsInterceptorConstants.INC_DESC_MESSAGE);
		} else {
			String response = "";
			Object obj = null;
			String childContentType = null;
			String prntContentType = null;
			int httpCode = 0;
			try {
				Map inputMap = new HashMap<String, String>();
				String url = cfmURL + MaterialsInterceptorConstants.GET_PO_QUOTATIONS;
				inputMap.putAll(multiValmap);
				log.info("getPoQuotations_inputpassed " + inputMap);
				url = mateInterceptorUtil.appendParamstoURL(url, inputMap);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if (headers != null && headers.length > 0) {
					for (Header header : headers) {
						if (CONTENT_TYPE.equals(header.getName())) {
							prntContentType = header.getValue();
						}
					}
				}
				log.info("getPoQuotations_outputreceived :: " + response);
				if (null != response && "" != response && response.contains(CONTENT_TYPE)
						&& response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex, contIdIndex);
					childContentType = contTypeSubString.substring(14, contTypeSubString.length());
				}

				if (isNotNullandEmpty(response)) {
					Pattern myPattern = Pattern.compile(JSON_PATTERN);
					Matcher m = myPattern.matcher(response);
					while (m.find()) {
						response = m.group(0);
					}
				}

				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("getPoQuotations_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCode != 200) {
				if (null != childContentType) {
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
				} else {
					return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
				}
			}
			if (null != childContentType) {
				return Response.ok(obj).type(childContentType).build();
			} else {
				return Response.ok(obj).type(prntContentType).build();
			}
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Response getShiptoMarkforAddressBS(String strSSO, String portalId,
			String customerId,String custCode) throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			ShiptoMarkforAddress shiptoMarkforAddress = materialsApp.getShiptoMarkforAddressBS(strSSO, portalId,
					customerId);
			return Response.ok(shiptoMarkforAddress).build();
		} else {
			String response = "";
			String childContentType = null;
			String prntContentType = null;
			Object obj = null;
			int httpCode = 0;
			try {
				String url = cfmURL+MaterialsInterceptorConstants.SHIP_TO_MART_FOR_ADDRESS;
				Map inputMap = new HashMap<String, String>();
				inputMap.put("customerId", customerId);
				log.info("getShiptoMarkforAddressBS_inputpassed " +inputMap);
				url = mateInterceptorUtil.appendParamstoURL(url, inputMap);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if(headers != null && headers.length > 0){
				for (Header header : headers) {
					if(CONTENT_TYPE.equals(header.getName())){
					prntContentType = header.getValue();
					}
				}
				}
				if(null != response && "" != response && response.contains(CONTENT_TYPE) && response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex,contIdIndex);
					childContentType = contTypeSubString.substring(14,contTypeSubString.length());
					}
				log.info("getShiptoMarkforAddressBS_outputreceived"+response);
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata =  resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode =  Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("getShiptoMarkforAddressBS_exceptionblock"+e);
				if(response == null)
				{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE +e.getMessage());
				}
				else{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if(httpCode != 200)
			{
				if(null != childContentType){
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
					}
					else{
						return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
					}
			}
			if(null != childContentType){
				return Response.ok(obj).type(childContentType).build();
				}
				else{
					return Response.ok(obj).type(prntContentType).build();
				}
		}
	}
	/**
	 * @param custId
	 * @param sso
	 * @param portalId
	 * @return 
	 * @throws MaterialsException
	 */
	public Response getCustAdminDetailsBS(String sso,String portalId,String custId) throws MaterialsException {

		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(sso, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			CustomerAdminDetailsBO customerAdminDetailsBO = materialsApp.getCustAdminDetailsBS(sso, portalId,custId);
			return Response.ok(customerAdminDetailsBO).build();
		} else{
			String response = "";
			String childContentType = null;
			String prntContentType = null;
			Object obj = null;
			int httpCode = 0; 
			try {
				String url = cfmURL+MaterialsInterceptorConstants.GET_CUSTOMER_DETAILS;
				Map<String, String> map = new HashMap<String, String>();
				map.put("custId", custId);
				log.info("getCustAdminDetailsBS_inputpassed " +map);
				url = mateInterceptorUtil.appendParamstoURL(url, map);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, sso);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if(headers != null && headers.length > 0){
				for (Header header : headers) {
					if(CONTENT_TYPE.equals(header.getName())){
					prntContentType = header.getValue();
					}
				}
				}
				
				if(null != response && "" != response && response.contains(CONTENT_TYPE) && response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex,contIdIndex);
					childContentType = contTypeSubString.substring(14,contTypeSubString.length());
					}
				log.info("getCustAdminDetailsBS_outputreceived"+response);
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata =  resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode =  Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
				
			} catch (Exception e) {
				log.info("getCustAdminDetailsBS_exceptionblock"+e);
				if(response == null)
				{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE +e.getMessage());
				}
				else{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if(httpCode != 200)
			{
				if(null != childContentType){
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
					}
					else{
						return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
					}
			}
			if(null != childContentType){
				return Response.ok(obj).type(childContentType).build();
				}
				else{
					return Response.ok(obj).type(prntContentType).build();
				}
		}
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Response getCommercialAgreementBS(String strSSO, String portalId, MultivaluedMap<String, String> map)
			throws MaterialsException {

		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {

			throw new MaterialsException(ERROR_8451, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),
					MaterialsInterceptorConstants.INC_DESC_MESSAGE);

		} else {

			String response = "";
			Object obj = null;
			String childContentType = null;
			String prntContentType = null;
			int httpCodeStatusCode = 0;
			try {
				String url = cfmURL + MaterialsInterceptorConstants.GET_COMMERCIAL_AGGREMENT;
				Map inputMap = new HashMap<String, String>();
				inputMap.putAll(map);
				log.info("getCommercialAgreementBS_inputpassed " + inputMap);
				url = mateInterceptorUtil.appendParamstoURL(url, inputMap);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if (headers != null && headers.length > 0) {
					for (Header header : headers) {
						if (CONTENT_TYPE.equals(header.getName())) {
							prntContentType = header.getValue();
						}
					}
				}
				if (null != response && "" != response && response.contains(CONTENT_TYPE)
						&& response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex, contIdIndex);
					childContentType = contTypeSubString.substring(14, contTypeSubString.length());
				}
				log.info("getCommercialAgreementBS_outputreceived" + response);
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCodeStatusCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("getCommercialAgreementBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCodeStatusCode != 200) {
				if (null != childContentType) {
					return Response.status(httpCodeStatusCode).entity(obj.toString()).type(childContentType).build();
				} else {
					return Response.status(httpCodeStatusCode).entity(obj.toString()).type(prntContentType).build();
				}
			}
			if (null != childContentType) {
				return Response.ok(obj).type(childContentType).build();
			} else {
				return Response.ok(obj).type(prntContentType).build();
			}

		}

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Response getCommercialAgreementPartBS(String strSSO, String portalId,
			MultivaluedMap<String, String> multiValmap) throws MaterialsException {

		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {

			throw new MaterialsException(ERROR_8451, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),
					MaterialsInterceptorConstants.INC_DESC_MESSAGE);

		} else {

			String response = "";
			Object obj = null;
			String childContentType = null;
			String prntContentType = null;
			int httpCodeStatusCode = 0;
			try {
				String url = cfmURL + MaterialsInterceptorConstants.GET_COMMERCIAL_AGGREMENT_PART;
				Map inputMap = new HashMap<String, String>();
				inputMap.putAll(multiValmap);
				log.info("getCommercialAgreementPartBS_inputpassed " + inputMap);
				url = mateInterceptorUtil.appendParamstoURL(url, inputMap);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if (headers != null && headers.length > 0) {
					for (Header header : headers) {
						if (CONTENT_TYPE.equals(header.getName())) {
							prntContentType = header.getValue();
						}
					}
				}
				if (null != response && "" != response && response.contains(CONTENT_TYPE)
						&& response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex, contIdIndex);
					childContentType = contTypeSubString.substring(14, contTypeSubString.length());
				}
				log.info("getCommercialAgreementPartBS_outputreceived" + response);
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCodeStatusCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("getCommercialAgreementPartBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCodeStatusCode != 200) {
				if (null != childContentType) {
					return Response.status(httpCodeStatusCode).entity(obj.toString()).type(childContentType).build();
				} else {
					return Response.status(httpCodeStatusCode).entity(obj.toString()).type(prntContentType).build();
				}
			}
			if (null != childContentType) {
				return Response.ok(obj).type(childContentType).build();
			} else {
				return Response.ok(obj).type(prntContentType).build();
			}

		}

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Response getRatingPlugBS(String strSSO, String portalId, MultivaluedMap<String, String> map)
			throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			throw new MaterialsException(ERROR_8451, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),
					MaterialsInterceptorConstants.INC_DESC_MESSAGE);
		} else {
			log.info("getRatingPlugBS Start -- Snecma");
			String childContentType = null;
			String prntContentType = null;
			String response = "";
			Object obj = null;
			int httpCode = 0;
			try {
				String url = cfmURL + MaterialsInterceptorConstants.RATING_PLUGIN;
				Map inputMap = new HashMap<String, String>();
				inputMap.putAll(map);
				log.info("getRatingPlugBS_inputpassed " + inputMap);
				url = mateInterceptorUtil.appendParamstoURL(url, inputMap);
				log.info("getRatingPlugBS 1 -- Snecma" + url);
				HttpClient client = new HttpClient();
				log.info("getRatingPlugBS 2 -- Snecma");
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				log.info("getRatingPlugBS 3 -- Snecma" + url);
				method.addRequestHeader(AUTHORIZATION, authorization);

				method.addRequestHeader(SMSSO, strSSO);
				log.info("getRatingPlugBS 4 -- Before Execute");
				client.executeMethod(method);
				log.info("getRatingPlugBS 5 --After Execute");
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if (headers != null && headers.length > 0) {
					for (Header header : headers) {
						if (CONTENT_TYPE.equals(header.getName())) {
							prntContentType = header.getValue();
						}
					}
				}
				if (null != response && "" != response && response.contains(CONTENT_TYPE)
						&& response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex, contIdIndex);
					childContentType = contTypeSubString.substring(14, contTypeSubString.length());
				}
				log.info("getRatingPlugBS_outputreceived" + response);
				JSONObject resobj = new JSONObject(response);
				log.info("getRatingPlugBS 6 --After resobj" + resobj);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				log.info("getRatingPlugBS 7 --After resobj");
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				log.info("getRatingPlugBS 8 --After resobj");
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("getRatingPlugBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCode != 200) {
				if (null != childContentType) {
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
				} else {
					return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
				}
			}
			if (null != childContentType) {
				return Response.ok(obj).type(childContentType).build();
			} else {
				return Response.ok(obj).type(prntContentType).build();
			}
		}
	}

	@Override
	public Response createRatingPlugFormBS(String strSSO, String portalId, String ratingPlugDetails)
			throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			throw new MaterialsException(ERROR_8451, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),
					MaterialsInterceptorConstants.INC_DESC_MESSAGE);
		} else {
			String response = "";
			Object obj = null;
			StringWriter writer = new StringWriter();
			int httpCode = 0;
			try {
				log.info("createRatingPlugFormBS_InputJson  :: " + ratingPlugDetails);
				String url = cfmURL + MaterialsInterceptorConstants.CREATYE_RATING_PLUGIN;
				String payload;
				PutRatingPlugDetailsBO putRatingPlugDetailsBO = new PutRatingPlugDetailsBO(ratingPlugDetails);
				PutRatingPlugDetailsBO putRatingPlugDetailsBO1 = new PutRatingPlugDetailsBO();
				JAXBContext context = JAXBContext.newInstance(putRatingPlugDetailsBO1.getClass());
				Marshaller marshaller = context.createMarshaller();
				marshaller.marshal(putRatingPlugDetailsBO, writer);
				payload = writer.toString();
				log.info("createRatingPlugFormBS_inputpassed " + payload);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				PutMethod method = new PutMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				method.setRequestHeader(CONTENT_TYPE, TEXT_XML);
				method.setRequestBody(payload);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				log.info("createRatingPlugFormBS_outputreceived :: " + response);
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("createRatingPlugFormBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCode != 200) {
				return Response.status(httpCode).entity(obj.toString()).build();
			}
			return Response.ok(obj).build();
		}
	}

	@Override
	public Response getRatingPlugFormBS(String strSSO, String portalId, MultivaluedMap<String, String> multiValmap)
			throws MaterialsException {

		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			throw new MaterialsException(ERROR_8451, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),
					MaterialsInterceptorConstants.INC_DESC_MESSAGE);
		} else {
			String response = "";
			String childContentType = null;
			String prntContentType = null;
			Object obj = null;
			int httpCode = 0;
			try {
				String url = cfmURL + MaterialsInterceptorConstants.GET_RATING_PLUGIN_FORM;
				Map inputMap = new HashMap<String, String>();
				inputMap.putAll(multiValmap);
				log.info("getRatingPlugFormBS_inputpassed " + inputMap);
				url = mateInterceptorUtil.appendParamstoURL(url, inputMap);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, strSSO);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if (headers != null && headers.length > 0) {
					for (Header header : headers) {
						if (CONTENT_TYPE.equals(header.getName())) {
							prntContentType = header.getValue();
						}
					}
				}
				if (null != response && "" != response && response.contains(CONTENT_TYPE)
						&& response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex, contIdIndex);
					childContentType = contTypeSubString.substring(14, contTypeSubString.length());
				}
				log.info("getRatingPlugFormBS_outputreceived :: " + response);
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata = resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode = Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("getRatingPlugFormBS_exceptionblock" + e);
				if (response == null) {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + e.getMessage());
				} else {
					throw new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if (httpCode != 200) {
				if (null != childContentType) {
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
				} else {
					return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
				}
			}
			if (null != childContentType) {
				return Response.ok(obj).type(childContentType).build();
			} else {
				return Response.ok(obj).type(prntContentType).build();
			}
		}
	}

	public Response getRepairCatalogBS(String strSSO, String portalId, String fileName) throws MaterialsException {

		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);

		if (!isNotNullandEmpty(fileName)) {
			return htmlErrorResponse(MaterialsInterceptorConstants.ERR_DOC_NAME_NOT_FOUND);
		}
		log.info(ISGEAEUSER + isGEAEIncUser);
		Response response = null;
		if (isGEAEIncUser) {
			response = materialsApp.getRepairCatalogBS(strSSO, portalId, fileName);
		} else {
			throw new MaterialsException(ERROR_8451, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),
					MaterialsInterceptorConstants.SNECMA_DESC_MESSAGE);
		}
		return response;
	}

	public RepairCatalog getRepairCatalogListBS(MultivaluedMap<String, String> multiValmap, String strSSO,
			String portalId) throws MaterialsException {

		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(strSSO, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		RepairCatalog repairCatalog = null;
		if (isGEAEIncUser) {
			repairCatalog = materialsApp.getRepairCatalogListBS(multiValmap, strSSO, portalId);
		} else {
			throw new MaterialsException(ERROR_8451, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),
					MaterialsInterceptorConstants.SNECMA_DESC_MESSAGE);
		}
		return repairCatalog;
	}

}
