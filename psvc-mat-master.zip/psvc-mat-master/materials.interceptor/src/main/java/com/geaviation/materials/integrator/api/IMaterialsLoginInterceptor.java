/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016   
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Feb 24, 2016
 * Description    :     IMaterialsInterceptor.java
 * 
 * History        :  	Mar 12, 2014                
        
                    
 **********************************************************/
package com.geaviation.materials.integrator.api;

import com.geaviation.materials.exception.MaterialsException;


public interface IMaterialsLoginInterceptor {

	/**
	 * Returns materials access and role details for the given user.
	 * @param strSSO
	 * @param portalId
	 * @return Object
	 * @throws MaterialsException
	 */
	public Object requestMaterialsLogin(String strSSO, String portalId) throws MaterialsException;
	/**
	 * Used to conver role for myCFM users.
	 * @param loginResponse
	 * @param strSSO
	 * @param portalId
	 * @return Object
	 * @throws MaterialsException
	 */
	public Object roleConversion(Object loginResponse, String strSSO, String portalId) throws MaterialsException;
	/**
	 * Returns materials access and role details for the given user. Used by Attivio platform.
	 * @param strSSO
	 * @param portalId
	 * @return Object
	 * @throws MaterialsException
	 */
	public Object requestMaterialsLoginAttivio(String strSSO, String portalId) throws MaterialsException;
	
	
}
