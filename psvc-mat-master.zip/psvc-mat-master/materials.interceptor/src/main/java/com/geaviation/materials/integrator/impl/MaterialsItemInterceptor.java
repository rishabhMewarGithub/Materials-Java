package com.geaviation.materials.integrator.impl;

import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8450;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.AUTHORIZATION;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CONTENT_ID;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.CONTENT_TYPE;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8450;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.HTTP_CODE;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.INVENTORY_ITEM_ID;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ISGEAEUSER;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.JSON_DATA;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.RETURN;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.SMSSO;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorUtil.isNotNullandEmpty;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.geaviation.materials.app.api.IMaterialsItemApp;
import com.geaviation.materials.entity.ItemConfigHistoryBO;
import com.geaviation.materials.entity.KitStructureBO;
import com.geaviation.materials.entity.PartDetailsBO;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsItemInterceptor;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorUtil;

@Component
public class MaterialsItemInterceptor implements IMaterialsItemInterceptor {

	@Autowired
	private IMaterialsItemApp materialsItemApp;

	
	@Autowired
	private MaterialsInterceptorUtil mateInterceptorUtil;
	@Autowired
	MaterialsExceptionUtil materialsExceptionUtil;
	
	private static final Log log = LogFactory.getLog(MaterialsCartInterceptor.class);
	
	@Value("${AUTHORIZATION}")
	private String authorization;
	@Value("${CFM.URL}")
    private String cfmURL;
	
	@Override
	public Response getItemAvailPricDtlBS(String sso, String portalId,
			String inventoryItemId, String custCode, String custId,String partNumber) throws MaterialsException{
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(sso, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			PartDetailsBO partDetailsBO = materialsItemApp.getItemAvailPricDtlBS(sso, portalId,
					inventoryItemId,partNumber);
			return Response.ok(partDetailsBO).build();
		} else{
			String response = "";
			String childContentType = null;
			String prntContentType = null;
			Object obj = null;
			int httpCode = 0;
			try {
				String url = cfmURL+MaterialsInterceptorConstants.GET_PART_DETAILS;
				Map<String, String> map = new HashMap<String, String>();
				if (isNotNullandEmpty(inventoryItemId)) {
					map.put(INVENTORY_ITEM_ID, inventoryItemId);
				}
				if (isNotNullandEmpty(custCode)) {
					map.put("custCode", custCode);
				}
				if (isNotNullandEmpty(custId)) {
					map.put("custId", custId);
				}
				log.info("getItemAvailPricDtlBS_inputpassed " +map);
				url = mateInterceptorUtil.appendParamstoURL(url, map);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, sso);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if(headers != null && headers.length > 0){
				for (Header header : headers) {
					if(CONTENT_TYPE.equals(header.getName())){
					prntContentType = header.getValue();
					}
				}
				}
				if(null != response && "" != response && response.contains(CONTENT_TYPE) && response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex,contIdIndex);
					childContentType = contTypeSubString.substring(14,contTypeSubString.length());
					}
				log.info("getItemAvailPricDtlBS_outputreceived :: "+response);
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata =  resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode =  Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
				
			} catch (Exception e) {
				log.info("getItemAvailPricDtlBS_exceptionblock"+e);
				if(response == null)
				{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE +e.getMessage());
				}
				else{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if(httpCode != 200)
			{
				if(null != childContentType){
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
					}
					else{
						return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
					}
			}
			if(null != childContentType){
				return Response.ok(obj).type(childContentType).build();
				}
				else{
					return Response.ok(obj).type(prntContentType).build();
				}
		}
	}


	@Override
	public Response getKitStructureBS(String sso, String portalId, String inventoryItemId)
			throws MaterialsException{
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(sso, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if(isGEAEIncUser){
			KitStructureBO kitStructureBO = materialsItemApp.getKitStructureBS(sso, portalId, inventoryItemId);
			return Response.ok(kitStructureBO).build();
		}else{
			String response = "";
			String childContentType = null;
			String prntContentType = null;
			Object obj = null;
			int httpCode = 0;
			try {
				String url = cfmURL+MaterialsInterceptorConstants.KIT_STRUCTURE;
				Map<String, String> map = new HashMap<String, String>();
				map.put("inventoryItemId", inventoryItemId);
				log.info("getKitStructureBS_inputpassed " +map);
				url = mateInterceptorUtil.appendParamstoURL(url, map);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, sso);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if(headers != null && headers.length > 0){
				for (Header header : headers) {
					if(CONTENT_TYPE.equals(header.getName())){
					prntContentType = header.getValue();
					}
				}
				}
				if(null != response && "" != response && response.contains(CONTENT_TYPE) && response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex,contIdIndex);
					childContentType = contTypeSubString.substring(14,contTypeSubString.length());
					}
				log.info("getKitStructureBS_outputreceived :: "+response);
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata =  resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode =  Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
			} catch (Exception e) {
				log.info("getKitStructureBS_exceptionblock"+e);
				if(response == null)
				{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE +e.getMessage());
				}
				else{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if(httpCode != 200)
		{
				if(null != childContentType){
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
					}
					else{
						return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
					}
		}
		if(null != childContentType){
			return Response.ok(obj).type(childContentType).build();
			}
			else{
				return Response.ok(obj).type(prntContentType).build();
			}
		}
	}

	@Override
	public Response getItemConfigHistoryBS(String sso, String portalId, String inventoryItemId,String partNumber) 
			throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(sso, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		if (isGEAEIncUser) {
			ItemConfigHistoryBO itemConfigHistoryBO = materialsItemApp.getItemConfigHistoryBS(sso, portalId,
					inventoryItemId,partNumber);
			return Response.ok(itemConfigHistoryBO).build();
		} else{
			String response = "";
			String childContentType = null;
			String prntContentType = null;
			Object obj = null;
			int httpCode = 0;
			try {
				String url = cfmURL+MaterialsInterceptorConstants.GET_PART_CONF;
				Map<String, String> map = new HashMap<String, String>();
				map.put("inventoryItemId", inventoryItemId);
				log.info("getItemConfigHistoryBS_inputpassed " +map);
				url = mateInterceptorUtil.appendParamstoURL(url, map);
				HttpClient client = new HttpClient();
				URI uri = new URI(url, false);
				GetMethod method = new GetMethod(uri.getEscapedURI());
				method.addRequestHeader(AUTHORIZATION, authorization);
				method.addRequestHeader(SMSSO, sso);
				client.executeMethod(method);
				response = method.getResponseBodyAsString();
				Header[] headers = method.getResponseHeaders();
				if(headers != null && headers.length > 0){
				for (Header header : headers) {
					if(CONTENT_TYPE.equals(header.getName())){
					prntContentType = header.getValue();
					}
				}
				}
				if(null != response && "" != response && response.contains(CONTENT_TYPE) && response.contains(CONTENT_ID)) {
					int contTypeIndex = response.indexOf(CONTENT_TYPE);
					int contIdIndex = response.indexOf(CONTENT_ID);
					String contTypeSubString = response.substring(contTypeIndex,contIdIndex);
					childContentType = contTypeSubString.substring(14,contTypeSubString.length());
					}
				log.info("getItemConfigHistoryBS_outputreceived :: "+response);
				JSONObject resobj = new JSONObject(response);
				JSONObject jsondata =  resobj.getJSONObject(RETURN).getJSONObject(JSON_DATA);
				httpCode =  Integer.parseInt(resobj.getJSONObject(RETURN).getString(HTTP_CODE));
				obj = jsondata.toString();
				
			} catch (Exception e) {
				log.info("getItemConfigHistoryBS_exceptionblock"+e);
				if(response == null)
				{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE +e.getMessage());
				}
				else{
					throw new MaterialsException(ERROR_8450,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
							MaterialsInterceptorConstants.DESC_MESSAGE + response);
				}
			}
			if(httpCode != 200)
			{
				if(null != childContentType){
					return Response.status(httpCode).entity(obj.toString()).type(childContentType).build();
					}
					else{
						return Response.status(httpCode).entity(obj.toString()).type(prntContentType).build();
					}
			}
			if(null != childContentType){
				return Response.ok(obj).type(childContentType).build();
				}
				else{
					return Response.ok(obj).type(prntContentType).build();
				}
		}
	}

	@Override
	public Response getRepUsedItemConfigHistory(String sso, String portalId, String partNumber) 
			throws MaterialsException {
		boolean isGEAEIncUser = true;
		isGEAEIncUser = mateInterceptorUtil.isGEAEUser(sso, portalId);
		log.info(ISGEAEUSER + isGEAEIncUser);
		ItemConfigHistoryBO itemConfigHistoryBO = null;
		if (isGEAEIncUser) {
			itemConfigHistoryBO = materialsItemApp.getRepUsedItemConfigHistory(sso, portalId, partNumber);
		}
		return Response.ok(itemConfigHistoryBO).build();
	}
}
