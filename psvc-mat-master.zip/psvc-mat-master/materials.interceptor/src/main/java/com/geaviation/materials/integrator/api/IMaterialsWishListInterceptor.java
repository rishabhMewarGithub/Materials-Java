package com.geaviation.materials.integrator.api;

import java.util.List;

import javax.ws.rs.core.Response;

import com.geaviation.materials.entity.BulkAddPartBO;
import com.geaviation.materials.exception.MaterialsException;

public interface IMaterialsWishListInterceptor {

	public Response insertWishListBS( String strSSO, String portalId,String partNumber) throws MaterialsException;
	public Response getWishListDetailsBS(String strSSO, String portalId) throws MaterialsException;
	public Response deleteWishListBS(String strSSO,String portalId,String partNumber) throws MaterialsException;
	public Response wishLstToSaveLstBS(String strSSO,String portalId,List<BulkAddPartBO> partnumberLst) throws MaterialsException;
}
