package com.geaviation.materials.ws.test;

import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8450;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8451;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8450;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8451;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;

import com.geaviation.materials.app.api.IMaterialsApp;
import com.geaviation.materials.app.api.IMaterialsCartApp;
import com.geaviation.materials.entity.CartCountBS;
import com.geaviation.materials.entity.DeleteCartLineBO;
import com.geaviation.materials.entity.LineDetailBO;
import com.geaviation.materials.entity.PurchasePOBO;
import com.geaviation.materials.entity.SaveCartRequestDetails;
import com.geaviation.materials.entity.SaveCartResponseDetails;
import com.geaviation.materials.entity.StatusBO;
import com.geaviation.materials.entity.TotalPurchaseOrderBO;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsInterceptor;
import com.geaviation.materials.integrator.impl.MaterialsCartInterceptor;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants;
import com.geaviation.materials.ws.impl.MaterialsServicesImpl;
import com.geaviation.materials.ws.test.util.Constants;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MaterialsCartTest.class)
public class MaterialsCartTest {

	@Mock
	private MaterialsCartInterceptor materialsCartInterceptor;
	@Mock
	IMaterialsCartApp materialsCartApp;
	
	@Mock
	IMaterialsInterceptor materialsInterceptor;
	
	@Mock
	private IMaterialsApp materialsApp;
	
	@InjectMocks
	private MaterialsServicesImpl materialsServicesImpl;
	public static final String PORTAL_CWC = "CWC";
	public static final String SSO_502306485 = "502306485";
	public static final String MESSAGE_SSO_NULL = "SSO ID is null";

	@Test
	public void getCartBSSuccess() throws MaterialsException {

		TotalPurchaseOrderBO totalPurchaseOrderBO = new TotalPurchaseOrderBO();
		totalPurchaseOrderBO.setTotalPurchaseOrderValue("002");
		when(materialsCartInterceptor.getCartBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Response.ok(totalPurchaseOrderBO).build());
		when(materialsCartApp.getCartBS(Mockito.anyString(), Mockito.anyString())).thenReturn(totalPurchaseOrderBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		TotalPurchaseOrderBO response = (TotalPurchaseOrderBO) materialsServicesImpl.getCartBS(request, "").getEntity();
		assertNotNull(response);
		assertEquals("002", response.getTotalPurchaseOrderValue());
	}

	@Test
	public void getCartBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsCartInterceptor)
							.getCartBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
			materialsServicesImpl.getCartBS(request, "");
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}

	@Test
	public void saveCartBSSuccess() throws MaterialsException {

		List<SaveCartRequestDetails> saveCartRequestList = new ArrayList<SaveCartRequestDetails>();

		List<SaveCartResponseDetails> saveCartResponseDetailsList = new ArrayList<SaveCartResponseDetails>();
		SaveCartResponseDetails saveCartResponseDetails = new SaveCartResponseDetails();
		saveCartResponseDetails.setStatusMessage(Constants.SUCCESS);
		saveCartResponseDetailsList.add(saveCartResponseDetails);
		when(materialsCartInterceptor.saveCartBS(Mockito.anyList(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Response.ok(saveCartResponseDetailsList).build());

		when(materialsCartApp.saveCartBS(Mockito.anyList(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(saveCartResponseDetailsList);

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		List<SaveCartResponseDetails> response = (List<SaveCartResponseDetails>) materialsServicesImpl
				.saveCartBS(request, saveCartRequestList).getEntity();
		assertNotNull(response);
		assertEquals(Constants.SUCCESS, response.get(0).getStatusMessage());
	}

	@Test
	public void saveCartBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		List<SaveCartRequestDetails> saveCartRequestList = new ArrayList<SaveCartRequestDetails>();
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsCartInterceptor)
							.saveCartBS(Mockito.anyList(), Mockito.anyString(), Mockito.anyString());
			materialsServicesImpl.saveCartBS(request, saveCartRequestList);
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}

	@Test
	public void deleteCartBSSuccess() throws MaterialsException {
		StatusBO statusBO = new StatusBO();
		statusBO.setSuccess(Constants.SUCCESS);
		when(materialsCartInterceptor.deleteCartBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Response.ok(statusBO).build());
		when(materialsCartApp.deleteCartBS(Mockito.anyString(), Mockito.anyString())).thenReturn(statusBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		StatusBO response = (StatusBO) materialsServicesImpl.deleteCartBS(request, "").getEntity();
		assertNotNull(response);
		assertEquals(Constants.SUCCESS, response.getSuccess());
	}

	@Test
	public void deleteCartBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsCartInterceptor)
							.deleteCartBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
			materialsServicesImpl.deleteCartBS(request, "");
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}

	@Test
	public void getCartCountBSSuccess() throws MaterialsException {
		CartCountBS cartCountBS = new CartCountBS();
		cartCountBS.setItemCount("100");
		when(materialsCartInterceptor.getCartCountBS(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Response.ok(cartCountBS).build());
		when(materialsCartApp.getCartCountBS(Mockito.anyString(), Mockito.anyString())).thenReturn(cartCountBS);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		CartCountBS response = (CartCountBS) materialsServicesImpl.getCartCountBS(request).getEntity();
		assertNotNull(response);
		assertEquals("100", response.getItemCount());
	}

	@Test
	public void getCartCountBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsCartInterceptor)
							.getCartCountBS(Mockito.anyString(), Mockito.anyString());
			materialsServicesImpl.getCartCountBS(request);
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}

	@Test
	public void deleteCartLineBSSuccess() throws MaterialsException {
		DeleteCartLineBO deleteCartLineBO = new DeleteCartLineBO();
		deleteCartLineBO.setSuccess(true);
		when(materialsCartInterceptor.deleteCartLineBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(Response.ok(deleteCartLineBO).build());
		when(materialsCartApp.deleteCartLineBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(deleteCartLineBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		DeleteCartLineBO response = (DeleteCartLineBO) materialsServicesImpl.deleteCartLineBS(request, "", "")
				.getEntity();
		assertNotNull(response);
		assertEquals(true, response.isSuccess());
	}

	@Test
	public void deleteCartLineBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsCartInterceptor).deleteCartLineBS(
							Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
			materialsServicesImpl.deleteCartLineBS(request, "", "");
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}
	
	@Test
	public void addLineItemBSSuccess() throws MaterialsException {
		StatusBO statusBO = new StatusBO();
		statusBO.setSuccess(Constants.SUCCESS);
		when(materialsCartInterceptor.addLineItemBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(Response.ok(statusBO).build());
		when(materialsCartApp.addLineItemBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()
				,Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(statusBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		StatusBO response = (StatusBO) materialsServicesImpl.addLineItemBS(request, "", "","","","","","","","")
				.getEntity();
		assertNotNull(response);
		assertEquals(Constants.SUCCESS, response.getSuccess());
	}

	@Test
	public void addLineItemBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsCartInterceptor).addLineItemBS(
							Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
			materialsServicesImpl.addLineItemBS(request, "", "","","","","","","","");
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}
	
	@Test
	public void getLineDetailBSSuccess() throws MaterialsException {
		LineDetailBO lineDetailBO = new LineDetailBO();
		lineDetailBO.setDisplayMessage("test");
		when(materialsInterceptor.getLineDetailBS(Mockito.anyString(),Mockito.anyString(),Mockito.any(MultivaluedMap.class))).thenReturn(Response.ok(lineDetailBO).build());
		when(materialsApp.getLineDetailBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),Mockito.anyString(),
				Mockito.anyString(),Mockito.anyString(),Mockito.anyList(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(lineDetailBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		LineDetailBO response = (LineDetailBO) materialsServicesImpl.getLineDetailBS(request,null)
				.getEntity();
		assertNotNull(response);
		assertEquals("test", response.getDisplayMessage());
	}

	@Test
	public void getLineDetailBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsInterceptor).getLineDetailBS(Mockito.anyString(),Mockito.anyString(),Mockito.any(MultivaluedMap.class));
			materialsServicesImpl.getLineDetailBS(request,null);
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}
	
    @Test
    public void purchasePOBSSuccess() throws MaterialsException {
           PurchasePOBO purchasePOBO = new PurchasePOBO();
           purchasePOBO.setTotalDiscount("100");
           
           List<PurchasePOBO>  listPurchasePOBO = new ArrayList<PurchasePOBO>();
           listPurchasePOBO.add(purchasePOBO);
           
    when(materialsCartInterceptor.purchasePOBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(Response.ok(listPurchasePOBO).build());
           when(materialsCartApp.purchasePOBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(listPurchasePOBO);
           MockHttpServletRequest request = new MockHttpServletRequest();
           request.addHeader(Constants.SM_SSOID, SSO_502306485);
           request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
           List<PurchasePOBO> response = (List<PurchasePOBO>) materialsServicesImpl.purchasePOBS(request,"", "").getEntity();
           assertNotNull(response);
           assertEquals("100", response.get(0).getTotalDiscount());
    }

    @Test
    public void purchasePOBSFail() throws MaterialsException {
           MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
           MockHttpServletRequest request = new MockHttpServletRequest();
           request.addHeader(Constants.SM_SSOID, SSO_502306485);
           request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
           try {
                  doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
                        MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsCartInterceptor).purchasePOBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
                  materialsServicesImpl.purchasePOBS(request,null, null);
                  fail();
           } catch (MaterialsException mae) {
                  assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
           }
    }
    @Test
    public void getPoQuotationsSuccess() throws MaterialsException {
           MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
           MockHttpServletRequest request = new MockHttpServletRequest();
           request.addHeader(Constants.SM_SSOID, SSO_502306485);
           request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
           try{
           doThrow(new MaterialsException(ERROR_8451,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451), MaterialsInterceptorConstants.INC_DESC_MESSAGE)).when(materialsInterceptor).getPoQuotations(Mockito.anyString(),Mockito.anyString(),Mockito.any(MultivaluedMap.class));
           
           UriInfo ui = Mockito.mock(UriInfo.class);
           materialsServicesImpl.getPoQuotations(ui,request);
           }
           catch (MaterialsException mae) {
                  assertEquals(mae.getDescMsg(), MaterialsInterceptorConstants.INC_DESC_MESSAGE);
           }
           
           
    }

    @Test
    public void getPoQuotationsFail() throws MaterialsException {
           MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
           MockHttpServletRequest request = new MockHttpServletRequest();
           request.addHeader(Constants.SM_SSOID, SSO_502306485);
           request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
           try {
                  doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
                        MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsInterceptor).getPoQuotations(Mockito.anyString(),Mockito.anyString(),Mockito.any(MultivaluedMap.class));
                  UriInfo ui = Mockito.mock(UriInfo.class);
                  materialsServicesImpl.getPoQuotations(ui,request);
                  fail();
           } catch (MaterialsException mae) {
                  assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
           }
    }


}
