package com.geaviation.materials.ws.test;


import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_ICAO_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_SSO_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_HEADER_ID_NOT_FOUND;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.INC_DESC_MESSAGE;
import static com.geaviation.materials.ws.test.util.Constants.DELIVERYID;
import static com.geaviation.materials.ws.test.util.Constants.ERROR_8501;
import static com.geaviation.materials.ws.test.util.Constants.FAILURE_MESSAGE;
import static com.geaviation.materials.ws.test.util.Constants.HEADERID;
import static com.geaviation.materials.ws.test.util.Constants.INVOICEHEADERID;
import static com.geaviation.materials.ws.test.util.Constants.ORDERHEADERID;
import static com.geaviation.materials.ws.test.util.Constants.PORTAL;
import static com.geaviation.materials.ws.test.util.Constants.PORTAL_ID;
import static com.geaviation.materials.ws.test.util.Constants.SM_SSOID;
import static com.geaviation.materials.ws.test.util.Constants.SSO_502299002;
import static com.geaviation.materials.ws.test.util.Constants.SSO;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;
import javax.ws.rs.core.UriInfo;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.geaviation.materials.app.api.IMaterialsApp;
import com.geaviation.materials.app.api.IMaterialsOrdersApp;
import com.geaviation.materials.entity.CustGlobEnqDetails;
import com.geaviation.materials.entity.CustomerAdminDetailsBO;
import com.geaviation.materials.entity.DisputeDocumentBO;
import com.geaviation.materials.entity.OrderAuditHistoryBO;
import com.geaviation.materials.entity.PricingCatalogBO;
import com.geaviation.materials.entity.StatusBO;
import com.geaviation.materials.exception.MaterialsErrorCodes;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsInterceptor;
import com.geaviation.materials.integrator.api.IMaterialsOrdersInterceptor;
import com.geaviation.materials.ws.impl.MaterialsServicesImpl;
import com.geaviation.materials.ws.test.util.Constants;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=MaterialsTest.class)
public class MaterialsTest {
	
	
	private MockMvc mockMvc;
	
	@Mock
	private IMaterialsOrdersApp iMaterialsOrdersApp;
	
	@Mock
	private IMaterialsOrdersInterceptor materialsOrdersInterceptor;
	
	@InjectMocks
	private MaterialsServicesImpl materialsServiceImpl;
	@Mock
	private IMaterialsInterceptor materialsInterceptor;
	@Mock
    private IMaterialsApp materialsApp;
	
	public static final String SSO_502306485 = "502306485";
	public static final String INC_MSG = "This functionality is not available for INC user";

	@Before
	public void initializeMockito(){
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(materialsServiceImpl).build();
	}
	

	
	@Test
	public void testGetOrdersSuccess() throws MaterialsException {
		final String sso = SSO;
		final String portalId = PORTAL;
		final String contentType = "application/x-www-form-urlencoded";
		final String icaoCode = "MMGE";
				
		UriInfo mockUriInfo = Mockito.mock(UriInfo.class);
		MultivaluedMap<String, String> mockMap = Mockito.mock(MultivaluedMap.class);
	    when(mockUriInfo.getQueryParameters()).thenReturn(mockMap);
	    when(mockMap.get(0)).thenReturn(new ArrayList<String>());
	    
	    HttpServletRequest mockedRequest = Mockito
				.mock(HttpServletRequest.class);
		when(mockedRequest.getHeader(SM_SSOID)).thenReturn(sso);
		when(mockedRequest.getHeader(PORTAL_ID)).thenReturn(portalId);
	    when(materialsOrdersInterceptor.getOrders(sso, portalId, mockMap, contentType, icaoCode)).thenReturn(Response.ok().build());
	    	    
	    Response response = materialsOrdersInterceptor.getOrders(sso, portalId, mockMap, contentType, icaoCode);
	    assertEquals(200, response.getStatus());
					
	}
	
	
	@Test
	public void testGetHeaderDetailBSSuccess() throws MaterialsException {
		final String sso = SSO;
		final String portalId = PORTAL;
		final String msNumber = "";
		final String orderHeaderId = "3907578";
		final String deliveryId = "";
		final String invoiceHeaderId = "";		
		
	    HttpServletRequest mockedRequest = Mockito
				.mock(HttpServletRequest.class);
		when(mockedRequest.getHeader(SM_SSOID)).thenReturn(sso);
		when(mockedRequest.getHeader(PORTAL_ID)).thenReturn(portalId);
	    when(materialsOrdersInterceptor.getHeaderDetailBS(sso, portalId, msNumber, deliveryId, orderHeaderId,
				invoiceHeaderId)).thenReturn(Response.ok().build());
	    	    
	    Response response = materialsOrdersInterceptor.getHeaderDetailBS(sso, portalId, msNumber, deliveryId, orderHeaderId,
				invoiceHeaderId);
	    assertEquals(200, response.getStatus());		
	}
	
	
	@Test
	public void testGetHeaderDetailBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();

		final String msNumber = "";
		final String orderHeaderId = "";
		final String deliveryId = "";
		final String invoiceHeaderId = "";	
		
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		
		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8303,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8303), ERR_HEADER_ID_NOT_FOUND))
							.when(materialsOrdersInterceptor).getHeaderDetailBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString());

			materialsServiceImpl.getHeaderDetailBS(request, msNumber, deliveryId, orderHeaderId, invoiceHeaderId);

			fail();

		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), "Header ID not found");
		}
	}
	
	
	
	@Test
	public void testGetOrderAuditHistoryBSSuccess() throws MaterialsException {
		final String sso = SSO;
		final String portalId = PORTAL;
		final String headerId = "1482003";
				
	    HttpServletRequest mockedRequest = Mockito
				.mock(HttpServletRequest.class);
		when(mockedRequest.getHeader(SM_SSOID)).thenReturn(sso);
		when(mockedRequest.getHeader(PORTAL_ID)).thenReturn(portalId);
		OrderAuditHistoryBO orderAuditHistoryBO = new OrderAuditHistoryBO();
	    when(iMaterialsOrdersApp.getOrderAuditHistoryBS(sso, portalId, headerId)).thenReturn(orderAuditHistoryBO);
	    
	    orderAuditHistoryBO = iMaterialsOrdersApp.getOrderAuditHistoryBS(sso, portalId, headerId);
	    Response response = Response.ok(orderAuditHistoryBO).build();
	    assertEquals(200, response.getStatus());	
	}
	
	
	@Test
	public void testGetOrderAuditHistoryBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();

		final String sso = SSO;
		final String portalId = PORTAL;
		final String headerId = "";
		
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		
		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8303,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8303), ERR_HEADER_ID_NOT_FOUND))
							.when(iMaterialsOrdersApp).getOrderAuditHistoryBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());

			iMaterialsOrdersApp.getOrderAuditHistoryBS(sso, portalId, headerId);

			fail();

		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), "Header ID not found");
		}
	}
	
	
	@Test
	public void testGetOrderTemplateBSSuccess() throws MaterialsException {
		final String sso = SSO;
		final String portalId = PORTAL;
				
	    HttpServletRequest mockedRequest = Mockito
				.mock(HttpServletRequest.class);
		when(mockedRequest.getHeader(SM_SSOID)).thenReturn(sso);
		when(mockedRequest.getHeader(PORTAL_ID)).thenReturn(portalId);
		OrderAuditHistoryBO orderAuditHistoryBO = new OrderAuditHistoryBO();
	    when(materialsOrdersInterceptor.getOrderTemplateBS(sso, portalId)).thenReturn(Response.ok().build());
	    
	    Response response = materialsOrdersInterceptor.getOrderTemplateBS(sso, portalId);
	    assertEquals(200, response.getStatus());
	}
	
	
	@Test
	public void testGetOrderTemplateBSFail() throws MaterialsException {
			    
	    MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();

		final String sso = "";
		final String portalId = PORTAL;
		
		HttpServletRequest mockedRequest = Mockito
				.mock(HttpServletRequest.class);
		when(mockedRequest.getHeader(SM_SSOID)).thenReturn(sso);
		when(mockedRequest.getHeader(PORTAL_ID)).thenReturn(portalId);
		
		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8303,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8303), ERR_SSO_NOT_FOUND))
							.when(materialsOrdersInterceptor).getOrderTemplateBS(Mockito.anyString(), Mockito.anyString());

			materialsOrdersInterceptor.getOrderTemplateBS(sso, portalId);

			fail();

		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), "SSO ID not found");
		}	    
	}
	
	
	@Test
	public void getPricingCatalogBSSuccess() throws MaterialsException {

		PricingCatalogBO pricingCatalogBO = new PricingCatalogBO();
		pricingCatalogBO.setSuccess(true);

		when(materialsInterceptor.getPricingCatalog(Mockito.any(MultivaluedMap.class), Mockito.anyString(),
				Mockito.anyString())).thenReturn(Response.ok(pricingCatalogBO).build());
		when(materialsApp.getPricingCatalog(Mockito.any(MultivaluedMap.class), Mockito.anyString(),
				Mockito.anyString())).thenReturn(pricingCatalogBO);

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		// MultivaluedMap<String, String> multiValmap = new
		// MultivaluedHashMap<String, String>();
		// multiValmap.add("key1","value1");
		UriInfo uriInfo = Mockito.mock(UriInfo.class);
		when(uriInfo.getQueryParameters()).thenReturn(null);
		PricingCatalogBO actualResponseStatus = (PricingCatalogBO) materialsServiceImpl
				.getPricingCatalogBS(uriInfo, request).getEntity();
		assertNotNull(actualResponseStatus);
		assertEquals(true, actualResponseStatus.isSuccess());

	}

	@Test
	public void getPricingCatalogBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		MultivaluedMap<String, String> multiValmap = new MultivaluedHashMap<String, String>();
		multiValmap.add("key1", "value");
		UriInfo uriInfo = Mockito.mock(UriInfo.class);
		when(uriInfo.getQueryParameters()).thenReturn(multiValmap);

		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8303,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8303), ERR_ICAO_NOT_FOUND))
							.when(materialsInterceptor).getPricingCatalog(Mockito.any(MultivaluedMap.class),
									Mockito.anyString(), Mockito.anyString());

			materialsServiceImpl.getPricingCatalogBS(uriInfo, request);

			fail();

		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), "ICAO not found");
		}

	}

	@Test
	public void getPricingCatalogDocBSSuccess() throws MaterialsException {

		StreamingOutput stream = null;
		stream = new StreamingOutput() {
			public void write(OutputStream out) throws IOException, WebApplicationException {
				//Mockito testing
			}
		};
		when(materialsInterceptor.getPricingCatalogDocBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(
						Response.ok(stream).header("content-disposition", "attachment; filename = text").build());
		when(materialsApp.getPricingCatalogDocBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString())).thenReturn(Response.ok().build());

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		Object actualResponseStatus = materialsServiceImpl.getPricingCatalogDoc("", "", "", request).getEntity();
		assertNotNull(actualResponseStatus);
	}

	@Test
	public void getPricingCatalogDocBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);

		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8303,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8303), ERR_ICAO_NOT_FOUND))
							.when(materialsInterceptor).getPricingCatalogDocBS(Mockito.anyString(), Mockito.anyString(),
									Mockito.anyString(), Mockito.anyString(), Mockito.anyString());

			materialsServiceImpl.getPricingCatalogDoc("", "", "", request);

			fail();

		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), "ICAO not found");
		}

	}

	@Test
	public void getLineSatusHistoryBSSuccess() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MultivaluedMap<String, String> multiValmap = new MultivaluedHashMap<String, String>();
		multiValmap.add("key1", "value1");
		UriInfo uriInfo = Mockito.mock(UriInfo.class);
		when(uriInfo.getQueryParameters()).thenReturn(multiValmap);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);

		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8451,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8451), INC_DESC_MESSAGE))
							.when(materialsInterceptor).getLineStatusHistoryBS(Mockito.anyString(), Mockito.anyString(),
									Mockito.any(MultivaluedMap.class));

			materialsServiceImpl.getLineStatusHistoryBS(uriInfo, request);

			fail();

		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), INC_MSG);
		}

	}
	
	@Test
	public void getCommercialAgreementBSSuccess() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MultivaluedMap<String, String> multiValmap = new MultivaluedHashMap<String, String>();
		multiValmap.add("key1", "value_1");
		UriInfo uriInfo = Mockito.mock(UriInfo.class);
		when(uriInfo.getQueryParameters()).thenReturn(multiValmap);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);

		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8451,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8451), INC_DESC_MESSAGE))
							.when(materialsInterceptor).getCommercialAgreementBS(Mockito.anyString(), Mockito.anyString(),
									Mockito.any(MultivaluedMap.class));

			materialsServiceImpl.getCommercialAgreementBS(request, uriInfo);

			fail();

		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), INC_MSG);
		}

	}
	
	public void getCommercialAgreementPartBSSuccess() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MultivaluedMap<String, String> multiValmap = new MultivaluedHashMap<String, String>();
		multiValmap.add("key1", "value1");
		UriInfo uriInfo = Mockito.mock(UriInfo.class);
		when(uriInfo.getQueryParameters()).thenReturn(multiValmap);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);

		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8451,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8451), INC_DESC_MESSAGE))
							.when(materialsInterceptor).getCommercialAgreementPartBS(Mockito.anyString(), Mockito.anyString(),
									Mockito.any(MultivaluedMap.class));

			materialsServiceImpl.getCommercialAgreementPartBS(uriInfo, request);

			fail();

		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), INC_MSG);
		}

	}
	
	public void getRatingPlugBSSuccess() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MultivaluedMap<String, String> multiValmap = new MultivaluedHashMap<String, String>();
		multiValmap.add("key1", "value_1");
		UriInfo uriInfo = Mockito.mock(UriInfo.class);
		when(uriInfo.getQueryParameters()).thenReturn(multiValmap);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);

		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8451,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8451), INC_DESC_MESSAGE))
							.when(materialsInterceptor).getRatingPlugBS(Mockito.anyString(), Mockito.anyString(),
									Mockito.any(MultivaluedMap.class));

			materialsServiceImpl.getRatingPlugBS(uriInfo, request);

			fail();

		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), INC_MSG);
		}

	}
	
	@Test
	public void getCustAdminDetailsBSSuccess() throws MaterialsException {
		CustomerAdminDetailsBO customerAdminDetailsBO = new CustomerAdminDetailsBO();
		customerAdminDetailsBO.setMessage("test");
		when(materialsInterceptor.getCustAdminDetailsBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(Response.ok(customerAdminDetailsBO).build());
		when(materialsApp.getCustAdminDetailsBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(customerAdminDetailsBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		CustomerAdminDetailsBO response = (CustomerAdminDetailsBO) materialsServiceImpl.getCustAdminDetailsBS(null,request)
				.getEntity();
		assertNotNull(response);
		assertEquals("test", response.getMessage());
	}

	@Test
	public void getCustAdminDetailsBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, "");
		request.addHeader(PORTAL_ID, PORTAL);
		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8301, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND)).when(materialsInterceptor).getCustAdminDetailsBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
			materialsServiceImpl.getCustAdminDetailsBS(null,request);
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), "SSO ID not found");
		}
	}
	
	public void getRatingPlugFormBSSuccess() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MultivaluedMap<String, String> multiValmap = new MultivaluedHashMap<String, String>();
		multiValmap.add("key1", "value");
		UriInfo uriInfo = Mockito.mock(UriInfo.class);
		when(uriInfo.getQueryParameters()).thenReturn(multiValmap);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);

		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8451,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8451), INC_DESC_MESSAGE))
							.when(materialsInterceptor).getRatingPlugFormBS(Mockito.anyString(), Mockito.anyString(),
									Mockito.any(MultivaluedMap.class));

			materialsServiceImpl.getRatingPlugFormBS(request, uriInfo);

			fail();

		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), INC_MSG);
		}

	}
	
	public void createRatingPlugFormBSSuccess() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);

		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8451,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8451), INC_DESC_MESSAGE))
							.when(materialsInterceptor).createRatingPlugFormBS(Mockito.anyString(), Mockito.anyString(),
									Mockito.anyString());

			materialsServiceImpl.createRatingPlugFormBS(request, "");

			fail();

		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), INC_MSG);
		}

	}
	
	
	@Test
	public void getcsvFileSuccess() throws MaterialsException {
		MvcResult result;
		String orderHeaderId = "8170033";
		String msNumber = "";
		String deliveryId = "";
		String invoiceHeaderId = "";
		
		
		final String sso = SSO;
		final String portalId = PORTAL;
				
	    HttpServletRequest mockedRequest = Mockito
				.mock(HttpServletRequest.class);
		when(mockedRequest.getHeader(SM_SSOID)).thenReturn(sso);
		when(mockedRequest.getHeader(PORTAL_ID)).thenReturn(portalId);
		OrderAuditHistoryBO orderAuditHistoryBO = new OrderAuditHistoryBO();
	    when(iMaterialsOrdersApp.getcsvFile(sso, portalId, msNumber, deliveryId, orderHeaderId, invoiceHeaderId)).thenReturn(Response.ok().build());
	    
	    Response response = iMaterialsOrdersApp.getcsvFile(sso, portalId, msNumber, deliveryId, orderHeaderId, invoiceHeaderId);
	    assertEquals(200, response.getStatus());
	}
	
	@Test
	public void getcsvFileFail() throws MaterialsException {
		MvcResult result;
		String orderHeaderId = "8170033";
		String msNumber = "";
		String deliveryId = "";
		String invoiceHeaderId = "";
		HttpServletRequest mockedRequest = Mockito
				.mock(HttpServletRequest.class);
		when(mockedRequest.getHeader(SM_SSOID)).thenReturn(SSO_502299002);
		when(mockedRequest.getHeader(PORTAL_ID)).thenReturn(PORTAL);
		when(iMaterialsOrdersApp.getcsvFile(SM_SSOID, PORTAL_ID, msNumber, deliveryId, orderHeaderId, invoiceHeaderId)).thenReturn(Response.ok().build());
		Response response = iMaterialsOrdersApp.getcsvFile("", "", "", "", "", "");
		assertEquals(null, response);
	}
	
	
	@Test
	public void getMaterialsDocumentBSSuccess() throws MaterialsException {	
		
		StatusBO statusBo = new StatusBO();
		HttpServletRequest mockedRequest = Mockito
					.mock(HttpServletRequest.class);
		when(mockedRequest.getHeader(SM_SSOID)).thenReturn("502416212");
		when(mockedRequest.getHeader(PORTAL_ID)).thenReturn("myCFM");
		when(materialsOrdersInterceptor.getMaterialsDocumentBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(Response.ok(statusBo).build());
		Response response = materialsOrdersInterceptor.getMaterialsDocumentBS("502416212", "myCFM", "", "Invoice", "", "7146888", "", "", "");
		
		assertEquals(200, response.getStatus());
	}
	
	
	@Test
	public void getMaterialsDocumentBSFail() throws MaterialsException {
		
		StatusBO statusBO = new StatusBO();
		HttpServletRequest mockedRequest = Mockito
					.mock(HttpServletRequest.class);
		when(mockedRequest.getHeader(SM_SSOID)).thenReturn("");
		when(mockedRequest.getHeader(PORTAL_ID)).thenReturn("");
		when(materialsOrdersInterceptor.getMaterialsDocumentBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(Response.ok(statusBO).build());
		Response response = materialsOrdersInterceptor.getMaterialsDocumentBS(null, null, null, null, null, null, null, null, null);
		statusBO = (StatusBO) response.getEntity();
		assertEquals(null, statusBO.getSuccess());
	}
	
		
	@Test
	public void getPDFFileFail() throws MaterialsException {	
		String orderHeaderId = "";
		DisputeDocumentBO disputeDocumentBO = new DisputeDocumentBO();
		HttpServletRequest mockedRequest = Mockito
					.mock(HttpServletRequest.class);
		when(mockedRequest.getHeader(SM_SSOID)).thenReturn(SSO_502299002);
		when(mockedRequest.getHeader(PORTAL_ID)).thenReturn(PORTAL);
		when(iMaterialsOrdersApp.getPDFFile(SSO_502299002, PORTAL, orderHeaderId)).thenReturn(disputeDocumentBO);
		
		when(iMaterialsOrdersApp.getPDFFile(SSO_502299002, PORTAL, orderHeaderId)).thenReturn(disputeDocumentBO);
		disputeDocumentBO = iMaterialsOrdersApp.getPDFFile(SSO_502299002, PORTAL, orderHeaderId);
		byte[] fileContent = disputeDocumentBO.getFileData();
		assertEquals(null, fileContent);
	}
    @Test
    public void getGlobEnqCustIdListBSSuccess() throws MaterialsException {
           CustGlobEnqDetails custGlobEnqDetails = new CustGlobEnqDetails();
           custGlobEnqDetails.setStatus(true);
    when(materialsApp.getGlobEnqCustIdList(Mockito.anyString(),Mockito.anyString())).thenReturn(custGlobEnqDetails);
           MockHttpServletRequest request = new MockHttpServletRequest();
           request.addHeader(SM_SSOID, SSO_502306485);
           request.addHeader(PORTAL_ID, PORTAL);
           CustGlobEnqDetails response = (CustGlobEnqDetails) materialsServiceImpl.getGlobEnqCustIdListBS(request)
                        .getEntity();
           assertNotNull(response);
           assertEquals(true, response.isStatus());
    }
    
    @Test
    public void getGlobEnqCustIdListBSFail() throws MaterialsException {
           MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
           MockHttpServletRequest request = new MockHttpServletRequest();
           request.addHeader(SM_SSOID, "");
           request.addHeader(PORTAL_ID, PORTAL);
           try {
                  doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8301, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND)).when(materialsApp).getGlobEnqCustIdList(Mockito.anyString(),Mockito.anyString());
                  materialsServiceImpl.getGlobEnqCustIdListBS(request);
                  fail();
           } catch (MaterialsException mae) {
                  assertEquals(mae.getDescMsg(), "SSO ID not found");
           }
    }


}
