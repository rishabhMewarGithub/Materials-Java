package com.geaviation.materials.ws.test;

import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8450;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8451;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8450;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8451;
import static com.geaviation.materials.ws.test.util.Constants.PORTAL;
import static com.geaviation.materials.ws.test.util.Constants.PORTAL_ID;
import static com.geaviation.materials.ws.test.util.Constants.SM_SSOID;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.doThrow;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsRfqInterceptor;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants;
import com.geaviation.materials.ws.impl.MaterialsServicesImpl;
import com.geaviation.materials.ws.test.util.Constants;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=MaterialsRfqTest.class)
public class MaterialsRfqTest {
	
	@Mock
	private IMaterialsRfqInterceptor materialsRfqInterceptor;
	
	@Mock
	private MaterialsServicesImpl materialsServiceImpl;
	
	@InjectMocks
	private MaterialsServicesImpl materialsServicesImpl;
	public static final String SSO_502306485 = "502306485";	
	
	@Before
	public void initializeMockito(){
		MockitoAnnotations.initMocks(this);
		MockMvcBuilders.standaloneSetup(materialsServiceImpl).build();
	}	
	
	 @Test
	    public void listRFQBSSuccess() throws MaterialsException {
	           MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
	           MockHttpServletRequest request = new MockHttpServletRequest();
	           request.addHeader(SM_SSOID, SSO_502306485);
	           request.addHeader(PORTAL_ID, PORTAL);
	           try{
	           doThrow(new MaterialsException(ERROR_8451,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451), MaterialsInterceptorConstants.INC_DESC_MESSAGE)).when(materialsRfqInterceptor).listRFQBS(Mockito.anyString(),Mockito.anyString(),Mockito.any(MultivaluedMap.class));
	           
	           UriInfo ui = Mockito.mock(UriInfo.class);
	           materialsServicesImpl.listRFQBS(ui,request);
	           }
	           catch (MaterialsException mae) {
	                  assertEquals(mae.getDescMsg(), MaterialsInterceptorConstants.INC_DESC_MESSAGE);
	           }
	           
	           
	    }

	    @Test
	    public void listRFQBSFail() throws MaterialsException {
	           MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
	           MockHttpServletRequest request = new MockHttpServletRequest();
	           request.addHeader(SM_SSOID, SSO_502306485);
	           request.addHeader(PORTAL_ID, PORTAL);
	           try {
	                  doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
	                        MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsRfqInterceptor).listRFQBS(Mockito.anyString(),Mockito.anyString(),Mockito.any(MultivaluedMap.class));
	                  UriInfo ui = Mockito.mock(UriInfo.class);
	                  materialsServicesImpl.listRFQBS(ui,request);
	                  fail();
	           } catch (MaterialsException mae) {
	                  assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
	           }
	    }
	    
	    @Test
	    public void getRFQDetailBSSuccess() throws MaterialsException {
	           MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
	           MockHttpServletRequest request = new MockHttpServletRequest();
	           request.addHeader(SM_SSOID, SSO_502306485);
	           request.addHeader(PORTAL_ID, PORTAL);
	           try{
	           doThrow(new MaterialsException(ERROR_8451,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451), MaterialsInterceptorConstants.INC_DESC_MESSAGE)).when(materialsRfqInterceptor).getRFQDetailBS(Mockito.anyString(),Mockito.anyString(),Mockito.any(MultivaluedMap.class));
	           
	           UriInfo ui = Mockito.mock(UriInfo.class);
	           materialsServicesImpl.getRFQDetailBS(ui,request);
	           }
	           catch (MaterialsException mae) {
	                  assertEquals(mae.getDescMsg(), MaterialsInterceptorConstants.INC_DESC_MESSAGE);
	           }
	           
	           
	    }

	    @Test
	    public void getRFQDetailBSFail() throws MaterialsException {
	           MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
	           MockHttpServletRequest request = new MockHttpServletRequest();
	           request.addHeader(SM_SSOID, SSO_502306485);
	           request.addHeader(PORTAL_ID, PORTAL);
	           try {
	                  doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
	                        MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsRfqInterceptor).getRFQDetailBS(Mockito.anyString(),Mockito.anyString(),Mockito.any(MultivaluedMap.class));
	                  UriInfo ui = Mockito.mock(UriInfo.class);
	                  materialsServicesImpl.getRFQDetailBS(ui,request);
	                  fail();
	           } catch (MaterialsException mae) {
	                  assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
	           }
	    }
	    
	    @Test
	    public void getRFQBSSuccess() throws MaterialsException {
	           MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
	           MockHttpServletRequest request = new MockHttpServletRequest();
	           request.addHeader(SM_SSOID, SSO_502306485);
	           request.addHeader(PORTAL_ID, PORTAL);
	           try{
	           doThrow(new MaterialsException(ERROR_8451,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451), MaterialsInterceptorConstants.INC_DESC_MESSAGE)).when(materialsRfqInterceptor).getRFQBS(Mockito.anyString(),Mockito.anyString(),Mockito.any(MultivaluedMap.class));
	           
	           UriInfo ui = Mockito.mock(UriInfo.class);
	           materialsServicesImpl.getRFQBS(request,ui);
	           }
	           catch (MaterialsException mae) {
	                  assertEquals(mae.getDescMsg(), MaterialsInterceptorConstants.INC_DESC_MESSAGE);
	           }
	           
	           
	    }

	    @Test
	    public void getRFQBSFail() throws MaterialsException {
	           MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
	           MockHttpServletRequest request = new MockHttpServletRequest();
	           request.addHeader(SM_SSOID, SSO_502306485);
	           request.addHeader(PORTAL_ID, PORTAL);
	           try {
	                  doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
	                        MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsRfqInterceptor).getRFQBS(Mockito.anyString(),Mockito.anyString(),Mockito.any(MultivaluedMap.class));
	                  UriInfo ui = Mockito.mock(UriInfo.class);
	                  materialsServicesImpl.getRFQBS(request,ui);
	                  fail();
	           } catch (MaterialsException mae) {
	                  assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
	           }
	    }
	    
	    @Test
	    public void createRFQBSSuccess() throws MaterialsException {
	           MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
	           MockHttpServletRequest request = new MockHttpServletRequest();
	           request.addHeader(SM_SSOID, SSO_502306485);
	           request.addHeader(PORTAL_ID, PORTAL);
	           try{
	           doThrow(new MaterialsException(ERROR_8451,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451), MaterialsInterceptorConstants.INC_DESC_MESSAGE)).when(materialsRfqInterceptor).createRFQBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
	           
	           materialsServicesImpl.createRFQBS("","","","","","","","",request);
	           }
	           catch (MaterialsException mae) {
	                  assertEquals(mae.getDescMsg(), MaterialsInterceptorConstants.INC_DESC_MESSAGE);
	           }
	           
	           
	    }

	    @Test
	    public void createRFQBSFail() throws MaterialsException {
	           MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
	           MockHttpServletRequest request = new MockHttpServletRequest();
	           request.addHeader(SM_SSOID, SSO_502306485);
	           request.addHeader(PORTAL_ID, PORTAL);
	           try {
	                  doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
	                        MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsRfqInterceptor).createRFQBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
	                  materialsServicesImpl.createRFQBS("","","","","","","","",request);
	                  fail();
	           } catch (MaterialsException mae) {
	                  assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
	           }
	    }

			
}
