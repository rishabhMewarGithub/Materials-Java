package com.geaviation.materials.ws.test;

import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8450;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8450;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import javax.ws.rs.core.Response;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;

import com.geaviation.materials.app.api.IMaterialsApp;
import com.geaviation.materials.app.api.IMaterialsCartApp;
import com.geaviation.materials.app.api.IMaterialsItemApp;
import com.geaviation.materials.entity.ItemConfigHistoryBO;
import com.geaviation.materials.entity.KitStructureBO;
import com.geaviation.materials.entity.PartDetailsBO;
import com.geaviation.materials.entity.TotalPurchaseOrderBO;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsInterceptor;
import com.geaviation.materials.integrator.api.IMaterialsItemInterceptor;
import com.geaviation.materials.integrator.impl.MaterialsCartInterceptor;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants;
import com.geaviation.materials.ws.impl.MaterialsServicesImpl;
import com.geaviation.materials.ws.test.util.Constants;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MaterialsItemTest.class)
public class MaterialsItemTest {

	@Mock
	private MaterialsCartInterceptor materialsCartInterceptor;
	@Mock
	IMaterialsCartApp materialsCartApp;
	
	@Mock
	IMaterialsInterceptor materialsInterceptor;
	
	@Mock
	private IMaterialsApp materialsApp;
	@Mock
	private IMaterialsItemInterceptor materialsItemInterceptor;
	@Mock
	private IMaterialsItemApp materialsItemApp;
	
	@InjectMocks
	private MaterialsServicesImpl materialsServicesImpl;
	
	public static final String SSO_502306485 = "502306485";
	public static final String MESSAGE_SSO_NULL = "SSO ID is null";
	
	@Test
	public void getItemAvailPricDtlBSSuccess() throws MaterialsException {

		PartDetailsBO partDetailsBO = new PartDetailsBO();
		partDetailsBO.setAvailability("8");
		when(materialsItemInterceptor.getItemAvailPricDtlBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Response.ok(partDetailsBO).build());
		when(materialsItemApp.getItemAvailPricDtlBS(Mockito.anyString(), Mockito.anyString(),Mockito.anyString(), Mockito.anyString())).thenReturn(partDetailsBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		PartDetailsBO response = (PartDetailsBO) materialsServicesImpl.getItemAvailPricDtlBS(request, "","","","").getEntity();
		assertNotNull(response);
		assertEquals("8", response.getAvailability());
	}

	@Test
	public void getItemAvailPricDtlBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsItemInterceptor)
							.getItemAvailPricDtlBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
			materialsServicesImpl.getItemAvailPricDtlBS(request, "","","","");
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}
	
	@Test
	public void getItemAvailPricPartDtlBSSuccess() throws MaterialsException {

		PartDetailsBO partDetailsBO = new PartDetailsBO();
		partDetailsBO.setAvailability("19");

		when(materialsItemApp.getItemAvailPricPartDtlBS(Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(partDetailsBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		PartDetailsBO response = (PartDetailsBO) materialsServicesImpl.getItemAvailPricPartDtlBS(request, "").getEntity();
		assertNotNull(response);
		assertEquals("19", response.getAvailability());
	}

	@Test
	public void getItemAvailPricPartDtlBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsItemApp)
							.getItemAvailPricPartDtlBS(Mockito.anyString(), Mockito.anyString(),Mockito.anyString());
			materialsServicesImpl.getItemAvailPricPartDtlBS(request, "");
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}



	@Test
	public void getKitStructureBSSuccess() throws MaterialsException {

		KitStructureBO kitStructureBO = new KitStructureBO();
		kitStructureBO.setKitAvailability("9");
		when(materialsItemInterceptor.getKitStructureBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Response.ok(kitStructureBO).build());
		when(materialsItemApp.getKitStructureBS(Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(kitStructureBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		KitStructureBO response = (KitStructureBO) materialsServicesImpl.getKitStructureBS("",request).getEntity();
		assertNotNull(response);
		assertEquals("9", response.getKitAvailability());
	}

	@Test
	public void getKitStructureBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsItemInterceptor)
							.getKitStructureBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
			materialsServicesImpl.getKitStructureBS("",request);
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}


	@Test
	public void getItemConfigHistoryBSSuccess() throws MaterialsException {

		ItemConfigHistoryBO itemConfigHistoryBO = new ItemConfigHistoryBO();
		itemConfigHistoryBO.setMessage(Constants.SUCCESS);
		when(materialsItemInterceptor.getItemConfigHistoryBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Response.ok(itemConfigHistoryBO).build());
		when(materialsItemApp.getItemConfigHistoryBS(Mockito.anyString(), Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(itemConfigHistoryBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		ItemConfigHistoryBO response = (ItemConfigHistoryBO) materialsServicesImpl.getItemConfigHistoryBS(request,"","").getEntity();
		assertNotNull(response);
		assertEquals(Constants.SUCCESS, response.getMessage());
	}

	@Test
	public void getItemConfigHistoryBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsItemInterceptor)
							.getItemConfigHistoryBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
			materialsServicesImpl.getItemConfigHistoryBS(request,"","");
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}
	

	@Test
	public void getRepUsedItemConfigHistorySuccess() throws MaterialsException {

		ItemConfigHistoryBO itemConfigHistoryBO = new ItemConfigHistoryBO();
		itemConfigHistoryBO.setMessage(Constants.SUCCESS);
		when(materialsItemInterceptor.getRepUsedItemConfigHistory(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Response.ok(itemConfigHistoryBO).build());
		when(materialsItemApp.getRepUsedItemConfigHistory(Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(itemConfigHistoryBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		ItemConfigHistoryBO response = (ItemConfigHistoryBO) materialsServicesImpl.getRepUsedItemConfigHistory(request,"").getEntity();
		assertNotNull(response);
		assertEquals(Constants.SUCCESS, response.getMessage());
	}

	@Test
	public void getRepUsedItemConfigHistoryFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsItemInterceptor)
							.getRepUsedItemConfigHistory(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
			materialsServicesImpl.getRepUsedItemConfigHistory(request,"");
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}
}
