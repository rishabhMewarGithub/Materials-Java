package com.geaviation.materials.ws.test;

import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_ICAO_NOT_FOUND;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;

import com.geaviation.materials.app.api.IMaterialsLoginApp;
import com.geaviation.materials.entity.MaterialsLoginResponse;
import com.geaviation.materials.exception.MaterialsErrorCodes;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsLoginInterceptor;
import com.geaviation.materials.ws.impl.MaterialsServicesImpl;
import com.geaviation.materials.ws.test.util.Constants;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = MaterialsLoginTest.class)
public class MaterialsLoginTest {


	@Mock
	private IMaterialsLoginInterceptor materialsLoginInterceptor;
	
	@Mock
	private IMaterialsLoginApp materialsLoginApp;

	@InjectMocks
	private MaterialsServicesImpl materialsServicesImpl;
	
	public static final String PORTAL_CWC = "CWC";
	public static final String SSO_502306485 = "502306485";
	public static final String SUCCESS = "success";
	public static final String MESSAGE_SSO_NULL = "SSO ID is null";


	@Test
	public void requestMaterialsLoginSuccess() throws MaterialsException {

		MaterialsLoginResponse materialsLoginResponse = new MaterialsLoginResponse();
		materialsLoginResponse.setSuccess(true);

		when(materialsLoginInterceptor.requestMaterialsLogin(Mockito.anyString(), Mockito.anyString()))
						.thenReturn(materialsLoginResponse);
		when(materialsLoginApp.requestMaterialsLogin(Mockito.anyString(), Mockito.anyString()))
		.thenReturn(materialsLoginResponse);

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		MaterialsLoginResponse actualResponseStatus = (MaterialsLoginResponse)materialsServicesImpl.requestMaterialsLogin(request).getEntity();
		assertNotNull(actualResponseStatus);
		assertEquals(true, actualResponseStatus.isSuccess());
		

	}

	@Test
	public void requestMaterialsLoginFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);

		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8303, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8303), ERR_ICAO_NOT_FOUND))
			.when(materialsLoginInterceptor).requestMaterialsLogin(Mockito.anyString(), Mockito.anyString());

			materialsServicesImpl.requestMaterialsLogin(request);
			
			fail();

		} 
		catch (MaterialsException mae){
			assertEquals(mae.getDescMsg(),Constants.ICAO_NOT_FOUND);
		}
		

	}

	
	@Test
	public void requestMaterialsLoginAttivioSuccess() throws MaterialsException {

		MaterialsLoginResponse materialsLoginResponse = new MaterialsLoginResponse();
		materialsLoginResponse.setSuccess(true);

		when(materialsLoginInterceptor.requestMaterialsLoginAttivio(Mockito.anyString(), Mockito.anyString()))
						.thenReturn(materialsLoginResponse);
		when(materialsLoginApp.requestMaterialsLogin(Mockito.anyString(), Mockito.anyString()))
		.thenReturn(materialsLoginResponse);

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		MaterialsLoginResponse actualResponseStatus = (MaterialsLoginResponse)materialsServicesImpl.requestMaterialsLoginAttivio(request).getEntity();
		assertNotNull(actualResponseStatus);
		assertEquals(true, actualResponseStatus.isSuccess());
		

	}

	@Test
	public void requestMaterialsLoginAttivioFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);

		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8303, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8303), ERR_ICAO_NOT_FOUND))
			.when(materialsLoginInterceptor).requestMaterialsLoginAttivio(Mockito.anyString(), Mockito.anyString());

			materialsServicesImpl.requestMaterialsLoginAttivio(request);
			
			fail();

		} 
		catch (MaterialsException mae){
			assertEquals(mae.getDescMsg(),Constants.ICAO_NOT_FOUND);
		}
		

	}
	
	
	@Test
	public void requestRepairsLoginSuccess() throws MaterialsException {

		MaterialsLoginResponse materialsLoginResponse = new MaterialsLoginResponse();
		materialsLoginResponse.setSuccess(true);

		when(materialsLoginApp.requestRepairsLogin(Mockito.anyString(), Mockito.anyString()))
		.thenReturn(materialsLoginResponse);

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		MaterialsLoginResponse actualResponseStatus = (MaterialsLoginResponse)materialsServicesImpl.requestRepairsLogin(request).getEntity();
		assertNotNull(actualResponseStatus);
		assertEquals(true, actualResponseStatus.isSuccess());
		

	}

	@Test
	public void requestRepairsLoginFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);

		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8303, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8303), ERR_ICAO_NOT_FOUND))
			.when(materialsLoginApp).requestRepairsLogin(Mockito.anyString(), Mockito.anyString());

			materialsServicesImpl.requestRepairsLogin(request);
			
			fail();

		} 
		catch (MaterialsException mae){
			assertEquals(mae.getDescMsg(),Constants.ICAO_NOT_FOUND);
		}
		

	}
	
	
	@Test
	public void requestRepairsLoginAttivioBSSuccess() throws MaterialsException {

		MaterialsLoginResponse materialsLoginResponse = new MaterialsLoginResponse();
		materialsLoginResponse.setSuccess(true);

		when(materialsLoginApp.requestRepairsLoginAttivio(Mockito.anyString(), Mockito.anyString()))
		.thenReturn(materialsLoginResponse);

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		MaterialsLoginResponse actualResponseStatus = (MaterialsLoginResponse)materialsServicesImpl.requestRepairsLoginAttivioBS(request).getEntity();
		assertNotNull(actualResponseStatus);
		assertEquals(true, actualResponseStatus.isSuccess());
		

	}

	@Test
	public void requestRepairsLoginAttivioBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);

		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8303, materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8303), ERR_ICAO_NOT_FOUND))
			.when(materialsLoginApp).requestRepairsLoginAttivio(Mockito.anyString(), Mockito.anyString());

			materialsServicesImpl.requestRepairsLoginAttivioBS(request);
			
			fail();

		} 
		catch (MaterialsException mae){
			assertEquals(mae.getDescMsg(),Constants.ICAO_NOT_FOUND);
		}
		

	}

}
