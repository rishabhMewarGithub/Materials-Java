package com.geaviation.materials.ws.test;

import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_DOCUMENT_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_HEADER_ID_NOT_FOUND;
import static com.geaviation.materials.app.impl.util.MaterialsAppConstants.ERR_INSUFFICIENT_INPUTS;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8450;
import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8451;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8450;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8451;
import static com.geaviation.materials.ws.test.util.Constants.PORTAL_ID;
import static com.geaviation.materials.ws.test.util.Constants.SM_SSOID;
import static com.geaviation.materials.ws.test.util.Constants.SSO;
import static com.geaviation.materials.ws.test.util.Constants.PORTAL;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.Collections;

import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.geaviation.materials.app.api.IMaterialsApp;
import com.geaviation.materials.app.api.IMaterialsOrdersApp;
import com.geaviation.materials.app.api.IMaterialsShipmentApp;
import com.geaviation.materials.entity.DeleteOrderLineBO;
import com.geaviation.materials.entity.DisputeDocumentBO;
import com.geaviation.materials.entity.DisputeOrderStatusBO;
import com.geaviation.materials.entity.InvoiceDocDO;
import com.geaviation.materials.entity.OrderDetailsBO;
import com.geaviation.materials.entity.OrderStatusBO;
import com.geaviation.materials.entity.StatusBO;
import com.geaviation.materials.entity.UpdateShipmentBO;
import com.geaviation.materials.exception.MaterialsErrorCodes;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsOrdersInterceptor;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants;
import com.geaviation.materials.ws.impl.MaterialsServicesImpl;
import com.geaviation.materials.ws.test.util.Constants;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=MaterialsOrdersTest.class)
public class MaterialsOrdersTest {
	
	@Mock
	private IMaterialsOrdersApp iMaterialsOrdersApp;
	
	@Mock
	private IMaterialsOrdersInterceptor materialsOrdersInterceptor;
	
	@Mock
	private MaterialsServicesImpl materialsServiceImpl;

	
	@Mock
	private IMaterialsApp materialsApp;
	
	@Mock
	private IMaterialsShipmentApp materialsShipmentApp;
	
	@InjectMocks
	private MaterialsServicesImpl materialsServicesImpl;
	public static final String SSO_502306485 = "502306485";	
	public static final String MESSAGE_SSO_NULL = "SSO ID is null";

	@Before
	public void initializeMockito(){
		MockitoAnnotations.initMocks(this);
		MockMvcBuilders.standaloneSetup(materialsServiceImpl).build();
	}	
	
	@Test
	public void deleteOrderLineBSSuccess() throws MaterialsException {
		DeleteOrderLineBO deleteOrderLineBO = new DeleteOrderLineBO();
		deleteOrderLineBO.setSuccess(true);
		when(materialsOrdersInterceptor.deleteOrderLineBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(Response.ok(deleteOrderLineBO).build());
		when(iMaterialsOrdersApp.deleteOrderLineBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(deleteOrderLineBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		DeleteOrderLineBO response = (DeleteOrderLineBO) materialsServicesImpl.deleteOrderLineBS(request,"9177702","30140383")
				.getEntity();
		assertNotNull(response);
		assertEquals(true, response.isSuccess());
	}
	
	@Test
	public void deleteOrderLineBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8334,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8334), ERR_HEADER_ID_NOT_FOUND)).when(materialsOrdersInterceptor).deleteOrderLineBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
			materialsServicesImpl.deleteOrderLineBS(request,"","30140383");
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), "Header ID not found");
		}
	}
	
	@Test
	public void updateShipmentDetailsBSSuccess() throws MaterialsException {
		UpdateShipmentBO updateShipmentBO = new UpdateShipmentBO();
		updateShipmentBO.setSuccess(true);
		when(materialsOrdersInterceptor.updateShipmentDetailsBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(updateShipmentBO);
		when(iMaterialsOrdersApp.updateShipmentDetailsBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(updateShipmentBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		UpdateShipmentBO response = (UpdateShipmentBO) materialsServicesImpl.updateShipmentDetailsBS(null,null,null,null,request)
				.getEntity();
		assertNotNull(response);
		assertEquals(true, response.isSuccess());
	}
	
	@Test
	public void updateShipmentDetailsBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8343,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8343), ERR_INSUFFICIENT_INPUTS)).when(materialsOrdersInterceptor).updateShipmentDetailsBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
			materialsServicesImpl.updateShipmentDetailsBS(null,null,null,null,request);
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), "Insufficient inputs");
		}
	}
	
	@Test
	public void downloadDisputeDocBSSuccess() throws MaterialsException {		
		DisputeDocumentBO disputeDocumentBO = new DisputeDocumentBO();
		byte[] fileContent = "test".getBytes();
		disputeDocumentBO.setFileData(fileContent);
		disputeDocumentBO.setFileName("test");
		when(materialsOrdersInterceptor.downloadDisputeDocBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(disputeDocumentBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		StreamingOutput response =   (StreamingOutput) materialsServicesImpl.downloadDisputeDocBS("","","",request).getEntity();
		assertNotNull(response);	
	}
	
	@Test
	public void downloadDisputeDocBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8340,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8340), ERR_DOCUMENT_NOT_FOUND)).when(materialsOrdersInterceptor).downloadDisputeDocBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
			materialsServicesImpl.downloadDisputeDocBS("","","",request);
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), "Document not Found");
		}
	}
			
	@Test
	public void createDisputeOrderBSSuccess() throws MaterialsException {
		DisputeOrderStatusBO disputeOrderStatusBO=new DisputeOrderStatusBO();
		disputeOrderStatusBO.setDisputeMessage("test");
		when(materialsOrdersInterceptor.createDisputeOrderBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyObject(),Mockito.any())).thenReturn(disputeOrderStatusBO);
		HttpHeaders httpReq = Mockito.mock(HttpHeaders.class);
		when(httpReq.getRequestHeader(SM_SSOID)).thenReturn(Collections.singletonList(SSO));
		when(httpReq.getRequestHeader(PORTAL_ID)).thenReturn(Collections.singletonList(PORTAL));
		disputeOrderStatusBO = (DisputeOrderStatusBO) materialsServicesImpl.createDisputeOrderBS(httpReq,"","","","","","","",true,"","","","","","","","",null)
				.getEntity();
		assertNotNull(disputeOrderStatusBO);
		assertEquals("test", disputeOrderStatusBO.getDisputeMessage());
	}
	
	@Test
	public void createDisputeOrderBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		HttpHeaders httpReq = Mockito.mock(HttpHeaders.class);
		when(httpReq.getRequestHeader(SM_SSOID)).thenReturn(Collections.singletonList(SSO));
		when(httpReq.getRequestHeader(PORTAL_ID)).thenReturn(Collections.singletonList(PORTAL));
		try {
			doThrow(new MaterialsException(ERROR_8451, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),
					MaterialsInterceptorConstants.SNECMA_DESC_MESSAGE)).when(materialsOrdersInterceptor).createDisputeOrderBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyObject(),Mockito.any());
			materialsServicesImpl.createDisputeOrderBS(httpReq,"","","","","","","",true,"","","","","","","","",null);
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), "This functionality is not available for Snecma user");
		}
	}
	
	
	@Test
	public void uploadOrderTemplateBSSuccess() throws MaterialsException {	
		OrderStatusBO orderStatusBO= new OrderStatusBO();
		orderStatusBO.setDisplayMessage("test");
		when(materialsOrdersInterceptor.uploadOrderTemplateBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.any())).thenReturn(Response.ok(orderStatusBO).build());
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		orderStatusBO = (OrderStatusBO) materialsServicesImpl.uploadOrderTemplateBS(request,null,null)
				.getEntity();
		assertNotNull(orderStatusBO);
		assertEquals("test", orderStatusBO.getDisplayMessage());
		
	}
	
	@Test
	public void uploadOrderTemplateBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsOrdersInterceptor).uploadOrderTemplateBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.any());
			materialsServicesImpl.uploadOrderTemplateBS(request,null,null);
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), "Problem occured while calling the Snecma SOAP web service : ");
		}
	}

	
	@Test
	public void getInvoiceDocumentBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(iMaterialsOrdersApp).getInvoiceDocBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
			materialsServicesImpl.getInvoiceDocumentBS(null,request);
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), "Problem occured while calling the Snecma SOAP web service : ");
		}
	}

	@Test
	public void getInvoiceDocumentBSSuccess() throws MaterialsException {
		InvoiceDocDO invoiceDocDO = new InvoiceDocDO();
		invoiceDocDO.setStatusMessage(Constants.SUCCESS);
		when(iMaterialsOrdersApp.getInvoiceDocBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(invoiceDocDO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		StatusBO response = (StatusBO) materialsServicesImpl.getInvoiceDocumentBS("",request)
				.getEntity();
		assertNotNull(response);
		assertEquals(Constants.SUCCESS, response.getSuccess());
	}
	
	@Test
	public void getOrderDetailsBSSuccess() throws MaterialsException {
		OrderDetailsBO orderDetailsBO = new OrderDetailsBO();
		orderDetailsBO.setHeaderId("8148727");   
		when(iMaterialsOrdersApp.getOrderDetailsBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(orderDetailsBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		OrderDetailsBO response = (OrderDetailsBO) materialsServicesImpl.getOrderDetailsBS(request,"")
				.getEntity();
		assertNotNull(response);
		assertEquals("8148727", response.getHeaderId());
	}
	
	@Test
	public void getOrderDetailsBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(SM_SSOID, SSO_502306485);
		request.addHeader(PORTAL_ID, PORTAL);
		try {
			doThrow(new MaterialsException(MaterialsErrorCodes.ERROR_8343,
					materialsExceptionUtil.getErrorMessage(MaterialsErrorCodes.ERROR_8343), ERR_INSUFFICIENT_INPUTS)).when(iMaterialsOrdersApp).getOrderDetailsBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
			materialsServicesImpl.getOrderDetailsBS(request,null);
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), "Insufficient inputs");
		}
	}
}