package com.geaviation.materials.ws.test.util;

public class Constants {
	
	public static final String PORTAL = "CWC";
    public static final String SSO = "502299002";
    public static final String SSO_502299002 = "502299002";
    public static final String EMPTY_STRING = "";
    public static final String SM_SSOID="sm_ssoid";
    public static final String PORTAL_ID="portal_id";
    public static final String MSNUMBER = "msNumber";
    
    
    public static final String FAILURE_MESSAGE = "Junit Failed";
    public static final String ICAOCODE="icaoCode";
    public static final String ORDERHEADERID = "orderHeaderId";
    public static final String HEADERID = "headerId";
    public static final String DELIVERYID = "deliveryId";
    public static final String INVOICEHEADERID = "invoiceHeaderId";
	public static final String MAE_ERR_MSG="Problem occured while calling the Snecma SOAP web service : ";
	public static final String SUCCESS="Success";
	public static final String ICAO_NOT_FOUND="ICAO not found";
	public static final String PARTNUMBER = "9370M47P01";
    public static final int ERROR_8501 = 8501;
    
    private Constants()
    {             
    }

}
