package com.geaviation.materials.ws.test;

import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8450;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8450;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;

import com.geaviation.materials.app.api.IMaterialsApp;
import com.geaviation.materials.app.api.IMaterialsWishListApp;
import com.geaviation.materials.entity.BulkAddPartBO;
import com.geaviation.materials.entity.BulkPartDetailsBO;
import com.geaviation.materials.entity.DeleteWishListBO;
import com.geaviation.materials.entity.InsertWishListResponse;
import com.geaviation.materials.entity.OrderStatusBO;
import com.geaviation.materials.entity.ShippingAddressBO;
import com.geaviation.materials.entity.ShiptoMarkforAddress;
import com.geaviation.materials.entity.WishListDetailsBO;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsInterceptor;
import com.geaviation.materials.integrator.api.IMaterialsWishListInterceptor;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants;
import com.geaviation.materials.ws.impl.MaterialsServicesImpl;
import com.geaviation.materials.ws.test.util.Constants;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MaterialsWishListAndBulkTest.class)
public class MaterialsWishListAndBulkTest {

	@Mock
	private IMaterialsWishListInterceptor materialsWishListInterceptor;
	@Mock
	IMaterialsWishListApp materialsWishListApp;
	
	@Mock
	IMaterialsInterceptor materialsInterceptor;
	
	@Mock
	private IMaterialsApp materialsApp;
	
	@InjectMocks
	private MaterialsServicesImpl materialsServicesImpl;
	public static final String SSO_502306485 = "502306485";
	public static final String MESSAGE_SSO_NULL = "SSO ID is null";
	public static final String PARTNUMBER = "9370M47P01";	

	@Test
	public void getWishListDetailsSuccess() throws MaterialsException {
		
		List<WishListDetailsBO> wishListDetailsBOList = new ArrayList<WishListDetailsBO>();
		WishListDetailsBO wishListDetailsBO = new WishListDetailsBO();
		wishListDetailsBO.setMessage(Constants.SUCCESS);
		wishListDetailsBO.setPartNumber(Constants.PARTNUMBER);
		wishListDetailsBOList.add(wishListDetailsBO);
		
		when(materialsWishListInterceptor.getWishListDetailsBS(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Response.ok(wishListDetailsBOList).build());
		when(materialsWishListApp.getWishListDetailsBS(Mockito.anyString(), Mockito.anyString())).thenReturn(wishListDetailsBOList);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		List response =  (List) materialsServicesImpl.getWishListDetails(request).getEntity();
		assertNotNull(response);
		assertEquals(Constants.PARTNUMBER, ((WishListDetailsBO) response.get(0)).getPartNumber());
		assertEquals(Constants.SUCCESS, ((WishListDetailsBO) response.get(0)).getMessage());
	}
	
	@Test
	public void getWishListDetailsFail() throws MaterialsException {
		
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsWishListInterceptor)
							.getWishListDetailsBS(Mockito.anyString(), Mockito.anyString());
			materialsServicesImpl.getWishListDetails(request);
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}
	
	@Test
	public void deleteWishListSuccess() throws MaterialsException {
		
		List<DeleteWishListBO> deleteWishListBOList = new ArrayList<DeleteWishListBO>();
		DeleteWishListBO deleteWishListBO = new DeleteWishListBO();
		deleteWishListBO.setMessage(Constants.SUCCESS);
		deleteWishListBO.setPartNumber(PARTNUMBER);
		deleteWishListBOList.add(deleteWishListBO);
		
		when(materialsWishListInterceptor.deleteWishListBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Response.ok(deleteWishListBOList).build());
		when(materialsWishListApp.deleteWishListBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(deleteWishListBOList);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		List<DeleteWishListBO> response =  (List) materialsServicesImpl.deleteWishList(request,PARTNUMBER).getEntity();
		assertNotNull(response);
		assertEquals(PARTNUMBER, ((DeleteWishListBO) response.get(0)).getPartNumber());
		assertEquals(Constants.SUCCESS, ((DeleteWishListBO) response.get(0)).getMessage());
	}
	
	@Test
	public void deleteWishListFail() throws MaterialsException {
		
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsWishListInterceptor)
							.deleteWishListBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
			materialsServicesImpl.deleteWishList(request,"");
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}
	@Test
	public void insertWishListSuccess() throws MaterialsException {
		
		//List<DeleteWishListBO> deleteWishListBOList = new ArrayList<DeleteWishListBO>();
		InsertWishListResponse insertWishList = new InsertWishListResponse();
		insertWishList.setMessage(Constants.SUCCESS);
		
		when(materialsWishListInterceptor.insertWishListBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(Response.ok(insertWishList).build());
		when(materialsWishListApp.insertWishListBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(insertWishList);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		InsertWishListResponse response =   (InsertWishListResponse) materialsServicesImpl.insertWishListBS(request,PARTNUMBER).getEntity();
		assertNotNull(response);
		assertEquals(Constants.SUCCESS, response.getMessage());
	}
	
	@Test
	public void insertWishListFail() throws MaterialsException {
		
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsWishListInterceptor)
							.insertWishListBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
			materialsServicesImpl.insertWishListBS(request,"");
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}
	
	@Test
	public void wishListToSaveListSuccess() throws MaterialsException {
		
		List<BulkAddPartBO> bulkAddPartBOList = new ArrayList<BulkAddPartBO>();
		BulkAddPartBO bulkAddPartBO = new BulkAddPartBO();
		bulkAddPartBO.setCustomerCode("KLM");
		bulkAddPartBO.setQuantity("1");
		bulkAddPartBOList.add(bulkAddPartBO);
		OrderStatusBO orderStatusBO = new OrderStatusBO();
		orderStatusBO.setDisplayMessage(Constants.SUCCESS);
		
		when(materialsWishListInterceptor.wishLstToSaveLstBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyList()))
				.thenReturn(Response.ok(orderStatusBO).build());
		when(materialsWishListApp.wishLstToSaveLstBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyList())).thenReturn(orderStatusBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		OrderStatusBO response =  (OrderStatusBO) materialsServicesImpl.wishListToSaveList(request,bulkAddPartBOList).getEntity();
		assertNotNull(response);
		assertEquals(Constants.SUCCESS, response.getDisplayMessage());
	}
	
	@Test
	public void wishListToSaveListFail() throws MaterialsException {
		
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		List<BulkAddPartBO> bulkAddPartBOList = new ArrayList<BulkAddPartBO>();
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsWishListInterceptor)
							.wishLstToSaveLstBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyList());
			materialsServicesImpl.wishListToSaveList(request,bulkAddPartBOList);
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}
	

	@Test
	public void getShiptoMarkforAddressBSSuccess() throws MaterialsException {
		
		ShiptoMarkforAddress shiptoMarkforAddressBO = new ShiptoMarkforAddress();
		List<ShippingAddressBO> shippingAddressBOList = new ArrayList<ShippingAddressBO>();
		ShippingAddressBO shippingAddressBO = new ShippingAddressBO();
		shippingAddressBO.setCustomerId("KLM");
		shippingAddressBOList.add(shippingAddressBO);
		
		shiptoMarkforAddressBO.setLstShppingAddressBO(shippingAddressBOList);
		
		when(materialsInterceptor.getShiptoMarkforAddressBS(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString()))
		.thenReturn(Response.ok(shiptoMarkforAddressBO).build());
		when(materialsApp.getShiptoMarkforAddressBS(Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(shiptoMarkforAddressBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		ShiptoMarkforAddress response =  (ShiptoMarkforAddress) materialsServicesImpl.getShiptoMarkforAddressBS(request,"","").getEntity();
		assertNotNull(response);
		assertEquals("KLM", response.getLstShppingAddressBO().get(0).getCustomerId());
	}
	
	@Test
	public void getShiptoMarkforAddressBSFail() throws MaterialsException {
		
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		List<BulkAddPartBO> bulkAddPartBOList = new ArrayList<BulkAddPartBO>();
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsInterceptor)
							.getShiptoMarkforAddressBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
			materialsServicesImpl.getShiptoMarkforAddressBS(request,"","");
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}
	
	@Test
	public void addBulkPartDtlsSuccess() throws MaterialsException {
		List<BulkAddPartBO> bulkAddPartBOList = new ArrayList<BulkAddPartBO>();
		OrderStatusBO orderStatusBO = new OrderStatusBO();
		orderStatusBO.setDisplayMessage(Constants.SUCCESS);
			
		when(materialsApp.addBulkPartDtls(Mockito.anyString(), Mockito.anyString(),Mockito.anyList())).thenReturn(orderStatusBO);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		OrderStatusBO response =  (OrderStatusBO) materialsServicesImpl.addBulkPartDtls(request,bulkAddPartBOList).getEntity();
		assertNotNull(response);
		assertEquals(Constants.SUCCESS, response.getDisplayMessage());
	}
	
	@Test
	public void addBulkPartDtlsFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		List<BulkAddPartBO> bulkAddPartBOList = new ArrayList<BulkAddPartBO>();
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsApp)
							.addBulkPartDtls(Mockito.anyString(), Mockito.anyString(), Mockito.anyList());
			materialsServicesImpl.addBulkPartDtls(request,bulkAddPartBOList);
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}

	@Test
	public void getBulkSearchPartDtlBSSuccess() throws MaterialsException {
		List< BulkPartDetailsBO> bulkPartLst = new ArrayList<BulkPartDetailsBO>();
		BulkPartDetailsBO bulkPartDetailsBO = new BulkPartDetailsBO();
		bulkPartDetailsBO.setDisplayMessage(Constants.SUCCESS);
		bulkPartLst.add(bulkPartDetailsBO);
			
		when(materialsApp.getBulkSearchPartDtlBS(Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(bulkPartLst);
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		List response =  (List) materialsServicesImpl.getBulkSearchPartDtlBS(request,"").getEntity();
		assertNotNull(response);
		assertEquals(Constants.SUCCESS, ((BulkPartDetailsBO) response.get(0)).getDisplayMessage());
	}
	
	@Test
	public void getBulkSearchPartDtlBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, Constants.PORTAL);
		try {
			doThrow(new MaterialsException(ERROR_8450, materialsExceptionUtil.getErrorMessage(ERROR_CODE_8450),
					MaterialsInterceptorConstants.DESC_MESSAGE)).when(materialsApp)
							.getBulkSearchPartDtlBS(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
			materialsServicesImpl.getBulkSearchPartDtlBS(request,"");
			fail();
		} catch (MaterialsException mae) {
			assertEquals(mae.getDescMsg(), Constants.MAE_ERR_MSG);
		}
	}
}