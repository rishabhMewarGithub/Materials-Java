
package com.geaviation.materials.ws.test;

import static com.geaviation.materials.exception.SnecmaErrorCodes.ERROR_8451;
import static com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants.ERROR_CODE_8451;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;
import javax.ws.rs.core.UriInfo;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;

import com.geaviation.materials.app.api.IMaterialsApp;
import com.geaviation.materials.entity.RepairCatalog;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsInterceptor;
import com.geaviation.materials.integrator.impl.util.MaterialsInterceptorConstants;
import com.geaviation.materials.ws.impl.MaterialsServicesImpl;
import com.geaviation.materials.ws.test.util.Constants;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = RepairCatalogTest.class)
public class RepairCatalogTest {

	
	@Mock
	private IMaterialsInterceptor materialsInterceptor;
	
	@Mock
	private IMaterialsApp materialsApp;

	@InjectMocks
	private MaterialsServicesImpl materialsServicesImpl;
	
	public static final String PORTAL_CWC = "CWC";
	public static final String SSO_502306485 = "502306485";
	public static final String SUCCESS = "success";
	public static final String MESSAGE_SSO_NULL = "SSO ID is null";


	@Test
	public void getRepairCatalogBSSuccess() throws MaterialsException {

		StreamingOutput stream = null;
		when(materialsInterceptor.getRepairCatalogBS(Mockito.anyString(), Mockito.anyString(),  Mockito.anyString()))
						.thenReturn(Response.ok(stream).build());
		
		when(materialsApp.getRepairCatalogBS(Mockito.anyString(), Mockito.anyString(),  Mockito.anyString()))
		.thenReturn(Response.ok(stream).build());

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		Response response = materialsServicesImpl.getRepairCatalogBS("Repair_Catalog_Change_Report - February 2017.xlsx", request);
		
		assertEquals(200, response.getStatus());

	}

	@Test
	public void getRepairCatalogBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);

		try {
			doThrow(new MaterialsException(ERROR_8451,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),MaterialsInterceptorConstants.SNECMA_DESC_MESSAGE))
			.when(materialsInterceptor).getRepairCatalogBS(Mockito.anyString(), Mockito.anyString(),Mockito.anyString());

			materialsServicesImpl.getRepairCatalogBS("Repair_Catalog_Change_Report - February 2017.xlsx",request);
			
			fail();

		} 
		catch (MaterialsException mae){
			assertEquals(mae.getDescMsg(),MaterialsInterceptorConstants.SNECMA_DESC_MESSAGE);
		}
		

	}
	
	@Test
	public void getRepairCatalogListBSSuccess() throws MaterialsException {

		RepairCatalog repairCatalog = new RepairCatalog();
		repairCatalog.setiTotalRecords(10D);
		UriInfo uriInfo = Mockito.mock(UriInfo.class);
		when(materialsInterceptor.getRepairCatalogListBS(Mockito.any(MultivaluedMap.class), Mockito.anyString(),  Mockito.anyString()))
						.thenReturn(repairCatalog);
		
		when(materialsApp.getRepairCatalogListBS(Mockito.any(MultivaluedMap.class), Mockito.anyString(),  Mockito.anyString()))
		.thenReturn(repairCatalog);

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		RepairCatalog response = (RepairCatalog) materialsServicesImpl.getRepairCatalogListBS(uriInfo, request).getEntity();
		
		assertEquals("10.0", response.getiTotalRecords().toString());

	}

	@Test
	public void getRepairCatalogListBSFail() throws MaterialsException {
		MaterialsExceptionUtil materialsExceptionUtil = new MaterialsExceptionUtil();

		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader(Constants.SM_SSOID, SSO_502306485);
		request.addHeader(Constants.PORTAL_ID, PORTAL_CWC);
		UriInfo uriInfo = Mockito.mock(UriInfo.class);
		try {
			doThrow(new MaterialsException(ERROR_8451,materialsExceptionUtil.getErrorMessage(ERROR_CODE_8451),MaterialsInterceptorConstants.SNECMA_DESC_MESSAGE))
			.when(materialsInterceptor).getRepairCatalogListBS(Mockito.any(MultivaluedMap.class), Mockito.anyString(),Mockito.anyString());

			materialsServicesImpl.getRepairCatalogListBS(uriInfo,request);
			
			fail();

		} 
		catch (MaterialsException mae){
			assertEquals(mae.getDescMsg(),MaterialsInterceptorConstants.SNECMA_DESC_MESSAGE);
		}
		

	}

	

	
}
