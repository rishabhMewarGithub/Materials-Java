package com.geaviation.materials.ws.config;


import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
 
/**
* The WebSecurityConfig class is to customize the spring security comnponents
* The default Init and Configure methods can be overrided to achieve required security
*
* @author  Balamurugan Krishnamurthy
* @version 1.0
* @since   2017-Dec-01
*/
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
     
    /**
    Configure Method overridden to acheive required security.
    This method enable protection for actuator and swagger services
    Add any number of service with comma seperated as below for protection.
    */ 
     
     
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable()
          .httpBasic().and()
            .authorizeRequests()
             .antMatchers("/**/actuator/manage/**","/**/swagger.json").authenticated()
              .anyRequest().permitAll();
           
    }
     
    /**
    Once spring starter security added as dependency, Spring makes the service URL secure.
    For myGEA portals, the application services need not be secure. This method override the default security configurations
    and enable security only for actuator and swagger.
    Add pipe symbol below and add any other service that requries protection.
    */ 
     
     @Override
        public void configure(WebSecurity web) throws Exception {
                 web
                .ignoring()
                    .regexMatchers("^(?!.*(/actuator/manage|/swagger.json)).*$");         }
     
    
  
}