/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 12, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Code Review    :     Feb 24, 2016
 * Description    :     MaterialsServiceUtil.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.ws.util;

import static com.geaviation.materials.ws.util.Constants.AOC;
import static com.geaviation.materials.ws.util.Constants.AOC_PLACEHOLDER;
import static com.geaviation.materials.ws.util.Constants.EMPTY_STRING;
import static com.geaviation.materials.ws.util.Constants.ERR_MESSAGE_RB;
import static com.geaviation.materials.ws.util.Constants.ERR_PORTAL_ID_NOT_FOUND;
import static com.geaviation.materials.ws.util.Constants.ERR_SSO_NOT_FOUND;
import static com.geaviation.materials.ws.util.Constants.PORTAL_AERODP;
import static com.geaviation.materials.ws.util.Constants.PORTAL_CFM;
import static com.geaviation.materials.ws.util.Constants.PORTAL_CWC;
import static com.geaviation.materials.ws.util.Constants.PORTAL_GEHONDA;
import static com.geaviation.materials.ws.util.Constants.PORTAL_ID;
import static com.geaviation.materials.ws.util.Constants.SM_SSOID;
import static com.geaviation.materials.ws.util.Constants.UNKNOWN_ERROR;

import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.owasp.encoder.Encode;

import com.geaviation.materials.exception.MaterialsErrorCodes;
import com.geaviation.materials.exception.MaterialsException;
public class MaterialsServiceUtil {
	
	private static final Log LOG = LogFactory.getLog(MaterialsServiceUtil.class);
	private MaterialsServiceUtil(){
		
	}
	
	public static Response authorize(HttpServletRequest request) throws MaterialsException {
		final String sso = getSMSSOId(request);
		final String portalId = getPortalId(request);
		if (isNotNullandEmpty(sso) && isNotNullandEmpty(portalId)) {
			return Response.status(Status.OK.getStatusCode()).entity("GOOD")
					.build();
		} else {
			return Response.status(Status.UNAUTHORIZED.getStatusCode())
					.entity("BAD").build();
		}
	}
	
	/**
	 * Get SSO Id from request
	 * @param request
	 * @return Normalized User Id as a String
	 * @throws MaterialsException
	 */
	public static String getSMSSOId(final HttpServletRequest request) throws MaterialsException {
		String strUserId = EMPTY_STRING;
		String normaizedUserId = EMPTY_STRING;
		strUserId = request.getHeader(SM_SSOID);
		normaizedUserId = StringEscapeUtils.escapeJava(Encode.forHtml(Normalizer.normalize(strUserId, Form.NFC)));
		if(null!=normaizedUserId && !normaizedUserId.trim().equals(EMPTY_STRING)){
			Pattern p = Pattern.compile("^[a-zA-Z0-9]{0,15}$");
			if (!p.matcher(normaizedUserId).find()) {
				throw new MaterialsException(MaterialsErrorCodes.ERROR_8301, getErrorMessage(MaterialsErrorCodes.ERROR_8301), ERR_SSO_NOT_FOUND);
			}
		}
		return normaizedUserId;
	}
	
	/**
	 * Get Portal Id from request
	 * @param request
	 * @return Portal Id as a String
	 * @throws MaterialsException
	 */
	public static String getPortalId(final HttpServletRequest request) throws MaterialsException {
		String strPortalId = EMPTY_STRING;
		String normaizedPortalId = EMPTY_STRING;
		strPortalId = request.getHeader(PORTAL_ID);
		normaizedPortalId = StringEscapeUtils.escapeJava(Encode.forHtml(Normalizer.normalize(strPortalId, Form.NFC)));
		if(null!=normaizedPortalId && !normaizedPortalId.trim().equals(EMPTY_STRING) && (PORTAL_CWC.equalsIgnoreCase(normaizedPortalId)||PORTAL_CFM.equalsIgnoreCase(normaizedPortalId)||PORTAL_GEHONDA.equalsIgnoreCase(normaizedPortalId)||PORTAL_AERODP.equalsIgnoreCase(normaizedPortalId))){
			return normaizedPortalId;			
	}
		else{
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8302, getErrorMessage(MaterialsErrorCodes.ERROR_8302), ERR_PORTAL_ID_NOT_FOUND);
		}
	
	}
	/**
	 * Returns true if the given string is not null and not empty
	 * @param strData
	 * @return boolean
	 */
	public static boolean isNotNullandEmpty(final String strData) {
		boolean isValid = false;
		if (null != strData && !EMPTY_STRING.equals(strData.trim())) {
			isValid = true;
		}
		return isValid;
	}
	
	/**
	 * Returns empty string if the given string is null else returns the value of the string
	 * @param value
	 * @return String
	 */
	public static String checkNull(String value) {
		if (null==value) {
			return EMPTY_STRING;
		}
		return value;
	}
	public static String getContentType(final HttpServletRequest request) {
        String contentType = EMPTY_STRING;
        contentType = request.getHeader("contentType");
        return contentType;
 }
public static String getIcaoCode(final HttpServletRequest request) {
        String contentType = EMPTY_STRING;
        contentType = request.getHeader("icao_code");
        return contentType;
}
	/**
	 * @param errorCode
	 * @return String
	 * @throws Exception
	 */
	public static String getErrorMessage(String errorCode) throws MaterialsException{
		String errorMessage = EMPTY_STRING;
		if(isNotNullandEmpty(errorCode))
		{
			errorMessage = getPropertyValue(errorCode.trim());
			if(isNotNullandEmpty(errorMessage) && errorMessage.contains(AOC_PLACEHOLDER))
			{
				errorMessage+=getPropertyValue(AOC);
				errorMessage=errorMessage.replace(AOC_PLACEHOLDER, EMPTY_STRING);
			}
		}
		return errorMessage;
	}
	/**
	 * @param intErrorCode
	 * @return String
	 * @throws Exception
	 */
	public static String getErrorMessage(int intErrorCode) throws MaterialsException{
		String strErrorCode = EMPTY_STRING;
		String errorMessage = EMPTY_STRING;
		strErrorCode = Integer.toString(intErrorCode);
		if(isNotNullandEmpty(strErrorCode))
		{
			errorMessage = getPropertyValue(strErrorCode);
			if(isNotNullandEmpty(errorMessage) && errorMessage.contains(AOC_PLACEHOLDER))
			{
				errorMessage+=getPropertyValue(AOC);
				errorMessage=errorMessage.replace(AOC_PLACEHOLDER, EMPTY_STRING);
			}
		}
		return errorMessage;
	}
	/**
	 * @param msgKey
	 * @return String
	 * @throws Exception
	 */
	public static String getPropertyValue(String msgKey) throws MaterialsException{
		String msgVal = EMPTY_STRING;
		if(isNotNullandEmpty(msgKey)){
			msgVal = getPropertyValue(msgKey,ERR_MESSAGE_RB);
		}
		return msgVal;
	}

	/**
	 * @param msgKey
	 * @param propertyFile
	 * @return String
	 * @throws Exception
	 */
	public static String getPropertyValue(String msgKey,String propertyFile) throws MaterialsException {
		String msgVal = "Property entry not found for the key '"+msgKey+"'";
		ResourceBundle rb = null;
		try {
			rb = ResourceBundle.getBundle(propertyFile);
			if(isNotNullandEmpty(msgKey)){
				msgVal = rb.getString(msgKey);
			}
		}
		catch (MissingResourceException mre) {
			LOG.info(mre);
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8400,getErrorMessage(UNKNOWN_ERROR), msgVal);
		}
		return msgVal;
	}

	public static String validateString(String inputString){
		String validatedString = EMPTY_STRING;
		if(isNotNullandEmpty(inputString)){
			validatedString = StringEscapeUtils.escapeJava(Encode.forHtml(Normalizer.normalize(inputString, Form.NFC)));
		}
		return validatedString;
	}

}
