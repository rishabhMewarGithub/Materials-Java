
package com.geaviation.materials.ws.util;


public class Constants {
	
    public static final String EMPTY_STRING = "";
    public static final String HYPHEN = "-";
    public static final String PDF_EXTENSION = ".pdf";
    public static final String XLS_EXTENSION = ".xls";
    public static final String SM_SSOID = "sm_ssoid";
    public static final String PORTAL_ID = "portal_id";
    public static final String DOCX_EXTENSION=".docx";
    public static final String DOC_EXTENSION=".doc";
    public static final String SCRAP = "scrap"; 
    public static final String SCRAP_DOC_NAME="ScrapInstructions";
	public static final String RETURN_INSTRUECTIONS = "returnIns";
	public static final String RETURN_INS_DOC_NAME = "Return_ShipmentInstructions";
	public static final String RETURN_LABEL = "returnLbl";
	public static final String RETURN_LABEL_DOC_NAME = "Return_Label";
	public static final String BUYBACK_INSTRUCTIONS = "buyBackIns";
	public static final String BUYBACK_INS_DOC_NAME = "Buyback_ShipmentInstructions";
	public static final String PROFORMA = "proforma";
	public static final String PROFORMA_DOC_NAME = "ProformaInvoice";
	public static final String ATA = "ata";
	public static final String ATA_DOC_NAME = "ATA106";
	public static final String COMP_REPAIR_DOC_NAME_0="Comp_Repair_";
	public static final String COMP_REPAIR_DOC_NAME_1="_Catalog";
	public static final String CWCI="CWCI";

	public static final String ERR_MESSAGE_RB = "errorMessage";
	public static final String AOC_PLACEHOLDER = "##AOC##";
	public static final String AOC = "AOC";
	public static final String UNKNOWN_ERROR = "UNKNOWN_ERROR";
	public static final String ERR_SSO_NOT_FOUND = "SSO ID not found";
	public static final String ERR_PORTAL_ID_NOT_FOUND = "Portal ID not found";
	
	//Checkmarx Fix
		public static final String PORTAL_CFM = "myCFM";
		public static final String PORTAL_GEHONDA = "GEHonda";
		public static final String PORTAL_AERODP = "AERODP";
		public static final String PORTAL_CWC = "CWC";
}
