package com.geaviation.materials.ws.config;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;

import com.geaviation.dss.service.common.util.DataServiceUtils;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

@Configuration
@ConfigurationProperties
@EnableAutoConfiguration(exclude = DataSourceAutoConfiguration.class)
public class MongoConfiguration extends AbstractMongoConfiguration {

	@Value("${SPRING.DATA.MONGODB.USERNAME}")
	private String mongoDatabaseUserName;

	@Value("${SPRING.DATA.MONGODB.PASSWORD}")
	private String mongoDatabasePassword;

	@Value("${SPRING.DATA.MONGODB.REPLICASET}")
	private String mongoDatabaseReplicaset;

	@Value("${SPRING.DATA.MONGODB.DB}")
	private String mongoDatabaseDb;

	@Value("${SPRING.DATA.MONGODB.URL}")
	private String mongoDatabaseUrl;

	@Value("${ENCRYPTIONALGO}")
	private String encryptionAlgo;

	@Value("${ENCRYPTIONPWD}")
	private String deccryptionkey;
	
	@Value("${SPRING.DATA.MONGODB.URLPARAM}")
	private String urlParams;

	protected String getDatabaseName() {
		return mongoDatabaseDb;
	}

	public @Bean MongoClient mongo() throws IOException {
		return new MongoClient(createMongoClientURI());
	}

	private MongoClientURI createMongoClientURI() throws IOException {

		final StringBuilder uriVal = new StringBuilder(mongoDatabaseUrl);
		if (mongoDatabaseUserName != null) {
			uriVal.append(mongoDatabaseUserName);
		}

		if (mongoDatabasePassword != null) {
			uriVal.append(':').append(DataServiceUtils.getSecurePassword(mongoDatabaseUserName,
					mongoDatabasePassword, encryptionAlgo, deccryptionkey));

		}

		uriVal.append('@');

		uriVal.append(mongoDatabaseReplicaset).append('/');

		if (mongoDatabaseDb != null) {
			uriVal.append(mongoDatabaseDb);
		}
		if (urlParams != null) {
			uriVal.append(urlParams);
		}

		return new MongoClientURI(uriVal.toString());
	}
}