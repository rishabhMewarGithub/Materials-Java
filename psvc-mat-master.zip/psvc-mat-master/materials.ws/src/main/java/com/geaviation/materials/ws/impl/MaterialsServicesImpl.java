package com.geaviation.materials.ws.impl;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.apache.cxf.jaxrs.ext.multipart.Multipart;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.geaviation.materials.app.api.IMaterialsApp;
import com.geaviation.materials.app.api.IMaterialsItemApp;
import com.geaviation.materials.app.api.IMaterialsLoginApp;
import com.geaviation.materials.app.api.IMaterialsOrdersApp;
import com.geaviation.materials.entity.BulkAddPartBO;
import com.geaviation.materials.entity.BulkPartDetailsBO;
import com.geaviation.materials.entity.CustGlobEnqDetails;
import com.geaviation.materials.entity.DisputeDocumentBO;
import com.geaviation.materials.entity.DisputeOrderInput;
import com.geaviation.materials.entity.DisputeOrderStatusBO;
import com.geaviation.materials.entity.InvoiceDocDO;
import com.geaviation.materials.entity.MaterialsLoginResponse;
import com.geaviation.materials.entity.OrderAuditHistoryBO;
import com.geaviation.materials.entity.OrderDetailsBO;
import com.geaviation.materials.entity.OrderStatusBO;
import com.geaviation.materials.entity.PartDetailsBO;
import com.geaviation.materials.entity.RepairCatalog;
import com.geaviation.materials.entity.SaveCartRequestDetails;
import com.geaviation.materials.entity.StatusBO;
import com.geaviation.materials.entity.UpdateOrderRequestDetails;
import com.geaviation.materials.entity.UpdateShipmentBO;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.util.MaterialsExceptionUtil;
import com.geaviation.materials.integrator.api.IMaterialsCartInterceptor;
import com.geaviation.materials.integrator.api.IMaterialsInterceptor;
import com.geaviation.materials.integrator.api.IMaterialsItemInterceptor;
import com.geaviation.materials.integrator.api.IMaterialsLoginInterceptor;
import com.geaviation.materials.integrator.api.IMaterialsOrdersInterceptor;
import com.geaviation.materials.integrator.api.IMaterialsRfqInterceptor;
import com.geaviation.materials.integrator.api.IMaterialsWishListInterceptor;
import com.geaviation.materials.ws.util.MaterialsServiceUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.Extension;
import io.swagger.annotations.ExtensionProperty;

@RestController
@RequestMapping
@Path("/")
@Api(value = "/materials")
@Service
public class MaterialsServicesImpl {

	@Autowired
	private IMaterialsCartInterceptor materialsCartInterceptor;

	@Autowired
	private IMaterialsInterceptor materialsInterceptor;

	@Autowired
	@Qualifier("materialsOrdersInterceptor")
	private IMaterialsOrdersInterceptor materialsOrdersInterceptor;

	@Autowired
	private IMaterialsLoginInterceptor materialsLoginInterceptor;

	@Autowired
	private IMaterialsLoginApp materialsLoginApp;

	@Autowired
	MaterialsExceptionUtil materialsExceptionUtil;

	@Autowired
	private IMaterialsOrdersApp materialsOrdersApp;
	@Autowired
	private IMaterialsWishListInterceptor materialsWishListInterceptor;
	@Autowired
	private IMaterialsApp materialsApp;
	
	@Autowired
	private IMaterialsItemInterceptor materialsItemInterceptor;
	@Autowired
	private IMaterialsItemApp materialsItemApp;
	@Autowired
	private IMaterialsRfqInterceptor materialsRfqInterceptor;

	@Value("${DEPLOYEDVERSION}")
	private String deployedVersion;

	private static final Log LOG = LogFactory.getLog(MaterialsServicesImpl.class);
	
	@GET
	@Path("/ping")
	public String ping() throws MaterialsException {
		StringBuilder pingResponse = new StringBuilder();
		pingResponse.append("Version " + deployedVersion + "\n");
		Method[] methods = MaterialsServicesImpl.class.getDeclaredMethods();
		int i = 0;
		pingResponse.append("Deployed Services list:\n");
		while (i < methods.length) {
			pingResponse.append(methods[i].getReturnType().getName() + " " + methods[i].getName() + "\n");
			i++;
		}
		return pingResponse.toString();

	}

	/**
	 * Returns materials access and role details for the given user.
	 * 
	 * @param sm_ssoid
	 *            valid user SSO. can not be NULL.
	 * @param portal_id
	 *            valid portal_id. can not be NULL.
	 * @throws MaterialsException
	 */

	@ApiOperation(value = "Get materials access and role details", notes = "requestMaterialsLoginBS Service will return access and role details.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "1") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })

	@GET
	@Path("/requestMaterialsLoginBS")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response requestMaterialsLogin(@Context HttpServletRequest request) throws MaterialsException {
		LOG.info("Inside MaterialsServicesImpl :: requestMaterialsLogin called");
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		Object loginResponse = materialsLoginInterceptor.requestMaterialsLogin(strSSO, portalId);
		if (null != portalId && "myCFM".equalsIgnoreCase(portalId)) {
			Object materialsLoginResp = materialsLoginInterceptor.roleConversion(loginResponse, strSSO, portalId);
			response = Response.ok(materialsLoginResp).build();
			return response;
		}
		response = Response.ok(loginResponse).build();
		return response;
	}

	/**
	 * Returns materials access and role details for the given user. Used by
	 * Attivio platform.
	 * 
	 * @param sm_ssoid
	 *            valid user SSO. can not be NULL.
	 * @param portal_id
	 *            valid portal_id. can not be NULL.
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get materials access and role details", notes = "requestMaterialsLoginAttivioBS Service will return access and role details. Used by Attivio platform.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "2") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Path("/requestMaterialsLoginAttivioBS")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response requestMaterialsLoginAttivio(@Context HttpServletRequest request) throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		Object loginResponse = materialsLoginInterceptor.requestMaterialsLoginAttivio(strSSO, portalId);
		response = Response.ok(loginResponse).build();
		return response;
	}

	/**
	 * Attivio Specific service for Repair Security This service will restrict
	 * Repair Services other than CWC portal
	 */

	/**
	 * Returns repair materials access and role details for the given user. Used
	 * by Attivio platform.
	 * 
	 * @param sm_ssoid
	 *            valid user SSO. can not be NULL.
	 * @param portal_id
	 *            valid portal_id. can not be NULL.
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get repair materials access and role details", notes = "requestRepairsLoginAttivioBS service will return access and role details. Used by Attivio platform.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "3") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Path("/requestRepairsLoginAttivioBS")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response requestRepairsLoginAttivioBS(@Context HttpServletRequest request) throws MaterialsException {

		Response response = null;
		MaterialsLoginResponse loginResponse = new MaterialsLoginResponse();
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		loginResponse = materialsLoginApp.requestRepairsLoginAttivio(strSSO, portalId);
		response = Response.ok(loginResponse).build();
		return response;
	}

	/**
	 * Returns repair materials access and role details for the given user.
	 * 
	 * @param sm_ssoid
	 *            valid user SSO. can not be NULL.
	 * @param portal_id
	 *            valid portal_id. can not be NULL.
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get repair materials access and role details", notes = "requestRepairsLogin service will return access and role details.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "4") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Path("/requestRepairsLogin")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response requestRepairsLogin(@Context HttpServletRequest request) throws MaterialsException {
		Response response = null;
		MaterialsLoginResponse loginResponse = new MaterialsLoginResponse();
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		loginResponse = materialsLoginApp.requestRepairsLogin(strSSO, portalId);
		response = Response.ok(loginResponse).build();
		return response;
	}

	/**
	 * Return cart containing all the line details
	 * 
	 * @param request
	 * @param cartHeaderId
	 * @return details of cart as json object
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Cart Details", notes = "it will give the cart containing all the line details.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "5") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Path("/getCartBS")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response getCartBS(@Context HttpServletRequest request, @FormParam("cartHeaderId") String cartHeaderId)
			throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsCartInterceptor.getCartBS(strSSO, portalId, cartHeaderId);
		return response;
	}

	/**
	 * To save cart for later in checkout page
	 * 
	 * @param request
	 * @param saveCartRequestList-
	 *            details of cart
	 * @return json which contains cartHeaderId and Line Details of part present
	 *         in the cart
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "To save Cart for later", notes = "Move items present in cart to Saved For Later.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "6") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/saveCartBS")
	public Response saveCartBS(@Context HttpServletRequest request, List<SaveCartRequestDetails> saveCartRequestList)
			throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsCartInterceptor.saveCartBS(saveCartRequestList, strSSO, portalId);
		return response;
	}

	/**
	 * To empty the cart
	 * 
	 * @param request
	 * @param cartHeaderId
	 *            - optional
	 * @return true/false
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "To clear the cart ", notes = "Delete items present in cart.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "7") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@DELETE
	@Path("/deleteCartBS")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response deleteCartBS(@Context HttpServletRequest request, @FormParam("cartHeaderId") String cartHeaderId)
			throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsCartInterceptor.deleteCartBS(strSSO, portalId, cartHeaderId);
		return response;

	}

	/**
	 * Return total No. of items in the cart
	 * 
	 * @param request
	 * @return no of items present in cart
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "No of items in cart ", notes = "No of items present in cart.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "8") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getCartCountBS")
	public Response getCartCountBS(@Context HttpServletRequest request) throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsCartInterceptor.getCartCountBS(strSSO, portalId);
		return response;
	}

	/**
	 * To delete a particular line items in the cart
	 * 
	 * @param request
	 * @param cartHeaderId
	 *            - required
	 * @param cartLineId
	 *            - required
	 * @return - true/false
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Delete single items in the cart ", notes = "Delete a line items present in cart.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "9") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@POST
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/deleteCartLineBS")
	public Response deleteCartLineBS(@Context HttpServletRequest request,
			@FormParam("cartHeaderId") String cartHeaderId, @FormParam("cartLineId") String cartLineId)
			throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsCartInterceptor.deleteCartLineBS(strSSO, portalId, cartHeaderId, cartLineId);
		return response;
	}

	/**
	 * Returns repair materials access and role details for the given user.
	 * 
	 * @param inventoryItemId
	 *            valid inventoryItemId. can not be NULL.
	 * @param selectedCustomerId
	 *            valid selectedcustomerId. can not be NULL.
	 * @param selectedSupplierCode
	 *            valid selectedSupplierCode. can not be NULL.
	 * @param selectedCustomerId
	 *            valid selectedcustomerId. can not be NULL.
	 * @param quantity
	 *            valid quantity. can not be NULL.
	 * @param pricingListId
	 *            valid pricingListId. can not be NULL.
	 * @param commercialAgreementNumber
	 * @param quotationNumber
	 * @param quickOrder
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Add order line details to the cart", notes = "addLineItemBS will add order line to the cart.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "10") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@POST
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/addLineItemBS")
	public Response addLineItemBS(@Context HttpServletRequest request,
			@ApiParam(name = "inventoryItemId", value = "Inventory Item Id", allowMultiple = false, required = true) @FormParam("inventoryItemId") String inventoryItemId,
			@ApiParam(name = "selectedCustomerId", value = "Customer Id", allowMultiple = false, required = true) @FormParam("selectedCustomerId") String selectedCustomerId,
			@ApiParam(name = "selectedSupplierCode", value = "Supplier Code", allowMultiple = false, required = true) @FormParam("selectedSupplierCode") String selectedSupplierCode,
			@ApiParam(name = "quantity", value = "Quantity", allowMultiple = false, required = true) @FormParam("quantity") String quantity,
			@ApiParam(name = "pricingListId", value = "Price List Id", allowMultiple = false, required = true) @FormParam("pricingListId") String pricingListId,
			@ApiParam(name = "commercialAgreementNumber", value = "Commercial Agreement Number", allowMultiple = false, required = true) @FormParam("commercialAgreementNumber") String commercialAgreementNumber,
			@ApiParam(name = "quotationNumber", value = "Quotation Number", allowMultiple = false, required = false) @FormParam("quotationNumber") String quotationNumber,
			@ApiParam(name = "quickOrder", value = "Quick Order", allowMultiple = false, required = false) @FormParam("quickOrder") String quickOrder,
			@ApiParam(name = "quoteHeaderId", value = "Quote Header Id", allowMultiple = false, required = false) @FormParam("quoteHeaderId") String quoteHeaderId)
			throws MaterialsException {

		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsCartInterceptor.addLineItemBS(strSSO, portalId, inventoryItemId, selectedCustomerId,
				selectedSupplierCode, quantity, pricingListId, commercialAgreementNumber, quotationNumber, quickOrder,
				quoteHeaderId);
		return response;
	}

	/**
	 * On clicking a particular order in new-materials Return line details of
	 * that order
	 * 
	 * @param request
	 * @param form
	 * @return json containing all line level details of that particular order
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get Line Details of a Order ", notes = "On Clicking order row in materials widget", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "11") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getLineDetailBS")
	public Response getLineDetailBS(@Context HttpServletRequest request, MultivaluedMap<String, String> form)
			throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsInterceptor.getLineDetailBS(strSSO, portalId, form);
		return response;
	}

	@ApiOperation(value = "To delete order line", notes = "deleteOrderLineBS Service will deletes an orders line level detail.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "12") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true), })
	@POST
	@Path("/deleteOrderLineBS")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response deleteOrderLineBS(@Context HttpServletRequest request,
			@ApiParam(name = "headerId", value = "eg.9177702", allowMultiple = false, required = true) @FormParam("headerId") String headerId,
			@ApiParam(name = "lineId", value = "eg.30140383", allowMultiple = false, required = true) @FormParam("lineId") String lineId)
			throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsOrdersInterceptor.deleteOrderLineBS(strSSO, portalId, headerId, lineId);
		return response;
	}

	@ApiOperation(value = "To update customer shipment details", notes = "updateShipmentDetailsBS Service will update shipment details of customer.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "13") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true), })
	@POST
	@Path("/updateShipmentDetailsBS")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public javax.ws.rs.core.Response updateShipmentDetailsBS(
			@ApiParam(name = "updateType", value = "eg.Ship Address Change", allowMultiple = false, required = true) @FormParam("updateType") String updateType,
			@ApiParam(name = "existingContent", value = "eg.Code:KLMD12|Address 1:KLM ROYAL DUTCH AIRLINES|Address 2:2312 TOUHY AVENUE|City:ELK GROVE VILLAGE|State:IL|Zip:60007|Country:US|Default:false|Customer Code:400732", allowMultiple = false, required = true) @FormParam("existingContent") String existingContent,
			@ApiParam(name = "updatedContent", value = "eg.Code:KLMD12|Address 1:KLM ROYAL DUTCH AIRLINEStest|Address 2:2312 TOUHY AVENUE|City:ELK GROVE VILLAGE|State:IL|Zip:60007|Country:US|Default:false|Customer Code:400732", allowMultiple = false, required = true) @FormParam("updatedContent") String updatedContent,
			@ApiParam(name = "customerId", value = "eg.customerId", allowMultiple = false, required = true) @FormParam("customerId") String customerId,
			@Context HttpServletRequest request) throws MaterialsException {

		UpdateShipmentBO updateShipmentBO = null;
		Response response = null;
		String sso = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		updateShipmentBO = materialsOrdersInterceptor.updateShipmentDetailsBS(sso, portalId, updateType,
				existingContent, updatedContent, customerId);
		response = Response.ok(updateShipmentBO).build();
		return response;
	}

	@ApiOperation(value = "downloads dispute related docs", notes = "downloadDisputeDocBS Service will download dispute documents.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "14") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true), })
	@GET
	@Path("/downloadDisputeDocBS")
	@Produces({ "application/doc", "application/json", "text/html" })
	public javax.ws.rs.core.Response downloadDisputeDocBS(
			@ApiParam(name = "orderHeaderId", value = "eg.9280600", allowMultiple = false, required = true) @FormParam("orderHeaderId") String orderHeaderId,
			@ApiParam(name = "lineId", value = "", allowMultiple = false, required = false) @FormParam("lineId") String lineId,
			@ApiParam(name = "docType", value = "eg.proforma", allowMultiple = false, required = true) @FormParam("docType") String docType,
			@Context HttpServletRequest request) throws MaterialsException {

		Response response = null;
		DisputeDocumentBO disputeDocumentBO = null;
		byte[] fileContent = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		disputeDocumentBO = materialsOrdersInterceptor.downloadDisputeDocBS(strSSO, portalId, orderHeaderId, lineId,
				docType);
		fileContent = disputeDocumentBO.getFileData();
		String fileName = disputeDocumentBO.getFileName();
		response = buildResponse(fileContent, fileName);
		return response;
	}

	private Response buildResponse(final byte[] bytes, String fileName) {
		Response response = null;
		StreamingOutput stream = null;
		stream = new StreamingOutput() {
			public void write(OutputStream out) throws IOException, WebApplicationException {
				try {
					out.write(bytes);
				} catch (Exception e) {
					throw new WebApplicationException(e);
				}
			}
		};
		if (bytes != null) {
			response = Response.ok(stream).header("content-disposition", "attachment; filename = " + fileName).build();
		}
		return response;
	}

	@ApiOperation(value = "upload bulk order template", notes = "uploadOrderTemplateBS Service will upload the data for bulk order.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "15") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true), })
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Path("/uploadOrderTemplateBS")
	public Response uploadOrderTemplateBS(@Context HttpServletRequest request, @Multipart("custCode") String custCode,
			List<Attachment> orderTemplate) throws MaterialsException {

		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		return materialsOrdersInterceptor.uploadOrderTemplateBS(strSSO, portalId, custCode, orderTemplate);
	}

	@ApiOperation(value = "creates dispute for orders", notes = "createDisputeOrderBS Service will create dispute based on the dispute reason.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "16") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true), })
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Path("/createDisputeOrderBS")
	public Response createDisputeOrderBS(@Context HttpHeaders httpReq, @Multipart("orderHeaderId") String orderHeaderId,
			@Multipart("lineId") String lineId, @Multipart("disputeReason") String disputeReason,
			@Multipart("serialNumberSelectedSerialNumber") String serialNumberSelectedSerialNumber,
			@Multipart("serialNumberReceivedSerialNumber") String serialNumberReceivedSerialNumber,
			@Multipart("discrepancyPartNumberReceived") String discrepancyPartNumberReceived,
			@Multipart("discrepancyQuantityReceived") String discrepancyQuantityReceived,
			@Multipart("addToCartFlag") boolean addToCartFlag,
			@Multipart("underShipmentQuantityReceived") String underShipmentQuantityReceived,
			@Multipart("overShipmentQuantityReceived") String overShipmentQuantityReceived,
			@Multipart("buyBackRequestedBy") String buyBackRequestedBy,
			@Multipart("buyBackRequestedQuantity") String buyBackRequestedQuantity,
			@Multipart("buyBackValue") String buyBackValue,
			@Multipart("pricingErrorExpectedUnitPrice") String pricingErrorExpectedUnitPrice,
			@Multipart("disputeComments") String disputeComments, @Multipart("customerId") String customerId,
			List<Attachment> serialNumberPhotoAttachment) throws MaterialsException {

		Response response = null;
		String strSSO = StringEscapeUtils.escapeJava(
				Encode.forHtml(Normalizer.normalize((String) httpReq.getRequestHeader("sm_ssoid").get(0), Form.NFC)));
		String portalId = StringEscapeUtils.escapeJava(
				Encode.forHtml(Normalizer.normalize((String) httpReq.getRequestHeader("portal_id").get(0), Form.NFC)));
		DisputeOrderInput disputeOrderInputBO = new DisputeOrderInput();
		disputeOrderInputBO.setOrderHeaderId(orderHeaderId);
		disputeOrderInputBO.setLineId(lineId);
		disputeOrderInputBO.setSerialNumberSelectedSerialNumber(serialNumberSelectedSerialNumber);
		disputeOrderInputBO.setSerialNumberReceivedSerialNumber(serialNumberReceivedSerialNumber);
		disputeOrderInputBO.setDisputeReason(disputeReason);
		disputeOrderInputBO.setDiscrepancyPartNumberReceived(discrepancyPartNumberReceived);
		disputeOrderInputBO.setDiscrepancyQuantityReceived(discrepancyQuantityReceived);
		disputeOrderInputBO.setAddToCartFlag(addToCartFlag);
		disputeOrderInputBO.setUnderShipmentQuantityReceived(underShipmentQuantityReceived);
		disputeOrderInputBO.setOverShipmentQuantityReceived(overShipmentQuantityReceived);
		disputeOrderInputBO.setBuyBackRequestedBy(buyBackRequestedBy);
		disputeOrderInputBO.setBuyBackRequestedQuantity(buyBackRequestedQuantity);
		disputeOrderInputBO.setBuyBackValue(buyBackValue);
		disputeOrderInputBO.setPricingErrorExpectedUnitPrice(pricingErrorExpectedUnitPrice);
		disputeOrderInputBO.setDisputeComments(disputeComments);
		disputeOrderInputBO.setCustomerId(customerId);
		DisputeOrderStatusBO disputeOrderStatusBO = materialsOrdersInterceptor.createDisputeOrderBS(strSSO, portalId,
				disputeOrderInputBO, serialNumberPhotoAttachment);
		response = Response.ok(disputeOrderStatusBO).build();
		return response;
	}

	/**
	 * Returns Orders using SSO, Portal Id and ICAO code
	 * 
	 * @param ui
	 * @param request
	 * @return Response
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get materials Order details", notes = "getOrders Service will return Order details.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "17") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Path("/getOrders")
	@Produces({ "application/json" })
	public Response getOrders(@Context UriInfo ui, @Context HttpServletRequest request) throws MaterialsException {
		Response response = null;
		String sso = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		String contentType = MaterialsServiceUtil.getContentType(request);
		String icaoCode = MaterialsServiceUtil.getIcaoCode(request);
		MultivaluedMap<String, String> multiValmap = ui.getQueryParameters();
		response = materialsOrdersInterceptor.getOrders(sso, portalId, multiValmap, contentType, icaoCode);
		return response;
	}

	/**
	 * Returns Header details
	 * 
	 * @param request
	 * @param msNumber
	 * @param deliveryId
	 * @param orderHeaderId
	 * @param invoiceHeaderId
	 * @return Response
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get materials Header details", notes = "getHeaderDetailBS Service will return Header details.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "18") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getHeaderDetailBS")
	public Response getHeaderDetailBS(@Context HttpServletRequest request, @FormParam("msNumber") String msNumber,
			@FormParam("deliveryId") String deliveryId, @FormParam("orderHeaderId") String orderHeaderId,
			@FormParam("invoiceHeaderId") String invoiceHeaderId) throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsOrdersInterceptor.getHeaderDetailBS(strSSO, portalId, msNumber, deliveryId, orderHeaderId,
				invoiceHeaderId);
		return response;
	}

	/**
	 * Returns Order Audit History
	 * 
	 * @param request
	 * @param headerId
	 * @return Response
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get materials Order Audit History details", notes = "getOrderAuditHistoryBS Service will return Audit History details.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "19") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getOrderAuditHistoryBS")
	public Response getOrderAuditHistoryBS(@Context HttpServletRequest request, @FormParam("headerId") String headerId)
			throws MaterialsException {
		OrderAuditHistoryBO orderAuditList = null;
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		orderAuditList = materialsOrdersApp.getOrderAuditHistoryBS(strSSO, portalId, headerId);
		response = Response.ok(orderAuditList).build();
		return response;
	}

	/**
	 * Returns Order template
	 * 
	 * @param request
	 * @return Response
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get materials Order Template", notes = "getOrderTemplateBS Service will return Order template.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "20") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Produces({ "application/vnd.ms-excel", "application/json" })
	@Path("/getOrderTemplateBS")
	public Response getOrderTemplateBS(@Context HttpServletRequest request) throws MaterialsException {
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		return materialsOrdersInterceptor.getOrderTemplateBS(strSSO, portalId);
	}

	@ApiOperation(value = "Update materials Order details", notes = "updateOrderBS Service will update the Orderr details.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "21") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/updateOrderBS")
	public Response updateOrderBS(@Context HttpServletRequest request,
			List<UpdateOrderRequestDetails> updateOrderRequestList) throws MaterialsException {

		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsOrdersInterceptor.updateOrderBS(strSSO, portalId, updateOrderRequestList);
		return response;

	}

	/**
	 * 
     * @param ui
     * @param request
     * @return response
     * @throws MaterialsException
     */
     @ApiOperation(value = "Get Line Status History", notes = "getLineStatusHistoryBS Service", response = Response.class, extensions = {
                   @Extension(name = "serviceMetaData", properties = {
                                @ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
                                @ExtensionProperty(name = "dataSource", value = "Oracle"),
                                @ExtensionProperty(name = "isExternal", value = "false"),
                                @ExtensionProperty(name = "isCore", value = "false"),
                                @ExtensionProperty(name = "isInfo", value = "true"),
                                @ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
                                @ExtensionProperty(name = "responseObject", value = "Response"),
                                @ExtensionProperty(name = "risklevel", value = "Medium"),
                                @ExtensionProperty(name = "dataClassification", value = "GE Internal"),
                                @ExtensionProperty(name = "mockdataRefid", value = "22") }) })

            @ApiImplicitParams({
                   @ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
                   @ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true)})
     @ApiParam(name = "UriInfo", value= " ")

     @GET
     @Path("/getLineStatusHistoryBS")
     @Produces({"application/json"})
     public Response getLineStatusHistoryBS(@Context UriInfo ui, 
                   @Context HttpServletRequest request)throws MaterialsException{
            Response response = null;
            String sso =  MaterialsServiceUtil.getSMSSOId(request);
            String portalId = MaterialsServiceUtil.getPortalId(request);
            MultivaluedMap<String, String> multiValmap = ui.getQueryParameters();
            response = materialsInterceptor.getLineStatusHistoryBS(sso, portalId, multiValmap);
            return response;
     }
     
     /**Returns the pricing catalog 
      * @param ui
     * @param request
     * @return response
     * @throws MaterialsException
     */
     @ApiOperation(value = "Get Pricing Catalog", notes = "getPricingCatalogBS Service will return Pricing Catalogs.", response = Response.class, extensions = {
                   @Extension(name = "serviceMetaData", properties = {
                                @ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
                                @ExtensionProperty(name = "dataSource", value = "Oracle"),
                                @ExtensionProperty(name = "isExternal", value = "false"),
                                @ExtensionProperty(name = "isCore", value = "false"),
                                @ExtensionProperty(name = "isInfo", value = "true"),
                                @ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
                                @ExtensionProperty(name = "responseObject", value = "Response"),
                                @ExtensionProperty(name = "risklevel", value = "Medium"),
                                @ExtensionProperty(name = "dataClassification", value = "GE Internal"),
                                @ExtensionProperty(name = "mockdataRefid", value = "23") }) })

            @ApiImplicitParams({
                   @ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
                   @ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true)})
            @ApiParam(name = "UriInfo", value= "sEcho=2&iColumns=5&sColumns=&iDisplayStart=0&iDisplayLength=24&mDataProp_0=platform&mDataProp_1=function&mDataProp_2=pdfLink&mDataProp_3=revisionDate&mDataProp_4=excelLink&sSearch=&bRegex=false&sSearch_0=&bRegex_0=false&sSearch_1=&bRegex_1=false&sSearch_2=&bRegex_2=false&sSearch_3=&bRegex_3=false&sSearch_4=&bRegex_4=false&iSortCol_0=1&sSortDir_0=desc&iSortingCols=1")
     @GET
     @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
     @Path("/getPricingCatalogBS")
     public javax.ws.rs.core.Response getPricingCatalogBS(
                   @Context UriInfo ui,
                   @Context HttpServletRequest request) throws MaterialsException {
            MultivaluedMap<String, String> multiValmap = ui.getQueryParameters();
            String strSSO = MaterialsServiceUtil.getSMSSOId(request);
            String portalId = MaterialsServiceUtil.getPortalId(request);
            Response response = null;
            response = materialsInterceptor.getPricingCatalog(multiValmap, strSSO, portalId);
            return response;
     }
     
     /**
     * Returns the pricing Catalog Doc
     * @param platform
     * @param docType
     * @param effDate
     * @param request
     * @return
     * @throws MaterialsException
     */
     @ApiOperation(value = "Get Pricing Catalog Doc", notes = "getPricingCatalogDocBS Service will return Pricing Catalogs Doc.", response = Response.class, extensions = {
                   @Extension(name = "serviceMetaData", properties = {
                                @ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
                                @ExtensionProperty(name = "dataSource", value = "Oracle"),
                                @ExtensionProperty(name = "isExternal", value = "false"),
                                @ExtensionProperty(name = "isCore", value = "false"),
                                @ExtensionProperty(name = "isInfo", value = "true"),
                                @ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
                                @ExtensionProperty(name = "responseObject", value = "Response"),
                                @ExtensionProperty(name = "risklevel", value = "Medium"),
                                @ExtensionProperty(name = "dataClassification", value = "GE Internal"),
                                @ExtensionProperty(name = "mockdataRefid", value = "24") }) })

            @ApiImplicitParams({
                   @ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
                   @ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true)})
     @GET
     @Path("/getPricingCatalogDocBS")
     @Produces({ "application/pdf", "application/vnd.ms-excel","application/json","text/html"})
     public javax.ws.rs.core.Response getPricingCatalogDoc(@ApiParam(name = "platform", value="Q0Y2", required = true)
                   @FormParam("platform") String platform, @ApiParam(name = "docType", value="RVhDRUw", required = true)
                   @FormParam("docType") String docType, @ApiParam(name = "effDate", value="MjAxNi0xMS0wMQ", required = true) @FormParam("effDate") String effDate,@Context HttpServletRequest request) throws MaterialsException {
            Response response = null;
            String strSSO = MaterialsServiceUtil.getSMSSOId(request);
            String portalId = MaterialsServiceUtil.getPortalId(request);
            response = materialsInterceptor.getPricingCatalogDocBS(MaterialsServiceUtil.validateString(platform), MaterialsServiceUtil.validateString(docType),
                         strSSO, portalId,MaterialsServiceUtil.validateString(effDate));
            return response;
     }


	@ApiOperation(value = "Crete purchase Order", notes = "purchasePOBS Service will create purchase for items in cart.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "25") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })

	/**
	 * Returns PurchasePO Details
	 * 
	 * @param request
	 * @param cartHeaderId
	 * @param orderType
	 * @return Response
	 * @throws MaterialsException
	 */

	@POST
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/purchasePOBS")
	public Response purchasePOBS(@Context HttpServletRequest request, @FormParam("cartHeaderId") String cartHeaderId,
			@FormParam("orderType") String orderType) throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsCartInterceptor.purchasePOBS(strSSO, portalId, cartHeaderId, orderType);
		return response;
	}

	@ApiOperation(value = "Get purchase order quotation", notes = "getPoQuotations Service will give purchase order quotation.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "26") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })

	/**
	 * Returns Purchase order quotation Details
	 * 
	 * @param ui
	 * @param request
	 * @return Response
	 * @throws MaterialsException
	 */
	@GET
	@Path("/getPoQuotations")
	@Produces({ "application/json" })
	public Response getPoQuotations(@Context UriInfo ui, @Context HttpServletRequest request)
			throws MaterialsException {
		Response response = null;
		String sso = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		MultivaluedMap<String, String> multiValmap = ui.getQueryParameters();
		response = materialsInterceptor.getPoQuotations(sso, portalId, multiValmap);
		return response;
	}

	/**
	 * Get ShiptoMark address
	 * @param request
	 * @param customerId
	 * @param custCode
	 * @return getShiptoMarkforAddressBS Object
	 * @throws MaterialsException
	 */
	
	@ApiOperation(value = "ShiptoMark address details", notes = "return shiptomark address.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "27") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getShiptoMarkforAddressBS")
	public Response getShiptoMarkforAddressBS(@Context HttpServletRequest request,
			@ApiParam(name = "customerId", value = "Customer Id", allowMultiple = false, required = true) @FormParam("customerId") String customerId, 
			@ApiParam(name = "CustCode", value = "Customer Code", allowMultiple = false, required = true) @FormParam("CustCode") String custCode)
			throws MaterialsException {
		Response response = null; 
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsInterceptor.getShiptoMarkforAddressBS(strSSO,
				portalId, customerId,custCode);
		return response;
	}
	
	/**
	 * Move items to wishlist
	 * @param request
	 * @param partNumber
	 * @return InsertWishListResponse Object
	 * @throws MaterialsException
	 */
	
	@ApiOperation(value = "WishList Operation", notes = "move items to wishlist", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "28") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@POST
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/insertWishList")
	public Response insertWishListBS(@Context HttpServletRequest request,
			@ApiParam(name = "partNumber", value = "Part Number", allowMultiple = false, required = true) @FormParam("partNumber") String partNumber) throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsWishListInterceptor.insertWishListBS(strSSO,portalId,partNumber);
		return response;
	}
	
	/**
	 * Get items present in wishlist
	 * @param request
	 * @return WishListDetailsBO
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "WishList Operation", notes = "get wishlist items", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "29") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Produces({ MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Path("/getWishListDetails")
	public Response getWishListDetails(@Context HttpServletRequest request) throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsWishListInterceptor.getWishListDetailsBS(strSSO,portalId);
		return response;
	}
	/**
	 * Delete items from wishlist
	 * @param request
	 * @param partNumber
	 * @return DeleteWishListBO
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "WishList Operation", notes = "delete wishlist items", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "30") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Path("/deleteWishListBS")
	public Response deleteWishList(@Context HttpServletRequest request,
			@ApiParam(name = "partNumber", value = "Part Number", allowMultiple = false, required = true) @FormParam("partNumber") String partNumber) throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsWishListInterceptor.deleteWishListBS(strSSO,portalId,partNumber);
		return response;
	}
	
	
	/**
	 * Move Wishlist items to Save for later
	 * @param request
	 * @param partsLstr
	 * @return orderStatusBO
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "WishList Operation", notes = "move wishlist items to save for later", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "31") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces({ MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Path("/wishLstToSaveLst")
	public Response wishListToSaveList(@Context HttpServletRequest request,List<BulkAddPartBO> partsLstr) throws MaterialsException
	{
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsWishListInterceptor.wishLstToSaveLstBS(strSSO,portalId,partsLstr);
		return response;
	}
	
	/**
	 * add one or more part to wishlist-Bulk Operation
	 * @param request
	 * @param List Of BulkAddPartBO
	 * @return OrderStatusBO
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Bulk Operation", notes = "add one or more part to wishlist ", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "32") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/addBulkPartDtls")
	 public Response addBulkPartDtls(@Context HttpServletRequest request, 
			 @ApiParam(name = "partNumber", value = "All Part Numbers to be added", allowMultiple = false, required = true) List<BulkAddPartBO> partsLst)throws MaterialsException{
		   Response response = null;
		   String ssoId = MaterialsServiceUtil.getSMSSOId(request);
		   String portalId = MaterialsServiceUtil.getPortalId(request);
		   OrderStatusBO orderStatusBO = materialsApp.addBulkPartDtls(ssoId, portalId, partsLst);
		   response = Response.ok(orderStatusBO).build();
			return response;
		}
	
	/**
	 * Bulk Search for parts
	 * @param request
	 * @param partNumbers
	 * @return BulkPartDetailsBO
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Bulk Operation", notes = "searc one or more part ", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "33") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getBulkSearchPartDtlBS")
	public Response getBulkSearchPartDtlBS(@Context HttpServletRequest request,
			@ApiParam(name = "partNumber", value = "Part Numbers", allowMultiple = false, required = true) @FormParam("partNumbers") String partNumbers)throws MaterialsException {
		List< BulkPartDetailsBO> bulkPartLst = null;
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
	    bulkPartLst=materialsApp.getBulkSearchPartDtlBS(strSSO, portalId, partNumbers);
	     response = Response.ok(bulkPartLst).build();		
		return response;
	}
	
	/**
	 * @param custId
	 * @param request
	 * @return customer details based on the custId
	 * @throws MaterialsException
	 */

	@ApiOperation(value = "gets customer shipment details", notes = "customer shipment details based on the custId.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "34") }) })

		@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			})
	@GET
	@Path("/getCustAdminDetailsBS")
	@Produces( { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response getCustAdminDetailsBS(@ApiParam(name = "custId", value = "eg.400732", allowMultiple = false, required = true)@FormParam("custId") String custId,
			@Context HttpServletRequest request) throws MaterialsException {
		Response response = null;
		
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsInterceptor.getCustAdminDetailsBS(strSSO, portalId, custId);
		return response;

	}
	
	/**
	 * price and availability details of a part number.
	 * @param request
	 * @param invontoryItemId
	 * @param custCode
	 * @param custId
	 * @param partNumber
	 * @return PartDetailsBO
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "price and availability of a part", notes = "price and availability details of a part number.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "35") }) })

		@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			})
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getItemAvailPricDtlBS")
	public Response getItemAvailPricDtlBS(@Context HttpServletRequest request,
			@ApiParam(name = "inventoryItemId", value = "eg.2877748", allowMultiple = false, required = true)@FormParam("inventoryItemId") String invontoryItemId,
			@ApiParam(name = "custCode", value = "", allowMultiple = false, required = true)@FormParam("custCode") String custCode,
			@ApiParam(name = "custId", value = "", allowMultiple = false, required = true)@FormParam("custId") String custId,
			@ApiParam(name = "partNumber", value = "eg.2300M17P02", allowMultiple = false, required = true)@FormParam("partNumber") String partNumber) throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsItemInterceptor.getItemAvailPricDtlBS(strSSO, portalId,invontoryItemId,custCode,custId,partNumber);
		return response;
	}

	/**
	 * getItemAvailPricPartDtlBS will return the PricingList,AvailabilityList and ApplicableCust Details
	 * @param request
	 * @param partNumber
	 * @return PartDetailsBO
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "price and availability of a part", notes = "PricingList,AvailabilityList and ApplicableCust Details", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "36") }) })

		@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			})
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getItemAvailPricPartDtlBS")
	public Response getItemAvailPricPartDtlBS(@Context HttpServletRequest request,
			@ApiParam(name = "partNumber", value = "eg.2300M17P02", allowMultiple = false, required = true)@FormParam("partNumber") String partNumber)throws MaterialsException {
		PartDetailsBO partDetailsBO = null;
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
	    partDetailsBO=materialsItemApp.getItemAvailPricPartDtlBS(strSSO, portalId,partNumber);
		response = Response.ok(partDetailsBO).build();		
		return response;

	}

	/**
	 * Config History of a part
	 * @param request
	 * @param invontoryItemId
	 * @param partNumber
	 * @return ItemConfigHistoryBO
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Config History of a part", notes = "Config History of a part", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "37") }) })

		@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			})
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getItemConfigHistoryBS")
	public Response getItemConfigHistoryBS(@Context HttpServletRequest request,
			@ApiParam(name = "inventoryItemId", value = "eg.479791", allowMultiple = false, required = true)@FormParam("inventoryItemId") String invontoryItemId,
			@ApiParam(name = "partNumber", value = "eg.J1437P1127", allowMultiple = false, required = true)@FormParam("partNumber") String partNumber)
			throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsItemInterceptor.getItemConfigHistoryBS(strSSO, portalId, invontoryItemId,partNumber);
		return response;

	}
	
	
	/**
	 * Kit Structure of a part
	 * @param inventoryItemId
	 * @param request
	 * @return KitStructureBO
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Kit Structure of a part", notes = "Kit Structure of a part", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "38") }) })

		@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			})
	@GET
	@Path("/getKitStructureBS")
	@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	public Response getKitStructureBS(@ApiParam(name = "inventoryItemId", value = "eg.1535914", allowMultiple = false, required = true)@FormParam("inventoryItemId") String inventoryItemId,
			@Context HttpServletRequest request) throws MaterialsException{		
		Response response = null;
		String sso =  MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsItemInterceptor.getKitStructureBS(sso, portalId, inventoryItemId);
		return response;
	}
	
	/**
	 * Config History of used and repairs part
	 * @param request
	 * @param partNumber
	 * @return ItemConfigHistoryBO
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Config History of a part", notes = "Config History of used and repairs part", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "39") }) })

		@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			})
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getRepUsedItemConfigHistory")
	public Response getRepUsedItemConfigHistory(@Context HttpServletRequest request,
			@ApiParam(name = "partNumber", value = "eg.J1437P1127", allowMultiple = false, required = true)@FormParam("partNumber") String partNumber)
			throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsItemInterceptor.getRepUsedItemConfigHistory(strSSO, portalId, partNumber);
		return response;
	}
	
	/**
	 * Get Commercial Agreement BS
	 * @param request
	 * @param ui
	 * @return Response
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get Commercial Agreement", notes = "getCommercialAgreementBS Service", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "40") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Path("/getCommercialAgreementBS")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response getCommercialAgreementBS(@Context HttpServletRequest request, @ApiParam(name = "UriInfo", value = " ", allowMultiple = false, required = true) @Context UriInfo ui)
			throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		MultivaluedMap<String, String> multiValmap = ui.getQueryParameters();
		response = materialsInterceptor.getCommercialAgreementBS(strSSO, portalId, multiValmap);
		return response;
	}

	/**
	 * Get Commercial Agreement Part
	 * @param ui
	 * @param request
	 * @return Response
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get Commercial Agreement Part", notes = "getCommercialAgreementPartBS Service", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "41") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Path("/getCommercialAgreementPartBS")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response getCommercialAgreementPartBS(@ApiParam(name = "UriInfo", value = " ", allowMultiple = false, required = true) @Context UriInfo ui, @Context HttpServletRequest request)
			throws MaterialsException {
		Response response = null;
		MultivaluedMap<String, String> multiValmap = ui.getQueryParameters();
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsInterceptor.getCommercialAgreementPartBS(strSSO, portalId, multiValmap);
		return response;
	}

	/**
	 * Get Rating Plug
	 * @param ui
	 * @param request
	 * @return Response
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get Rating PLug", notes = "getratingPlugBS Service", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "42") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Path("/getRatingPlugBS")
	@Produces({ "application/json" })
	public Response getRatingPlugBS(@ApiParam(name = "UriInfo", value = " ", allowMultiple = false, required = true) @Context UriInfo ui, @Context HttpServletRequest request)
			throws MaterialsException {
		Response response = null;
		String sso = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		MultivaluedMap<String, String> multiValmap = ui.getQueryParameters();
		response = materialsInterceptor.getRatingPlugBS(sso, portalId, multiValmap);
		return response;
	}

	/**
	 * Create Rating Plug Form
	 * @param request
	 * @param ratingPlugDetails
	 * @return Response
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Create Rating Plug Form", notes = "createRatingPlugFormBS Service", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "43") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@POST
	@Path("/createRatingPlugFormBS")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces({ "application/json" })
	public Response createRatingPlugFormBS(@Context HttpServletRequest request, @ApiParam(name = "ratingPlugDetails", value = " ", allowMultiple = false, required = true) String ratingPlugDetails)
			throws MaterialsException {
		Response response = null;
		String sso = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsInterceptor.createRatingPlugFormBS(sso, portalId, ratingPlugDetails);
		return response;
	}

	/**
	 * Get Rating Plug Form
	 * @param request
	 * @param ui
	 * @return Response
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get Rating Plug Form", notes = "getRatingPlugFormBS Service", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "44") }) })

	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Path("/getRatingPlugFormBS")
	@Produces({ "application/json", "text/html" })
	public Response getRatingPlugFormBS(@Context HttpServletRequest request, @ApiParam(name = "UriInfo", value = " ", allowMultiple = false, required = true) @Context UriInfo ui)
			throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		MultivaluedMap<String, String> multiValmap = ui.getQueryParameters();
		response = materialsInterceptor.getRatingPlugFormBS(strSSO, portalId, multiValmap);
		return response;
	}
	
	/**
     * send invoice document to your e-mail
     * 
     * @param invoiceId
     * @param request
     * @return invoice document based on invoice id
     * @throws MaterialsException
     */
    @ApiOperation(value = "gets invoice document", notes = "invoice document based on the invoiceId.", response = Response.class, extensions = {
            @Extension(name = "serviceMetaData", properties = {
                    @ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
                    @ExtensionProperty(name = "dataSource", value = "Oracle"),
                    @ExtensionProperty(name = "isExternal", value = "false"),
                    @ExtensionProperty(name = "isCore", value = "false"),
                    @ExtensionProperty(name = "isInfo", value = "true"),
                    @ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
                    @ExtensionProperty(name = "responseObject", value = "Response"),
                    @ExtensionProperty(name = "risklevel", value = "Medium"),
                    @ExtensionProperty(name = "dataClassification", value = "GE Internal"),
                    @ExtensionProperty(name = "mockdataRefid", value = "45")})})

    @ApiImplicitParams({
            @ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
            @ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true),
    })
    @GET
    @Path("/getInvoiceDocumentBS")
    @Produces({"application/json", "text/html"})
    public Response getInvoiceDocumentBS(@ApiParam(name = "invoiceId", value = "20342670", allowMultiple = false, required = true) @FormParam("invoiceId") String invoiceId,
                                                          @Context HttpServletRequest request) throws MaterialsException {
        Response response = null;
        InvoiceDocDO invoiceDocDO = null;
        StatusBO statusBo = new StatusBO();
        String strSSO = MaterialsServiceUtil.getSMSSOId(request);
        String portalId = MaterialsServiceUtil.getPortalId(request);
        invoiceDocDO = materialsOrdersApp.getInvoiceDocBS(strSSO, portalId, invoiceId);
        statusBo.setSuccess(invoiceDocDO.getStatusMessage());
        response = Response.ok(statusBo).build();
        return response;
    }
    
	/**
	 * lists RFQ -not available for INC user,For SA, Json from SA will be returned
	 * @param ui
	 * @param request
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "lists RFQ", notes = "lists RFQ, functionality for SA user.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "46") }) })

		@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			})
	@GET
	@Path("/listRFQBS")
	@Produces( { MediaType.APPLICATION_JSON})
	public Response listRFQBS(@Context UriInfo ui,@Context HttpServletRequest request)
			 throws MaterialsException {
		Response response = null;
		String strSSO = MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		MultivaluedMap<String, String> multiValmap = ui.getQueryParameters();
		response = materialsRfqInterceptor.listRFQBS(strSSO, portalId,multiValmap);
		return response;
	}

	/**
	 * gets RFQ details -not available for INC user,For SA, Json from SA will be returned
	 * @param ui
	 * @param request
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "gets RFQ details", notes = "gets RFQ details-functionality for SA user", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "47") }) })

		@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			})
	@GET
	@Path("/getRFQDetailBS")
	@Produces({"application/json"})
	public Response getRFQDetailBS(@Context UriInfo ui,
			@Context HttpServletRequest request) throws MaterialsException{
		Response response = null;
		String sso =  MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		MultivaluedMap<String, String> multiValmap = ui.getQueryParameters();
		response = materialsRfqInterceptor.getRFQDetailBS(sso, portalId, multiValmap);
		return response;
	}
	
	/**
	 * gets RFQ -not available for INC user,For SA, Json from SA will be returned
	 * @param request
	 * @param ui
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "gets RFQ", notes = "gets RFQ-functionality for SA user", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "48") }) })

		@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			})
	@GET
	@Path("/getRFQBS")
	@Produces({"application/json","text/html"})
	public javax.ws.rs.core.Response getRFQBS(@Context HttpServletRequest request,@Context UriInfo ui) throws MaterialsException {
		Response response = null;
		String strSSO =  MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		MultivaluedMap<String, String> multiValmap = ui.getQueryParameters();
		response = materialsRfqInterceptor.getRFQBS(strSSO,portalId,multiValmap);
		return response;
	}
	
	/**
	 * Creates RFQ -not available for INC user,For SA, Json from SA will be returned
	 * @param customerCode
	 * @param rfqClientNumber
	 * @param rfqSubmittedDate
	 * @param rfqPriorityCode
	 * @param partNumber
	 * @param orderedQuantity
	 * @param rfqConditionCode
	 * @param rfqCustomerRemarks
	 * @param request
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "creates RFQ", notes = "creates RFQ-functionality for SA user", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "49") }) })

		@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			})
	@POST
    @Path("/createRFQBS")
    @Produces({"application/json","text/html"})
    public javax.ws.rs.core.Response createRFQBS(@FormParam ("customerCode") String customerCode
                  ,@FormParam ("rfqClientNumber") String rfqClientNumber
                  ,@FormParam ("rfqSubmittedDate") String rfqSubmittedDate
                  ,@FormParam ("rfqPriorityCode") String rfqPriorityCode
                  ,@FormParam ("partNumber") String partNumber
                  ,@FormParam ("orderedQuantity") String orderedQuantity
                  ,@FormParam ("rfqConditionCode") String rfqConditionCode
                  ,@FormParam ("rfqCustomerRemarks") String rfqCustomerRemarks,@Context HttpServletRequest request) throws MaterialsException {

           Response response = null;
           String strSSO =  MaterialsServiceUtil.getSMSSOId(request);
           String portalId = MaterialsServiceUtil.getPortalId(request);
           response = materialsRfqInterceptor.createRFQBS(customerCode,rfqClientNumber,rfqSubmittedDate,rfqPriorityCode,partNumber,orderedQuantity,rfqConditionCode,rfqCustomerRemarks,strSSO,portalId);
           return response;
    }
	
	/**
	 * Get materials Order details in CSV file
	 * @param msNumber
	 * @param deliveryId
	 * @param orderHeaderId
	 * @param invoiceHeaderId
	 * @param request
	 * @return
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get materials Order details in CSV file", notes = "getcsvFile Service will return Order Details in csv format.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "50") }) })
	@ApiImplicitParams({
			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })	
	@GET
	@Produces({"application/json","text/csv"})
	@Path("/getcsvFile")
	public Response getcsvFile(@ApiParam(name = "msNumber", value = "ms Number", allowMultiple = false) @FormParam("msNumber") String msNumber,
			@ApiParam(name = "deliveryId", value = "Delivery Id", allowMultiple = false) @FormParam("deliveryId") String deliveryId,
			@ApiParam(name = "orderHeaderId", value = "OrderHeader Id", allowMultiple = false) @FormParam("orderHeaderId") String orderHeaderId,
			@ApiParam(name = "invoiceHeaderId", value = "Invoice Header Id", allowMultiple = false) @FormParam("invoiceHeaderId") String invoiceHeaderId,
			@Context HttpServletRequest request)throws MaterialsException{
		Response response = null;
		String sso =  MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		response = materialsOrdersApp.getcsvFile(sso, portalId, msNumber, deliveryId,
				orderHeaderId, invoiceHeaderId);
		return response;
	}
	
	
	/**
	 * Get materials document for CFM in CSV file
	 * @param msNumber
	 * @param docType
	 * @param deliveryId
	 * @param invoiceHeaderId
	 * @param request
	 * @param proformaInvoiceId
	 * @param commercialInvoiceId
	 * @param notificationFlag
	 * @return
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get materials document for CFM in CSV file", notes = "getMaterialsDocumentBS Service will return materials document for CFM in csv format.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "51") }) })
	@ApiImplicitParams({
		@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
		@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })	
	@GET
	@Path("/getMaterialsDocumentBS")
	@Produces({"application/json","application/pdf","text/html","application/zip"})
	public Response getMaterialsDocumentBS(
			@ApiParam(name = "msNumber", value = "ms Number", allowMultiple = false) @FormParam("msNumber") String msNumber,
			@ApiParam(name = "docType", value = "Documnet Type", allowMultiple = false) @FormParam("docType") String docType,
			@ApiParam(name = "deliveryId", value = "Delivery Id", allowMultiple = false) @FormParam("deliveryId") String deliveryId, 
			@ApiParam(name = "invoiceHeaderId", value = "Invoice Header Id", allowMultiple = false) @FormParam("invoiceHeaderId") String invoiceHeaderId,@Context HttpServletRequest request,
			@ApiParam(name = "proformaInvoiceId", value = "Proforma Invoice Id", allowMultiple = false) @FormParam("proformaInvoiceId") String proformaInvoiceId,
			@ApiParam(name = "commercialInvoiceId", value = "Commercial Invoice Id", allowMultiple = false) @FormParam("commercialInvoiceId") String commercialInvoiceId,
			@ApiParam(name = "notificationFlag", value = "Notification Flag", allowMultiple = false) @FormParam("notificationFlag") String notificationFlag) throws MaterialsException {
		String strSSO =  MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		return materialsOrdersInterceptor.getMaterialsDocumentBS(strSSO,portalId,msNumber, docType,deliveryId,invoiceHeaderId,proformaInvoiceId,commercialInvoiceId,notificationFlag);	 
	}
	
	
	/**
	 * Get materials order details in PDF file
	 * @param orderHeaderId
	 * @param request
	 * @return
	 * @throws MaterialsException
	 */
	@ApiOperation(value = "Get materials order details in PDF file", notes = "getPDFFile Service will return materials order details in PDF file format.", response = Response.class, extensions = {
			@Extension(name = "serviceMetaData", properties = {
					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
					@ExtensionProperty(name = "dataSource", value = "Oracle"),
					@ExtensionProperty(name = "isExternal", value = "false"),
					@ExtensionProperty(name = "isCore", value = "false"),
					@ExtensionProperty(name = "isInfo", value = "true"),
					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
					@ExtensionProperty(name = "responseObject", value = "Response"),
					@ExtensionProperty(name = "risklevel", value = "Medium"),
					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
					@ExtensionProperty(name = "mockdataRefid", value = "52") }) })
	@ApiImplicitParams({
		@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
		@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
	@GET
	@Path("/getPDFFile")
	@Produces({"application/json","application/pdf", "text/html"})
	public Response getPDFFile(@ApiParam(name = "orderHeaderId", value = "OrderHeader Id", allowMultiple = false, required = true) @FormParam("orderHeaderId") String orderHeaderId,
			@Context HttpServletRequest request)throws MaterialsException{
		Response response = null;
		byte[] fileContent = null;
		String sso =  MaterialsServiceUtil.getSMSSOId(request);
		String portalId = MaterialsServiceUtil.getPortalId(request);
		DisputeDocumentBO documentBO = materialsOrdersApp.getPDFFile(sso, portalId, orderHeaderId);
		fileContent = documentBO.getFileData();
		String fileName = documentBO.getFileName();
		response = buildResponse(fileContent, fileName);
		return response;
	}
	
    /**
    * @param fileName
    * @param request
    * @return Repair pricing catalog
    * @throws MaterialsException
    */
    
    @ApiOperation(value = "gets repair pricing catalog document", notes = "getRepairCatalogBS will return pdf/xls/xlsx repair catalog", response = Response.class, extensions = {
                  @Extension(name = "serviceMetaData", properties = {
                               @ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
                               @ExtensionProperty(name = "dataSource", value = "Oracle"),
                               @ExtensionProperty(name = "isExternal", value = "false"),
                               @ExtensionProperty(name = "isCore", value = "false"),
                               @ExtensionProperty(name = "isInfo", value = "true"),
                               @ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
                               @ExtensionProperty(name = "responseObject", value = "Response"),
                               @ExtensionProperty(name = "risklevel", value = "Medium"),
                               @ExtensionProperty(name = "dataClassification", value = "GE Internal"),
                               @ExtensionProperty(name = "mockdataRefid", value = "53") }) })

           @ApiImplicitParams({
                  @ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
                  @ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true),
                  })
    @GET
    @Path("/getRepairCatalogBS")
    @Produces({"application/pdf","application/json","text/html"})
    public Response getRepairCatalogBS(@FormParam("fileName") String fileName,@Context HttpServletRequest request) throws MaterialsException {
           Response response = null;
           String sso =  MaterialsServiceUtil.getSMSSOId(request);
           String portalId = MaterialsServiceUtil.getPortalId(request);
           response = materialsInterceptor.getRepairCatalogBS(sso, portalId, fileName);
           
           return response;
    }      
    /**
    * @param ui (UriInfo)
    * @param request
    * @return list of repair catalog
    * @throws MaterialsException
    */
    
    @ApiOperation(value = "gets list of repair pricing catalog documents", notes = "getRepairCatalogListBS will return list of pdf/xls/xlsx repair catalogs", response = Response.class, extensions = {
                  @Extension(name = "serviceMetaData", properties = {
                               @ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
                               @ExtensionProperty(name = "dataSource", value = "Oracle"),
                               @ExtensionProperty(name = "isExternal", value = "false"),
                               @ExtensionProperty(name = "isCore", value = "false"),
                               @ExtensionProperty(name = "isInfo", value = "true"),
                               @ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
                               @ExtensionProperty(name = "responseObject", value = "Response"),
                               @ExtensionProperty(name = "risklevel", value = "Medium"),
                               @ExtensionProperty(name = "dataClassification", value = "GE Internal"),
                               @ExtensionProperty(name = "mockdataRefid", value = "54") }) })

           @ApiImplicitParams({
                  @ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
                  @ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true),
                  })
    @GET
    @Path("/getRepairCatalogListBS")
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getRepairCatalogListBS(
                  @Context UriInfo ui,
                  @Context HttpServletRequest request) throws MaterialsException {
           
           Response response = null;
           RepairCatalog repairCatalogBOList = null;
           MultivaluedMap<String, String> multiValmap = ui.getQueryParameters();
           String sso =  MaterialsServiceUtil.getSMSSOId(request);
           String portalId = MaterialsServiceUtil.getPortalId(request);
           repairCatalogBOList = materialsInterceptor.getRepairCatalogListBS(multiValmap, sso, portalId);
           response = Response.ok(repairCatalogBOList).build();
           return response;
    }

    /**
     * @param request-sm_ssoid,portal_id
     * @throws MaterialsException
     */
     @ApiOperation(value = "gets Customer ID List", notes = "gets Global Enquiry Customer ID List", response = Response.class, extensions = {
                   @Extension(name = "serviceMetaData", properties = {
                                @ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
                                @ExtensionProperty(name = "dataSource", value = "Oracle"),
                                @ExtensionProperty(name = "isExternal", value = "false"),
                                @ExtensionProperty(name = "isCore", value = "false"),
                                @ExtensionProperty(name = "isInfo", value = "true"),
                                @ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
                                @ExtensionProperty(name = "responseObject", value = "Response"),
                                @ExtensionProperty(name = "risklevel", value = "Medium"),
                                @ExtensionProperty(name = "dataClassification", value = "GE Internal"),
                                @ExtensionProperty(name = "mockdataRefid", value = "55") }) })

            @ApiImplicitParams({
                   @ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
                   @ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true),
                   })
     @GET
     @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
     @Path("/getGlobEnqCustIdListBS")
     public Response getGlobEnqCustIdListBS(@Context HttpServletRequest request)throws MaterialsException {
            Response response = null;
            String strSSO = MaterialsServiceUtil.getSMSSOId(request);
            String portalId = MaterialsServiceUtil.getPortalId(request);                   
            CustGlobEnqDetails custGlobEnqDetails = materialsApp.getGlobEnqCustIdList(strSSO,portalId);        
            response = Response.ok(custGlobEnqDetails).build();        
            return response;                 
     }
     
     /**
      * @param request
      * @param headerId
      * @return Order Details
      * @throws MaterialsException
      */
     @ApiOperation(value = "Get materials Order details", notes = "getOrderDetailsBS Service will return Order details.", response = Response.class, extensions = {
  			@Extension(name = "serviceMetaData", properties = {
  					@ExtensionProperty(name = "serviceOwner", value = "DSS-Team"),
  					@ExtensionProperty(name = "dataSource", value = "Oracle"),
  					@ExtensionProperty(name = "isExternal", value = "false"),
  					@ExtensionProperty(name = "isCore", value = "false"),
  					@ExtensionProperty(name = "isInfo", value = "true"),
  					@ExtensionProperty(name = "specification", value = "Swagger 2.0 Specification"),
  					@ExtensionProperty(name = "responseObject", value = "Response"),
  					@ExtensionProperty(name = "risklevel", value = "Medium"),
  					@ExtensionProperty(name = "dataClassification", value = "GE Internal"),
  					@ExtensionProperty(name = "mockdataRefid", value = "56") }) })

  	@ApiImplicitParams({
  			@ApiImplicitParam(name = "sm_ssoid", value = "SSO Of the User", dataType = "string", paramType = "header", allowMultiple = false, required = true),
  			@ApiImplicitParam(name = "portal_id", value = "Portal ID", dataType = "string", paramType = "header", allowMultiple = false, required = true) })
  	
      @GET
      @Path("/getOrderDetailsBS")
    	 @Produces( { MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    	 public Response getOrderDetailsBS(@Context HttpServletRequest request,
    			@ApiParam(name = "headerId", value="8148727", required = true) @FormParam("headerId") String headerId) throws MaterialsException {
    			OrderDetailsBO orderDetailsBO = null;
    			Response response = null;
    			String strSSO = MaterialsServiceUtil.getSMSSOId(request);
    			String portalId = MaterialsServiceUtil.getPortalId(request);
    			orderDetailsBO=materialsOrdersApp.getOrderDetailsBS(strSSO, portalId,headerId);
    			response = Response.ok(orderDetailsBO).build();
    			return response;
    	 }

}
