package com.geaviation.materials.ws;

import java.util.Arrays;
import java.util.Collections;

import org.apache.cxf.Bus;
import org.apache.cxf.endpoint.Server;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxrs.swagger.Swagger2Feature;
import org.codehaus.jackson.jaxrs.JacksonJsonProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.geaviation.materials.exception.mapper.MaterialsExceptionMapper;
import com.geaviation.materials.ws.impl.MaterialsServicesImpl;

@Configuration
@ComponentScan("com.geaviation.*")
@EnableAutoConfiguration(exclude = DataSourceAutoConfiguration.class)
public class MaterialsServicesSBApp {
	@Autowired
    private Bus bus;
    
    @Autowired
    private MaterialsServicesImpl materialsServicesImpl;
    
    @Autowired
    private MaterialsExceptionMapper materialsExceptionMapper;
    
	@Value("${DEPLOYEDVERSION}")
	private String deployedVersion;

    @Value("${SPRING_PROFILES_ACTIVE}")
	private String deployedInstance;

	public static void main(String[] args) {
		SpringApplication.run(MaterialsServicesSBApp.class, args);
	}

	  @Bean
	    public Server rsServer() {
	    	JAXRSServerFactoryBean endpoint = new JAXRSServerFactoryBean();
	        endpoint.setBus(bus);
	        endpoint.setServiceBeans(Arrays.<Object>asList(materialsServicesImpl));
	        endpoint.setAddress("/");
	        endpoint.setProviders(Arrays.<Object>asList(materialsExceptionMapper));
	        endpoint.setProvider(new JacksonJsonProvider());
	        
	        
	        Swagger2Feature swagger2Feature = new Swagger2Feature();
	        swagger2Feature.setTitle("New Materials API");
	        swagger2Feature.setTermsOfServiceUrl("All the above services usage restricted with Terms and Conditions. Written approval requried from service owner before comsuming any of the services");
	        swagger2Feature.setDescription("Services API for new materials applictions used on myGEAViation, myCFM, myGEHonda. These services used to create/view/edit different types of orders."
	        		+ "Click 'List operations' below to get list of all Service API calls.");
	        swagger2Feature.setLicenseUrl("https://mygeaviation.com");
	        swagger2Feature.setLicense("myGEAviation");
	        swagger2Feature.setContact("portalspringbootdevelopers@ge.com");
	        swagger2Feature.setTitle("New Materials API");
	        swagger2Feature.setVersion(deployedVersion.concat("(").concat(deployedInstance.toUpperCase()).concat(")"));
	        swagger2Feature.setPrettyPrint(true);
	        swagger2Feature.setSupportSwaggerUi(true);       
	        
	       endpoint.setFeatures(Collections.singletonList(swagger2Feature));
	        
	        
	        
	        
	        return endpoint.create();
	    }
}
