### Overview
Inprogress

Passport is new family of engines GE builds. These engines need to show up in only MyGEAV portal and user should able to view and order parts. Passport engines will have a separate operating unit (OU). Currently each portal is mapped to one OU so we need to map portal id to two OU one for CSO and other for passport.

Below are the changes identified so that we can handle passport orders .

#### Property changes  
  Modify PORTAL_TO_OPERATING_UNIT_MAPPING property to have  'CWC' portal id map to two OU separated by '~'  
  Ex: CWC:60377~12345

#### Service changes

##### /materials/requestMaterialsLoginBS
 1. If the request is for  myGEAV portal then call  stored procedures to check access and get login details.
 SP\_CHECK\_LOGIN and  SP\_REQUEST\_LOGIN are  stored procedures .  
 2. Response from the check access stored  procedure(SP\_CHECK\_LOGIN) will return one or two OU which the user has access to. If it is two then it will be '~' separated string. we store this value in  MaterialsUserBO.operatingUnitId and pass it on to other stored procedure calls as it is currently done. sp_check_login output ou id will pass to sp_request_login .

#### Services with input changes

##### /materials/purchasePOBS
1. Add new input param OU in the request from UI and pass on to procedure as operatingUnitId  

calls SP_PURCHASE_PO with custIdArray and operatingUnitId  from getCustLoginDetails also
cartHeaderId and orderType from request
calls SP_GET_LABEL_INFORMATION with custIdArray and operatingUnitId from getCustLoginDetails and also orderHeaderId from request.

##### /materials/getHeaderDetailBS
1. Add new input param OU in the request from UI and pass on to procedure as operatingUnitId  
Note : calls SP_GET_ORDER_HDR_INFO  with custIdArray and operatingUnitId from getCustLoginDetails and also msNumber, deliveryId, orderHeaderId, invoiceHeaderId  from request
calls SP_GET_LABEL_INFORMATION with custIdArray and operatingUnitId from getCustLoginDetails and also orderHeaderId from request.

##### /materials/getMaterialsDocumentBS*
where is it getting called
1. Add new input param OU in the request from UI and pass on to procedure as operatingUnitId  
Note: calls SP_GET_ORDER_HDR_INFO with custIdArray and operatingUnitId from getCustLoginDetails and also msNumber, deliveryId,invoiceHeaderId from request, orderHeaderId as null
calls  SP_INVOICE_FILE_RETURN with custIdArray and operatingUnitId from getCustLoginDetails and also invoiceId from request

##### /materials/getInvoiceDocumentBS
1. Add new input param OU in the request from UI and pass on to procedure as operatingUnitId  
calls SP_INVOICE_FILE_RETURN with custIdArray and operatingUnitId from getCustLoginDetails and also invoiceId from request

##### /materials/getLineDetailBS
1. Add new input param OU in the request from UI and pass on to procedure as operatingUnitId  
calls SP_GET_ORDER_LINE_INFO with custIdArray and operatingUnitId from getCustLoginDetails also msNumber,deliveryId,orderHeaderId,invoiceHeaderId from request


##### /materials/getOrderAuditHistoryBS
1. Add new input param OU in the request from UI and pass on to procedure as operatingUnitId  
calls SP_ORDER_AUDIT_HISTORY with custIdArray and operatingUnitId from getCustLoginDetails also headerId

##### /materials/updateOrderBS
1. Add new input param OU in the request from UI and pass on to procedure as operatingUnitId  
Note: calls SP_UPDATE_ORDER with custIdArray and operatingUnitId from getCustLoginDetails also UpdateOrderInputDO from request

##### /materials/deleteOrderLineBS
1. Add new input param OU in the request from UI and pass on to procedure as operatingUnitId  
calls SP_DELETE_ORDER_LINE with custIdArray and operatingUnitId from getCustLoginDetails and also headerId, lineId from request

##### /materials/createDisputeOrderBS
1. Add new input param OU in the request from UI and pass on to procedure as operatingUnitId
NOTE : calls SP_CREATE_DISPUTE_ORDER  
calls SP_GET_LABEL_INFORMATION with custIdArray and operatingUnitId from getCustLoginDetails and also orderHeaderId. custid is in request but not passed along to this call.
calls SP_GET_CAM_EMAIL with custIdArray and operatingUnitId from getCustLoginDetails

#### /materials/downloadDisputeDocBS
1. Add new input param OU in the request from UI and pass on to procedure as operatingUnitId  
NOTE: calls SP_GET_LABEL_INFORMATION with custIdArray and operatingUnitId from getCustLoginDetails and also orderHeaderId from request.

#### /materials/getPDFFile
1. Add new input param OU in the request from UI and pass on to procedure as operatingUnitId  
calls SP_GET_LABEL_INFORMATION with custIdArray and operatingUnitId from getCustLoginDetails and also orderHeaderId from request.

#### /materials/insertWishList
1. Add new input param supplier code and custid in the request from UI and pass on to procedure  
NOTE: calls  SP_WISHLT_INSERT with custIdArray and operatingUnitId from getCustLoginDetails and  partnumber from request

#### /materials/updateShipmentDetailsBS
1. Add new input param OU in the request from UI and pass on to procedure as operatingUnitId
calls  
NOTE: calls SP_GET_CAM_EMAIL with custIdArray and operatingUnitId from getCustLoginDetails


#### Service with changes to call getCustLoginDetails instead of requestMaterialsLogin

##### /materials/getCartBS
 1. Change this method to use getCustLoginDetails.
 2. need to look at removing the  input cartiheaderid since UI is not passing it and its not getting used within the service.  
   Note: calls  SP_GET_CART  custIdArray and operatingUnitId from requestMaterialsLogin
   cartHeaderId is not passed to the procedure

##### /materials/getBulkSearchPartDtlBS*
1. change call to getCustLoginDetails instead of requestMaterialsLogin  
Note:  calls SP_CUSTOMER_DETAILS with BulkPartDetailsBO.partAvailMsg as custid and operatingUnitId  from requestMaterialsLogin
 calls SP_BULK_ITEM_DETAILS with custid and operatingUnitId  from requestMaterialsLogin and also partnumbers from request

#### /materials/getItemConfigHistoryBS
1. Change to use getCustLoginDetails instead of requestMaterialsLogin  
NOTE: calls SP_ITEM_CONFIG_HISTORY with with custIdArray and operatingUnitId from requestMaterialsLogin also invontoryItemId, partNumber from request

#### /materials/getItemAvailPricDtlBS
1. Change to use getCustLoginDetails instead of requestMaterialsLogin  
NOTE: calls SP_ITEM_DETAILS with with custIdArray and operatingUnitId from requestMaterialsLogin also invontoryItemId from request

#### /materials/getOrderDetailsBS*
1. Change to use getCustLoginDetails instead of requestMaterialsLogin  
NOTE : calls SP_ORDER_DETAILS_DETAILS with with custIdArray and operatingUnitId from requestMaterialsLogin also invontoryItemId from request

#### /materials/deleteWishListBS
1. No change since we  pass the operating unit id from login detail and selected partnumber array from ui  but DB logic changes

##### /materials/getKitStructureBS*
1. No change since we  pass the operating unit id from login detail and selected inventoryItemId from ui  but DB logic changes  
Note:  calls SP_GET_KIT_STRUCTURE with custIdArray and operatingUnitId  from getCustLoginDetails and also inventoryItemId from request


#### Services with no changes but need to be tested since DB logic changes

##### /materials/getPricingCatalogBS
 1. No change since we  pass the operating unit id from login detail to this procedure  ( getPricingCatalogDS )  
  - DB  procedure logic change with current inputs so need testing.

##### /materials/getCartCountBS
- No change since we  pass the operating unit id from login detail to this procedure  but DB logic changes  
  Note: calls  SP_GET_CART_COUNT  with custIdArray and operatingUnitId  from getCustLoginDetails  
- DB change procedure login is changing so need testing

##### /materials/saveCartBS
 1. No change since we  pass the operating unit id from login detail to this procedure but DB logic changes  
  Note: calls SP_SAVE_CART   with custIdArray and operatingUnitId from getCustLoginDetails
 We may need to add ou to these two structure and pass that to stored procedure (SaveCartRequestDetails and SaveCartOrderLineInputDO)

##### /materials/deleteCartBS
1. No change since we  pass the operating unit id from login detail to this procedure but DB logic changes  
 Note: calls SP_DELETE_CART with custIdArray and operatingUnitId  from getCustLoginDetails
 cartHeaderId is not passed to the procedure

##### /materials/deleteCartLineBS
 1. No change since we  pass the operating unit id from login detail to this procedure but DB logic changes  
  calls SP_DELETE_CART_LINE with custIdArray and operatingUnitId  from getCustLoginDetails
 also cartHeaderId, cartLineId from request

##### /materials/addLineItemBS
 1. No change since we  pass the operating unit id from login detail and selected customer id from ui  but DB logic changes  
  calls SP_ADD_CART_LINE with custIdArray and operatingUnitId  from getCustLoginDetails also selectedCustomerId, selectedSupplierCode from input.

#### /materials/getItemAvailPricPartDtlBS*
 1. No change since we  pass the operating unit id from login detail and selected partnumber from ui  but DB logic changes

##### /materials/getCustAdminDetailsBS
confirm where this is called from with customer id in  the input.  
 calls SP_CUSTOMER_DETAILS with custId from request if its not empty  otherwise from requestMaterialsLogin and OU from requestMaterialsLogin.

#### /materials/getShiptoMarkforAddressBS
calls SP_CUSTOMER_DETAILS with custId from request if its not empty  otherwise from requestMaterialsLogin and OU from requestMaterialsLogin.


##### /materials/getcsvFile*
This one should not be used by myGEA otherwise we need to figure out how to send it specific  
  calls SP_GET_ORDER_HDR_INFO  msNumber, deliveryId, orderHeaderId, invoiceHeaderId
  calls SP_GET_LABEL_INFORMATION with custIdArray and operatingUnitId from getCustLoginDetails and also orderHeaderId from request
  This endpoint seems like only for myCFM please confirm from UI team. since it uses the same getHeaderDetailBS method if that changes input then we need to handle it for this as well.

#### /materials/addBulkPartDtls*
BulkAddPartBO should have customer id populated from request/UI.  
calls  SP_BULK_CART  with custIdArray and operatingUnitId from getCustLoginDetails. custid is in request but not flowing down to  getting passed to data layer. it could be a bug.

#### /materials/wishLstToSaveLst*
BulkAddPartBO should have customer id populated from request/UI.  
calls  SP_BULK_CART  with custIdArray and operatingUnitId from getCustLoginDetails. custid is in request but not flowing down to  getting passed to data layer. it could be a bug.

#### /materials/uploadOrderTemplateBS
 calls SP_BULK_CART_PO with custIdArray and operatingUnitId from getCustLoginDetails and custid is from request and gets populated for all individual items.

#### /materials/getWishListDetails
 calls SP_WISHLT_FETCH_DETAILS with custIdArray and operatingUnitId from getCustLoginDetails  

#### /materials/getGlobEnqCustIdListBS*
OU and role is required but the code currently is setting it to empty string so need further investigation  
NOTE: calls procedure SP_GET_GLOBAL_CUST_DETAILS with all empty string for custIdArray and operatingUnitId from requestMaterialsLogin
if needed to work procedure needs OU and role  from custlogin detail


### Attivio service changes
   Including Attivio changes here since it is related to the materials service changes.

##### /attivio/services/orderHistory/
 1. Modify service to filter by the new operating unit and supplier code
 2. Modify service response to include operating unit

##### /attivio/autosearch
 1. Modify service to filter by the new operating unit and supplier code
 2. Modify service response label to include operating unit in it. This might require index change depending on how this label is created.

#### /attivio/advsearch/l1
 1. Modify service to filter by the new operating unit and supplier code

#### /attivio/advsearch/l2
  1. Modify service to filter by the new operating unit and supplier code
  2. Modify service response title to include operating unit in it. This might require index change depending on how this label is created.


*Note: SP_GET_LABEL_INFORMATION* - both OU and orderid are required
