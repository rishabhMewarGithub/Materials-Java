package com.geaviation.materials.exception.util;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;

import com.geaviation.materials.exception.MaterialsErrorCodes;
import com.geaviation.materials.exception.MaterialsException;

@Component
public class MaterialsExceptionUtil {
	public static final String EMPTY_STRING = "";
	public static final String ERR_MESSAGE_RB = "errorMessage";
	public static final String AOC_PLACEHOLDER = "##AOC##";
	public static final String AOC = "AOC";
	public static final String UNKNOWN_ERROR = "UNKNOWN_ERROR";
	private static final Log log = LogFactory.getLog(MaterialsExceptionUtil.class);
	/**
	 * @param errorCode
	 * @return String
	 * @throws Exception
	 */
	public String getErrorMessage(String errorCode) throws MaterialsException{
		String errorMessage = EMPTY_STRING;
		if(isNotNullandEmpty(errorCode))
		{
			errorMessage = getPropertyValue(errorCode.trim());
			if(isNotNullandEmpty(errorMessage) && errorMessage.contains(AOC_PLACEHOLDER))
			{
				errorMessage+=getPropertyValue(AOC);
				errorMessage=errorMessage.replace(AOC_PLACEHOLDER, EMPTY_STRING);
			}
		}
		return errorMessage;
	}
	/**
	 * @param intErrorCode
	 * @return String
	 * @throws Exception
	 */
	public String getErrorMessage(int intErrorCode) throws MaterialsException{
		String strErrorCode = EMPTY_STRING;
		String errorMessage = EMPTY_STRING;
		strErrorCode = Integer.toString(intErrorCode);
		if(isNotNullandEmpty(strErrorCode))
		{
			errorMessage = getPropertyValue(strErrorCode);
			if(isNotNullandEmpty(errorMessage) && errorMessage.contains(AOC_PLACEHOLDER))
			{
				errorMessage+=getPropertyValue(AOC);
				errorMessage=errorMessage.replace(AOC_PLACEHOLDER, EMPTY_STRING);
			}
		}
		return errorMessage;
	}
	/**
	 * Returns true if the given string is not null and not empty
	 * @param strData
	 * @return boolean
	 */
	public static boolean isNotNullandEmpty(final String strData) {
		boolean isValid = false;
		if (null!=strData && !strData.trim().equals(EMPTY_STRING)) {
			isValid = true;
		}
		return isValid;
		
	}
	/**
	 * @param msgKey
	 * @return String
	 * @throws Exception
	 */
	public String getPropertyValue(String msgKey) throws MaterialsException{
		String msgVal = EMPTY_STRING;
		if(isNotNullandEmpty(msgKey)){
			msgVal = getPropertyValue(msgKey,ERR_MESSAGE_RB);
		}
		return msgVal;
	}
	/**
	 * @param msgKey
	 * @param propertyFile
	 * @return String
	 * @throws Exception
	 */
	public String getPropertyValue(String msgKey,String propertyFile) throws MaterialsException {
		String msgVal = "Property entry not found for the key '"+msgKey+"'";
		ResourceBundle rb = null;
		try {
			rb = ResourceBundle.getBundle(propertyFile);
			if(isNotNullandEmpty(msgKey)){
				msgVal = rb.getString(msgKey);
			}
		}
		catch (MissingResourceException mre) {
			log.info(mre);
			throw new MaterialsException(MaterialsErrorCodes.ERROR_8400,getErrorMessage(UNKNOWN_ERROR), msgVal);
		}
		return msgVal;
	}

}
