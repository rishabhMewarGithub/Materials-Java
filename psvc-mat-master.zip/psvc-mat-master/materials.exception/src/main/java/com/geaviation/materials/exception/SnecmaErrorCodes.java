/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Feb 24, 2016
 * Description    :     SnecmaErrorCodes.java
 * 
 * History        :  	Mar 12, 2014                
        
                    
 **********************************************************/
package com.geaviation.materials.exception;

public class SnecmaErrorCodes {
	public static final int ERROR_8450 = 8450;
	public static final int ERROR_8451 = 8451;
	public static final int ERROR_8452 = 8452;
	public static final int ERROR_8453 = 8453;
	public static final int ERROR_8454 = 8454;
	public static final int ERROR_8455 = 8455;
    public static final int ERROR_8456 = 8456;
    public static final int ERROR_8457 = 8457;
    public static final int ERROR_8458 = 8458;
    public static final int ERROR_8459 = 8459;
    public static final int ERROR_8460 = 8460;
    public static final int ERROR_8461 = 8461;
    public static final int ERROR_8462 = 8462;
    public static final int ERROR_8463 = 8463;
    public static final int ERROR_8464 = 8464;
}
