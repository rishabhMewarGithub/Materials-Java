package com.geaviation.materials.exception;

import com.geaviation.dss.service.common.exception.BaseException;

public class MaterialsException extends BaseException {
	
	private static final long serialVersionUID = -3034099437618664771L;

	private String descMsg;
	
	public MaterialsException(int errorCode) {
		super(errorCode);
	}
	
	public MaterialsException(int errorCode, String message){
		super(errorCode,message);
	}
	
	public MaterialsException(int errorCode, String message, Throwable cause) {
		super(errorCode, message, cause);
	}
	
	public MaterialsException(int errorCode, String message, String descMsg) {
		super(errorCode, message);
		this.descMsg = descMsg;
	}
	
	public String getDescMsg() {
		return descMsg;
	}
}
