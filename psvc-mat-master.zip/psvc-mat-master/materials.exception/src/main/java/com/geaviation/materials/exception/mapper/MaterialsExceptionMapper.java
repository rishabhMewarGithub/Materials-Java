
package com.geaviation.materials.exception.mapper;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

import com.geaviation.materials.exception.MaterialsErrorCodes;
import com.geaviation.materials.exception.MaterialsException;
import com.geaviation.materials.exception.fault.MaterialsFault;

@Service
public class MaterialsExceptionMapper implements ExceptionMapper<MaterialsException> {

	private static final Log log = LogFactory.getLog(MaterialsExceptionMapper.class);
	private String EMPTY_STRING = "";
	@Override
	public Response toResponse(MaterialsException materialsException) {
		String type = "Bad Request";
		String errMsg = EMPTY_STRING;
		String descMsg = EMPTY_STRING;
		int errorCd = materialsException.getErrorCode();
		Status httpStatus = Status.BAD_REQUEST; 
		errMsg = materialsException.getMessage();
		descMsg = materialsException.getDescMsg().trim();
		
		List<Integer> errorcodeList = new ArrayList<>();
		errorcodeList.add(MaterialsErrorCodes.ERROR_8001);
		errorcodeList.add(MaterialsErrorCodes.ERROR_8002);
		errorcodeList.add(MaterialsErrorCodes.ERROR_8004);
		errorcodeList.add(MaterialsErrorCodes.ERROR_8005);
		errorcodeList.add(MaterialsErrorCodes.ERROR_8006);
		errorcodeList.add(MaterialsErrorCodes.ERROR_8007);
		errorcodeList.add(MaterialsErrorCodes.ERROR_8008);
		errorcodeList.add(MaterialsErrorCodes.ERROR_8009);
		errorcodeList.add(MaterialsErrorCodes.ERROR_8303);
		errorcodeList.add(MaterialsErrorCodes.ERROR_8304);
		errorcodeList.add(MaterialsErrorCodes.ERROR_8331);
		errorcodeList.add(MaterialsErrorCodes.ERROR_8056);
		errorcodeList.add(MaterialsErrorCodes.ERROR_8464);
		errorcodeList.add(MaterialsErrorCodes.ERROR_8277);
	
		if(errorCd == MaterialsErrorCodes.ERROR_8476 || errorCd == MaterialsErrorCodes.ERROR_8477 || 
				errorCd == MaterialsErrorCodes.ERROR_8478 || errorCd == MaterialsErrorCodes.ERROR_8479 || errorCd == MaterialsErrorCodes.ERROR_8454){
			type = "Internal Server Error";
			httpStatus = Status.INTERNAL_SERVER_ERROR;
			log.error("MaterialsErrorLog: "+ errorCd +": "+descMsg);
		}
		if(errorcodeList.contains(errorCd))
		{
			type = "Forbidden";
			httpStatus = Status.FORBIDDEN;
			log.info("MaterialsInfoLog: "+ errorCd +": "+descMsg);
		}
 
		else if(errorCd == MaterialsErrorCodes.ERROR_8301 || errorCd == MaterialsErrorCodes.ERROR_8302 ||
				errorCd == MaterialsErrorCodes.ERROR_8330)

		{
			type = "Unauthorized";
			httpStatus = Status.UNAUTHORIZED;
			log.info("MaterialsInfoLog: "+ errorCd +": "+descMsg);
		}


		//for cfm MYJIRATEST-13088 fix - start
		else if(errorCd == 403 || errorCd == 500 || errorCd == 503 ){
			if(errorCd == 403)
			{
				httpStatus = Status.FORBIDDEN;
			}
			if(errorCd == 500)
			{
				httpStatus = Status.INTERNAL_SERVER_ERROR;
			}
			if(errorCd == 503)
			{
				httpStatus = Status.SERVICE_UNAVAILABLE;
			}
			return Response.status(httpStatus).entity(errMsg).build();
		}
		else{
			log.warn("MaterialsWarningLog: "+ errorCd +": "+descMsg);
		}
		
		
		
		MaterialsFault fault = new MaterialsFault(errorCd, errMsg, EMPTY_STRING, type, descMsg);
		return Response.status(httpStatus).entity(fault).build();
	}

}
