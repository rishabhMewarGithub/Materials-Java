/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 12, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     IMaterialsDAO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.data.api;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.entity.MaterialsUserAccess;
import com.geaviation.materials.entity.MaterialsUserBO;





public interface IMaterialsLoginDAO {
	
	/**
	 * Returns Operating Unit Id for the given Portal Id
	 * 
	 * @param portalId 		valid portal id. can not be NULL.
	 * @return opUid		operating unit id. 
	 * @throws TechnicalException
	 */
	public String getPortalOUDS(String portalId, boolean multipleOUID) throws TechnicalException;
		
	/**
	 * Returns user access details as MaterialsUserAccess object for the given user.
	 * The returned MaterialsUserAccess object will have success and message fields.
	 * 
	 * @param strSSO					valid user SSO. can not be NULL.
	 * @param icaoCd					valid icao. can not be NULL.
	 * @param opUid						valid operating unit id. can not be NULL. 
	 * @return	MaterialsUserAccess		MaterialsUserAccess object
	 * @throws TechnicalException
	 */
	public MaterialsUserAccess isHavingAccessDS(String strSSO, String icaoCd, String opUid)throws TechnicalException;
	
	
	/**
	 * Returns login details as MaterialsUserBO object for the given user.
	 * The returned MaterialsUserBO object will have user role and Customer object
	 * The MaterialsUserBO contains the following fields  
	*  role
	*  CustomerBO
	*  
	*  
	 * @param strSSO   				valid user SSO. can not be NULL.
	 * @param icaoCd				valid icao. can not be NULL.
	 * @param opUid   				valid operating unit id. can not be NULL. 
	 * @param impersonator			valid impersonator. can not be NULL. 
	 * @return MaterialsUserBO		MaterialsUserBO object
	 * @throws TechnicalException	
	 */
	public MaterialsUserBO requestLoginDS(String strSSO, String icaoCd, String opUid, String impersonator) throws TechnicalException;
	/**
	 * Returns repair login details as MaterialsUserBO object for the given user.
	 * The returned MaterialsUserBO object will have user role and Customer object
	 * The MaterialsUserBO contains the following fields  
	*  role
	*  CustomerBO
	*  
	*  
	 * @param strSSO   				valid user SSO. can not be NULL.
	 * @param icaoCd				valid icao. can not be NULL.
	 * @param opUid   				valid operating unit id. can not be NULL. 
	 * @param impersonator			valid impersonator. can not be NULL. 
	 * @return MaterialsUserBO		MaterialsUserBO object
	 * @throws TechnicalException	
	 */
	
	public MaterialsUserBO requestLoginRepairsDS(String sso, String icao,String opUid, String impersonator)throws TechnicalException;
	
}
