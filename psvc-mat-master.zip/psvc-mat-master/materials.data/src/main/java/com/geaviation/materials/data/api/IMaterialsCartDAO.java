/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	May 19, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     IMaterialsCartDAO.java
 * 
 * History        :  	May 19, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.data.api;

import java.util.List;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.entity.CartDO;
import com.geaviation.materials.entity.CustomerBO;
import com.geaviation.materials.entity.DeleteCartLineBO;
import com.geaviation.materials.entity.ItemDetailHeaderInputDO;
import com.geaviation.materials.entity.PurchasePODO;
import com.geaviation.materials.entity.SaveCartDetailsOutputDO;
import com.geaviation.materials.entity.SaveCartInputDO;
import com.geaviation.materials.entity.SaveCartOrderLineInputDO;
/**
 * @author 212589907
 *
 */
public interface IMaterialsCartDAO {
	
	public CartDO getCartDS(String strSSO, String icaoCode, List<CustomerBO> customerBOList,String role, String operatingUnitId,String portalId) throws TechnicalException;	
	/**
	 * Returns Cart details as SaveCartDetailsOutputDO JSON object for the given SaveCartRequest JSON.
	 * If sso or portalId input is null then it throws MaterialsException.
	 * The SaveCartDetailsOutputDO contains the following fields  
	*  cartHeaderId				denotes the cartHeaderId that is saved.
	*  statusMessage			denotes the message from the procedure.
	*  orderLineMessageBOList	denotes list of SaveCartOrderLineMessageBO		
	*  
	*  
	 * @param sso   				valid user SSO. can not be NULL.
	 * @param role					valid Role. can not be NULL. 
	 * @param icao   				valid ICAO. can not be NULL.
	 * @param custIdArray			valid Customer Ids. can not be NULL. 
	 * @param operatingUnitId   	valid operatingUnitId. can not be NULL.
	 * @param saveCartInputDOList
	 * @param saveCartOrderLineInputDOList 
	 * @return SaveCartResponse		SaveCartResponse object
	 * @throws TechnicalException	
	 */
	public SaveCartDetailsOutputDO saveCartDS(String sso, String role,	String icao, String[] custIdArray, String operatingUnitId, List<SaveCartInputDO> saveCartInputDOList,
			List<SaveCartOrderLineInputDO> saveCartOrderLineInputDOList, List<Boolean> esnValidFlagList, List<String> priorityList) throws TechnicalException;
	
	public String deleteCartDS(String strSSO,String  icaoCode,
			String[] custIdList, String role, String operatingUnitId) throws TechnicalException;
	
	public String[]  getCartCountDS(String strSSO,String  icaoCode,
			String[] custIdList, String role, String operatingUnitId) throws TechnicalException;
	public DeleteCartLineBO deleteCartLineDS(String sso,String icaoCode,String[] custIdList ,String role,String operatingUnitId,String cartHeaderId,String cartLineId)throws TechnicalException;
	public String   addLineItemDS(String strSSO,String icaoCode,String[] custIdList,String role,String operatingUnitId,String inventoryItemId,String selectedCustomerId,
		     String selectedSupplierCode,String quantity,String pricingListId, String quoteHeaderId)  throws TechnicalException;
	public PurchasePODO purchasePODS(String sso, String role,String icaoCode,String[] customerId ,String operatingUnitId,String cartHeaderId,List<ItemDetailHeaderInputDO> lstDetailHeaderInputDOs)throws TechnicalException;
}
