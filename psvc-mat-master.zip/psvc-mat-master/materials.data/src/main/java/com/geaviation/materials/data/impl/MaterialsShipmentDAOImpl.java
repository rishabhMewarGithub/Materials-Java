
package com.geaviation.materials.data.impl;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.data.api.IMaterialsShipmentDAO;
import com.geaviation.materials.data.impl.util.MaterialsDataConstants;
import com.geaviation.materials.data.impl.util.MaterialsDataUtil;
import com.geaviation.materials.data.impl.util.MaterialsQueryLoader;
import com.geaviation.materials.entity.CustLoginDetails;
import com.geaviation.materials.entity.DisputeOrderInput;
import com.geaviation.materials.entity.DisputeOrderStatusBO;
import com.geaviation.materials.entity.ReturnLabelDO;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
@Component
public class MaterialsShipmentDAOImpl implements IMaterialsShipmentDAO{
	
	private static final Log log = LogFactory.getLog(MaterialsShipmentDAOImpl.class);
	
	@Value("${QUERY_TIME_OUT_SECS}")
	private int queryTimeOutSecs;
	
	@Autowired
	@Qualifier("ampsOraDS")
	private DataSource ampsOraDS;

	@Autowired
	private MaterialsDataUtil materialsDataUtil;
	
	/**
	 * @param sso
	 * @param orderHeaderId
	 * @param custLoginDetails
	 * @return ReturnLabelDO object
	 */
	@Override
	public ReturnLabelDO getReturnLabelDetailDS(String sso, String orderHeaderId, CustLoginDetails custLoginDetails) {
		log.info("getReturnLabelDetailDS() method - START");
		Connection connection = null;
		String procStr = null;
		String pMessage = null;
		CallableStatement callStatement = null;
		ARRAY custArray = null;
		ArrayDescriptor custArrayDescriptor = null;
		ReturnLabelDO returnLabelDO = new ReturnLabelDO();
		try {
			connection = ampsOraDS.getConnection();
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_GET_LABEL_INFORMATION);
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
			oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null) {
				callStatement = oracleConnection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
				//Standard Inputs
				callStatement.setString(1, sso.toUpperCase());//P_SSO  VARCHAR2         
				callStatement.setString(2, custLoginDetails.getIcaoCode());//P_IACO_CODE   VARCHAR2    
				custArrayDescriptor = ArrayDescriptor.createDescriptor("APPS.V_CUST_ID_ARRAY",oracleConnection);
				custArray = new ARRAY(custArrayDescriptor, oracleConnection, custLoginDetails.getCustIdList());         
				callStatement.setArray(3, custArray);//P_CUST_ID   V_CUST_ID_ARRAY
				callStatement.setString(4, custLoginDetails.getRole());//P_ROLE   VARCHAR2
				callStatement.setString(5, custLoginDetails.getOperatingUnitId());//P_OU_ID  VARCHAR2
				//Input Parameters
				callStatement.setInt(6, Integer.parseInt(orderHeaderId));//P_ORDER_ID    NUMBER
				//Output Parameters
				callStatement.registerOutParameter(7, OracleTypes.VARCHAR);//P_RMA_NUMBER  NUMBER
				callStatement.registerOutParameter(8, OracleTypes.VARCHAR);//P_PO_NUMBER   VARCHAR2
				callStatement.registerOutParameter(9, OracleTypes.VARCHAR);//P_PART_NUMBER VARCHAR2
				callStatement.registerOutParameter(10, OracleTypes.VARCHAR);//P_QUANTITY   NUMBER
				callStatement.registerOutParameter(11, OracleTypes.VARCHAR);//P_REASON    VARCHAR2
				callStatement.registerOutParameter(12, OracleTypes.VARCHAR);//P_COO       VARCHAR2
				callStatement.registerOutParameter(13, OracleTypes.VARCHAR);//P_MSG       VARCHAR2
				callStatement.execute();
				//GET RESULTS
				pMessage = (String) callStatement.getObject(13);
				if(MaterialsDataUtil.isNotNullandEmpty(pMessage)){
					returnLabelDO.setpMessage(pMessage);
					log.info("getReturnLabelDetailDS() method returned pMessage - END");
					return returnLabelDO;
				}
				returnLabelDO.setRmaNumber(MaterialsDataUtil.getAsString(callStatement.getObject(7)));
				returnLabelDO.setPoNumber(MaterialsDataUtil.getAsString(callStatement.getObject(8)));
				returnLabelDO.setPartNumber(MaterialsDataUtil.getAsString(callStatement.getObject(9)));
				returnLabelDO.setQuantity(MaterialsDataUtil.getAsString(callStatement.getObject(10)));
				returnLabelDO.setReason(MaterialsDataUtil.getAsString(callStatement.getObject(11)));
				returnLabelDO.setCountryOfOrigin(MaterialsDataUtil.getAsString(callStatement.getObject(12)));
			}			
		}catch (Exception e) 
		{
			log.info(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}
		finally
		{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		log.info("getReturnLabelDetailDS() method - END");
		return returnLabelDO;
	}	

	@Override
	public DisputeOrderStatusBO createDisputeOrderDS(DisputeOrderInput disputeOrderInput) throws TechnicalException{
		log.info("Entered into createDisputeOrderDS() method");
		Connection connection = null;
		String procStr = null;
		String pMessage = null;
		CallableStatement callStatement = null;
		ARRAY custArray = null;
		ArrayDescriptor custArrayDescriptor = null;
		DisputeOrderStatusBO disputeOrderStatusBO = new DisputeOrderStatusBO();
		try {
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
			oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null) {
				procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_CREATE_DISPUTE_ORDER);
				callStatement = connection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
				//Standard Inputs
				callStatement.setString(1, disputeOrderInput.getSso().toUpperCase());
				callStatement.setString(2, disputeOrderInput.getIcao());
				custArrayDescriptor = ArrayDescriptor.createDescriptor("APPS.V_CUST_ID_ARRAY",oracleConnection);
				custArray = new ARRAY(custArrayDescriptor, oracleConnection, disputeOrderInput.getCustIdArray());
				callStatement.setArray(3, custArray);
				callStatement.setString(4, disputeOrderInput.getRole());
				callStatement.setString(5, disputeOrderInput.getOperatingUnitId());
				//Input Params
				callStatement.setInt(6, Integer.parseInt(disputeOrderInput.getOrderHeaderId()));//P_ORIG_ORDER_ID
				callStatement.setInt(7, Integer.parseInt(disputeOrderInput.getLineId()));//P_ORIG_LINE_ID
				callStatement.setString(8, disputeOrderInput.getDisputeReason());//P_DISPUTE
				callStatement.setString(9, disputeOrderInput.getSerialNumberSelectedSerialNumber());//P_SND_ATT_SNLST
				callStatement.setString(10, disputeOrderInput.getSerialNumberReceivedSerialNumber());//P_SND_ATT_RCLST
				//For Serial Number Attachment
				callStatement.setString(11,disputeOrderInput.getFileName());
				callStatement.setBytes(12,disputeOrderInput.getFileData());

				callStatement.setString(13, disputeOrderInput.getDiscrepancyPartNumberReceived());//P_DD_PN_RCVD
				callStatement.setString(14, disputeOrderInput.getDiscrepancyQuantityReceived());//P_DD_QTY_RCVD
				callStatement.setString(15, disputeOrderInput.getAddToCartFlagString());//P_REPLACE
				callStatement.setString(16, disputeOrderInput.getUnderShipmentQuantityReceived());//P_UD_QTY_RCVD
				callStatement.setString(17, disputeOrderInput.getOverShipmentQuantityReceived());//P_OD_QTY_RCVD
				callStatement.setString(18, disputeOrderInput.getBuyBackRequestedBy());//P_BB_REQ_BY
				callStatement.setString(19, disputeOrderInput.getBuyBackRequestedQuantity());//P_BB_QTY
				callStatement.setString(20, disputeOrderInput.getPricingErrorExpectedUnitPrice());//P_PE_EXP_PRICE
				callStatement.setString(21, disputeOrderInput.getDisputeComments());//P_ATT_COMMENTS
				//Output Parameters
				callStatement.registerOutParameter(22, OracleTypes.NUMBER);
				callStatement.registerOutParameter(23, OracleTypes.VARCHAR);
				callStatement.registerOutParameter(24, OracleTypes.VARCHAR);
				callStatement.registerOutParameter(25, OracleTypes.VARCHAR);
				callStatement.registerOutParameter(26, OracleTypes.VARCHAR);
				callStatement.registerOutParameter(27, OracleTypes.VARCHAR);
				callStatement.registerOutParameter(28, OracleTypes.NUMBER);
				callStatement.registerOutParameter(29, OracleTypes.NUMBER);
				callStatement.execute();
				//GET RESULTS
				BigDecimal orderNumber = (BigDecimal) callStatement.getObject(22);
				String orderType = (String)materialsDataUtil.encodeForJava(callStatement.getObject(23));
				pMessage =  (String) materialsDataUtil.encodeForJava(callStatement.getObject(24));
				String statusMessage =  (String) materialsDataUtil.encodeForJava(callStatement.getObject(25));
				String originalPONumber =  (String) materialsDataUtil.encodeForJava(callStatement.getObject(26));
				String originalPOLineNumber =  (String) materialsDataUtil.encodeForJava(callStatement.getObject(27));
				BigDecimal orderValue = (BigDecimal)callStatement.getObject(28);
				BigDecimal orderHeaderId = (BigDecimal) callStatement.getObject(29);
				
				log.info("createDisputeOrderDS(), pMessage--> "+pMessage);
				if(MaterialsDataUtil.isNotNullandEmpty(pMessage)){
					disputeOrderStatusBO.setpMessage(pMessage);
					log.info("createDisputeOrderDS() method returned at pMessage - END");
					return disputeOrderStatusBO;
				}
				//disputeOrderStatusBO.setSuccess(true);
				disputeOrderStatusBO.setDisputeOrderNumber(MaterialsDataUtil.getAsString(orderNumber));
				disputeOrderStatusBO.setScrapOrReturn(MaterialsDataUtil.getAsString(orderType));
				disputeOrderStatusBO.setOrderValue(MaterialsDataUtil.getAsString(orderValue));
				disputeOrderStatusBO.setOriginalPONumber(MaterialsDataUtil.getAsString(originalPONumber));
				disputeOrderStatusBO.setOriginalPOLineNumber(MaterialsDataUtil.getAsString(originalPOLineNumber));
				disputeOrderStatusBO.setStatusMessage(MaterialsDataUtil.getAsString(statusMessage));
				disputeOrderStatusBO.setDisputeOrderHeaderId(MaterialsDataUtil.getAsString(orderHeaderId));
			}			
		}catch (Exception e) 
		{
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}
		finally
		{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		log.info("createDisputeOrderDS() method - END");
		return disputeOrderStatusBO;
	}
	
}
