package com.geaviation.materials.data.impl;

import static com.geaviation.materials.data.impl.util.MaterialsDataUtil.getAsString;

import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Struct;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.data.api.IMaterialsCartDAO;
import com.geaviation.materials.data.impl.util.MaterialsDataConstants;
import com.geaviation.materials.data.impl.util.MaterialsDataUtil;
import com.geaviation.materials.data.impl.util.MaterialsQueryLoader;
import com.geaviation.materials.entity.CartDO;
import com.geaviation.materials.entity.CartHDRInfoDO;
import com.geaviation.materials.entity.CartMessageDO;
import com.geaviation.materials.entity.CustomerBO;
import com.geaviation.materials.entity.DeleteCartLineBO;
import com.geaviation.materials.entity.ItemDetailHeaderInputDO;
import com.geaviation.materials.entity.LineMessageDO;
import com.geaviation.materials.entity.PartDO;
import com.geaviation.materials.entity.PurchasePODO;
import com.geaviation.materials.entity.SaveCartDetailsOutputDO;
import com.geaviation.materials.entity.SaveCartInputDO;
import com.geaviation.materials.entity.SaveCartLineMessageOutputDO;
import com.geaviation.materials.entity.SaveCartMessageOutputDO;
import com.geaviation.materials.entity.SaveCartOrderLineInputDO;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

@Component
@Configuration
public class MaterialsCartDAOImpl implements IMaterialsCartDAO {
	
	private static final Log log = LogFactory.getLog(MaterialsCartDAOImpl.class);
	@Autowired
	private DataSource ampsOraDS;
	
	@Value("${PORTAL_TO_REQUESTED_DAYS_TO_ADD}")
	private String requestedDaysToAdd;
	
	@Autowired
	private MaterialsDataUtil materialsDataUtil;
	
	@Value("${QUERY_TIME_OUT_SECS}")
	private int queryTimeOutSecs;

	final static String APPSVCUSTIDARRAY = "APPS.V_CUST_ID_ARRAY";

	@Override
	public CartDO getCartDS(String strSSO, String icaoCode, List<CustomerBO> customerBOList,String role, String operatingUnitId,String portalId) throws TechnicalException{
		
		String procStr  = null;
		String[] custIds=null;
		String pMsg = null;
		String pPOTotal  = null;
		CartDO cartDO = null;
		Connection connection = null;
		CallableStatement callStatement = null;
		ArrayDescriptor descrip  = null;
		ARRAY custArray = null;
		Array cartHearerDetails  = null;
		Array cartHearerLineDetails = null;
		try {

			if(customerBOList != null && !customerBOList.isEmpty())
			{
				/*custIds = new String[customerBOList.size()];
				int customerCount = 0;
				for ( ;customerCount<customerBOList.size();customerCount++) {
					customerBO = customerBOList.get(customerCount);
					if(customerBO.getCustId() != null && ! customerBO.getCustId().isEmpty())
					custIds[customerCount]  = customerBO.getCustId();	
				}*/
				custIds = getCustIds(customerBOList);
			}
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_GET_CART);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null) {
				descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
			    custArray = new ARRAY(descrip,oracleConnection,custIds);
			    
				callStatement = oracleConnection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
				callStatement.setString(1, strSSO.toUpperCase());
				callStatement.setString(2, role);
				callStatement.setString(3, icaoCode);
				callStatement.setArray(4, custArray);
				callStatement.setString(5, operatingUnitId);
				callStatement.registerOutParameter(6, OracleTypes.ARRAY, "APPS.V_QUOTE_HEADER_ARRAY");
				callStatement.registerOutParameter(7, OracleTypes.ARRAY, "APPS.V_QUOTE_LINE_ARRAY");
				callStatement.registerOutParameter(8, OracleTypes.VARCHAR);
				callStatement.registerOutParameter(9, OracleTypes.VARCHAR);
				callStatement.execute();
				pMsg = (String) callStatement.getObject(8);
				cartDO = new CartDO();
				if(MaterialsDataUtil.isNotNullandEmpty(pMsg)){
					cartDO.setP_msg(pMsg);
					return cartDO;
				}
				pPOTotal = (String) callStatement.getObject(9);
				cartHearerDetails =  callStatement.getArray(6);
				cartDO = populateCartHDRDetailsValues(cartHearerDetails,cartDO,portalId);
				cartHearerLineDetails =  callStatement.getArray(7);
				cartDO = populateCartHDRLineDetailsValues(cartHearerLineDetails,cartDO);
				if(MaterialsDataUtil.isNotNullandEmpty(pPOTotal)){
					cartDO.setPo_total(pPOTotal);
				}
		    }
		    
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return cartDO;
	}
	
	private String[] getCustIds(List<CustomerBO> customerBOList) {
		String[] custIds = new String[customerBOList.size()];
		int customerCount = 0;
		CustomerBO customerBO = null;
		for ( ;customerCount<customerBOList.size();customerCount++) {
			customerBO = customerBOList.get(customerCount);
			if(customerBO.getCustId() != null && ! customerBO.getCustId().isEmpty())
			custIds[customerCount]  = customerBO.getCustId();	
		}
		return custIds;
	}
	
	@Override
	public SaveCartDetailsOutputDO saveCartDS(String sso, String role,	String icao, String[] custIdArray, String operatingUnitId, List<SaveCartInputDO> saveCartInputDOList,
			List<SaveCartOrderLineInputDO> saveCartOrderLineInputDOList, List<Boolean> esnValidFlagList, List<String> priorityList) throws TechnicalException{
			SaveCartDetailsOutputDO saveCartDetailsOutputDO = null;
			Connection connection = null;
			//Connection deligatingConnection = null;
			String procStr = null;
			String pMessage = null;
			ARRAY custArray = null;
			ARRAY cartHeaderArray = null;
			ARRAY cartLineArray = null;
			Array cartDetailsOut  = null;
			Array cartLineDetailsOut = null;
			ArrayDescriptor custArrayDescriptor = null;
			ArrayDescriptor cartHeaderArrayDescriptor = null;
			ArrayDescriptor cartLineArrayDescriptor = null;
			CallableStatement callStatement = null;
			try {
				connection = ampsOraDS.getConnection();
				OracleConnection oracleConnection = null;
				if (connection.isWrapperFor(OracleConnection.class)) {
					oracleConnection = connection.unwrap(OracleConnection.class);
				}
				procStr = MaterialsQueryLoader
						.getQuery(MaterialsDataConstants.SP_SAVE_CART);
				if(oracleConnection != null) {
					callStatement = oracleConnection.prepareCall(procStr);
					callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
					callStatement.setString(1, sso.toUpperCase());
					callStatement.setString(2, role);
					callStatement.setString(3, icao);
					
					custArrayDescriptor = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection);
					custArray = new ARRAY(custArrayDescriptor, oracleConnection, custIdArray);
					callStatement.setArray(4, custArray);
					callStatement.setString(5, operatingUnitId);
					
					cartHeaderArrayDescriptor = ArrayDescriptor.createDescriptor("APPS.V_QUOTE_HEADER_DTL_ARRAY",oracleConnection);
					SaveCartInputDO [] saveCartInputDOArr = saveCartInputDOList.toArray(new SaveCartInputDO[saveCartInputDOList.size()]);
					Object[] cartHeaderArrayObj = saveCartInputDOArr;
					cartHeaderArray = new ARRAY(cartHeaderArrayDescriptor, oracleConnection, cartHeaderArrayObj);
					callStatement.setObject(6, (Object)cartHeaderArray);
					
					cartLineArrayDescriptor = ArrayDescriptor.createDescriptor("APPS.V_QUOTE_LINE_DTL_ARRAY",oracleConnection);
					SaveCartOrderLineInputDO [] saveCartOrderLineInputDOArr = saveCartOrderLineInputDOList.toArray(new SaveCartOrderLineInputDO[saveCartOrderLineInputDOList.size()]);
					Object[] cartLineArrayObj = saveCartOrderLineInputDOArr;
					cartLineArray = new ARRAY(cartLineArrayDescriptor, oracleConnection, cartLineArrayObj);
					callStatement.setObject(7, (Object)cartLineArray);
					
					//OUT parameter
					callStatement.registerOutParameter(8, OracleTypes.ARRAY, "APPS.V_QT_HDR_STS_DTL_ARRAY");
					callStatement.registerOutParameter(9, OracleTypes.ARRAY, "APPS.V_QT_LINE_STS_DTL_ARRAY");
					callStatement.registerOutParameter(10, OracleTypes.VARCHAR);
					callStatement.execute();
					pMessage = (String) callStatement.getObject(10);
					saveCartDetailsOutputDO = new SaveCartDetailsOutputDO();
					if (MaterialsDataUtil.isNotNullandEmpty(pMessage)) {
						saveCartDetailsOutputDO.setProcMessage(pMessage);
						return saveCartDetailsOutputDO;
					}
					cartDetailsOut =  callStatement.getArray(8);
					saveCartDetailsOutputDO = populateSaveCartDetails(cartDetailsOut,saveCartDetailsOutputDO);
					cartLineDetailsOut =  callStatement.getArray(9);
					saveCartDetailsOutputDO = populateSaveCartLineDetails(cartLineDetailsOut,saveCartDetailsOutputDO, esnValidFlagList, priorityList);
				}
				
			} catch (Exception e) {
				log.info(e);
				throw new TechnicalException(e.getMessage(),e.getCause());
			}finally{
				materialsDataUtil.releaseResources(connection, callStatement, null);
			}
			return saveCartDetailsOutputDO;
	}


	@Override
	public String deleteCartDS(String strSSO,String  icaoCode,
	String[] custIdList, String role, String operatingUnitId) throws TechnicalException {
		String message=null;
		Connection connection = null;
		CallableStatement callStatement = null;
		//Connection delConnection = null;
		
		try{
			String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_DELETE_CART);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null) {
				ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
				ARRAY custArray = new ARRAY(descrip,oracleConnection,custIdList);
				callStatement = oracleConnection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
				callStatement.setString(1, strSSO.toUpperCase());
				callStatement.setString(2, role);
				callStatement.setString(3, icaoCode);
				callStatement.setArray(4,custArray);
				callStatement.setString(5,operatingUnitId);
	            callStatement.registerOutParameter(6, OracleTypes.VARCHAR);
	        	callStatement.execute();
			 message =(String) callStatement.getObject(6);
			}			
	}catch (Exception e) {
		log.info(e);
		throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		   return message;
	}

	
	@Override
	public String[]  getCartCountDS(String strSSO,String  icaoCode,
	String[] custIdList, String role, String operatingUnitId) throws TechnicalException {
		Connection connection = null;
		CallableStatement callStatement = null;
		//Connection delConnection = null;
		String[] cartCountValues=null;
		try{
	
			String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_GET_CART_COUNT);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null) {
				ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
				ARRAY custArray = new ARRAY(descrip,oracleConnection,custIdList);
				callStatement = oracleConnection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
				callStatement.setString(1, strSSO.toUpperCase());
				callStatement.setString(2, role);
				callStatement.setString(3, icaoCode);
				callStatement.setArray(4,custArray);
				callStatement.setString(5, operatingUnitId);
	            callStatement.registerOutParameter(6, OracleTypes.BIGINT);
	            callStatement.registerOutParameter(7, OracleTypes.VARCHAR);
	        	callStatement.execute();
				String message =(String) callStatement.getObject(7);
			    cartCountValues = new String[2];
				if(MaterialsDataUtil.isNotNullandEmpty(message)){
					cartCountValues[0]=message;
					cartCountValues[1]="";
		            return cartCountValues;
		           }
				String itemCount =callStatement.getObject(6).toString();
				cartCountValues[0]="";
				cartCountValues[1]=itemCount;
			}			
		}catch (Exception e) {
			log.info(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
			}finally{
				materialsDataUtil.releaseResources(connection, callStatement, null);
			}
		return cartCountValues;
	}

	@Override
	public DeleteCartLineBO deleteCartLineDS(String strSSO,String icaoCode,String[] custIdList ,String role,String operatingUnitId,String cartHeaderId,String cartLineId)throws TechnicalException {
		String procStr  = null;
		Connection connection = null;
		//Connection delConnection = null;
		CallableStatement callStatement = null;
		DeleteCartLineBO deleteCartLineBO=null;
		try {
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_DELETE_CART_LINE);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null) {
				ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
				ARRAY custArray = new ARRAY(descrip,oracleConnection,custIdList);
				callStatement = oracleConnection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
				callStatement.setString(1, strSSO.toUpperCase());
				callStatement.setString(2, role);
				callStatement.setString(3, icaoCode);
				callStatement.setArray(4, custArray);
				callStatement.setString(5, operatingUnitId);
				callStatement.setInt(6, Integer.parseInt(cartHeaderId));
				callStatement.setInt(7, Integer.parseInt(cartLineId));
				callStatement.registerOutParameter(8, OracleTypes.VARCHAR);
				callStatement.execute();
				String message = (String) callStatement.getObject(8);
				deleteCartLineBO= new DeleteCartLineBO();
				if(MaterialsDataUtil.isNotNullandEmpty(message)){
					deleteCartLineBO.setP_msg(message);
				}
				else
				{

					deleteCartLineBO.setSuccess(true);	
				}
			}			
		}catch (Exception e) {
			log.info(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return deleteCartLineBO;	
	}


	private CartDO populateCartHDRLineDetailsValues(Array array,CartDO cartDO) {
		PartDO partDO = null;
		List<PartDO> lstPartDO = new ArrayList<PartDO>();
		try {
			if (null != array) {
				Object[] returnRecordArray = (Object[]) array.getArray();
				int cartHRDCount = 0;
				for (;cartHRDCount < returnRecordArray.length; cartHRDCount++) {
					Struct struct = (Struct) returnRecordArray[cartHRDCount];
					Object[] obj = struct.getAttributes();
					partDO = new PartDO();
					partDO.setCartHeaderId(getAsString(obj[0]));
					partDO.setCartLineId(getAsString(obj[1]));
					partDO.setPartNumber(getAsString(obj[2]));
					partDO.setPartDescription(getAsString(obj[3]));
					partDO.setQuantity(getAsString(obj[4]));
					partDO.setUpq(getAsString(obj[5]));
					partDO.setLeadTime(getAsString(obj[6]));
					partDO.setUnitPrice(getAsString(obj[7]));
					partDO.setExtendedPrice(getAsString(obj[8]));
					partDO.setInventoryItemId(getAsString(obj[9]));
					partDO.setCustomerPurchaseOrderLineNumber(getAsString(obj[10]));
					partDO.setOrderLinePriority(getAsString(obj[11]));
					partDO.setOrderLineRequestedDate(materialsDataUtil.convertDate(getAsString(obj[12])));					
					partDO.setDiscountPrice(getAsString(obj[13]));
					partDO.setNetPrice(getAsString(obj[14]));
					partDO.setKitIndicator(getAsString(obj[15]));
					partDO.setOrderLineESN(getAsString(obj[16]));
					
					// Work Stop
					partDO.setOrderLineWorkStopDate(materialsDataUtil.convertDate(getAsString(obj[17])));
					partDO.setOrderLineWorkStopQuantity(getAsString(obj[18]));
					
					lstPartDO.add(partDO);
				}
			}
			cartDO.setPartDO(lstPartDO);
		} catch (Exception e) {
			log.info(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return cartDO;
	}
	private CartDO populateCartHDRDetailsValues(Array array,CartDO cartDO,String portalId) {
		CartHDRInfoDO cartHDRInfoDO = null;
		List<CartHDRInfoDO> lstcartHDRInfoDO = new ArrayList<CartHDRInfoDO>();
		try {
			if (null != array) {
				Object[] returnRecordArray = (Object[]) array.getArray();
				int cartLineHRDCount = 0;
				for (; cartLineHRDCount < returnRecordArray.length;cartLineHRDCount++) {
					Struct struct = (Struct) returnRecordArray[cartLineHRDCount];
					Object[] obj = struct.getAttributes();
					cartHDRInfoDO = new CartHDRInfoDO();
					cartHDRInfoDO.setCartHeaderId(getAsString(obj[0]));
					cartHDRInfoDO.setPurchaseOrderNumber(getAsString(obj[1]));
					cartHDRInfoDO.setRequestedDaysToAdd(getAsString(materialsDataUtil.getPortalRequestedDaysToAdd( requestedDaysToAdd, portalId.toUpperCase())));
					cartHDRInfoDO.setCustomerId(getAsString(obj[3]));
					cartHDRInfoDO.setCustomerCode(getAsString(obj[4]));
					cartHDRInfoDO.setSupplierCode(getAsString(obj[5]));
					cartHDRInfoDO.setPurchaseOrderValue(getAsString(obj[7]));
					cartHDRInfoDO.setSupplierDescription(getAsString(obj[8]));
					cartHDRInfoDO.setOrderHeaderDate(materialsDataUtil.convertDate(getAsString(obj[9])));
					cartHDRInfoDO.setOrderPriority(getAsString(obj[10]));					
					lstcartHDRInfoDO.add(cartHDRInfoDO);					
				}
			}
			cartDO.setCartDO(lstcartHDRInfoDO);
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return cartDO;
	}
	private SaveCartDetailsOutputDO populateSaveCartDetails(Array array, SaveCartDetailsOutputDO saveCartDetailsOutputDO) {
		SaveCartMessageOutputDO cartMessageDO = null;
		List<SaveCartMessageOutputDO> cartMessageDOList = new ArrayList<SaveCartMessageOutputDO>();
		try {
			if (null != array) {
				Object[] returnRecordArray = (Object[]) array.getArray();
				int cartLineHRDCount = 0;
				for (; cartLineHRDCount < returnRecordArray.length;cartLineHRDCount++) {
					Struct struct = (Struct) returnRecordArray[cartLineHRDCount];
					Object[] obj = struct.getAttributes();
					cartMessageDO = new SaveCartMessageOutputDO();
					cartMessageDO.setCartHeaderId(getAsString(obj[0]));
					cartMessageDO.setStatusMessage(getAsString(obj[1]));
					cartMessageDOList.add(cartMessageDO);	
				}
			}
			saveCartDetailsOutputDO.setSaveCartDOList(cartMessageDOList);
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return saveCartDetailsOutputDO;
	}

	private SaveCartDetailsOutputDO populateSaveCartLineDetails(Array array,
			SaveCartDetailsOutputDO saveCartDetailsOutputDO, List<Boolean> esnValidFlagList,
			List<String> priorityList) {
		SaveCartLineMessageOutputDO lineMessageDO = null;
		List<SaveCartLineMessageOutputDO> lineMessageDOList = new ArrayList<SaveCartLineMessageOutputDO>();
		try {
			if (null != array) {
				Object[] returnRecordArray = (Object[]) array.getArray();
				int cartLineHRDCount = 0;
				for (; cartLineHRDCount < returnRecordArray.length; cartLineHRDCount++) {
					Struct struct = (Struct) returnRecordArray[cartLineHRDCount];
					Object[] obj = struct.getAttributes();
					lineMessageDO = new SaveCartLineMessageOutputDO();
					lineMessageDO.setCartHeaderId(getAsString(obj[0]));
					lineMessageDO.setCartLineId(getAsString(obj[1]));

					if (MaterialsDataConstants.NORMAL.equalsIgnoreCase(priorityList.get(cartLineHRDCount))
							&& !esnValidFlagList.get(cartLineHRDCount)) {
						lineMessageDO.setEsnValidFlag(MaterialsDataConstants.N);
						lineMessageDO.setEsnStatusMsg(MaterialsDataConstants.ESN_STATUS_MSG_UPDATE);
						lineMessageDO.setStatusMessage(MaterialsDataConstants.ESN_STATUS_MSG_UPDATE);
					} else if (MaterialsDataConstants.WORK_STOP.equalsIgnoreCase(priorityList.get(cartLineHRDCount))
							&& !esnValidFlagList.get(cartLineHRDCount)) {
						lineMessageDO.setEsnValidFlag(MaterialsDataConstants.N);
						lineMessageDO.setEsnStatusMsg(MaterialsDataConstants.WORK_STOP_ESN_MSG);
						lineMessageDO.setStatusMessage(MaterialsDataConstants.WORK_STOP_ESN_MSG);
					} else {
						lineMessageDO.setStatusMessage(getAsString(obj[2]));
						lineMessageDO.setEsnValidFlag(getAsString(obj[4]));
						lineMessageDO.setEsnStatusMsg(getAsString(obj[5]));
					}
					lineMessageDOList.add(lineMessageDO);
				}
			}
			saveCartDetailsOutputDO.setSaveCartOrderLineDOList(lineMessageDOList);
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return saveCartDetailsOutputDO;
	}

	@Override
	public String   addLineItemDS(String strSSO,String icaoCode,String[] custIdList,String role,String operatingUnitid,String inventoryItemId,String selectedCustomerId,
            String selectedSupplierCode,String quantity,String pricingListId, String quoteHeaderId)  throws TechnicalException {
       Connection connection = null;
       CallableStatement callStatement = null;
       String message = null;
       OracleConnection oracleConnection = null;
       try{

              String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_ADD_CART_LINE);
              connection = ampsOraDS.getConnection();
              if (connection.isWrapperFor(OracleConnection.class)) {
              oracleConnection = connection.unwrap(OracleConnection.class);
              }
              if(oracleConnection != null) {
            	  ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
                  ARRAY custArray = new ARRAY(descrip,oracleConnection,custIdList);
                  callStatement = oracleConnection.prepareCall(procStr);
                  callStatement.setQueryTimeout(queryTimeOutSecs); //Refer config file for # of secs
                  callStatement.setString(1, strSSO.toUpperCase());
                  callStatement.setString(2, role);
                  callStatement.setString(3, icaoCode);
                  callStatement.setArray(4,custArray);
                  callStatement.setString(5, operatingUnitid);
           
                  /*if(!MaterialsDataUtil.isNotNullandEmpty(callStatement)){
                        callStatement.setNull(6, Types.INTEGER);
                  }
                  else{
                        int inventoryItemIdInt = Integer.parseInt(inventoryItemId);
                        callStatement.setInt(6, inventoryItemIdInt);
                  }
                  
                  if(!MaterialsDataUtil.isNotNullandEmpty(selectedCustomerId)){
                        callStatement.setNull(7, Types.INTEGER);
                  }
                  else{
                        int selectedCustomerIdInt = Integer.parseInt(selectedCustomerId);
                        callStatement.setInt(7, selectedCustomerIdInt);
                  }*/
                  
                  getItemIdCustomerId(callStatement, inventoryItemId,selectedCustomerId);
                  callStatement.setString(8,selectedSupplierCode);
                  
                  /*if(!MaterialsDataUtil.isNotNullandEmpty(quantity)){
                        callStatement.setNull(9, Types.INTEGER);
                  }
                  else{
                        int quantityInt = Integer.parseInt(quantity);
                        callStatement.setInt(9, quantityInt);
                  }
                  
                  if(!MaterialsDataUtil.isNotNullandEmpty(pricingListId)){
                        callStatement.setNull(10, Types.INTEGER);
                  }
                  else{
                        int pricingListIdInt = Integer.parseInt(pricingListId);
                        callStatement.setInt(10, pricingListIdInt);
                  }
                  
                  if(!MaterialsDataUtil.isNotNullandEmpty(quoteHeaderId)){
                        callStatement.setNull(11, Types.INTEGER);
                  }
                  else{
                        int quoteHeaderIdInt = Integer.parseInt(quoteHeaderId);
                        callStatement.setInt(11, quoteHeaderIdInt);
                  }*/
                  
                  getQuantityPriceListIdHeaderId(callStatement, quantity, pricingListId, quoteHeaderId);
                  callStatement.registerOutParameter(12, OracleTypes.VARCHAR);
                  callStatement.execute();
                  message =(String) callStatement.getObject(12);  
              }
              
              }catch (Exception e) {
                    log.info(e);
                    throw new TechnicalException(e.getMessage(),e.getCause());
                    }finally{
                    	materialsDataUtil.releaseResources(connection, callStatement, null);
                    }
                       return message;
              }

	private void getItemIdCustomerId (CallableStatement callStatement, String inventoryItemId, String selectedCustomerId) throws SQLException {
		if(!MaterialsDataUtil.isNotNullandEmpty(inventoryItemId)){
            callStatement.setNull(6, Types.INTEGER);
      }
      else{
            int inventoryItemIdInt = Integer.parseInt(inventoryItemId);
            callStatement.setInt(6, inventoryItemIdInt);
      }
      
      if(!MaterialsDataUtil.isNotNullandEmpty(selectedCustomerId)){
            callStatement.setNull(7, Types.INTEGER);
      }
      else{
            int selectedCustomerIdInt = Integer.parseInt(selectedCustomerId);
            callStatement.setInt(7, selectedCustomerIdInt);
      }
	}
	
	
	private void getQuantityPriceListIdHeaderId (CallableStatement callStatement, String quantity, String pricingListId, String quoteHeaderId) throws SQLException {
		if(!MaterialsDataUtil.isNotNullandEmpty(quantity)){
            callStatement.setNull(9, Types.INTEGER);
      }
      else{
            int quantityInt = Integer.parseInt(quantity);
            callStatement.setInt(9, quantityInt);
      }
      
      if(!MaterialsDataUtil.isNotNullandEmpty(pricingListId)){
            callStatement.setNull(10, Types.INTEGER);
      }
      else{
            int pricingListIdInt = Integer.parseInt(pricingListId);
            callStatement.setInt(10, pricingListIdInt);
      }
      
      if(!MaterialsDataUtil.isNotNullandEmpty(quoteHeaderId)){
            callStatement.setNull(11, Types.INTEGER);
      }
      else{
            int quoteHeaderIdInt = Integer.parseInt(quoteHeaderId);
            callStatement.setInt(11, quoteHeaderIdInt);
      }
	}
	
	@Override
    public PurchasePODO purchasePODS(String strSSO,String role,String icaoCode,String[] custIdList ,String operatingUnitId,String cartHeaderId,List<ItemDetailHeaderInputDO> lstDetailHeaderInputDOs)throws TechnicalException {
           String message;
           String procStr = null;
           String[] cartHeaderIds=null;
           Connection connection = null;
           CallableStatement callStatement = null;
           PurchasePODO purchasePODO = null;
           Array cart_Messages_Details  = null;
           Array cartMessagesLineDetails = null;
           ArrayList<String> cartHeaderIdList = null;
           ARRAY custArray = null;
           ARRAY headerArray = null;
           ArrayDescriptor descrip = null;
           ArrayDescriptor headerArrayDescriptor = null;
           
           try {
                  purchasePODO = new PurchasePODO();
               cartHeaderIdList = new ArrayList<String>(
                               Arrays.asList(cartHeaderId.split("\\|")));
                  if(cartHeaderIdList != null && !cartHeaderIdList.isEmpty())
                  {
                        cartHeaderIds = new String[cartHeaderIdList.size()];
                        int customerCount = 0;
                        for ( ;customerCount<cartHeaderIdList.size();customerCount++) {

                               cartHeaderIds[customerCount]  = cartHeaderIdList.get(customerCount) ;       
                        }
                  }
                  procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_PURCHASE_PO);
                  connection = ampsOraDS.getConnection();
                  
                  OracleConnection oracleConnection = null;
                          if (connection.isWrapperFor(OracleConnection.class)) {
                                 oracleConnection = connection.unwrap(OracleConnection.class);
                          }
                  descrip = ArrayDescriptor.createDescriptor("APPS.V_CUST_ID_ARRAY",oracleConnection); 
                  custArray = new ARRAY(descrip,oracleConnection,custIdList);
                  
                  headerArrayDescriptor = ArrayDescriptor.createDescriptor("APPS.V_CART_HDR_ARRAY",oracleConnection);
                  ItemDetailHeaderInputDO [] headerInputDOArr = lstDetailHeaderInputDOs.toArray(new ItemDetailHeaderInputDO[lstDetailHeaderInputDOs.size()]);
                  Object[] headerArrayObj = headerInputDOArr;
                  headerArray = new ARRAY(headerArrayDescriptor, oracleConnection, headerArrayObj);
                  
                  callStatement = oracleConnection.prepareCall(procStr);
                  callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
                  callStatement.setString(1, strSSO.toUpperCase());
                  callStatement.setString(2, role);
                  callStatement.setString(3, icaoCode);
                  callStatement.setArray(4, custArray);
                  callStatement.setString(5, operatingUnitId);
                  callStatement.setObject(6, (Object)headerArray);
                  callStatement.registerOutParameter(7, OracleTypes.ARRAY, "APPS.V_QT_HDR_STS_DTL_ARRAY");
                  callStatement.registerOutParameter(8, OracleTypes.ARRAY, "APPS.V_QT_LINE_STS_DTL_ARRAY");
                  callStatement.registerOutParameter(9, OracleTypes.VARCHAR);
                  callStatement.execute();
                  message = (String) callStatement.getObject(9);
                  purchasePODO = new PurchasePODO();
                  if(MaterialsDataUtil.isNotNullandEmpty(message)){
                        purchasePODO.setP_msg(message);
                        return purchasePODO;
                  }
                  cart_Messages_Details = (Array) callStatement.getArray(7);
                  purchasePODO = populateCartMessagesDetailsValues(cart_Messages_Details,purchasePODO);
                  cartMessagesLineDetails = (Array) callStatement.getArray(8);
                  purchasePODO = populateCartLineDetailsValues(cartMessagesLineDetails,purchasePODO);
           }catch (Exception e) {
           log.info(e);
                  throw new TechnicalException(e.getMessage(),e.getCause());
           }finally{
           materialsDataUtil.releaseResources(connection, callStatement, null);
           }
           return purchasePODO;
    }

	private PurchasePODO populateCartMessagesDetailsValues(Array array, PurchasePODO purchasePODO) {
		CartMessageDO cartMessageDO = null;
		List<CartMessageDO> cartMessageDOList = new ArrayList<CartMessageDO>();
		try {
			if (null != array) {
				Object[] returnRecordArray = (Object[]) array.getArray();
				int cartLineHRDCount = 0;
				for (; cartLineHRDCount < returnRecordArray.length; cartLineHRDCount++) {
					Struct struct = (Struct) returnRecordArray[cartLineHRDCount];
					Object[] obj = struct.getAttributes();
					cartMessageDO = new CartMessageDO();
					cartMessageDO.setCartHeaderId(getAsString(obj[0]));
					cartMessageDO.setStatusMessage(getAsString(obj[1]));
					cartMessageDO.setOrderHeaderId(getAsString(obj[2]));
					cartMessageDO.setSuccess(getAsString(obj[3]));
					cartMessageDOList.add(cartMessageDO);
				}
			}
			purchasePODO.setLstCartMessageDO(cartMessageDOList);
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return purchasePODO;
	}

	private PurchasePODO populateCartLineDetailsValues(Array array, PurchasePODO purchasePODO) {
		LineMessageDO lineMessageDO = null;
		List<LineMessageDO> LineMessageDOList = new ArrayList<LineMessageDO>();
		try {
			if (null != array) {
				Object[] returnRecordArray = (Object[]) array.getArray();
				int cartLineHRDCount = 0;
				for (; cartLineHRDCount < returnRecordArray.length; cartLineHRDCount++) {
					Struct struct = (Struct) returnRecordArray[cartLineHRDCount];
					Object[] obj = struct.getAttributes();
					lineMessageDO = new LineMessageDO();
					lineMessageDO.setCartHeaderId(getAsString(obj[0]));
					lineMessageDO.setCartLineId(getAsString(obj[1]));
					lineMessageDO.setStatusMessage(getAsString(obj[2]));
					lineMessageDO.setOrderLineId(getAsString(obj[3]));
					LineMessageDOList.add(lineMessageDO);
				}
			}
			purchasePODO.setLstLineMessageDO(LineMessageDOList);
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return purchasePODO;
	}
}
