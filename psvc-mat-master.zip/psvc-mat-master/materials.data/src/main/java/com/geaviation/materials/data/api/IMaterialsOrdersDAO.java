package com.geaviation.materials.data.api;

import java.util.List;
import java.util.Map;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.entity.DeleteOrderLineBO;
import com.geaviation.materials.entity.InvoiceDocDO;
import com.geaviation.materials.entity.LineDetailDO;
import com.geaviation.materials.entity.MaterialsDocumentDetails;
import com.geaviation.materials.entity.MaterialsOrderRequest;
import com.geaviation.materials.entity.OrderAuditDetailsDO;
import com.geaviation.materials.entity.OrderCFMListResponse;
import com.geaviation.materials.entity.OrderDO;
import com.geaviation.materials.entity.OrderHeaderDetails;
import com.geaviation.materials.entity.OrderListResponse;
import com.geaviation.materials.entity.OrderStatusBO;
import com.geaviation.materials.entity.OrderTemplateStatusBO;
import com.geaviation.materials.entity.PartsInputDO1;
import com.geaviation.materials.entity.PriorityBO;
import com.geaviation.materials.entity.UpdateOrderDetailsOutputDO;
import com.geaviation.materials.entity.UpdateOrderInputDO;
import com.geaviation.materials.entity.WccFileBO;

import oracle.stellent.ridc.IdcClient;
import oracle.stellent.ridc.model.DataObject;

/**
 * @author 212582171
 *
 */
public interface IMaterialsOrdersDAO {

	public OrderHeaderDetails getHeaderDetailDS(String sso,String icaoCode,String[] custId ,String role,String operatingUnitId, String msNumber,String deliveryId, String orderHeaderId, String invoiceHeaderId)throws TechnicalException;
	
	public MaterialsDocumentDetails getMaterialsDocumentDS(String msNumber,String docType,String shipmentDate)throws TechnicalException;
	
	public byte[] getInvoiceDocDS(String sso,String invoiceId)throws TechnicalException;
	
	public List<PriorityBO> getPriorityDS(String strSSO,String portalId)throws TechnicalException ;
	
	public OrderAuditDetailsDO getOrderAuditDS(String strSSO, String icaoCode,	String[] custIdList, String role, String operatingUnitId,String headerId) throws TechnicalException;
	
	public UpdateOrderDetailsOutputDO updateOrderDS(String sso, String role,String icao, String[] custIdArray, String operatingUnitId, List<UpdateOrderInputDO> updateOrderInputDOList, List<Boolean> esnValidFlagList, List<String> priorityList) throws TechnicalException;
	public DeleteOrderLineBO deleteOrderLineDS(String sso,String icaoCode,String[] custIdList ,String role,String operatingUnitId,String headerId,String lineId)throws TechnicalException;
	public String getCAMEmailDS(String sso,String icao,String[] custIds, String role,String opUid);
	public List<OrderTemplateStatusBO> uploadOrderTemplateDS(String strSSO, String icaoCode,	String[] custIdList, String role, String operatingUnitId,
			List<PartsInputDO1> partsInputDO1List, OrderStatusBO orderStatusBO, Map<String, String> statusMsgmap, 
			List<OrderTemplateStatusBO> orderList, List<Boolean> esnValidFlag, List<String> priorityList);
	public OrderCFMListResponse materialsOrderCFMListDS(MaterialsOrderRequest materialsOrderRequest,String portalId) throws TechnicalException;
	public OrderListResponse materialsOrderListDS(MaterialsOrderRequest materialsOrderRequest,String portalId) throws TechnicalException;
	InvoiceDocDO getInvoiceDocDS(String strSSO, String icaoCode, String[] custIdList, String role, String operatingUnitId, String invoiceId) throws TechnicalException;
	boolean isMSDocRequestExist(String docnumber, String docTypeCd,String emailId) throws TechnicalException;
	public int requestEmailMaterialsDocDS(String docType,String docnumber,String docversion,String userId,String userEmail)throws TechnicalException;
	public LineDetailDO getLineDetailDS(String strSSO, String icaoCode,	String[] custIdList, String role, String operatingUnitId, String msNumber, String deliveryId, String orderHeaderId, String invoiceHeaderId);
	public OrderDO getOrderDetailsDS(String sso,String icaoCode ,String custId,String role,String operatingUnitId ,String headerId )throws TechnicalException;
	public WccFileBO getWccShipDoc(String msNumber, String docType, String custCode, String shipDate);
	public byte[] getWccFileByName(IdcClient<?, ?, ?> idcClient, String fileName, String documentId);
	public boolean isWccFileExists(String msNumber, String docType, String custCode, String shipDate);
	public List<DataObject> getWccShipDocFileName(String msNumber, String docType, String custCode, String shipDate);
}
