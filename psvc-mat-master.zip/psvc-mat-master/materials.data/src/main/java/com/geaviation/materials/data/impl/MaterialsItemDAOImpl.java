package com.geaviation.materials.data.impl;

import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.EMPTY_STRING;
import static com.geaviation.materials.data.impl.util.MaterialsDataUtil.getAsString;
import static com.geaviation.materials.data.impl.util.MaterialsDataUtil.isCollectionNotEmpty;
import static com.geaviation.materials.data.impl.util.MaterialsDataUtil.isNotNullandEmpty;

import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Struct;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.data.api.IMaterialsItemDAO;
import com.geaviation.materials.data.impl.util.MaterialsDataConstants;
import com.geaviation.materials.data.impl.util.MaterialsDataUtil;
import com.geaviation.materials.data.impl.util.MaterialsQueryLoader;
import com.geaviation.materials.entity.ApplicableCustBO;
import com.geaviation.materials.entity.ApplicableProductLineBO;
import com.geaviation.materials.entity.AvailabilityListBO;
import com.geaviation.materials.entity.AvailableDiscounts;
import com.geaviation.materials.entity.CommercialAgreementListBO;
import com.geaviation.materials.entity.ConfigHistory;
import com.geaviation.materials.entity.CustomerBO;
import com.geaviation.materials.entity.ItemConfigHistoryBO;
import com.geaviation.materials.entity.KitComponentDetailsBO;
import com.geaviation.materials.entity.KitPricingListBO;
import com.geaviation.materials.entity.KitStructureBO;
import com.geaviation.materials.entity.PartDetailsBO;
import com.geaviation.materials.entity.PriceListBO;
import com.geaviation.materials.entity.PricingListBO;
import com.geaviation.materials.entity.QuotationBO;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

@Component
public class MaterialsItemDAOImpl implements IMaterialsItemDAO {

	@Value("${QUERY_TIME_OUT_SECS}")
	private int queryTimeOutSecs;
	
	@Value("${QUERY_TIME_OUT_MAX_SECS}")
	private int queryMaxTimeOutSecs;
	
	
	
	@Autowired
	@Qualifier("ampsOraDS")
	private DataSource ampsOraDS;	
	
	private static final Log log = LogFactory.getLog(MaterialsItemDAOImpl.class);
	
	final static String APPSVCUSTIDARRAY = "APPS.V_CUST_ID_ARRAY";
	
	@Autowired
	private MaterialsDataUtil materialsDataUtil;
	
	@Override
	public PartDetailsBO getItemAvailPricDtlDS(String strSSO,String icaoCd,List<CustomerBO> custIdList,String role,String opUid,String invontoryItemId) {
		PartDetailsBO partDetailsBO = new PartDetailsBO();
		List<AvailabilityListBO> availabilityList = new ArrayList<AvailabilityListBO>();
		List<PricingListBO> pricingList = new ArrayList<PricingListBO> ();
		List<ApplicableCustBO> applicableCustList = new ArrayList<ApplicableCustBO>();
		List<AvailableDiscounts> availableDiscountList = new ArrayList<AvailableDiscounts>();

		//declaring list of ApplicableEngineBO objects (added newly)
		List<ApplicableProductLineBO> applicableProductLineBOList = null;
		List<CommercialAgreementListBO> agreementListBOs = null;
		List<QuotationBO> quotationBOs = new ArrayList<QuotationBO>();
		Connection connection = null;
		CallableStatement callStatement = null;
		String procStr  = null;
		try{
			String[] custIds=null;
			if(custIdList != null && !custIdList.isEmpty())
			{
				custIds = new String[custIdList.size()];
				CustomerBO customerBO = null;
				int customerCount = 0;
				for ( ;customerCount<custIdList.size();customerCount++) {
					customerBO = custIdList.get(customerCount);
					if(customerBO.getCustId() != null && ! customerBO.getCustId().isEmpty())
						custIds[customerCount]  = customerBO.getCustId();	
				}
			}
			
			Properties info = new Properties();
			
			//Locale.setDefault(Locale.US);
		
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_ITEM_DETAILS);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
			ARRAY custArray = new ARRAY(descrip,oracleConnection,custIds);
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
			callStatement.setString(1, strSSO.toUpperCase());
			callStatement.setString(2, icaoCd);
			callStatement.setArray(3, custArray);
			callStatement.setString(4, role);
			callStatement.setString(5, opUid);
			callStatement.setInt(6, Integer.parseInt(invontoryItemId));
		
			log.info(strSSO.toUpperCase());
			log.info(icaoCd);
			log.info(custArray);
			log.info(role);
			log.info(opUid);
			log.info(Integer.parseInt(invontoryItemId));
			
			
			callStatement.registerOutParameter(7, OracleTypes.ARRAY, "APPS.V_PART_DETAILS");
			callStatement.registerOutParameter(8, OracleTypes.ARRAY, "APPS.V_PART_AVAIL");
			callStatement.registerOutParameter(9, OracleTypes.ARRAY, "APPS.V_PART_PRICE");
			callStatement.registerOutParameter(10, OracleTypes.ARRAY, "APPS.V_PART_APPLICABLE");
			callStatement.registerOutParameter(11, OracleTypes.VARCHAR);
			callStatement.registerOutParameter(12, OracleTypes.VARCHAR);
			callStatement.registerOutParameter(13, OracleTypes.VARCHAR);
			callStatement.registerOutParameter(14, OracleTypes.VARCHAR);
			//discount changes
			callStatement.registerOutParameter(15, OracleTypes.ARRAY, "APPS.V_PART_DISCOUNTS");
			callStatement.registerOutParameter(16, OracleTypes.VARCHAR);
			callStatement.registerOutParameter(17, OracleTypes.VARCHAR);
			callStatement.registerOutParameter(18, OracleTypes.ARRAY, "APPS.V_PART_BOM");
			//declaring another output parameter as requested for AreoDp ( added newly )
			callStatement.registerOutParameter(19, OracleTypes.VARCHAR);

		callStatement.execute(); 
			String kitIndicator = (String) callStatement.getObject(14);
			partDetailsBO.setKitIndicator(getBooleanFrmString(kitIndicator));
			String message = (String) callStatement.getObject(11);
			if(isNotNullandEmpty(message) ){
				partDetailsBO.setMessage(message);
				return partDetailsBO;
			}
			Array itemDetailsArray = (Array) callStatement.getArray(7);
			partDetailsBO = populateItemDetailsValues(itemDetailsArray,partDetailsBO);
			String partAvailMsg = (String) callStatement.getObject(12);
			if(partAvailMsg == null ){
				Array avlDetailsArray = (Array) callStatement.getArray(8);
				availabilityList = populateAvlDetailsValues(avlDetailsArray);
				partDetailsBO.setAvailabilityList(availabilityList);
			}
			else
			{
				partDetailsBO.setPartAvailMsg(partAvailMsg);
			}
			String partPricMsg = (String) callStatement.getObject(13);
			log.info("partPricMsg: "+partPricMsg);
			if(partPricMsg == null ){
				log.info("partPricMsg is Null: "+partPricMsg);
				Array pricingDetailsArray = (Array) callStatement.getArray(9);
				log.info("pricingDetailsArray: "+pricingDetailsArray);
				pricingList = populatePricingDetailsValues(pricingDetailsArray);
				if(isCollectionNotEmpty(pricingList)){
					partDetailsBO.setPricingList(pricingList);
				}
			}
			else
			{
				partDetailsBO.setPartPricMsg(partPricMsg);
			}
			Array applicableCustDetailsArray = (Array) callStatement.getArray(10);
			applicableCustList = populateapplicableCustDetailsValues(applicableCustDetailsArray);
			partDetailsBO.setApplicableCust(applicableCustList);

			//Item discount functionalities Starts 
			String discountMessage = (String) callStatement.getObject(16);
			partDetailsBO.setDiscountMessage(discountMessage);
			String criticalPartMessage = (String) callStatement.getObject(17);
			if(criticalPartMessage != null && "N".equals(criticalPartMessage))
			{
				partDetailsBO.setCriticalPartMessage(EMPTY_STRING);
			}
			else
			{
				partDetailsBO.setCriticalPartMessage(criticalPartMessage);
			}
			Array discountDetailsArray = (Array) callStatement.getArray(15);
			availableDiscountList = populateDiscountDetailsValues(discountDetailsArray);
			partDetailsBO.setAvailableDiscountList(availableDiscountList);


			//Getting ApplicableEngineBO object list
			Array applicableEngineArray = (Array) callStatement.getArray(18);
			applicableProductLineBOList = populateApplicableEngineBOValues(applicableEngineArray);
			partDetailsBO.setApplicableProductLineBO(applicableProductLineBOList);
			agreementListBOs = populateCommercialAgreementValues();
			quotationBOs = populateQuotationValues();
			partDetailsBO.setCommercialAgreementListBOs(agreementListBOs);
			partDetailsBO.setQuotationBO(quotationBOs);

			//ends
			//Getting the value for orderable attribute form database as requested for AreoDp ( added newly )
			String isOrderable = (String) callStatement.getObject(19);
			if(isNotNullandEmpty(isOrderable) ){
				partDetailsBO.setIsOrderable(isOrderable);
			}

		}


		catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}

		return partDetailsBO;
	}
	
	//Added to fix JIRA 5059
	
	@Override
	public PartDetailsBO getItemAvailPricPartDtlDS(String strSSO,String icaoCd,List<CustomerBO> custIdList,String role,String opUid,String partNumber) {
		log.info("Entered into getItemAvailPricPartDtlDS() method");
		PartDetailsBO partDetailsBO = new PartDetailsBO();
		List<AvailabilityListBO> availabilityList = new ArrayList<AvailabilityListBO>();
		List<PricingListBO> pricingList = new ArrayList<PricingListBO> ();
		List<ApplicableCustBO> applicableCustList = new ArrayList<ApplicableCustBO>();
		List<AvailableDiscounts> availableDiscountList = new ArrayList<AvailableDiscounts>();

		//declaring list of ApplicableEngineBO objects (added newly)
		List<ApplicableProductLineBO> applicableProductLineBOList = new ArrayList<ApplicableProductLineBO>();

		Connection connection = null;
		CallableStatement callStatement = null;
		String procStr  = null;
		try{
			String[] custIds=null;
			if(custIdList != null && !custIdList.isEmpty())
			{
				custIds = new String[custIdList.size()];
				CustomerBO customerBO = null;
				int customerCount = 0;
				for ( ;customerCount<custIdList.size();customerCount++) {
					customerBO = custIdList.get(customerCount);
					if(customerBO.getCustId() != null && ! customerBO.getCustId().isEmpty())
						custIds[customerCount]  = customerBO.getCustId();	
				}
			}
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_PART_ITEM_DETAILS);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
			ARRAY custArray = new ARRAY(descrip,oracleConnection,custIds);
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
			callStatement.setString(1, strSSO.toUpperCase());
			callStatement.setString(2, icaoCd);
			callStatement.setArray(3, custArray);
			callStatement.setString(4, role);
			callStatement.setString(5, opUid);
			callStatement.setString(6, partNumber.toUpperCase());
			callStatement.registerOutParameter(7, OracleTypes.ARRAY, "APPS.V_PART_DETAILS");
			callStatement.registerOutParameter(8, OracleTypes.ARRAY, "APPS.V_PART_AVAIL");
			callStatement.registerOutParameter(9, OracleTypes.ARRAY, "APPS.V_PART_PRICE");
			callStatement.registerOutParameter(10, OracleTypes.ARRAY, "APPS.V_PART_APPLICABLE");
			callStatement.registerOutParameter(11, OracleTypes.VARCHAR);
			callStatement.registerOutParameter(12, OracleTypes.VARCHAR);
			callStatement.registerOutParameter(13, OracleTypes.VARCHAR);
			callStatement.registerOutParameter(14, OracleTypes.VARCHAR);
			//discount changes
			callStatement.registerOutParameter(15, OracleTypes.ARRAY, "APPS.V_PART_DISCOUNTS");
			callStatement.registerOutParameter(16, OracleTypes.VARCHAR);
			callStatement.registerOutParameter(17, OracleTypes.VARCHAR);
			callStatement.registerOutParameter(18, OracleTypes.ARRAY, "APPS.V_PART_BOM");
			//declaring another output parameter as requested for AreoDp ( added newly )
			callStatement.registerOutParameter(19, OracleTypes.VARCHAR);

			callStatement.execute(); 
			String kitIndicator = (String) callStatement.getObject(14);
			partDetailsBO.setKitIndicator(getBooleanFrmString(kitIndicator));
			String message = (String) callStatement.getObject(11);
			if(isNotNullandEmpty(message) ){
				partDetailsBO.setMessage(message);
				return partDetailsBO;
			}
			Array itemDetailsArray = (Array) callStatement.getArray(7);
			partDetailsBO = populateItemDetailsValues(itemDetailsArray,partDetailsBO);
			String partAvailMsg = (String) callStatement.getObject(12);
			if(partAvailMsg == null ){
				Array avlDetailsArray = (Array) callStatement.getArray(8);
				availabilityList = populateAvlDetailsValues(avlDetailsArray);
				partDetailsBO.setAvailabilityList(availabilityList);
			}
			else
			{
				partDetailsBO.setPartAvailMsg(partAvailMsg);
			}
			String partPricMsg = (String) callStatement.getObject(13);
			if(partPricMsg == null ){
				Array pricingDetailsArray = (Array) callStatement.getArray(9);
				pricingList = populatePricingDetailsValues(pricingDetailsArray);
				if(isCollectionNotEmpty(pricingList)){
					partDetailsBO.setPricingList(pricingList);
				}
			}
			else
			{
				partDetailsBO.setPartPricMsg(partPricMsg);
			}
			Array applicableCustDetailsArray = (Array) callStatement.getArray(10);
			applicableCustList = populateapplicableCustDetailsValues(applicableCustDetailsArray);
			partDetailsBO.setApplicableCust(applicableCustList);

			//Item discount functionalities Starts 
			String discountMessage = (String) callStatement.getObject(16);
			partDetailsBO.setDiscountMessage(discountMessage);
			String criticalPartMessage = (String) callStatement.getObject(17);
			if(criticalPartMessage != null && ("N").equals(criticalPartMessage))
			{
				partDetailsBO.setCriticalPartMessage(EMPTY_STRING);
			}
			else
			{
				partDetailsBO.setCriticalPartMessage(criticalPartMessage);
			}
			Array discountDetailsArray = (Array) callStatement.getArray(15);
			availableDiscountList = populateDiscountDetailsValues(discountDetailsArray);
			partDetailsBO.setAvailableDiscountList(availableDiscountList);


			//Getting ApplicableEngineBO object list
			Array applicableengineArray = (Array) callStatement.getArray(18);
			applicableProductLineBOList = populateApplicableEngineBOValues(applicableengineArray);
			partDetailsBO.setApplicableProductLineBO(applicableProductLineBOList);

			//ends
			//Getting the value for orderable attribute form database as requested for AreoDp ( added newly )
			String isOrderable = (String) callStatement.getObject(19);
			if(isNotNullandEmpty(isOrderable) ){
				partDetailsBO.setIsOrderable(isOrderable);
			}

		}


		catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		log.info("End getItemAvailPricPartDtlDS() method");
		return partDetailsBO;
	}


	@Override
	public ItemConfigHistoryBO getItemConfigHistoryDS(String strSSO,
			String icaoCd, List<CustomerBO> custIdList, String role,
			String opUid, String invontoryItemId,String partNumber) {
		String procStr = null;
		String message = null;
		List<ConfigHistory> lstconfigHistoryBO = new ArrayList<ConfigHistory>();
		ItemConfigHistoryBO configHistoryBO = new ItemConfigHistoryBO();
		Array configHistoryArray = null;
		ARRAY array = null;
		ArrayDescriptor descrip = null;

		Connection connection = null;
		CallableStatement callStatement = null;

		lstconfigHistoryBO = populateConfigHistoryDetails(configHistoryArray);
		configHistoryBO.setConfigHistoryList(lstconfigHistoryBO);

		try {
			String[] custIds = null;
			if(custIdList != null && !custIdList.isEmpty())
			{
				custIds = new String[custIdList.size()];
				CustomerBO customerBO = null;
				int customerCount = 0;
				for ( ;customerCount<custIdList.size();customerCount++) {
					customerBO = custIdList.get(customerCount);
					if(customerBO.getCustId() != null && ! customerBO.getCustId().isEmpty())
						custIds[customerCount]  = customerBO.getCustId();	
				}
			}
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_ITEM_CONFIG_HISTORY);
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setQueryTimeout(queryMaxTimeOutSecs);//Refer config file for # of secs
			callStatement.setString(1, strSSO.toUpperCase());
			callStatement.setString(2, role);
			descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,	oracleConnection);
			array = new ARRAY(descrip, oracleConnection, custIds);
			callStatement.setString(3, icaoCd);
			callStatement.setArray(4, array);
			callStatement.setString(5, opUid);
			callStatement.setString(6, invontoryItemId);
			callStatement.setString(7, partNumber);
			callStatement.registerOutParameter(8, OracleTypes.ARRAY,"APPS.PART_HISTORY_INFO_ARRAY");
			callStatement.registerOutParameter(9, OracleTypes.VARCHAR);
			callStatement.execute();
			message = (String) callStatement.getObject(9);
			
			if (isNotNullandEmpty(message)) {
				configHistoryBO.setMessage(message);
				return configHistoryBO;
			}
			configHistoryArray = (Array) callStatement.getArray(8);
			lstconfigHistoryBO = populateConfigHistoryDetails(configHistoryArray);
			configHistoryBO.setConfigHistoryList(lstconfigHistoryBO);
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {

			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return configHistoryBO;
	}

	@Override
	public KitStructureBO getKitStructureDS(String sso, String icaoCode, String[] custIdList, String role, String operatingUnitId, 
			String inventoryItemId)throws TechnicalException{
		String procStr  = null;
		Connection connection = null;
		CallableStatement callStatement = null;
		KitStructureBO kitStructureBO=null;
		Array kitDetailsArray = null;
		Array kitComponentDtlsArray = null;
		try {
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_GET_KIT_STRUCTURE);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
			ARRAY custArray = new ARRAY(descrip,oracleConnection,custIdList);
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
			callStatement.setString(1, sso.toUpperCase());
			callStatement.setString(2, icaoCode);
			callStatement.setArray(3, custArray);
			callStatement.setString(4, role);
			callStatement.setString(5, operatingUnitId);
			callStatement.setInt(6, Integer.parseInt(inventoryItemId));
			callStatement.registerOutParameter(7,  OracleTypes.ARRAY, "APPS.V_KIT_HDR_INFO_ARRAY");
			callStatement.registerOutParameter(8,  OracleTypes.ARRAY, "APPS.V_KIT_COMP_INFO_ARRAY");
			callStatement.registerOutParameter(9, OracleTypes.VARCHAR);	
			callStatement.execute();
			String message = (String) callStatement.getObject(9);
			kitStructureBO= new KitStructureBO();
			if(isNotNullandEmpty(message)){
				kitStructureBO.setP_msg(message);	
				return kitStructureBO;
			}
			else{
				kitDetailsArray = (Array) callStatement.getArray(7);
				kitComponentDtlsArray = (Array) callStatement.getArray(8);
				kitStructureBO = populateKitStructureDetails(kitDetailsArray, kitComponentDtlsArray, kitStructureBO);
			}

		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return kitStructureBO;	
	}

	@Override
	public ItemConfigHistoryBO getRepUsedItemConfigHistory(String strSSO,  String icaoCode, String role,
			String operatingUnitId, String partNumber) throws TechnicalException {

		String procStr = null;
		String message = null;
		List<ConfigHistory> lstconfigHistoryBO = new ArrayList<ConfigHistory>();
		ItemConfigHistoryBO configHistoryBO = new ItemConfigHistoryBO();
		Array configHistoryArray = null;

		Connection connection = null;
		CallableStatement callStatement = null;

		lstconfigHistoryBO = populateConfigHistoryDetails(configHistoryArray);
		configHistoryBO.setConfigHistoryList(lstconfigHistoryBO);

		try {
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_REPAIR_USED_CONFIG_HISTORY);
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setQueryTimeout(queryMaxTimeOutSecs);//Refer config file for # of secs
			callStatement.setString(1, strSSO.toUpperCase());
			callStatement.setString(2, operatingUnitId);
			callStatement.setString(3, partNumber);
			callStatement.registerOutParameter(4, OracleTypes.ARRAY,"APPS.PART_HISTORY_INFO_ARRAY");
			callStatement.registerOutParameter(5, OracleTypes.VARCHAR);
			callStatement.execute();
			message = (String) callStatement.getObject(5);
			if (isNotNullandEmpty(message)) {
				configHistoryBO.setMessage(message);
				return configHistoryBO;
			}
			configHistoryArray = (Array) callStatement.getArray(4);
			lstconfigHistoryBO = populateConfigHistoryDetails(configHistoryArray);
			configHistoryBO.setConfigHistoryList(lstconfigHistoryBO);
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {

			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return configHistoryBO;
	
	}

	private List<ConfigHistory> populateConfigHistoryDetails(Array array) {
		Object[] returnrecordarray = null;
		Struct struct = null;
		Object[] obj = null;
		ConfigHistory itemConfigHistoryBO = null;
		List<ConfigHistory> lstconfigHistoryBO = new ArrayList<ConfigHistory>();
		try {
			if (null != array) {
				returnrecordarray = (Object[]) array.getArray();
				if (returnrecordarray != null) 
				{
					for (int i = 0; i < returnrecordarray.length; i++) {
						itemConfigHistoryBO = new ConfigHistory();
						struct = (Struct) returnrecordarray[i];
						obj = struct.getAttributes();
						itemConfigHistoryBO.setInventoryItemId(getAsString(obj[0]));
						itemConfigHistoryBO.setPartNumber(getAsString(obj[6]));
						itemConfigHistoryBO.setUnitPrice(getAsString(obj[2])); 
						itemConfigHistoryBO.setAvailability(getAsString(obj[3]));
						itemConfigHistoryBO.setUpq(getAsString(obj[4]));
						itemConfigHistoryBO.setServiceBulletin(getAsString(obj[5]));
						itemConfigHistoryBO.setAlt(getAsString(obj[7]));
						itemConfigHistoryBO.setEngineModel(getAsString(obj[8]));
						itemConfigHistoryBO.setCustomerCode(getAsString(obj[9]));							
						if(null !=getAsString(obj[10]) && !EMPTY_STRING.equalsIgnoreCase(getAsString(obj[10]))){
							itemConfigHistoryBO.setServiceBulletinDate(formatStrDate(getAsString(obj[10])));
						}else{
						itemConfigHistoryBO.setServiceBulletinDate(getAsString(obj[10]));
						}
						itemConfigHistoryBO.setInterChangeabilityCode(getAsString(obj[11]));
						itemConfigHistoryBO.setProductLine(getAsString(obj[12]));
						itemConfigHistoryBO.setEngineFamily(getAsString(obj[13]));
						itemConfigHistoryBO.setProduct(getAsString(obj[14]));
						itemConfigHistoryBO.setAltLevel(getAsString(obj[15]));
						itemConfigHistoryBO.setOriginalPartNumber(getAsString(obj[16]));
						itemConfigHistoryBO.setGekNumber(getAsString(obj[17]));
						itemConfigHistoryBO.setTechPubPlatform(getAsString(obj[18]));
						lstconfigHistoryBO.add(itemConfigHistoryBO);
					}
				}
			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return lstconfigHistoryBO;
	}
	private KitStructureBO populateKitStructureDetails(Array kitDetailsArray, Array kitComponentDtlsArray, KitStructureBO kitStructureBO){
		try {
			if (null != kitDetailsArray) {
				Object[] returnkitdtlsrecordarray = (Object[]) kitDetailsArray.getArray();
				List<PriceListBO> kitPriceList = new ArrayList<PriceListBO>();
				for (int count = 0; count < returnkitdtlsrecordarray.length;count++) {
					Struct struct = (Struct) returnkitdtlsrecordarray[count];
					Object[] obj = struct.getAttributes();
					if(count == 0){
						kitStructureBO.setKitName(getAsString(obj[0]));
						kitStructureBO.setKitDesciption(getAsString(obj[1]));
						kitStructureBO.setKitAvailability(getAsString(obj[2]));
					}
					PriceListBO priceListBO = new PriceListBO();
					priceListBO.setKitMessage(getAsString(obj[3]));
					priceListBO.setCustomerCode(getAsString(obj[4]));
					priceListBO.setPrice(getAsString(obj[5]));
					kitPriceList.add(priceListBO);
				}	
				kitStructureBO.setPriceList(kitPriceList);
			}
			if (null != kitComponentDtlsArray) {
				Object[] returnkitcomponentdtlsrecord_array = (Object[]) kitComponentDtlsArray.getArray();
				List<KitComponentDetailsBO> kitComponentDtlsList = new ArrayList<KitComponentDetailsBO>();
				Map<String, String> priceListMap = new HashMap<String, String>();
				for (int count = 0; count < returnkitcomponentdtlsrecord_array.length;count++) {
					Struct struct = (Struct) returnkitcomponentdtlsrecord_array[count];
					Object[] obj = struct.getAttributes();
					String key = getAsString(obj[0])+getAsString(obj[1]);
					if(priceListMap.containsKey(key)){
						String value = priceListMap.get(key);
						value = value + "|" + getAsString(obj[5])+"+"+getAsString(obj[6])+"+"+getAsString(obj[7]);
						priceListMap.remove(key);
						priceListMap.put(key, value);
					}
					else{
						KitComponentDetailsBO kitComponentDetailsBO = new KitComponentDetailsBO();
						kitComponentDetailsBO.setComponentLevel(getAsString(obj[0]));
						kitComponentDetailsBO.setComponentPartNumber(getAsString(obj[1]));
						kitComponentDetailsBO.setComponentPartDescription(getAsString(obj[2]));
						kitComponentDetailsBO.setComponentQuantity(getAsString(obj[3]));
						kitComponentDetailsBO.setComponentAvailability(getAsString(obj[4]));
						kitComponentDtlsList.add(kitComponentDetailsBO);
						priceListMap.put(key, getAsString(obj[5])+"+"+getAsString(obj[6])+"+"+getAsString(obj[7]));
					}
				}	
				for(KitComponentDetailsBO kitComponentDetailsBO : kitComponentDtlsList){
					String kitPricingDtls = priceListMap.get(kitComponentDetailsBO.getComponentLevel()+kitComponentDetailsBO.getComponentPartNumber());
					String[] pricingDtlsArray = kitPricingDtls.split("\\|");
					if(null != pricingDtlsArray){
						List<KitPricingListBO> kitPricingList = getkitPricingListDetails(pricingDtlsArray);
						kitComponentDetailsBO.setKitPricingList(kitPricingList);
					}
				}kitStructureBO.setComponentList(kitComponentDtlsList);
			}
			return kitStructureBO;
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
	}
	private List<KitPricingListBO> getkitPricingListDetails(String[] pricingDtlsArray) {
		List<KitPricingListBO> kitPricingList = new ArrayList<KitPricingListBO>();
		for(int compCount = 0 ; compCount < pricingDtlsArray.length;compCount++){
			String price = pricingDtlsArray[compCount].toString();
			String[] pricingList = price.split("\\+");
			if(null != pricingList && pricingList.length > 0){
				KitPricingListBO kitPricingListBO = new KitPricingListBO();
				if(isNotNullandEmpty(pricingList[0]))
					kitPricingListBO.setUnitPrice(Float.parseFloat(pricingList[0]));
				if(isNotNullandEmpty(pricingList[1]))
					kitPricingListBO.setExtendedPrice(Float.parseFloat(pricingList[1]));
				kitPricingListBO.setCustomerCode(pricingList[2]);
				kitPricingList.add(kitPricingListBO);
			}
		}
		return kitPricingList;
	}

	public List<ApplicableProductLineBO> populateApplicableEngineBOValues(Array array)
	{
		List<ApplicableProductLineBO> applicableEngineBOObj = new  ArrayList<ApplicableProductLineBO>();
		ApplicableProductLineBO applicableEngineBO =null;
		try {
			if (null != array) {
				Object[] returnrecordarray = (Object[]) array.getArray();
				for (int i = 0; i < returnrecordarray.length; i++) {
					Struct struct = (Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					applicableEngineBO = new ApplicableProductLineBO();
					applicableEngineBO.setCustCode(getAsString(obj[0]));
					applicableEngineBO.setEngineProductLine(getAsString(obj[1]));
					applicableEngineBOObj.add(applicableEngineBO);
				}
			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return applicableEngineBOObj;	
	}
	
	PartDetailsBO populateItemDetailsValues(Array array,PartDetailsBO partDetailsBO)
	{
		try {
			if (null != array) {
				Object[] returnrecordarray = (Object[]) array.getArray();
				for (int i = 0; i < returnrecordarray.length; i++) {
					Struct struct = (Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					partDetailsBO.setInventoryItemId(getAsString(obj[0]));
					partDetailsBO.setPartNumber(getAsString(obj[1]));
					partDetailsBO.setPartDescription(getAsString(obj[2]));
					partDetailsBO.setPricingIndicator(getAsString(obj[3]));

				}
			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return partDetailsBO;

	}
	List<AvailabilityListBO> populateAvlDetailsValues(Array array)
	{
		List<AvailabilityListBO> avlObj = new ArrayList<AvailabilityListBO>();
		AvailabilityListBO availabilityList = null;
		try {
			if (null != array) {
				Object[] returnrecordarray = (Object[]) array.getArray();
				for (int i = 0; i < returnrecordarray.length; i++) {
					Struct struct = (Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					availabilityList = new AvailabilityListBO();
					availabilityList.setinventoryItemId(getAsString(obj[0]));
					availabilityList.setLocation(getAsString(obj[1]));
					availabilityList.setQuantity(getAsString(obj[2]));
					avlObj.add(availabilityList);
				}
			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}

		return avlObj;		
	}
	private Boolean getBooleanFrmString(String strFlag) {
		Boolean flag = false;
			if ((isNotNullandEmpty(strFlag)) && ("Y".equalsIgnoreCase(strFlag))) {
				flag = true;
		}
		return flag;
	}
	List<ApplicableCustBO> populateapplicableCustDetailsValues(Array array)
	{
		List<ApplicableCustBO> applicableCustObj = new  ArrayList<ApplicableCustBO>();;
		ApplicableCustBO applicableCust =null;
		try {
			if (null != array) {
				Object[] returnrecordarray = (Object[]) array.getArray();
				for (int i = 0; i < returnrecordarray.length; i++) {
					Struct struct = (Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					applicableCust = new ApplicableCustBO();
					applicableCust.setInventoryItemId(getAsString(obj[0]));
					applicableCust.setCustCode(getAsString(obj[1]));
					applicableCust.setSupplierCode(getAsString(obj[2]));
					applicableCust.setCustId(getAsString(obj[3]));
					applicableCust.setUpq(getAsString(obj[4]));
					applicableCust.setPricingListId(getAsString(obj[5]));
					applicableCustObj.add(applicableCust);
				}
			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return applicableCustObj;	
	}
	
	List<PricingListBO> populatePricingDetailsValues(Array array)
	{
		List<PricingListBO> pricingObj = new ArrayList<PricingListBO>();
		PricingListBO itemPrice = null;
		try {
			if (null != array) {
				
				Object[] returnrecordarray = (Object[]) array.getArray();
				log.info("returnrecordarray size: "+returnrecordarray.length);
				for (int i = 0; i < returnrecordarray.length; i++) {
					Struct struct = (Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					log.info("obj info: "+obj);
					itemPrice = new PricingListBO();
					log.info("getAsString(obj[0]): "+getAsString(obj[0]));
					itemPrice.setInventoryItemId(getAsString(obj[0]));
					log.info("getAsString(obj[1]) "+getAsString(obj[1]));
					itemPrice.setCatalog(getAsString(obj[1]));
					log.info("getAsString(obj[2]) "+getAsString(obj[2]));
					itemPrice.setUnitPrice(getAsString(obj[2]));
					log.info("getAsString(obj[3]) "+getAsString(obj[3]));
					itemPrice.setUpq(getAsString(obj[3]));
					log.info("getAsString(obj[4]) "+getAsString(obj[4]));
					itemPrice.setLeadTime(getAsString(obj[4]));
					itemPrice.setCurrency("$");//Added for CFM testing
					pricingObj.add(itemPrice);
				}
			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return pricingObj;	
	}

	List<QuotationBO> populateQuotationValues() {
		List<QuotationBO> listQuotationBO = new ArrayList<QuotationBO>();
		try {
				/*quotationBO = new QuotationBO();
				quotationBO.setQuotationLeadTime("");
				listQuotationBO.add(quotationBO);*/
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return listQuotationBO;
	}

	public List<AvailableDiscounts> populateDiscountDetailsValues(Array array)
	{
		List<AvailableDiscounts> availableDiscountsObj = new  ArrayList<AvailableDiscounts>();
		AvailableDiscounts availableDiscount =null;
		try {
			if (null != array) {
				Object[] returnrecordarray = (Object[]) array.getArray();
				for (int i = 0; i < returnrecordarray.length; i++) {
					Struct struct = (Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					availableDiscount = new AvailableDiscounts();
					availableDiscount.setCustomerCode(getAsString(obj[0]));
					availableDiscount.setDiscountName(getAsString(obj[1]));
					availableDiscount.setDiscountPercent(getAsString(obj[2]));
					availableDiscount.setDiscountedPrice(getAsString(obj[3]));
					availableDiscount.setEligibileQuantiy(getAsString(obj[4]));
					availableDiscount.setRemainQuantity(getAsString(obj[5]));
					availableDiscount.setExpiryDate(getAsString(materialsDataUtil.convertDate(getAsString(obj[6]))));
					availableDiscount.setQualifierId(getAsString(obj[15]));
					availableDiscountsObj.add(availableDiscount);
				}
			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return availableDiscountsObj;	
	}

	private String formatStrDate(String strDate) {		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
		SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");		
		String toStrDate = EMPTY_STRING;		
		if(null !=strDate){
			java.util.Date date;
			try {				
				date = formatter.parse(strDate);
			} catch (ParseException e) {
				log.error(e);
				return strDate;
			}
			toStrDate = formatter1.format(date);
		}	
		return toStrDate;
	}
	
	List<CommercialAgreementListBO> populateCommercialAgreementValues() {
		List<CommercialAgreementListBO> commercialAgreementListBOs = new ArrayList<CommercialAgreementListBO>();
		try {
				/*agreementListBO = new CommercialAgreementListBO();
				agreementListBO.setUpq("");
				commercialAgreementListBOs.add(agreementListBO);*/
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return commercialAgreementListBOs;
	}
}
