/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 13, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     MaterialsDataConstants.java
 * 
 * History        :  	Mar 13, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.data.impl.util;

/**
 * @author 720053
 *
 */
public class MaterialsDataConstants {
	
	
	public static final String EMPTY_STRING = "";
	public static final int ZERO = 0;
	public static final String COMMA = ",";
	public static final String BLANK_SPACE = " ";
	public static final String FALSE = "FALSE";
	public static final String TRUE = "TRUE";
	public static final String YES = "Yes";
	public static final String NO = "No";
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String SUCCESS = "success";
	public static final String FAILURE = "failure";
	public static final String CT7 = "CT7";
	public static final String CT7GA = "CT7GA";
	public static final String CF34 = "CF34";
	public static final String CF34GA = "CF34GA";
	public static final String CF348 = "CF34-8";
	public static final String  CF348S = "CF34-8S";
	public static final String  GEAE = "GEAE";
	public static final String PORTAL_CWC = "CWC";
	public static final String NORMAL = "NORMAL";
	public static final String WORK_STOP = "WORK STOP";
	public static final String WSP = "WSP";
	public static final String ESN_STATUS_MSG_UPDATE = "ESN entered is invalid. Enter a Valid ESN";
	public static final String WORK_STOP_ESN_MSG = "Valid ESN required for priority work stop";
	public static final String WORK_STOP_WARNING_MSG = "ESN entered for work stop priority is invalid. Please update the ESN before purchasing";
	
	
	public static final String SESSION_FACTORY_INIT_ERROR = "Error while initializing sessionfactory object";
	public static final String MATERIALS_QUERY = "query";
	public static final String SP_CHECK_LOGIN = "SP_CHECK_LOGIN";
	public static final String SP_REQUEST_LOGIN = "SP_REQUEST_LOGIN";
	public static final String SP_CUSTOMER_ADMIN_DETAILS = "SP_CUSTOMER_ADMIN_DETAILS";
	public static final String SP_ORDER_DETAILS_DETAILS = "SP_ORDER_DETAILS_DETAILS";
	public static final String PRIORITY  = "_PRIORITY";
	public static final String SP_GET_PRICE_CATALOG_DETAILS = "SP_GET_PRICE_CATALOG_DETAILS";
	public static final String SP_CUSTOMER_DETAILS = "SP_CUSTOMER_DETAILS";
	public static final String SP_ORDER_LINE_DETAILS = "SP_ORDER_LINE_DETAILS";
	public static final String SP_ITEM_DETAILS = "SP_ITEM_DETAILS";
	public static final String SP_ITEM_CONFIG_HISTORY = "SP_ITEM_CONFIG_HISTORY";
	public static final String SP_DELETE_CART_LINE = "SP_DELETE_CART_LINE";
	public static final String SP_GET_CART_COUNT = "SP_GET_CART_COUNT";
	public static final String SP_PURCHASE_PO = "SP_PURCHASE_PO";
	public static final String SP_GET_CART = "SP_GET_CART";
	public static final String SP_ADD_CART_LINE = "SP_ADD_CART_LINE";
	public static final String SP_DELETE_CART = "SP_DELETE_CART";
	public static final String SP_SAVE_CART = "SP_SAVE_CART";
	public static final String SP_GET_ORDER_HDR_INFO = "SP_GET_ORDER_HDR_INFO";
	public static final String SP_GET_ORDER_LINE_INFO = "SP_GET_ORDER_LINE_INFO";
	public static final String SP_LINE_SHIPMENT_DETAIL = "SP_LINE_SHIPMENT_DETAIL";
	public static final String SP_UPDATE_ORDER = "SP_UPDATE_ORDER";
	public static final String SP_BULK_CART = "SP_BULK_CART";
	public static final String SP_BULK_CART_PO = "SP_BULK_CART_PO";
	public static final String SP_DELETE_ORDER_LINE = "SP_DELETE_ORDER_LINE";
	public static final String SP_CREATE_DISPUTE_ORDER = "SP_CREATE_DISPUTE_ORDER";
	public static final String SP_GET_CAM_EMAIL = "SP_GET_CAM_EMAIL";
	public static final String SP_GET_KIT_STRUCTURE = "SP_GET_KIT_STRUCTURE";
	public static final String SP_GET_LABEL_INFORMATION = "SP_GET_LABEL_INFORMATION";
	public static final String SP_INVOICE_FILE_RETURN = "SP_INVOICE_FILE_RETURN";
	//JIRA 5059
	public static final String SP_PART_ITEM_DETAILS = "SP_PART_ITEM_DETAILS";
	public static final String SP_GET_GLOBAL_CUST_DETAILS = "SP_GET_GLOBAL_CUST_DETAILS";
	public static final String SP_ADD_ORDER_LINE="SP_ADD_ORDER_LINE";
	public static final String SP_BULK_ITEM_DETAILS="SP_BULK_ITEM_DETAILS";
	public static final String SP_REQUEST_REPAIR_LOGIN= "SP_REQUEST_REPAIR_LOGIN";
	
	public static final String SP_ORDER_AUDIT_HISTORY ="SP_ORDER_AUDIT_HISTORY";
	public static final String SP_NEW_SPARES_EXPT_PO_DTLS_PRC = "SP_NEW_SPARES_EXPT_PO_DTLS_PRC";
	public static final String SP_WISHLT_INSERT = "SP_WISHLT_INSERT";
	public static final String SP_WISHLT_FETCH_DETAILS = "SP_WISHLT_FETCH_DETAILS";
	public static final String SP_WISHLT_DELETE = "SP_WISHLT_DELETE";
	
	public static final String SP_REPAIR_USED_CONFIG_HISTORY = "SP_REPAIR_USED_CONFIG_HISTORY";
	
	public static final String WCC_BIND_PARAM_GET_DATARESULTSET = "GET_DATARESULTSET";
	public static final String WCC_BIND_PARAM_DOCUMENTS = "Documents";
	public static final String WCC_BIND_PARAM_GETORIGFILENAMERESULTSET = "GetOrigFileNameResultSet";
	public static final String WCC_RESULT_COLNAME_DORIGINALNAME = "dOriginalName";
	public static final String WCC_DOC_COLNAME_DID = "dID";

	public static final String WCC_FILE_REVISION = "latestReleased";
	public static final String WCC_FILE_RENDITION = "web";
	
	public static final int WCC_DOC_NOT_FOUND_CODE = -16;
	public static final int WCC_DOC_FOUND = 0;
	
	private MaterialsDataConstants() {
		
	}
}
