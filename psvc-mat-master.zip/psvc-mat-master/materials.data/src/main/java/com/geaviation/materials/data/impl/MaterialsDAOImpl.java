/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 12, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     MaterialsDAOImpl.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.data.impl;

import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.CF34;
import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.CF348S;
import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.CF34GA;
import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.CT7;
import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.CT7GA;
import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.EMPTY_STRING;
import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.GEAE;
import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.PORTAL_CWC;
import static com.geaviation.materials.data.impl.util.MaterialsDataUtil.getAsString;

import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Struct;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.data.api.IMaterialsDAO;
import com.geaviation.materials.data.impl.util.MaterialsDataConstants;
import com.geaviation.materials.data.impl.util.MaterialsDataUtil;
import com.geaviation.materials.data.impl.util.MaterialsQueryLoader;
import com.geaviation.materials.entity.BulkPartDetailsBO;
import com.geaviation.materials.entity.CustAdmin;
import com.geaviation.materials.entity.CustGTAListBO;
import com.geaviation.materials.entity.CustGlobEnqDetails;
import com.geaviation.materials.entity.CustomerAdminDetailsBO;
import com.geaviation.materials.entity.CustomerBO;
import com.geaviation.materials.entity.DeliverAddress;
import com.geaviation.materials.entity.LineDetailDO;
import com.geaviation.materials.entity.LineInfoDO;
import com.geaviation.materials.entity.MappingAddress;
import com.geaviation.materials.entity.OrderStatusBO;
import com.geaviation.materials.entity.OrderTemplateStatusBO;
import com.geaviation.materials.entity.PartsInputDO2;
import com.geaviation.materials.entity.Platform;
import com.geaviation.materials.entity.PricingCatalogDO;
import com.geaviation.materials.entity.PricingCatalogDates;
import com.geaviation.materials.entity.PriorityBO;
import com.geaviation.materials.entity.ShipAddress;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.GridFSDownloadStream;
import com.mongodb.client.gridfs.model.GridFSFile;
import com.mongodb.client.model.Projections;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;



@Component
@Configuration
public class MaterialsDAOImpl implements IMaterialsDAO  {
	
	static final String APPSVCUSTIDARRAY = "APPS.V_CUST_ID_ARRAY";
	static final String GETCONNECTION = "getConnection";
	static final String EXECUTEQUERY = "executeQuery";
	static final String BYTES = "bytes";
	static final String DATE_FORMAT = "yyyy-MM-dd";
	static final String MATERIALS_STRING = "materials";
	static final String FILENAME_STRING = "filename";

		
	@Value("${QUERY_TIME_OUT_SECS}")
	private int queryTimeOutSecs;
	
	@Autowired
	@Qualifier("ampsOraDS")
	private DataSource ampsOraDS;	
	@Autowired
	@Qualifier("eorOraDS")
	private DataSource eorOraDS;
	
	@Autowired
	private MaterialsDataUtil materialsDataUtil;
	
	@Autowired
    private MongoClient mongoClient;

	private static final Log log = LogFactory.getLog(MaterialsDAOImpl.class);
	
	@Value("${PORTAL_PRIORITY_MAPPING}")
	private String  portalPriorityConfig;
	
	@Override
	public List<PriorityBO> getPriorityDS(String strSSO,String portalId)throws TechnicalException {
		log.info(" <getPriorityDS method> START  ");
		List<String> priorityLst;
		List<PriorityBO> priorityList = new ArrayList<PriorityBO>();
		Map<String,String> portalPriorityMap = new HashMap<String,String>();
		try{
			portalPriorityMap = materialsDataUtil.getPortalConfigAsMap(portalPriorityConfig);
			String priority = portalPriorityMap.get(portalId.toUpperCase());
			if(MaterialsDataUtil.isNotNullandEmpty(priority))
			{
				priorityLst = new ArrayList<String>(Arrays.asList(priority.split(MaterialsDataConstants.COMMA)));
				for (String priorityStr : priorityLst) {
					PriorityBO priorityBO = new PriorityBO();
					priorityBO.setPriority(priorityStr);
					priorityList.add(priorityBO);
				}
			}
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}
		log.info(" <getPriorityDS method> END  ");
		return priorityList;
	}

	@Override
	public CustomerAdminDetailsBO getCustDetailDS(String sso, String icaoCode,
			String[] custIdList, String role, String operatingUnitId,
			String headerId) throws TechnicalException {

		CustomerAdminDetailsBO custAdminDetailsDO = new CustomerAdminDetailsBO();
		Connection connection = null;
		//Connection deligatingConnection = null;
		CallableStatement callStatement = null;
		List<MappingAddress> mappingAddressList = new ArrayList<MappingAddress>();
		List<ShipAddress> shipAddressList = new ArrayList<ShipAddress>();
		List<CustGTAListBO> custGTAList = new ArrayList<CustGTAListBO>();
		List<CustAdmin> custAdminList = new ArrayList<CustAdmin>();
		List<DeliverAddress> deliverAddressList = new ArrayList<DeliverAddress>();
		MappingAddress mappingAddress = null;
		ShipAddress shipAddress =null;
		DeliverAddress deliverAddress =null;
		CustAdmin  custAdmin = null;
		CustGTAListBO custGTABO =null;
		try{
			String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_CUSTOMER_DETAILS);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
			ARRAY custArray = new ARRAY(descrip,oracleConnection,custIdList);
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
			callStatement.setString(1, sso.toUpperCase());
			callStatement.setString(2, icaoCode);
			callStatement.setArray(3,custArray);
			callStatement.setString(4, role);
			callStatement.setString(5, operatingUnitId);
			callStatement.setString(6, "");
			callStatement.registerOutParameter(7, OracleTypes.ARRAY, "APPS.V_CUST_SHIPPING_ARRAY");
			callStatement.registerOutParameter(8, OracleTypes.ARRAY, "APPS.V_CUST_DELIVER_ARRAY");
			callStatement.registerOutParameter(9, OracleTypes.ARRAY, "APPS.V_CUST_MAPPING_ARRAY");
			callStatement.registerOutParameter(10, OracleTypes.ARRAY, "APPS.V_CUSTOMER_GTA_ARRAY");
			callStatement.registerOutParameter(11, OracleTypes.ARRAY, "APPS.V_CUSTOMER_ADMIN_ARRAY");
			callStatement.registerOutParameter(12, OracleTypes.VARCHAR);
			callStatement.execute();
			String message =(String) callStatement.getObject(12);
			if(MaterialsDataUtil.isNotNullandEmpty(message)){
				custAdminDetailsDO.setMessage(message);
				return custAdminDetailsDO;
			}
			//Shipping Address   Details         
			Array shippingArray =  callStatement.getArray(7);
			List<Object[]> shippingBO = materialsDataUtil.getAsJavaObject(shippingArray);
			for(Object[] obj : shippingBO)
			{
				shipAddress = new ShipAddress();
				shipAddress.setShipAddressId(getAsString(obj[0]));
				shipAddress.setAddressName(getAsString(obj[1]));
				shipAddress.setAddressCode(getAsString(obj[2]));
				shipAddress.setAddress1(getAsString(obj[3]));
				shipAddress.setAddress2(getAsString(obj[4]));
				shipAddress.setCity(getAsString(obj[5]));
				shipAddress.setState(getAsString(obj[6]));
				shipAddress.setZip(getAsString(obj[7]));
				shipAddress.setCountry(getAsString(obj[8]));
				shipAddress.setDefaultInd(getAsString(obj[9])); 
				shipAddress.setCustId(getAsString(obj[10]));
				shipAddress.setAddress3(getAsString(obj[11]));
				shipAddress.setAddress4(getAsString(obj[12]));
				shipAddress.setDefaultShipToInd(getAsString(obj[13]));
				shipAddressList.add(shipAddress);
			}

			//DeliveredAddress Details
			Array deliveredArray =  callStatement.getArray(8);
			List<Object[]> deliveredBO = materialsDataUtil.getAsJavaObject(deliveredArray);
			for(Object[] obj : deliveredBO)
			{

				deliverAddress = new DeliverAddress();
				deliverAddress.setDeliverAddressId(getAsString(obj[0]));
				deliverAddress.setAddressName(getAsString(obj[1]));
				deliverAddress.setAddressCode(getAsString(obj[2]));
				deliverAddress.setAddress1(getAsString(obj[3]));
				deliverAddress.setAddress2(getAsString(obj[4]));
				deliverAddress.setCity(getAsString(obj[5]));
				deliverAddress.setState(getAsString(obj[6]));
				deliverAddress.setZip(getAsString(obj[7]));
				deliverAddress.setCountry(getAsString(obj[8]));
				deliverAddress.setDefaultInd(getAsString(obj[9])); 
				deliverAddress.setCustId(getAsString(obj[10]));
				deliverAddress.setAddress3(getAsString(obj[11]));
				deliverAddress.setAddress4(getAsString(obj[12]));
				deliverAddressList.add(deliverAddress);

			}

			//CustMapping Array detials
			Array custMappingArray =  callStatement.getArray(9);
			List<Object[]> custMappingBO = materialsDataUtil.getAsJavaObject(custMappingArray);
			for(Object[] obj : custMappingBO)
			{
				mappingAddress= new MappingAddress();
				mappingAddress.setShipAddressId(getAsString(obj[0]));
				mappingAddress.setShipAddressCode(getAsString(obj[1]));
				mappingAddress.setShipAddress1(getAsString(obj[2]));
				mappingAddress.setDeliverAddressId(getAsString(obj[3]));
				mappingAddress.setDeliverAddressCode(getAsString(obj[4]));
				mappingAddress.setDeliverAddress1(getAsString(obj[5]));
				mappingAddress.setDefaultInd(getAsString(obj[6])); 
				mappingAddress.setCustId(getAsString(obj[7]));
				mappingAddressList.add(mappingAddress);
			}

			//custGTAArray Details
			Array custGTAArray =  callStatement.getArray(10);
			List<Object[]> custGTADetails = materialsDataUtil.getAsJavaObject(custGTAArray);
			for(Object[] obj : custGTADetails)
			{
				custGTABO = new CustGTAListBO();
				custGTABO.setGtaNumber(getAsString(obj[0]));
				custGTABO.setCustAccounts(getAsString(obj[1]));
				custGTABO.setStartDt(materialsDataUtil.convertDate(getAsString(obj[2])));
				custGTABO.setExpDt(materialsDataUtil.convertDate(getAsString(obj[3])));
				custGTABO.setContractProduct(getAsString(obj[4]));
				custGTABO.setCustId(getAsString(obj[5]));
				custGTAList.add(custGTABO);
			}

			//custAdminArray Details
			Array custAdminArray =  callStatement.getArray(11);
			List<Object[]> custAdminBO = materialsDataUtil.getAsJavaObject(custAdminArray);
			for(Object[] obj : custAdminBO)
			{
				custAdmin = new CustAdmin();
				custAdmin.setCustName(getAsString(obj[0]));
				custAdmin.setCustEmail(getAsString(obj[1]));
				custAdmin.setCustPhone(getAsString(obj[2]));
				custAdmin.setCustId(getAsString(obj[3]));
				custAdminList.add(custAdmin);
			}

			//Cust Details

			custAdminDetailsDO.setShipAddressList(shipAddressList);
			custAdminDetailsDO.setDeliverAddressBOList(deliverAddressList);
			custAdminDetailsDO.setCustAdmin(custAdminList);
			custAdminDetailsDO.setMappingAddressList(mappingAddressList);
			custAdminDetailsDO.setCustGTAListBO(custGTAList);
			custAdminDetailsDO.setCustAdmin(custAdminList);

		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return custAdminDetailsDO;

	}

	@Override
	public LineDetailDO getLineDetailDS(String strSSO, String icaoCode,	String[] custIdList, String role, String operatingUnitId,
			String msNumber, String deliveryId, String orderHeaderId, String invoiceHeaderId) {
		String procStr  = null;
		Connection connection = null;
		CallableStatement callStatement = null;
		LineDetailDO lineDetailDO = null;
		List<LineInfoDO> lineInfoDOList = null;
		Array lineInfoArray  = null;

		String message = null;
		try {
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_GET_ORDER_LINE_INFO);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
			ARRAY custArray = new ARRAY(descrip,oracleConnection,custIdList);
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setQueryTimeout(queryTimeOutSecs);
			callStatement.setString(1, strSSO.toUpperCase());
			callStatement.setString(2, icaoCode);
			callStatement.setArray(3, custArray);
			callStatement.setString(4, role);
			callStatement.setString(5, operatingUnitId);
			callStatement.setString(6, msNumber);
			callStatement.setString(7,deliveryId);
			callStatement.setString(8, orderHeaderId);
			callStatement.setString(9, invoiceHeaderId);
			callStatement.registerOutParameter(10, OracleTypes.ARRAY, "APPS.V_ORDER_LINE_INFO_ARRAY");
			callStatement.registerOutParameter(11, OracleTypes.VARCHAR);
			callStatement.execute();
			message = (String) callStatement.getObject(11);
			lineDetailDO = new LineDetailDO();
			if(MaterialsDataUtil.isNotNullandEmpty(message)){
				lineDetailDO.setMessage(message);
				return lineDetailDO;
			}
			lineInfoDOList = new ArrayList<LineInfoDO>();
			lineInfoArray =  callStatement.getArray(10);
			lineInfoDOList = populateLineDetail(lineInfoArray);
			lineDetailDO.setLineInfoDOList(lineInfoDOList);
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return lineDetailDO;
	}
	private List<LineInfoDO> populateLineDetail(Array array) {
		List<LineInfoDO> lineInfoDOList = new ArrayList<LineInfoDO>(); 
		LineInfoDO lineInfoDO = null;
		try {
			if (null != array) {
				Object[] returnrecordarray = (Object[]) array.getArray();
				for (int i = 0; i < returnrecordarray.length; i++) {
					Struct struct = (Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					lineInfoDO = new LineInfoDO();

					lineInfoDO.setLineId(getAsString(obj[0]));
					lineInfoDO.setOrganisationId(getAsString(obj[1]));
					lineInfoDO.setHeaderId(getAsString(obj[2]));
					lineInfoDO.setLineNumber(getAsString(obj[3]));
					lineInfoDO.setOrderedItem(getAsString(obj[4]));
					lineInfoDO.setRequestDateTime((Timestamp)obj[5]);
					lineInfoDO.setPromiseDateTime((Timestamp)obj[6]);
					lineInfoDO.setScheduleArrivalDateTime((Timestamp)obj[7]);
					lineInfoDO.setScheduleShipDateTime((Timestamp)obj[8]);
					lineInfoDO.setOrderQuantityUnitOfMeasure(getAsString(obj[9]));

					lineInfoDO.setCanceledQuantity(getAsString(obj[10]));
					lineInfoDO.setShippedQuantity(getAsString(obj[11]));
					lineInfoDO.setOrderedQuantity(getAsString(obj[12]));
					lineInfoDO.setFulfilledQuantity(getAsString(obj[13]));
					lineInfoDO.setShippingQuantity(getAsString(obj[14]));
					lineInfoDO.setTaxExemptFlag(getAsString(obj[15]));
					lineInfoDO.setTaxExemptNumber(getAsString(obj[16]));
					lineInfoDO.setTaxExemptReasonCode(getAsString(obj[17]));
					lineInfoDO.setCustPONumber(getAsString(obj[18]));
					lineInfoDO.setSoldToOrgId(getAsString(obj[19]));

					lineInfoDO.setShipFromOrgId(getAsString(obj[20]));
					lineInfoDO.setShipToOrgId(getAsString(obj[21]));
					lineInfoDO.setDeliverToOrgId(getAsString(obj[22]));
					lineInfoDO.setInvoiceToOrgId(getAsString(obj[23]));
					lineInfoDO.setInventoryItemId(getAsString(obj[24]));
					lineInfoDO.setTaxCode(getAsString(obj[25]));
					lineInfoDO.setTaxRate(getAsString(obj[26]));
					lineInfoDO.setScheduleStatusCode(getAsString(obj[27]));
					lineInfoDO.setPriceListId(getAsString(obj[28]));
					lineInfoDO.setPricingDateTime((Timestamp)obj[29]);

					lineInfoDO.setShipmentNumber(getAsString(obj[30]));
					lineInfoDO.setShipmentPriorityCode(getAsString(obj[31]));
					lineInfoDO.setShippingMethod(getAsString(obj[32]));
					lineInfoDO.setFreightTermsCode(getAsString(obj[33]));
					lineInfoDO.setFreightCarrierCode(getAsString(obj[34]));
					lineInfoDO.setFobPoint(getAsString(obj[35]));
					lineInfoDO.setPaymentTermId(getAsString(obj[36]));
					lineInfoDO.setReturnContext(getAsString(obj[37]));
					lineInfoDO.setCountryOfOriginStr(getAsString(obj[38]));
					lineInfoDO.setReturnAttribute1(getAsString(obj[39]));

					lineInfoDO.setReturnAttribute2(getAsString(obj[40]));
					lineInfoDO.setUnitSellingPrice(getAsString(obj[41]));
					lineInfoDO.setUnitListPrice(getAsString(obj[42]));
					lineInfoDO.setExternalPrice(getAsString(obj[43]));
					lineInfoDO.setTaxValue(getAsString(obj[44]));
					lineInfoDO.setCreationDateTime((Timestamp)obj[45]);
					lineInfoDO.setCreatedBy(getAsString(obj[46]));
					lineInfoDO.setLastUpdateDateTime((Timestamp)obj[47]);
					lineInfoDO.setLastUpdatedBy(getAsString(obj[48]));
					lineInfoDO.setItemTypeCode(getAsString(obj[49]));

					lineInfoDO.setComponentNumber(getAsString(obj[50]));
					lineInfoDO.setActualShipmentDateTime((Timestamp)obj[51]);
					lineInfoDO.setLineType(getAsString(obj[52]));
					lineInfoDO.setPriceList(getAsString(obj[53]));
					lineInfoDO.setPaymentTerm(getAsString(obj[54]));
					lineInfoDO.setSoldTo(getAsString(obj[55]));
					lineInfoDO.setCustomerNumber(getAsString(obj[56]));
					lineInfoDO.setShipFrom(getAsString(obj[57]));
					lineInfoDO.setShipToLocation(getAsString(obj[58]));
					lineInfoDO.setShipToAddress1(getAsString(obj[59]));
					lineInfoDO.setShipToAddress2(getAsString(obj[60]));

					lineInfoDO.setShipToAddress3(getAsString(obj[61]));
					lineInfoDO.setShipToAddress4(getAsString(obj[62]));
					lineInfoDO.setShipToAddress5(getAsString(obj[63]));
					lineInfoDO.setDeliverToLocation(getAsString(obj[64]));
					lineInfoDO.setDeliverToAddress1(getAsString(obj[65]));
					lineInfoDO.setDeliverToAddress2(getAsString(obj[66]));
					lineInfoDO.setDeliverToAddress3(getAsString(obj[67]));
					lineInfoDO.setDeliverToAddress4(getAsString(obj[68]));
					lineInfoDO.setDeliverToAddress5(getAsString(obj[69]));
					lineInfoDO.setInvoiceToLocation(getAsString(obj[70]));

					lineInfoDO.setInvoiceToAddress1(getAsString(obj[71]));
					lineInfoDO.setInvoiceToAddress2(getAsString(obj[72]));
					lineInfoDO.setInvoiceToAddress3(getAsString(obj[73]));
					lineInfoDO.setInvoiceToAddress4(getAsString(obj[74]));
					lineInfoDO.setInvoiceToAddress5(getAsString(obj[75]));
					lineInfoDO.setOrderNumber(getAsString(obj[76]));
					lineInfoDO.setQuoteNumber(getAsString(obj[77]));
					lineInfoDO.setOrderTypeId(getAsString(obj[78]));
					lineInfoDO.setOrderedDateTime((Timestamp)obj[79]);
					lineInfoDO.setReturnReason(getAsString(obj[80]));

					lineInfoDO.setSplitFromLineId(getAsString(obj[81]));
					lineInfoDO.setShipSetId(getAsString(obj[82]));
					lineInfoDO.setPlanningPriority(getAsString(obj[83]));
					lineInfoDO.setShippingInstructions(getAsString(obj[84]));
					lineInfoDO.setPackingInstructions(getAsString(obj[85]));
					lineInfoDO.setInvoicedQuantity(getAsString(obj[86]));
					lineInfoDO.setFlowStatus(getAsString(obj[87]));
					lineInfoDO.setCustomerLineNumber(getAsString(obj[88]));
					lineInfoDO.setOriginalOrderedItem(getAsString(obj[89]));
					lineInfoDO.setOrderSource(getAsString(obj[90]));

					lineInfoDO.setKeyword(getAsString(obj[91]));
					lineInfoDO.setPartNomenclature(getAsString(obj[92]));
					lineInfoDO.setSalesPerson(getAsString(obj[93]));
					lineInfoDO.setDeliveryId(getAsString(obj[94]));
					lineInfoDO.setInvoiceNumber(getAsString(obj[95]));
					lineInfoDO.setDiscountPercent(getAsString(obj[96]));
					lineInfoDO.setDiscountAmount(getAsString(obj[97]));
					lineInfoDO.setInvoiceDateTime((Timestamp)obj[98]);
					lineInfoDO.setTotalInvoiceValue(getAsString(obj[99]));
					lineInfoDO.setOriginalPOForReturn(getAsString(obj[100]));

					lineInfoDO.setCancelUpdateAllowedFlag(getAsString(obj[101]));
					lineInfoDO.setShipmentDisputeAllowedFlag(getAsString(obj[102]));
					lineInfoDO.setMsNumber(getAsString(obj[103]));
					lineInfoDO.setShippingStatusStr(getAsString(obj[104]));
					lineInfoDO.setShipmentQuantity(getAsString(obj[105]));
					lineInfoDO.setDimensions(getAsString(obj[106]));
					lineInfoDO.setGrossWeight(getAsString(obj[107]));
					lineInfoDO.setSerialNumbers(splitString(getAsString(obj[108]),"|"));
					lineInfoDO.setLinkToCarrier(getAsString(obj[109]));

					lineInfoDO.setReturnCountryOfOrigin(getAsString(obj[110]));
					lineInfoDO.setUpq(getAsString(obj[111]));
					lineInfoDO.setInvoiceId(getAsString(obj[112]));
					lineInfoDO.setQuantityUpdateAllowedFlag(getAsString(obj[113]));
					lineInfoDO.setShipToAddress(getAsString(obj[114]));
					lineInfoDO.setDeliverToAddress(getAsString(obj[115]));
					lineInfoDO.setInvoiceToAddress(getAsString(obj[116]));
					lineInfoDO.setOrderLineESN(getAsString(obj[117]));
					lineInfoDO.setDisputeCreated(getAsString(obj[118]));
					lineInfoDO.setCriticalPartFlag(getAsString(obj[119]));
					
					//Work stop changes
					lineInfoDO.setOrderLineWorkStopDate((Timestamp)obj[120]);
					lineInfoDO.setOrderLineWorkStopQuantity((getAsString(obj[121])));
					
					lineInfoDOList.add(lineInfoDO);
				}
			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return lineInfoDOList;
	}
	/**
	 * @param input
	 * @param delimitter
	 * @return array
	 * @Description:This method splits the input String according to the delimiter.
	 */
	public String[] splitString(final String input,
			final String delimitter) {
		String[] result = null;
		if (MaterialsDataUtil.isNotNullandEmpty(input)) {
			StringTokenizer stringToken = new StringTokenizer(input, delimitter);
			int count = stringToken.countTokens();
			result = new String[count];
			int index = 0;
			while (stringToken.hasMoreTokens()) {
				result[index] = stringToken.nextToken().trim();
				index++;
			}
		}
		return result;
	}

	@Override
	public Platform getAllPricingCatalogDS(String portalId, String icaoCode, String icaoCodeAvialGTA)
			throws TechnicalException {
		//ResultSet rs = null;
		String query = null;
		Connection connection = null;
		PreparedStatement pstmt = null;
		Platform platform = new Platform();
		ArrayList<String> platformList = new ArrayList<String>();
		try {
			connection = eorOraDS.getConnection();
			log.info("entered into getAllPricingCatalogDS method");
			if (!("myCFM").equals(portalId)) {
				query = "select type from da_eor_catalog_doc "
						+ "where active='Y' and ((upper(type) not like 'CFM%') and (upper(type) not like 'LEAP%')) group by display_name, type";
			} else {
				query = "select type from da_eor_catalog_doc "
						+ "where active='Y' and ((upper(type) like 'CFM%') or (upper(type) like 'LEAP%')) group by display_name, type";
			}
			pstmt = connection.prepareStatement(query);
			pstmt.setQueryTimeout(queryTimeOutSecs);// Refer config file for
														// # of secs
			pstmt.execute();
			try(ResultSet rs = pstmt.getResultSet()){				
				//rs = pstmt.getResultSet();
				while (rs.next()) {
					platformList.add(rs.getString(1));
				}
			}catch(SQLException e){
				log.error(e);
			}
			
			platform.setPlatform(platformList);
			platformList = populatePlatformWithGTA(portalId, platformList, icaoCode, null, icaoCodeAvialGTA);
			platform.setPlatform(platformList);
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {
			materialsDataUtil.releaseResources(connection, pstmt, null);
		}
		return platform;
	}

	@Override
	public Platform getPricingCatalogDS(String strSSO, String portalId, String icaoCd, String[] custIds, String role,
			String opUid, String icaoCodeGTA, String icaoCodeAvialGTA) throws TechnicalException {
		log.info("Entered into getPricingCatalogDS() method");
		Connection connection = null;
		// Connection deligatingConnection = null;
		String procStr = null;
		String message = null;
		ARRAY array = null;
		ArrayDescriptor descrip = null;
		Array platformDetailsArray = null;
		Platform platform = new Platform();
		CallableStatement callStatement = null;
		try {
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			// deligatingConnection = getDelegatingConnection(connection);
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_GET_PRICE_CATALOG_DETAILS);
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setQueryTimeout(queryTimeOutSecs);// Refer config
																// file for # of
																// secs
			callStatement.setString(1, strSSO.toUpperCase());
			callStatement.setString(2, icaoCd);
			descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY, oracleConnection);
			array = new ARRAY(descrip, oracleConnection, custIds);
			callStatement.setArray(3, array);
			callStatement.setString(4, role);
			callStatement.setString(5, opUid);
			callStatement.registerOutParameter(6, OracleTypes.ARRAY, "APPS.V_PRICING_CATALOG_ARRAY");
			callStatement.registerOutParameter(7, OracleTypes.VARCHAR);
			callStatement.execute();
			message = (String) callStatement.getObject(7);
			if (MaterialsDataUtil.isNotNullandEmpty(message)) {
				platform.setMessage(message);
				return platform;
			}
			platformDetailsArray = (Array) callStatement.getArray(6);
			platform = populatePlatformValues(portalId, platformDetailsArray, icaoCd, icaoCodeGTA, icaoCodeAvialGTA);
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		log.info("getPricingCatalogDS() method - END");
		return platform;
	}

	public Map<String, PricingCatalogDates> getGEAEEffectiveDateDS(List<String> lstPlatform) throws TechnicalException {
		int i = 1;
		//ResultSet rs = null;
		String type = null;
		String query = null;
		String platformData = null;
		Connection connection = null;
		PreparedStatement pstmt = null;
		Date effectiveDates = null;
		Date excelRevDate = null;
		String displayName = null;
		String task = EMPTY_STRING;
		StopWatch watch = new StopWatch();
		HashMap<String, PricingCatalogDates> mapEffectiveDates = new HashMap<String, PricingCatalogDates>();
		PricingCatalogDates pricingCatalogDates = null;
		try {
			task = GETCONNECTION;
			materialsDataUtil.startLogging(task, watch);
			log.info("lstPlatform " + lstPlatform);
			connection = eorOraDS.getConnection();
			materialsDataUtil.endLogging(task, watch);
			if (lstPlatform != null && !lstPlatform.isEmpty()) {
				type = generateQsForIn(lstPlatform.size());
			}

			query = "Select TYPE,Effective_Date,Excel_rev_date,display_name From Da_Eor_Catalog_Doc "
					+ "Where type in (" + type + ") " + "And Active ='Y'";

			pstmt = connection.prepareStatement(query);
			pstmt.setQueryTimeout(queryTimeOutSecs);// Refer config file for
														// # of secs
			if (lstPlatform != null && !lstPlatform.isEmpty())
				for (String cataLogType : lstPlatform) {
					pstmt.setString(i++, cataLogType);
				}

			task = EXECUTEQUERY;
			materialsDataUtil.startLogging(task, watch);
			pstmt.execute();
			try(ResultSet rs = pstmt.getResultSet()){
				materialsDataUtil.endLogging(task, watch);
				while (rs.next()) {
					platformData = rs.getString(1);
					effectiveDates = rs.getDate(2);
					excelRevDate = rs.getDate(3);
					displayName = rs.getString(4);
					pricingCatalogDates = new PricingCatalogDates();
					pricingCatalogDates.setType(platformData);
					pricingCatalogDates.setEffectiveDate(getStrFromDate(effectiveDates));
					pricingCatalogDates.setExcelRevDate(getStrFromDate(excelRevDate));
					pricingCatalogDates.setDisplayName(displayName);
					StringBuilder platformEffDatekey = new StringBuilder();
					platformEffDatekey = platformEffDatekey.append(platformData).append("|").append(effectiveDates);
					mapEffectiveDates.put(platformEffDatekey.toString(), pricingCatalogDates);
					task = BYTES;
					materialsDataUtil.startLogging(task, watch);
					materialsDataUtil.endLogging(task, watch);
				}
			} catch(SQLException e){
				log.error(e);
			}			
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {
			materialsDataUtil.releaseResources(connection, pstmt, null);
		}
		return mapEffectiveDates;
	}

	public Map<String, PricingCatalogDates> getEffectiveDateDS(List<String> lstPlatform) throws TechnicalException {
		int i = 1;
		//ResultSet rs = null;
		String platform = null;
		String platformData=null;
		String displayName = null;
		String query = null;
		Connection connection = null;
		PreparedStatement pstmt = null;
		Date effectiveDates = null;
		Date excelRevDate = null;
		String task = EMPTY_STRING;
		StopWatch watch = new StopWatch();
		HashMap<String, PricingCatalogDates> mapEffectiveDates = new HashMap<String, PricingCatalogDates>();
		PricingCatalogDates pricingCatalogDates = null;
		try {
			task = GETCONNECTION;
			materialsDataUtil.startLogging(task, watch);
			connection = eorOraDS.getConnection();
			materialsDataUtil.endLogging(task, watch);
			if (lstPlatform != null && !lstPlatform.isEmpty()) {
				platform = generateQsForIn(lstPlatform.size());
			}
			/*
			 * if (lstPlatform != null && !lstPlatform.isEmpty()) { displayName
			 * = generateQsForIn(lstPlatform.size()); }
			 */
			query = "Select type, display_name, Max(Effective_Date),Excel_rev_date From Da_Eor_Catalog_Doc "
					+ "Where UPPER(type) in (" + platform + ") "
					+ "And Active ='Y' Group By type, display_name,Excel_rev_date";
			pstmt = connection.prepareStatement(query);
			pstmt.setQueryTimeout(queryTimeOutSecs);// Refer config file for
														// # of secs
			if (lstPlatform != null && !lstPlatform.isEmpty())
				for (String platfrm : lstPlatform) {
					pstmt.setString(i++, platfrm);
				}
			/*
			 * if (lstPlatform != null && !lstPlatform.isEmpty()) for (String
			 * displName : lstPlatform) { pstmt.setString(i++, displName); }
			 */

			task = EXECUTEQUERY;
			materialsDataUtil.startLogging(task, watch);
			pstmt.execute();
			try(ResultSet rs = pstmt.getResultSet()){
				materialsDataUtil.endLogging(task, watch);
				while (rs.next()) {
					platformData = rs.getString(1);
					displayName = rs.getString(2);
					effectiveDates = rs.getDate(3);
					excelRevDate = rs.getDate(4);
					pricingCatalogDates = new PricingCatalogDates();
					pricingCatalogDates.setType(platformData);
					pricingCatalogDates.setEffectiveDate(getStrFromDate(effectiveDates));
					pricingCatalogDates.setExcelRevDate(getStrFromDate(excelRevDate));
					pricingCatalogDates.setDisplayName(displayName);
					StringBuilder platformEffDatekey = new StringBuilder();
					platformEffDatekey = platformEffDatekey.append(platformData).append("|").append(effectiveDates);
					mapEffectiveDates.put(platformEffDatekey.toString(), pricingCatalogDates);
					task = BYTES;
					materialsDataUtil.startLogging(task, watch);
					materialsDataUtil.endLogging(task, watch);
				}
			} catch(SQLException e) {
				log.error(e);
			}			
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {
			materialsDataUtil.releaseResources(connection, pstmt, null);
		}
		return mapEffectiveDates;
	}

	@Override
	public PricingCatalogDO getPDFExcelCatalogDS(String platform, String docType, Date effDate)
			throws TechnicalException {
		Connection connection = null;
		PreparedStatement pstmt = null;
		//ResultSet rs = null;
		byte[] bytes = null;
		PricingCatalogDO pricingCatalogDO = null;
		String catalogType = null;
		try {
			String task = EMPTY_STRING;
			StopWatch watch = new StopWatch();
			task = GETCONNECTION;
			materialsDataUtil.startLogging(task, watch);
			connection = eorOraDS.getConnection();
			materialsDataUtil.endLogging(task, watch);
			if (("pdf").equalsIgnoreCase(docType)) {
				catalogType = "catalog_pdf";
			} else {
				catalogType = "catalog_excel";
			}

			String query = "SELECT * FROM da_eor_catalog_doc " + "WHERE effective_date= ? "
					+ "AND active = 'Y' AND UPPER(type) = ?";
			/* + "ORDER BY effective_date DESC"; */

			/*
			 * String query = "SELECT * FROM da_eor_catalog_doc " +
			 * "WHERE effective_date = " +
			 * "(SELECT MAX(effective_date) FROM da_eor_catalog_doc " +
			 * "WHERE UPPER(platform) = ? " + "AND active = 'Y' " +
			 * "AND type NOT LIKE '%A' AND UPPER(display_name) = ?) " +
			 * "AND UPPER(platform) = ? " + "AND type NOT LIKE '%A' " +
			 * "AND active = 'Y' AND UPPER(display_name) = ?" +
			 * "ORDER BY effective_date DESC";
			 */

			pstmt = connection.prepareStatement(query);
			pstmt.setQueryTimeout(queryTimeOutSecs);// Refer config file for
														// # of secs
			pstmt.setDate(1, effDate);
			pstmt.setString(2, platform.toUpperCase());

			task = EXECUTEQUERY;
			materialsDataUtil.startLogging(task, watch);
			try(ResultSet rs = pstmt.executeQuery()){
				materialsDataUtil.endLogging(task, watch);
				while (rs.next()) {
					pricingCatalogDO = new PricingCatalogDO();
					java.sql.Blob myBlob = rs.getBlob(catalogType);
					Date effectiveDate = rs.getDate("effective_date");
					Date revisionDate = rs.getDate("Excel_rev_date");
					task = BYTES;
					materialsDataUtil.startLogging(task, watch);
					bytes = myBlob.getBytes(1, (int) myBlob.length());
					pricingCatalogDO.setDocConent(bytes);
					pricingCatalogDO.setEffDt(getStrFromDate(effectiveDate));
					pricingCatalogDO.setRevisionDate(getStrFromDate(revisionDate));
					materialsDataUtil.endLogging(task, watch);
				}
			} catch(SQLException e){
				log.error(e);
			} 			
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {
			//materialsDataUtil.releaseResources(connection, pstmt, rs);
			materialsDataUtil.releaseResources(connection, pstmt, null);
		}
		return pricingCatalogDO;
	}

	@Override
	public PricingCatalogDO getAllPDFExcelCatalogDS(String platform, String docType, Date effDate)
			throws TechnicalException {
		Connection connection = null;
		PreparedStatement pstmt = null;
		//ResultSet rs = null;
		byte[] bytes = null;
		PricingCatalogDO pricingCatalogDO = null;
		String catalogType = null;
		try {
			log.info("effDate dao impl" + effDate);
			String task = EMPTY_STRING;
			StopWatch watch = new StopWatch();
			task = GETCONNECTION;
			materialsDataUtil.startLogging(task, watch);
			connection = eorOraDS.getConnection();
			materialsDataUtil.endLogging(task, watch);
			if (("pdf").equalsIgnoreCase(docType)) {
				catalogType = "catalog_pdf";
			} else {
				catalogType = "catalog_excel";
			}
			String query = "SELECT * FROM da_eor_catalog_doc " + "WHERE effective_date = ?" + "AND UPPER(TYPE) = ? "
					+ "AND active = 'Y'";
			/* + "ORDER BY effective_date DESC"; */

			// String query = "SELECT * FROM da_eor_catalog_doc "
			// + "WHERE effective_date = ? "
			// + "AND UPPER(TYPE) = ? "
			// + "AND active = 'Y' AND UPPER(TYPE) = ?"
			// + "ORDER BY effective_date DESC";
			pstmt = connection.prepareStatement(query);
			pstmt.setQueryTimeout(queryTimeOutSecs);// Refer config file for
														// # of secs
			pstmt.setDate(1, effDate);
			pstmt.setString(2, platform.toUpperCase());
			task = EXECUTEQUERY;
			materialsDataUtil.startLogging(task, watch);
			try(ResultSet rs = pstmt.executeQuery()){
				materialsDataUtil.endLogging(task, watch);
				while (rs.next()) {
					pricingCatalogDO = new PricingCatalogDO();
					java.sql.Blob myBlob = rs.getBlob(catalogType);
					Date effectiveDate = rs.getDate("effective_date");
					Date revisionDate = rs.getDate("Excel_rev_date");
					task = BYTES;
					materialsDataUtil.startLogging(task, watch);
					bytes = myBlob.getBytes(1, (int) myBlob.length());
					pricingCatalogDO.setDocConent(bytes);
					pricingCatalogDO.setEffDt(getStrFromDate(effectiveDate));
					pricingCatalogDO.setRevisionDate(getStrFromDate(revisionDate));
					materialsDataUtil.endLogging(task, watch);
				}
			} catch(SQLException e) {
				log.error(e);
			} 			
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {
			//materialsDataUtil.releaseResources(connection, pstmt, rs);
			materialsDataUtil.releaseResources(connection, pstmt, null);
		}
		return pricingCatalogDO;
	}

	private String getStrFromDate(Date dt) {
		String fmtedDt = null;
		if (dt != null) {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT);
			fmtedDt = simpleDateFormat.format(dt);
			return fmtedDt;
		}
		return "";
	}
	
	private String generateQsForIn(int numQs) {
		String items = "";
		for (int i = 0; i < numQs; i++) {
			if (i != 0)
				items += ", ";
			items += "?";
		}
		return items;
	}

	private Platform populatePlatformValues(String portalId, Array array, String icaoCd, String icaoCodeGTA,
			String icaoCodeAvialGTA) {
		Object[] returnrecordarray = null;
		Struct struct = null;
		Object[] obj = null;
		Platform platform = new Platform();
		ArrayList<String> lstPlatform = new ArrayList<String>();
		try {
			if (null != array) {
				returnrecordarray = (Object[]) array.getArray();
				if (returnrecordarray != null) {
					for (int i = 0; i < returnrecordarray.length; i++) {
						struct = (Struct) returnrecordarray[i];
						obj = struct.getAttributes();
						lstPlatform.add(obj[0].toString().toUpperCase());
					}
				}
				lstPlatform = populatePlatformWithGTA(portalId, lstPlatform, icaoCd, icaoCodeGTA, icaoCodeAvialGTA);
				platform.setPlatform(lstPlatform);

			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return platform;
	}

	private ArrayList<String> populatePlatformWithGTA(String portalId, ArrayList<String> lstPlatform, String icaoCd,
			String icaoCodeGTA, String icaoCodeAvialGTA) {
		if (MaterialsDataUtil.isNotNullandEmpty(icaoCodeGTA)) {
			if (icaoCodeGTA.contains(icaoCd.toUpperCase())) {
				if (lstPlatform.contains(CT7)) {
					lstPlatform.add(CT7GA);
				}
				if (lstPlatform.contains(CF34)) {
					lstPlatform.add(CF34GA);
				}
			}
		}
		if (((icaoCodeAvialGTA.contains(icaoCd.toUpperCase())) || (GEAE.equalsIgnoreCase(icaoCd.toUpperCase())))
				&& (PORTAL_CWC.equalsIgnoreCase(portalId))) {
			lstPlatform.add(CF348S);
		}
		return lstPlatform;
	}
	
	@Override
	public List<OrderTemplateStatusBO> addBulkPrtDtlsDS(String strSSO, String icaoCode,	String[] custIdList, String role, String operatingUnitId,
			List<PartsInputDO2> partsInputDOList,  OrderStatusBO orderStatusBO, Map<String, String> statusMsgmap, 
			List<OrderTemplateStatusBO> orderList){
		String procStr  = null;
		Connection connection = null;
		CallableStatement callStatement = null;
		ARRAY partsArray  = null;
		Array orderInfoArray  = null;
		List<OrderTemplateStatusBO> orderTemplateStatusList = null;
		
		String message = null;
		try {
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_BULK_CART);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
			ARRAY custArray = new ARRAY(descrip,oracleConnection,custIdList);
			ArrayDescriptor partsArraydescrip = ArrayDescriptor.createDescriptor("APPS.V_BULK_CART_LINE_ARRAY",oracleConnection); 
			
			PartsInputDO2 [] partsInputDOArray = partsInputDOList.toArray(new PartsInputDO2[partsInputDOList.size()]);
			Object[] partsArrayObj = partsInputDOArray;
			partsArray = new ARRAY(partsArraydescrip, oracleConnection, partsArrayObj);
		
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setQueryTimeout(queryTimeOutSecs);
			callStatement.setString(1, strSSO.toUpperCase());
			callStatement.setString(2, role);
			callStatement.setString(3, icaoCode);
			callStatement.setArray(4, custArray);
			callStatement.setString(5, operatingUnitId);
			callStatement.setObject(6, (Object)partsArray);
			callStatement.registerOutParameter(7, OracleTypes.ARRAY, "APPS.V_BULK_CART_LINE_STS_ARRAY");
			callStatement.registerOutParameter(8, OracleTypes.VARCHAR);
			callStatement.execute();
			message = (String) callStatement.getObject(8);
			if(MaterialsDataUtil.isNotNullandEmpty(message)){
				orderStatusBO.setDisplayMessage(message);
				return orderList;
			}
			else{
				orderInfoArray = (Array) callStatement.getArray(7);
				orderTemplateStatusList = populateOrderStatustDetails(orderInfoArray,orderStatusBO, statusMsgmap, orderList);
			}
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return orderTemplateStatusList;
	}
	
	private List<OrderTemplateStatusBO> populateOrderStatustDetails(Array orderInfoArray, OrderStatusBO orderStatusBO, 
			Map<String, String> statusMsgmap, List<OrderTemplateStatusBO> orderList) {
		try {
			if (null != orderInfoArray) {
				Object[] returnrecordarray = (Object[]) orderInfoArray.getArray();
				orderList = new ArrayList<OrderTemplateStatusBO>();
				int count = 0;
				for (; count < returnrecordarray.length;count++) {
					Struct struct = (Struct) returnrecordarray[count];
					Object[] obj = struct.getAttributes();
					OrderTemplateStatusBO orderTemplateStatusBO= new OrderTemplateStatusBO();
					String statusMsg = "";
					orderTemplateStatusBO.setPoLineNumber(MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[0])));
					orderTemplateStatusBO.setPartNumber(MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[1])));
					orderTemplateStatusBO.setQuantity(Integer.parseInt(MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[2]))));
					orderTemplateStatusBO.setSuccess(MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[3])));
					if(MaterialsDataUtil.getAsString(obj[4]) != null)
						statusMsg = MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[4]));
					orderTemplateStatusBO.setEsnValidFlag(MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[5])));
					orderTemplateStatusBO.setEsnStatusMsg(MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[6])));
					statusMsgmap.put(MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[0]))+MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[1])), statusMsg);
					orderList.add(orderTemplateStatusBO);	
				}
			}
			orderStatusBO.setOrdrStatusBO(orderList);
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return orderList;
	}

	@Override
	public List<BulkPartDetailsBO> getBulkSearchPartDtlDS(String strSSO, String icaoCd, List<CustomerBO> custIdList, String role, String opUid, String[] partNumber) {
		log.info("Entered into getBulkSearchPartDtlDS() method");
		BulkPartDetailsBO bulkPartDetailsBO = new BulkPartDetailsBO();
		List<BulkPartDetailsBO> bulkPartLst = new ArrayList<BulkPartDetailsBO>();
		Connection connection = null;
		CallableStatement callStatement = null;
		String procStr  = null;
		try{
			String[] custIds= null;
			if(custIdList != null && !custIdList.isEmpty()) {
				custIds = new String[custIdList.size()];
				CustomerBO customerBO = null;
				int customerCount = 0;
				for ( ;customerCount<custIdList.size();customerCount++) {
					customerBO = custIdList.get(customerCount);
					if(customerBO.getCustId() != null && ! customerBO.getCustId().isEmpty())
						custIds[customerCount]  = customerBO.getCustId();
				}
			}
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_BULK_ITEM_DETAILS);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			ArrayDescriptor custIDArr = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY, oracleConnection); 
			ARRAY custArray = new ARRAY(custIDArr, oracleConnection, custIds);
			ArrayDescriptor partNumberArr = ArrayDescriptor.createDescriptor("APPS.V_PART_NUM_LIST_ARRAY", oracleConnection); 
			ARRAY partNoArray = new ARRAY(partNumberArr, oracleConnection, partNumber);
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setQueryTimeout(queryTimeOutSecs);
			callStatement.setString(1,strSSO.toUpperCase());
			callStatement.setString(2,icaoCd);
			callStatement.setArray(3,custArray);
			callStatement.setString(4,role);
			callStatement.setString(5,opUid);
			callStatement.setArray(6,partNoArray);
			callStatement.registerOutParameter(7, OracleTypes.ARRAY, "APPS.V_BULK_PART_DETAILS");
			callStatement.registerOutParameter(8, OracleTypes.VARCHAR);
			callStatement.execute(); 
			String message =(String) callStatement.getObject(8);
			Array itemDetailsArray = callStatement.getArray(7);
			if(!MaterialsDataUtil.isNotNullandEmpty(message)){
				bulkPartLst = populateBulkPartDetails(itemDetailsArray);
			} else {
				bulkPartDetailsBO.setMessage(message);
				bulkPartLst.add(bulkPartDetailsBO);
			}
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		} finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		log.info("End getBulkSearchPartDtlDS() method");
		return bulkPartLst;
	}

	private List<BulkPartDetailsBO> populateBulkPartDetails(Array itemDetailsArray) {
		BulkPartDetailsBO bulkPartDetailsBO = null;
		List<BulkPartDetailsBO> bulkList = new ArrayList<BulkPartDetailsBO>();
		try {		
			if (null != itemDetailsArray) {
				Object[] returnrecordarray = (Object[]) itemDetailsArray.getArray();
				for (int i = 0; i < returnrecordarray.length; i++) {
					bulkPartDetailsBO =  new BulkPartDetailsBO();
					Struct struct = (Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					bulkPartDetailsBO.setInventoryItemId(MaterialsDataUtil.getAsString(obj[0]));
					bulkPartDetailsBO.setPartNumber(MaterialsDataUtil.getAsString(obj[1]));
					bulkPartDetailsBO.setPartDescription(MaterialsDataUtil.getAsString(obj[2]));
					bulkPartDetailsBO.setQuantity(MaterialsDataUtil.getAsString(obj[3]));
					bulkPartDetailsBO.setUnitPrice(MaterialsDataUtil.getAsString(obj[4]));
					bulkPartDetailsBO.setUpq(MaterialsDataUtil.getAsString(obj[5]));
					bulkPartDetailsBO.setLeadTime(MaterialsDataUtil.getAsString(obj[6]));
					bulkPartDetailsBO.setDiscountPercent(MaterialsDataUtil.getAsString(obj[7]));
					bulkPartDetailsBO.setDisplayMessage(MaterialsDataUtil.getAsString(obj[8]));
					bulkPartDetailsBO.setPartAvailMsg(MaterialsDataUtil.getAsString(obj[9]));
					bulkPartDetailsBO.setPricMessage(MaterialsDataUtil.getAsString(obj[10]));
					bulkPartDetailsBO.setDiscountMessage(MaterialsDataUtil.getAsString(obj[11]));
					bulkPartDetailsBO.setCriticalPartMessage(MaterialsDataUtil.getAsString(obj[12]));
					bulkList.add(bulkPartDetailsBO);
				}
			}
		}		
		catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}				
		return bulkList;
	}

	@Override
	public GridFSFile getFile(String filename) {
		if (filename == null) {
			return null;
		}
		MongoDatabase mongoDb = mongoClient.getDatabase(MATERIALS_STRING);
		MongoCollection<Document> collection = mongoDb.getCollection("artifacts.files");
		Object id = null;
		BasicDBObject query = new BasicDBObject();
		query.put(FILENAME_STRING , filename);
		MongoCursor<Document> cursor = collection.find(query).projection(Projections.include("_id")).iterator();
		while (cursor.hasNext()) {
			Document currentDoc = cursor.next();
			id = currentDoc.get("_id");
		}
		GridFSBucket bucket = GridFSBuckets.create(mongoDb, "artifacts");
		return bucket.find(new Document("_id", id)).first();
	}

	@Override
	public byte[] getFileDataFully(ObjectId id, String bucketName) {
		if (id == null) {
			return new byte[0];
		}
		MongoDatabase mongoDb = mongoClient.getDatabase(MATERIALS_STRING);
		GridFSBucket bucket = GridFSBuckets.create(mongoDb, bucketName);

		GridFSDownloadStream downloadStream = bucket.openDownloadStream(id);

		int fileLength = (int) downloadStream.getGridFSFile().getLength();
		byte[] rtn = new byte[fileLength];
		int bytesRead = downloadStream.read(rtn);
		int bytesLeft = fileLength - bytesRead;
		if (bytesLeft > 0) {
			int chunkSize = bytesRead;
			int offset = bytesRead;
			do {
				int readSize = chunkSize < bytesLeft ? chunkSize : bytesLeft;
				bytesRead = downloadStream.read(rtn, offset, readSize);
				bytesLeft -= bytesRead;
				offset += bytesRead;
			} while (bytesLeft > 0);
		}
		downloadStream.close();
		return rtn;
	}

	@Override
	public Map<Object, Object> getFileList(String portalId) {
		if (portalId == null) {
			return null;
		}
		Map<Object, Object> fileMap = new HashMap<Object, Object>();
		MongoDatabase mongoDb = mongoClient.getDatabase(MATERIALS_STRING);
		MongoCollection<Document> collection = mongoDb.getCollection("artifacts.files");
		BasicDBObject query = new BasicDBObject();
		query.put("metadata.portalId", portalId);
		query.put("metadata.docType", "Catalogs");
		MongoCursor<Document> cursor = collection.find(query).projection(Projections.include(FILENAME_STRING , "metadata"))
				.iterator();
		while (cursor.hasNext()) {
			Document currentDoc = cursor.next();
			Object createUpdateDate= ((Document)currentDoc.get("metadata")).get("createUpdateDate");
			fileMap.put(currentDoc.get(FILENAME_STRING), createUpdateDate);
		}
		return fileMap;
	}

	public CustGlobEnqDetails getGlobEnqCustIdListDS(String strSSO, String opUid, String icaoCode, String role)
			throws TechnicalException {
		log.info("Entered into getGlobEnqCustIdListDS() method");
		Connection connection = null;
		CallableStatement callStatement = null;
		String message = EMPTY_STRING;
		boolean status = false;
		List<CustomerBO> customerBOList = null;
		String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_GET_GLOBAL_CUST_DETAILS);
		CustGlobEnqDetails custGlobEnqDetails = null;
		try {
			connection = ampsOraDS.getConnection();
			callStatement = connection.prepareCall(procStr);
			callStatement.setQueryTimeout(queryTimeOutSecs);// Refer config file
															// for # of secs
			callStatement.setString(1, strSSO.toUpperCase());
			callStatement.setString(2, opUid);
			callStatement.setString(3, icaoCode);
			callStatement.setString(4, role);
			callStatement.registerOutParameter(5, OracleTypes.ARRAY, "APPS.V_CUST_LIST_ARRAY");
			callStatement.registerOutParameter(6, OracleTypes.VARCHAR);
			callStatement.execute();
			custGlobEnqDetails = new CustGlobEnqDetails();
			message = (String) callStatement.getObject(6);
			if (MaterialsDataUtil.isNotNullandEmpty(message) && message.equalsIgnoreCase(MaterialsDataConstants.TRUE)) {
				custGlobEnqDetails.setStatus(true);
			} else {
				custGlobEnqDetails.setStatus(status);
			}
			Array custArray = (Array) callStatement.getArray(5);
			customerBOList = populateGlobEnqCustValues(custArray);
			custGlobEnqDetails.setCustomerBOList(customerBOList);
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		log.info("getGlobEnqCustIdListDS() method - END");
		return custGlobEnqDetails;
	}

	private List<CustomerBO> populateGlobEnqCustValues(Array array) {
		List<CustomerBO> list = new ArrayList<CustomerBO>();
		CustomerBO custObj = null;
		try {
			if (null != array) {
				Object[] returnrecordarray = (Object[]) array.getArray();
				for (int i = 0; i < returnrecordarray.length; i++) {
					Struct struct = (Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					custObj = new CustomerBO();
					custObj.setCustCode(getAsString(obj[1]));
					custObj.setCustName(getAsString(obj[0]));
					list.add(custObj);
				}
			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return list;
	}
	@Override
	public GridFSFile getFaaMsDoc(String folder, String filename) {
		if (filename == null) {
			return null;
		}
		MongoDatabase mongoDb = mongoClient.getDatabase(MATERIALS_STRING);
		MongoCollection<Document> collection = mongoDb.getCollection("artifactsDoc.files");
		Object id = null;
		BasicDBObject query = new BasicDBObject();
		query.put(FILENAME_STRING , filename);
		query.put("metadata.srcFolder" , folder);
		MongoCursor<Document> cursor = collection.find(query).projection(Projections.include("_id")).iterator();
		while (cursor.hasNext()) {
			Document currentDoc = cursor.next();
			id = currentDoc.get("_id");
		}
		GridFSBucket bucket = GridFSBuckets.create(mongoDb, "artifactsDoc");
		return bucket.find(new Document("_id", id)).first();
	}


}
