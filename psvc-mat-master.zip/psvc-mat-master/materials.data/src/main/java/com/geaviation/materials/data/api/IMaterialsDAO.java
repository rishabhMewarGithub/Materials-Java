/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Mar 12, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     IMaterialsDAO.java
 * 
 * History        :  	Mar 12, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.data.api;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import org.bson.types.ObjectId;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.entity.BulkPartDetailsBO;
import com.geaviation.materials.entity.CustGlobEnqDetails;
import com.geaviation.materials.entity.CustomerAdminDetailsBO;
import com.geaviation.materials.entity.CustomerBO;
import com.geaviation.materials.entity.LineDetailDO;
import com.geaviation.materials.entity.OrderStatusBO;
import com.geaviation.materials.entity.OrderTemplateStatusBO;
import com.geaviation.materials.entity.PartsInputDO2;
import com.geaviation.materials.entity.Platform;
import com.geaviation.materials.entity.PricingCatalogDO;
import com.geaviation.materials.entity.PricingCatalogDates;
import com.geaviation.materials.entity.PriorityBO;
import com.mongodb.client.gridfs.model.GridFSFile;

public interface IMaterialsDAO {
	
	public List<PriorityBO> getPriorityDS(String strSSO,String portalId)throws TechnicalException;
	
	/**
	 * Returns CustAdminDetailsDO details as CustAdminDetailsDO object for the given user.
	 * The returned CustAdminDetailsDO object will have CustAdminDetails details object..
	 * The getCustDetailDS contains the following fields  

	 *  
	 *  
	* @param userId   				valid user SSO. can not be NULL.
	 * @param icaoCode				valid icaoCode. can not be NULL. 
	 * @param custIDList		    valid custIDList. can not be NULL.
	 * @param role				    valid role. can not be NULL.
     * @param operatingUnitId		valid operating Unit Id. can not be NULL.
     * @param headerId				valid header Id. can not be NULL.
	 * @return OrderDO		        OrderDO objects
	 * @throws TechnicalException	
	 */
	public CustomerAdminDetailsBO getCustDetailDS(String sso,String icaoCode ,String[] custIdList,String role,String operatingUnitId ,String headerId)throws TechnicalException;
	
	/**
	 * @param strSSO
	 * @param icaoCode
	 * @param custIdList
	 * @param role
	 * @param operatingUnitId
	 * @param msNumber
	 * @param deliveryId
	 * @param orderHeaderId
	 * @param invoiceHeaderId
	 * @return
	 */
	public LineDetailDO getLineDetailDS(String strSSO, String icaoCode, String[] custIdList, String role,
			String operatingUnitId, String msNumber, String deliveryId, String orderHeaderId, String invoiceHeaderId);

	public Platform getAllPricingCatalogDS(String portalId, String icaoCode, String icaoCodeAvialGTA)
			throws TechnicalException;

	public Platform getPricingCatalogDS(String strSSO, String portalId, String icaoCd, String[] custIds, String role,
			String opUid, String icaoCodeList, String icaoCodeAvialGTA) throws TechnicalException;

	public Map<String, PricingCatalogDates> getGEAEEffectiveDateDS(List<String> lstPlatform) throws TechnicalException;

	public Map<String, PricingCatalogDates> getEffectiveDateDS(List<String> lstPlatform) throws TechnicalException;

	public PricingCatalogDO getAllPDFExcelCatalogDS(String platform, String docType, Date effDate)
			throws TechnicalException;

	public PricingCatalogDO getPDFExcelCatalogDS(String platform, String docType, Date effDate)
			throws TechnicalException;

	public List<OrderTemplateStatusBO> addBulkPrtDtlsDS(String sso, String icaoCode, String[] custIdList, String role,
			String operatingUnitId, List<PartsInputDO2> partsInputDOList, OrderStatusBO orderStatusBO,
			Map<String, String> statusMsgmap, List<OrderTemplateStatusBO> orderList);

	public List<BulkPartDetailsBO> getBulkSearchPartDtlDS(String strSSO, String icaoCd, List<CustomerBO> custIdList,
			String role, String opUid, String[] partNumber);

	/**
	 * @param filename
	 * @return GridFSFile
	 */
	public GridFSFile getFile(String filename);

	/**
	 * @param id
	 * @return byte[] of file
	 */
	public byte[] getFileDataFully(ObjectId id, String bucketName);

	/**
	 * @param portalId
	 * @return map of filename and createUpdateDate
	 */
	public Map<Object, Object> getFileList(String portalId);
	public CustGlobEnqDetails getGlobEnqCustIdListDS(String strSSO, String opUid,String icaoCode,String role)
            throws TechnicalException;

	public GridFSFile getFaaMsDoc(String folder, String filename);



}
