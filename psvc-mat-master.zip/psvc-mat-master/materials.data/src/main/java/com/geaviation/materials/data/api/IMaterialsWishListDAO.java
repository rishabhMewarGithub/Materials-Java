package com.geaviation.materials.data.api;

import java.util.List;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.entity.DeleteWishListBO;
import com.geaviation.materials.entity.InsertWishListResponse;
import com.geaviation.materials.entity.WishListDetailsBO;

public interface IMaterialsWishListDAO {

	public InsertWishListResponse insertWishListDS(String partNumber, String strSSO, String portalId,String operatingUnitId) throws TechnicalException;
	public List<WishListDetailsBO> getWishListDetailsDS(String strSSO, String portalId,String operatingUnitId,String[] custIdArray,String role) throws TechnicalException;
	public List<DeleteWishListBO> deleteWishListDS(String strSSO, String portalId,String[] partNumberArray,String icaoCode) throws TechnicalException;
}
