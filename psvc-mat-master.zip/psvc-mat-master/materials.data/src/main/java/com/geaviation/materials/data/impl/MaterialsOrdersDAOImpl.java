package com.geaviation.materials.data.impl;

import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.EMPTY_STRING;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Struct;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.axis.client.Stub;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.dss.service.common.util.DataServiceUtils;
import com.geaviation.materials.data.api.IMaterialsOrdersDAO;
import com.geaviation.materials.data.impl.util.MaterialsDataConstants;
import com.geaviation.materials.data.impl.util.MaterialsDataUtil;
import com.geaviation.materials.data.impl.util.MaterialsQueryLoader;
import com.geaviation.materials.entity.DeleteOrderLineBO;
import com.geaviation.materials.entity.InvoiceDocDO;
import com.geaviation.materials.entity.LineDetailDO;
import com.geaviation.materials.entity.LineInfoDO;
import com.geaviation.materials.entity.MaterialsDocumentDetails;
import com.geaviation.materials.entity.MaterialsOrderRequest;
import com.geaviation.materials.entity.MaterialsOrders;
import com.geaviation.materials.entity.MaterialsOrdersCFM;
import com.geaviation.materials.entity.OrderAuditDO;
import com.geaviation.materials.entity.OrderAuditDetailsDO;
import com.geaviation.materials.entity.OrderCFMListResponse;
import com.geaviation.materials.entity.OrderDO;
import com.geaviation.materials.entity.OrderHeaderDetails;
import com.geaviation.materials.entity.OrderListResponse;
import com.geaviation.materials.entity.OrderStatusBO;
import com.geaviation.materials.entity.OrderTemplateStatusBO;
import com.geaviation.materials.entity.PartsInputDO1;
import com.geaviation.materials.entity.PriorityBO;
import com.geaviation.materials.entity.UpdateOrderDetailsOutputDO;
import com.geaviation.materials.entity.UpdateOrderInputDO;
import com.geaviation.materials.entity.UpdateOrderOutputDO;
import com.geaviation.materials.entity.WccFileBO;
import com.stellent.www.GetFile.GetFileByNameResult;
import com.stellent.www.GetFile.GetFileLocator;
import com.stellent.www.GetFile.GetFileSoap;
import com.stellent.www.GetFile.IdcProperty;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.stellent.ridc.IdcClient;
import oracle.stellent.ridc.IdcClientException;
import oracle.stellent.ridc.IdcContext;
import oracle.stellent.ridc.model.DataBinder;
import oracle.stellent.ridc.model.DataObject;
import oracle.stellent.ridc.model.DataResultSet;
import oracle.stellent.ridc.protocol.ServiceResponse;



@Component
public class MaterialsOrdersDAOImpl implements IMaterialsOrdersDAO {
	
	final static String APPSVCUSTIDARRAY = "APPS.V_CUST_ID_ARRAY";
	public static final String DATE_FORMAT1= "dd-MMM-yy";
	public static final String DATE_FORMAT2= "MM/dd/yyyy";
	
	@Value("${PORTAL_TO_OPERATING_UNIT_MAPPING}")
	private String portalToOperatingUnitIdConfig;
	
	@Value("${QUERY_TIME_OUT_SECS}")
	private int queryTimeOutSecs;
	
	@Value("${PORTAL_PRIORITY_MAPPING}")
	private String portalPriorityConfig;
	
	@Autowired
	@Qualifier("ampsOraDS")
	private DataSource ampsOraDS;

	@Autowired
	@Qualifier("wciOraDS")
	private DataSource wciOraDS;
	
	@Autowired
	@Qualifier("eorOraDS")
	private DataSource eorOraDS;
	
	@Value("${ENCRYPTIONALGO}")
    private String encryptionAlgo;

    @Value("${ENCRYPTIONPWD}")
    private String encryptionkey;
    
	@Value("${WCC.IDC.URL}")
	private String idcUrl;
	
	@Value("${WCC.IDC.USER}")
	private String idcUser;
	
	@Value("${WCC.IDC.MSNUM.COLNAME}")
	private String idcMsNumColName;
	
	@Value("${WCC.IDC.DOCTYPE.COLNAME}")
	private String idcDocTypeColName;
	
	@Value("${WCC.IDC.CUSTCODE.COLNAME}")
	private String idcCustCodeColName;
	
	@Value("${WCC.IDC.SHIPDATE.COLNAME}")
	private String idcShipDateColName;
	
	@Autowired
	private MaterialsDataUtil materialsDataUtil;
	
	private static final Log log = LogFactory.getLog(MaterialsOrdersDAOImpl.class);
	
	/**
	 * @param sso
	 * @param icaoCode
	 * @param custId
	 * @param role
	 * @param operatingUnitId
	 * @param msNumber
	 * @param deliveryId
	 * @param orderHeaderId
	 * @param invoiceHeaderId
	 * @return Order Header details
	 * @throws TechnicalException
	 */
	@Override
	public OrderHeaderDetails getHeaderDetailDS(String sso,String icaoCode,String[] custId ,String role,String operatingUnitId,
			String msNumber,String deliveryId, String orderHeaderId, String invoiceHeaderId)throws TechnicalException
			{
		String procStr  = null;
		Connection connection = null;
		//Connection delConnection = null;
		CallableStatement callStatement = null;
		OrderHeaderDetails orderHeaderDetails = null;
		Array cartHdrInfo  = null;
		Array columnGroupInfo = null;
		Array colGEAEGroupInfo = null;
		Array columnInfo = null;
		

		String msg = null;
		try {
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_GET_ORDER_HDR_INFO);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
			oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null){
				//delConnection = materialsDataUtil.getDelegatingConnection(connection);
				ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
				ARRAY custArray = new ARRAY(descrip,oracleConnection,custId);
				callStatement = oracleConnection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);
				callStatement.setString(1, sso.toUpperCase());
				callStatement.setString(2, icaoCode);
				callStatement.setArray(3, custArray);
				callStatement.setString(4, role);
				callStatement.setString(5, operatingUnitId);
				callStatement.setString(6, msNumber);
				callStatement.setString(7,deliveryId);
				callStatement.setString(8, orderHeaderId);
				callStatement.setString(9, invoiceHeaderId);
				callStatement.registerOutParameter(10, OracleTypes.ARRAY, "APPS.V_ORDER_HDR_INFO_ARRAY");
				callStatement.registerOutParameter(11, OracleTypes.ARRAY, "APPS.V_COLUMN_GRP_INFO_ARRAY");
				callStatement.registerOutParameter(12, OracleTypes.ARRAY, "APPS.V_MYGEA_GRP_INFO_ARRAY");
				callStatement.registerOutParameter(13, OracleTypes.ARRAY, "APPS.V_COLUMN_INFO_ARRAY");
				callStatement.registerOutParameter(14, OracleTypes.VARCHAR);
				callStatement.execute();
				msg = (String) callStatement.getObject(14);
				orderHeaderDetails = new OrderHeaderDetails();
				if(MaterialsDataUtil.isNotNullandEmpty(msg)){
					orderHeaderDetails.setDisplayMessage(msg);
					return orderHeaderDetails;
				}
				else{
					cartHdrInfo =  callStatement.getArray(10);
					columnGroupInfo =  callStatement.getArray(11);
					colGEAEGroupInfo  =  callStatement.getArray(12);
					columnInfo =  callStatement.getArray(13);
					orderHeaderDetails = materialsDataUtil.getCartHdrDetails(cartHdrInfo,columnGroupInfo,colGEAEGroupInfo,columnInfo,orderHeaderDetails);
				}
			}
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return orderHeaderDetails;	
	}
	
	public DeleteOrderLineBO deleteOrderLineDS(String strSSO,String icaoCode,String[] custIdList ,String role,
			String operatingUnitId,String headerId,String lineId)throws TechnicalException {
		String procStr  = null;
		Connection connection = null;
		CallableStatement callStatement = null;
		DeleteOrderLineBO deleteOrderLineBO=null;
		try {
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_DELETE_ORDER_LINE);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null) {
				ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
				ARRAY custArray = new ARRAY(descrip,oracleConnection,custIdList);
				callStatement = connection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
				callStatement.setString(1, strSSO.toUpperCase());
				callStatement.setString(2, icaoCode);
				callStatement.setArray(3, custArray);
				callStatement.setString(4, role);
				callStatement.setString(5, operatingUnitId);
				callStatement.setInt(6, Integer.parseInt(headerId));
				callStatement.setInt(7, Integer.parseInt(lineId));
				callStatement.registerOutParameter(8, OracleTypes.VARCHAR);
				callStatement.execute();
				String message = (String) callStatement.getObject(8);
				deleteOrderLineBO= new DeleteOrderLineBO();
				if(isNotNullandEmpty(message)){
					deleteOrderLineBO.setP_msg(message);
				}
				else
				{

					deleteOrderLineBO.setSuccess(true);	
				}
			}			
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return deleteOrderLineBO;	
	}

	/**
	 * Returns true if the given string is not null and not empty
	 * @param strData
	 * @return boolean
	 */
	private boolean isNotNullandEmpty(final String strData) {
		boolean isValid = false;
		if (strData != null && !"null".equals(strData) && !strData.trim().equals(EMPTY_STRING)) {
			isValid = true;
		}
		return isValid;
	}
	

	@Override
	public String getCAMEmailDS(String sso, String icao, String[] custIds,	String role, String opUid) {
		log.info("Entered into getCAMEmailDS() method");
		Connection connection = null;
		CallableStatement callStatement = null;
		String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_GET_CAM_EMAIL);
		String result = null;
		try {
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null) {
				ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
				ARRAY custArray = new ARRAY(descrip,oracleConnection,custIds);
				callStatement = connection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
				callStatement.setString(1, sso.toUpperCase());
				callStatement.setString(2, icao);
				callStatement.setArray(3, custArray);
				callStatement.setString(4, role);
				callStatement.setString(5, opUid);
				callStatement.registerOutParameter(6, OracleTypes.VARCHAR);
				callStatement.execute();
				result = (String) callStatement.getObject(6);
			}			
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		log.info("getCAMEmailDS() method - END");
		return result;
	}

	public List<OrderTemplateStatusBO> uploadOrderTemplateDS(String strSSO, String icaoCode,	String[] custIdList, String role, String operatingUnitId,
			List<PartsInputDO1> partsInputDOList,  OrderStatusBO orderStatusBO, Map<String, String> statusMsgmap, 
			List<OrderTemplateStatusBO> orderList, List<Boolean> esnValidFlag, List<String> priorityList){
		String procStr  = null;
		Connection connection = null;
		CallableStatement callStatement = null;
		ARRAY partsArray  = null;
		Array orderInfoArray  = null;
		List<OrderTemplateStatusBO> orderTemplateStatusList = null;
		
		String message = null;
		try {
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_BULK_CART_PO);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null) {
				ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
				ARRAY custArray = new ARRAY(descrip,oracleConnection,custIdList);		
				ArrayDescriptor partsArraydescrip = ArrayDescriptor.createDescriptor("APPS.V_BULK_CART_PO_ARRAY",oracleConnection); 			
				PartsInputDO1 [] partsInputDOArray = partsInputDOList.toArray(new PartsInputDO1[partsInputDOList.size()]);
				Object[] partsArrayObj = partsInputDOArray;
				partsArray = new ARRAY(partsArraydescrip, oracleConnection, partsArrayObj);
			
				callStatement = connection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);
				callStatement.setString(1, strSSO.toUpperCase());
				callStatement.setString(2, role);
				callStatement.setString(3, icaoCode);
				callStatement.setArray(4, custArray);
				callStatement.setString(5, operatingUnitId);
				callStatement.setObject(6, (Object)partsArray);
				callStatement.registerOutParameter(7, OracleTypes.ARRAY, "APPS.V_BULK_CART_PO_STS_ARRAY");
				callStatement.registerOutParameter(8, OracleTypes.VARCHAR);
				callStatement.execute();

				message = (String) callStatement.getObject(8);
				if(isNotNullandEmpty(message)){
					orderStatusBO.setDisplayMessage(message);
					return orderList;
				}
				else{
					orderInfoArray =  callStatement.getArray(7);
					orderTemplateStatusList = populateOrderStatustDetailsCFM(orderInfoArray,orderStatusBO, statusMsgmap, orderList, esnValidFlag, priorityList);
				}
			}			
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return orderTemplateStatusList;
	}

	private List<OrderTemplateStatusBO> populateOrderStatustDetailsCFM(Array orderInfoArray, OrderStatusBO orderStatusBO, 
			Map<String, String> statusMsgmap, List<OrderTemplateStatusBO> orderList, List<Boolean> esnValidFlag,
			List<String> priorityList) {
		try {
			if (null != orderInfoArray) {
				Object[] returnrecordarray = (Object[]) orderInfoArray.getArray();
				orderList = new ArrayList<OrderTemplateStatusBO>();
				int count = 0;
				for (; count < returnrecordarray.length; count++) {
					Struct struct = (Struct) returnrecordarray[count];
					Object[] obj = struct.getAttributes();
					OrderTemplateStatusBO orderTemplateStatusBO = new OrderTemplateStatusBO();
					String statusMsg = "";
					orderTemplateStatusBO
							.setPoNumber(MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[0])));
					orderTemplateStatusBO
							.setPoLineNumber(MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[1])));
					orderTemplateStatusBO
							.setPartNumber(MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[2])));
					orderTemplateStatusBO.setQuantity(
							Integer.parseInt(MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[3]))));
					orderTemplateStatusBO
							.setSuccess(MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[4])));
					if (MaterialsDataUtil.getAsString(obj[5]) != null)
						statusMsg = MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[5]));

					if (MaterialsDataConstants.NORMAL.equalsIgnoreCase(priorityList.get(count))
							&& !esnValidFlag.get(count)) {
						orderTemplateStatusBO.setEsnValidFlag(MaterialsDataConstants.N);
						orderTemplateStatusBO.setEsnStatusMsg(MaterialsDataConstants.ESN_STATUS_MSG_UPDATE);
					} else if (MaterialsDataConstants.WSP.equalsIgnoreCase(priorityList.get(count))
							&& !esnValidFlag.get(count)) {
						orderTemplateStatusBO.setEsnValidFlag(MaterialsDataConstants.N);
						orderTemplateStatusBO.setEsnStatusMsg(MaterialsDataConstants.WORK_STOP_WARNING_MSG);
					} else {
						orderTemplateStatusBO.setEsnValidFlag(
								MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[6])));
						orderTemplateStatusBO.setEsnStatusMsg(
								MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[7])));
					}
					statusMsgmap.put(
							MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[1]))
									+ MaterialsDataUtil.getAsString(materialsDataUtil.encodeForJava(obj[2])),
							statusMsg);
					orderList.add(orderTemplateStatusBO);
				}
			}
			orderStatusBO.setOrdrStatusBO(orderList);
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return orderList;
	}
	
	/**
	 * Returns true if the document exists in Web Center so we can display the links in the UI. Returns false otherwise and we do not display link 
	 * in UI
	 * @param msNumber
	 * @param docType
	 * @return boolean
	 */
	public boolean isWccFileExists(String msNumber, String docType, String custCode, String shipDate) {
		return (!this.getWccShipDocFileName(msNumber, docType, custCode, shipDate).isEmpty());
	}
	
	public List<DataObject> getWccShipDocFileName(String msNumber, String docType, String custCode, String shipDate) {
		IdcClient<?, ?, ?> idcClient = null;
        IdcContext userContext = null;
        
        DataBinder dataBinder = null;
        DataBinder responseBinder = null;
        
        ServiceResponse response = null;
        
        DataResultSet resultSet = null;
        
        String strWhereClause = "";
        List<DataObject> lstDataObjects = null;
        
        idcClient = materialsDataUtil.getIdcClient(this.idcUrl);
        
        try {
            userContext = materialsDataUtil.getIdcContext(this.idcUser); // get the UserContext Object by passing the Username.
            dataBinder = materialsDataUtil.getIdcDataBinder(idcClient); // get the binder

			//This is the where condition that Web Center uses to run the SQL code on their side
			//We needed to use Oracle Date functions for them to be able to run this SQL code correctly
			//Not really the best way to do dynamic SQL so might be something to improve in the future
			//once the Web Center team has better APIs for us to use
            strWhereClause =
                    "DocMeta." + idcMsNumColName + "='" + msNumber
                    + "' and DocMeta." + idcDocTypeColName + "='" + docType 
                    + "' and DocMeta." + idcCustCodeColName + "='" + custCode
                    + "' and TRUNC(DocMeta." + idcShipDateColName + ")=TO_DATE('" + shipDate + "', 'RRRR-MM-DD')";

            log.info("WCC WHERE CLAUSE: " + strWhereClause);

            // populate the binder with the parameters
            dataBinder.putLocal("IdcService", MaterialsDataConstants.WCC_BIND_PARAM_GET_DATARESULTSET);
            dataBinder.putLocal("dataSource", MaterialsDataConstants.WCC_BIND_PARAM_DOCUMENTS);
            dataBinder.putLocal("whereClause", strWhereClause);
            dataBinder.putLocal("resultName", MaterialsDataConstants.WCC_BIND_PARAM_GETORIGFILENAMERESULTSET);

            // execute the request
            response = idcClient.sendRequest(userContext, dataBinder);
            responseBinder = response.getResponseAsBinder();

            // get the result set
            resultSet = responseBinder.getResultSet(MaterialsDataConstants.WCC_BIND_PARAM_GETORIGFILENAMERESULTSET);
            lstDataObjects = resultSet.getRows();
            
        } catch (Exception ex) {
        	log.error("Error with Web Center IDC Service!");
        	log.error("Doc Type: " + docType);
        	log.error("MS Number: " + msNumber);
			throw new TechnicalException(ex.getMessage(), ex.getCause());
        }
        
        return lstDataObjects;
	}
	
	/**
	 * Determines the file name for the document given the MS Number and Document Type and also, downloads the document from Web Center.
	 * These 2 parameters are considered as metadata in WCC. So, we are recovering the file name based on metadata that we provide.
	 * It returns a String object that contains the file name of the document in WCC. We use this file name as input to another WCC API to retrieve the 
	 * actual file contents.
	 * @param msNumber
	 * @param docType
	 * @return String (File Name)
	 */
	@Override
	public WccFileBO getWccShipDoc(String msNumber, String docType, String custCode, String shipDate) {
		List<DataObject> lstDataObjects = getWccShipDocFileName(msNumber, docType, custCode, shipDate);
        DataObject dataObject = null;
        String strOrigFileName = null;
		WccFileBO wccFile = new WccFileBO();
		
        if(!lstDataObjects.isEmpty()) {
            // getting the first element from the list
            dataObject = lstDataObjects.get(0);

            // retrieve the file name
            strOrigFileName = dataObject.get(MaterialsDataConstants.WCC_RESULT_COLNAME_DORIGINALNAME);
            
            wccFile.setFileName(strOrigFileName);
			wccFile.setFileContent(getWccFileByName(materialsDataUtil.getIdcClient(idcUrl), strOrigFileName, dataObject.get(MaterialsDataConstants.WCC_DOC_COLNAME_DID)));
			wccFile.setStatusCode(MaterialsDataConstants.WCC_DOC_FOUND);
			wccFile.setStatusMessage("Document: " + strOrigFileName + " was retrieved successfully!");
        }
        else {
        	wccFile.setStatusCode(MaterialsDataConstants.WCC_DOC_NOT_FOUND_CODE);
        	wccFile.setStatusMessage("Document Type: " + docType + " for MS Number: " + msNumber + " not found in Web Center!");
        }
     
        return wccFile;
    }
	
	/* Retrieves the actual document file from Web Center and returns it as a byte array.
	 * Parameters:
	 * 	idcClient: IdcClient object used to connect to IDC
	 * 	fileName: File name of the document stored in IDC
	 * 	documentId: Document ID of the doc stored in IDC
	 */
	@Override
	public byte[] getWccFileByName(IdcClient<?, ?, ?> idcClient, String fileName, String documentId) {
		//create new instance of DataBinder to retrieve file
		DataBinder dataBinder = materialsDataUtil.getIdcDataBinder(idcClient);
		ServiceResponse response = null;
		InputStream inputStream = null;
		
		dataBinder.putLocal("IdcService", "GET_FILE"); // using the GET_FILE Service for file retrieval
        dataBinder.putLocal(MaterialsDataConstants.WCC_DOC_COLNAME_DID, documentId); // adding the document ID as a parameter for GET_FILE Service
        
        // execute the request
        try {
			response = idcClient.sendRequest(materialsDataUtil.getIdcContext(idcUser), dataBinder);
			inputStream = response.getResponseStream();
		} catch (IdcClientException e) {
			log.error("Error sending IDC request to retrieve document from Web Center.");
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
        
        byte[] fileContent = null;
        try {
	        //Get contents of input stream and write into byte array
	        if(inputStream != null) {
	        	fileContent = IOUtils.toByteArray(inputStream);
	        }
        } catch(IOException e) {
        	log.error("Error occurred retrieving file: " + fileName + " with IDC document ID: " + documentId);
        	throw new TechnicalException(e.getMessage(), e.getCause());
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            }
            catch(Exception e) {
            	log.error("Error closing InputStream object in getIdcFileByName method!");
            }
        }
        
        return fileContent;
	}	

	/**
	 * @param msNumber
	 * @param docType
	 * @param shipmentDate
	 * @return Material document details
	 * @throws TechnicalException
	 */
	@Override
	public MaterialsDocumentDetails getMaterialsDocumentDS(String msNumber, String docType,String shipmentDate)throws TechnicalException {
		MaterialsDocumentDetails materialsDocURL = new MaterialsDocumentDetails();
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String msnum = "";
		String shipDate ="";
		shipDate = materialsDataUtil.convertDateToYYMMMDD(shipmentDate);
        log.info("msNumber DS-->"+msNumber);
		if(msNumber != null && msNumber.length() >= 6)
		{
			msnum = msNumber.substring(0, 1)+"%"+msNumber.substring(1, 6);
		}
		log.info("msnum DS-->"+msnum);
		try {
			connection = wciOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null){
				String query = "SELECT MAX(a.doc_version),a.doc_number,b.storage_path_text,c.doc_type_cd"
						+ " FROM WCI_DOC_VERSION_PATH a,WCI_DOC_PATH b,wci_document_type c,wci_document d  "
						+ " WHERE"
						+ " a.doc_path_seq_id=b.doc_path_seq_id"
						+ " AND a.doc_type_cd = c.doc_type_cd"
						+ " AND a.doc_number = d.doc_number"
						+ " AND a.doc_type_cd = ?"
						+ " AND a.doc_number like ?"
						+ " AND (d.doc_date "
						+ "	BETWEEN TO_DATE(?,'yy-mm-dd')-15 AND TO_DATE(?,'yy-mm-dd')+15)"
						+ " GROUP BY a.doc_number,b.storage_path_text, c.doc_type_cd,d.doc_date";
				pstmt = connection.prepareStatement(query);
				pstmt.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
				pstmt.setString(1, docType);
				pstmt.setString(2, msnum);
				pstmt.setString(3, shipDate);
				pstmt.setString(4, shipDate);
				rs = pstmt.executeQuery();
				while (rs != null && rs.next()) {
					materialsDocURL.setDocVersion(rs.getString(1));
					materialsDocURL.setDocNumber(rs.getString(2));
					materialsDocURL.setStoragePathText(rs.getString(3));
					materialsDocURL.setDocTypeCd(rs.getString(4));
				}
			}			
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {
			materialsDataUtil.releaseResources(connection, pstmt, rs);
		}
		return materialsDocURL;
	}

	/**
	 * @param sso
	 * @param invoiceId
	 * @return bytes
	 * @throws TechnicalException
	 */
	@Override
	public byte[] getInvoiceDocDS(String strSSO,String invoiceId) throws TechnicalException {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		byte[] bytes = null;
		try {
			connection = eorOraDS.getConnection();
			String query = "SELECT INVC_DOC_BLB from DA_INVOICE_DOC WHERE INVC_NUM = ?";
			pstmt = connection.prepareStatement(query);
			pstmt.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
			pstmt.setString(1, invoiceId);
			rs = pstmt.executeQuery();
			while (rs != null && rs.next()) {
				java.sql.Blob myBlob = rs.getBlob(1);
				bytes = myBlob.getBytes(1, (int) myBlob.length());
			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {
			materialsDataUtil.releaseResources(connection, pstmt, rs);
		}
		return bytes;
	}
	
	/**
	 * @param strSSO
	 * @param portalId
	 * @return List of Priority objects
	 * @throws TechnicalException
	 */
	@Override
	public List<PriorityBO> getPriorityDS(String strSSO,String portalId)throws TechnicalException {
		log.info(" <getPriorityDS method> START  ");
		List<String> priorityLst;
		List<PriorityBO> priorityList = new ArrayList<PriorityBO>();
		Map<String,String> portalPriorityMap = new HashMap<>();
		try{
			portalPriorityMap = materialsDataUtil.getPortalConfigAsMap(portalPriorityConfig);
			String priority = portalPriorityMap.get(portalId.toUpperCase());
			if(MaterialsDataUtil.isNotNullandEmpty(priority))
			{
				priorityLst = new ArrayList<String>(Arrays.asList(priority.split(MaterialsDataConstants.COMMA)));
				for (String priorityStr : priorityLst) {
					PriorityBO priorityBO = new PriorityBO();
					priorityBO.setPriority(priorityStr);
					priorityList.add(priorityBO);
				}
			}
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}
		log.info(" <getPriorityDS method> END  ");
		return priorityList;
	}

	
	/**
	 * @param strSSO
	 * @param icaoCode
	 * @param custIdList
	 * @param role
	 * @param operatingUnitId
	 * @param headerId
	 * @return Order Audit details
	 * @throws TechnicalException
	 */
	@Override
	public OrderAuditDetailsDO getOrderAuditDS(String strSSO, String icaoCode,
			String[] custIdList, String role, String operatingUnitId,
			String headerId) {
		String procStr  = null;
		Connection connection = null;
		//Connection delConnection = null;
		CallableStatement callStatement = null;
		OrderAuditDetailsDO orderAuditDetailsDO = null;
		List<OrderAuditDO> orderAuditlist = null;
		Array OrderAuditArray  = null;

		String message = null;
		try {
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_ORDER_AUDIT_HISTORY);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
			oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null) {
				//delConnection = materialsDataUtil.getDelegatingConnection(connection);
				ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
				ARRAY custArray = new ARRAY(descrip,oracleConnection,custIdList);
				callStatement = oracleConnection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);
				callStatement.setString(1, strSSO.toUpperCase());
				callStatement.setString(2, role);
				callStatement.setString(3, icaoCode);
				callStatement.setArray(4, custArray);
				callStatement.setString(5, operatingUnitId);
				callStatement.setString(6, headerId);
				callStatement.registerOutParameter(7, OracleTypes.ARRAY, "APPS.V_AUDIT_HISTORY_ARRAY");
				//p_Error_status
				callStatement.registerOutParameter(8, OracleTypes.VARCHAR);
				//p_msg
				callStatement.registerOutParameter(9, OracleTypes.VARCHAR);
				callStatement.execute();
				message = (String) callStatement.getObject(9);
				orderAuditDetailsDO = new OrderAuditDetailsDO();
				if(MaterialsDataUtil.isNotNullandEmpty(message)){
					orderAuditDetailsDO.setMessage(message);
					return orderAuditDetailsDO;
				}
				String error_status = (String) callStatement.getObject(8);
				orderAuditDetailsDO.setError_status(error_status);
				orderAuditlist = new ArrayList<OrderAuditDO>();
				OrderAuditArray =  callStatement.getArray(7);
				orderAuditlist = populateOrderAuditHistory(OrderAuditArray);
				orderAuditDetailsDO.setOrderAuditDOList(orderAuditlist);
			}			
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return orderAuditDetailsDO;
	}
	
	
	/**
	 * @param array
	 * @return List of OrderAuditDO objects
	 */
	private List<OrderAuditDO> populateOrderAuditHistory(Array array) {
		List<OrderAuditDO> orderAuditlist = new ArrayList<OrderAuditDO>(); 
		OrderAuditDO orderAuditDO = null;
		try {
			if (null != array) {
				Object[] returnrecordarray = (Object[]) array.getArray();
				for (int i = 0; i < returnrecordarray.length; i++) {
					Struct struct = (Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					orderAuditDO = new OrderAuditDO();
					orderAuditDO.setLineNumber(MaterialsDataUtil.getAsString(obj[0]));
					orderAuditDO.setAttrName(MaterialsDataUtil.getAsString(obj[1]));
					orderAuditDO.setOldValue(MaterialsDataUtil.getAsString(obj[2]));
					orderAuditDO.setNewValue(MaterialsDataUtil.getAsString(obj[3]));
					orderAuditDO.setUpdatedBy(MaterialsDataUtil.getAsString(obj[4]));
					orderAuditDO.setChangeDate(materialsDataUtil.FormatedDate(MaterialsDataUtil.getAsString(obj[5])));
					orderAuditlist.add(orderAuditDO);
				}
			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return orderAuditlist;
	}
	
	
	/**
	 * @param sso
	 * @param role
	 * @param icao
	 * @param custIdArray
	 * @param operatingUnitId
	 * @param updateOrderInputDOList
	 * @return UpdateOrderDetailsOutputDO object
	 * @throws TechnicalException
	 */
	@Override
	public UpdateOrderDetailsOutputDO updateOrderDS(String sso, String role,
			String icao, String[] custIdArray, String operatingUnitId,
			List<UpdateOrderInputDO> updateOrderInputDOList, List<Boolean> esnValidFlagList, List<String> priorityList)
					throws TechnicalException {

		UpdateOrderDetailsOutputDO updateOrderDetailsOutputDO = null;
		Connection connection = null;
		String procStr = null;
		String pMessage = null;
		//Connection deligatingConnection = null;
		CallableStatement callStatement = null;
		ARRAY custArray = null;
		ARRAY updateOrderArray = null;
		Array updateOrderOut  = null;
		ArrayDescriptor custArrayDescriptor = null;
		ArrayDescriptor updateOrderArrayDescriptor = null;
		try {
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
			oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null) {
				//deligatingConnection = getDelegatingConnection(connection);
				procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_UPDATE_ORDER);
				callStatement = oracleConnection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
				callStatement.setString(1, sso.toUpperCase());
				callStatement.setString(2, icao);
				custArrayDescriptor = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection);
				custArray = new ARRAY(custArrayDescriptor, oracleConnection, custIdArray);
				callStatement.setArray(3, custArray);
				callStatement.setString(4, role);
				callStatement.setString(5, operatingUnitId);

				updateOrderArrayDescriptor = ArrayDescriptor.createDescriptor("APPS.V_ORDER_LINE_UPD_ARRAY",oracleConnection);
				UpdateOrderInputDO [] updateOrderInputDOArr = updateOrderInputDOList.toArray(new UpdateOrderInputDO[updateOrderInputDOList.size()]);
				Object[] updateOrderArrayObj = updateOrderInputDOArr;
				updateOrderArray = new ARRAY(updateOrderArrayDescriptor, oracleConnection, updateOrderArrayObj);
				callStatement.setObject(6, (Object)updateOrderArray);

				//out parameter
				callStatement.registerOutParameter(7, OracleTypes.ARRAY, "APPS.V_ORD_LN_UPD_STS_ARRAY");
				callStatement.registerOutParameter(8, OracleTypes.VARCHAR);
				callStatement.execute();
				pMessage = (String) callStatement.getObject(8);
				updateOrderDetailsOutputDO = new UpdateOrderDetailsOutputDO();
				if (MaterialsDataUtil.isNotNullandEmpty(pMessage)) {
					updateOrderDetailsOutputDO.setProcMessage(pMessage);
					return updateOrderDetailsOutputDO;
				}
				updateOrderOut =  callStatement.getArray(7);
				updateOrderDetailsOutputDO = populateUpdateOrderDetails(updateOrderOut,updateOrderDetailsOutputDO, esnValidFlagList, priorityList);
			}	
		} 
		catch (Exception e) 
		{
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}
		finally
		{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return updateOrderDetailsOutputDO;
	}
	
	
	/**
	 * @param array
	 * @param updateOrderDetailsOutputDO
	 * @return UpdateOrderDetailsOutputDO object
	 */
	private UpdateOrderDetailsOutputDO populateUpdateOrderDetails(Array array,
			UpdateOrderDetailsOutputDO updateOrderDetailsOutputDO, List<Boolean> esnValidFlagList,
			List<String> priorityList) {
		UpdateOrderOutputDO updateOrderOutput = null;
		List<UpdateOrderOutputDO> updateOrderOutputList = new ArrayList<UpdateOrderOutputDO>();
		try {
			if (null != array) {
				Object[] returnrecordarray = (Object[]) array.getArray();
				int cartLineHRDCount = 0;
				for (; cartLineHRDCount < returnrecordarray.length; cartLineHRDCount++) {
					Struct struct = (Struct) returnrecordarray[cartLineHRDCount];
					Object[] obj = struct.getAttributes();
					updateOrderOutput = new UpdateOrderOutputDO();

					updateOrderOutput.setHeaderId(MaterialsDataUtil.getAsString(obj[0]));
					updateOrderOutput.setLineId(MaterialsDataUtil.getAsString(obj[1]));
					if ((MaterialsDataConstants.NORMAL.equalsIgnoreCase(priorityList.get(cartLineHRDCount))
							&& (!esnValidFlagList.get(cartLineHRDCount)))) {
						updateOrderOutput.setSuccess(MaterialsDataUtil.getAsString(obj[2]));
						updateOrderOutput.setStatusMessage("");
						updateOrderOutput.setEsnValidFlag(MaterialsDataConstants.N);
						updateOrderOutput.setEsnStatusMsg(MaterialsDataConstants.ESN_STATUS_MSG_UPDATE);
					} else if ((MaterialsDataConstants.WORK_STOP.equalsIgnoreCase(priorityList.get(cartLineHRDCount))
							&& (!esnValidFlagList.get(cartLineHRDCount)))) {
						updateOrderOutput.setSuccess(MaterialsDataConstants.N);
						updateOrderOutput.setStatusMessage(MaterialsDataConstants.WORK_STOP_ESN_MSG);
						updateOrderOutput.setEsnValidFlag(MaterialsDataConstants.N);
						updateOrderOutput.setEsnStatusMsg(MaterialsDataConstants.WORK_STOP_ESN_MSG);
					} else {
						updateOrderOutput.setSuccess(MaterialsDataUtil.getAsString(obj[2]));
						updateOrderOutput.setStatusMessage(MaterialsDataUtil.getAsString(obj[3]));
						updateOrderOutput.setEsnValidFlag(MaterialsDataUtil.getAsString(obj[4]));
						updateOrderOutput.setEsnStatusMsg(MaterialsDataUtil.getAsString(obj[5]));
					}
					updateOrderOutputList.add(updateOrderOutput);
				}

			}
			updateOrderDetailsOutputDO.setUpdateOrderList(updateOrderOutputList);

		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}

		return updateOrderDetailsOutputDO;
	}

	@Override
	public OrderCFMListResponse materialsOrderCFMListDS(MaterialsOrderRequest materialsOrderRequest, String portalId)
			throws TechnicalException {

		OrderCFMListResponse materialsOrdersListResponse = new OrderCFMListResponse();
		List<MaterialsOrdersCFM> materialsOrdersList = null;
		Connection connection = null;
		OracleConnection oracleConnection = null;
		CallableStatement callStatement = null;
		log.error("materialsOrdersListDSV2 start");
		// String procStr =
		// MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_NEW_SPARES_EXPT_PO_DTLS_PRC);

		try {
			String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_NEW_SPARES_EXPT_PO_DTLS_PRC);
			connection = ampsOraDS.getConnection();
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setString(1, materialsOrderRequest.getIcaoCode());
			log.info("icaoCode::" + materialsOrderRequest.getIcaoCode());
			log.info("custCode::" + materialsOrderRequest.getCustCode());

			callStatement.setString(2, materialsOrderRequest.getCustCode());

			callStatement.setString(3, materialsOrderRequest.getRequestDateFrom());
			// LOG.info("custCode::"+
			// materialsOrderRequest.getRequestDateFrom());
			callStatement.setString(4, materialsOrderRequest.getRequestDateTo());
			// LOG.info("requestDateTo::"+
			// materialsOrderRequest.getRequestDateTo());

			callStatement.setString(5, materialsOrderRequest.getOrderedDateFrom());
			// LOG.info("getOrderedDateFrom::"+
			// materialsOrderRequest.getOrderedDateFrom());
			callStatement.setString(6, materialsOrderRequest.getOrderedDateTo());
			// LOG.info("getOrderedDateFrom::"+
			// materialsOrderRequest.getOrderedDateFrom());

			callStatement.setString(7, materialsOrderRequest.getDeliveryDateFrom());
			// LOG.info("getDeliveryDateFrom::"+
			// materialsOrderRequest.getDeliveryDateFrom());

			callStatement.setString(8, materialsOrderRequest.getDeliveryDateTo());
			// LOG.info("getDeliveryDateTo::"+
			// materialsOrderRequest.getDeliveryDateTo());

			callStatement.setString(9, materialsOrderRequest.getShipmentDateFrom());
			// LOG.info("getShipmentDateFrom::"+
			// materialsOrderRequest.getShipmentDateFrom());

			callStatement.setString(10, materialsOrderRequest.getShipmentDateTo());

			// LOG.info("getShipmentDateTo::"+
			// materialsOrderRequest.getShipmentDateTo());

			callStatement.setString(11, materialsOrderRequest.getMsNumber());
			// LOG.info("getMsNumber::"+ materialsOrderRequest.getMsNumber());

			callStatement.setString(12, materialsOrderRequest.getMsNumberValue());
			// LOG.info("getMsNumberValue::"+
			// materialsOrderRequest.getMsNumberValue());

			callStatement.setString(13, materialsOrderRequest.getOrderLineType());
			// LOG.info("getOrderLineType::"+
			// materialsOrderRequest.getOrderLineType());

			callStatement.setString(14, materialsOrderRequest.getOrderLineTypeValue());
			// LOG.info("getOrderLineTypeValue::"+
			// materialsOrderRequest.getOrderLineTypeValue());

			callStatement.setString(15, materialsOrderRequest.getCustomerNumber());
			// LOG.info("getCustomerNumber::"+
			// materialsOrderRequest.getCustomerNumber());

			callStatement.setString(16, materialsOrderRequest.getCustomerNumberValue());
			// LOG.info("getCustomerNumberValue::"+
			// materialsOrderRequest.getCustomerNumberValue());

			callStatement.setString(17, materialsOrderRequest.getPurchaseOrder());
			// LOG.info("getPurchaseOrder::"+
			// materialsOrderRequest.getPurchaseOrder());

			callStatement.setString(18, materialsOrderRequest.getPurchareOrderValue());
			// LOG.info("getPurchareOrderValue::"+
			// materialsOrderRequest.getPurchareOrderValue());

			callStatement.setString(19, materialsOrderRequest.getInvoiceNumber());
			// LOG.info("getInvoiceNumber::"+
			// materialsOrderRequest.getInvoiceNumber());
			callStatement.setString(20, materialsOrderRequest.getInvoiceNumberValue());
			// LOG.info("getInvoiceNumberValue::"+
			// materialsOrderRequest.getInvoiceNumberValue());

			callStatement.setString(21, materialsOrderRequest.getCustomerLineNumber());
			// LOG.info("getCustomerLineNumber::"+
			// materialsOrderRequest.getCustomerLineNumber());

			callStatement.setString(22, materialsOrderRequest.getCustomerLineNumberValue());
			// LOG.info("getCustomerLineNumberValue::"+
			// materialsOrderRequest.getCustomerLineNumberValue());

			callStatement.setString(23, materialsOrderRequest.getOrderStatus());
			// LOG.info("getOrderStatus::"+
			// materialsOrderRequest.getOrderStatus());

			callStatement.setString(24, materialsOrderRequest.getOrderStatusValue());
			// LOG.info("getOrderStatusValue::"+
			// materialsOrderRequest.getOrderStatusValue());

			callStatement.setString(25, materialsOrderRequest.getPartNumber());
			// LOG.info("getPartNumber::"+
			// materialsOrderRequest.getPartNumber());

			callStatement.setString(26, materialsOrderRequest.getPartNumberValue());
			// LOG.info("getPartNumberValue::"+
			// materialsOrderRequest.getPartNumberValue());

			callStatement.setString(27, materialsOrderRequest.getRequestedQty());
			// LOG.info("getRequestedQty::"+
			// materialsOrderRequest.getRequestedQty());

			callStatement.setString(28, materialsOrderRequest.getRequestedQtyValue());
			// LOG.info("getRequestedQtyValue::"+
			// materialsOrderRequest.getRequestedQtyValue());

			callStatement.setString(29, materialsOrderRequest.getCancelledQty());
			// LOG.info("getCancelledQty::"+
			// materialsOrderRequest.getCancelledQty());

			callStatement.setString(30, materialsOrderRequest.getCancelledQtyValue());
			// LOG.info("getCancelledQtyValue::"+
			// materialsOrderRequest.getCancelledQtyValue());

			callStatement.setString(31, materialsOrderRequest.getShippedQty());
			// LOG.info("getShippedQty::"+
			// materialsOrderRequest.getShippedQty());

			callStatement.setString(32, materialsOrderRequest.getShippedQtyValue());
			// LOG.info("getShippedQtyValue::"+
			// materialsOrderRequest.getShippedQtyValue());

			callStatement.setString(33, materialsOrderRequest.getInvoicedQuantity());
			// LOG.info("getInvoicedQuantity::"+
			// materialsOrderRequest.getInvoicedQuantity());

			callStatement.setString(34, materialsOrderRequest.getInvoicedQuantityValue());
			// LOG.info("getInvoicedQuantityValue::"+
			// materialsOrderRequest.getInvoicedQuantityValue());

			callStatement.setString(35, materialsOrderRequest.getEngineFamily());
			// LOG.info("getEngineFamily::"+
			// materialsOrderRequest.getEngineFamily());

			callStatement.setString(36, materialsOrderRequest.getEngineFamilyValue());
			// LOG.info("getEngineFamilyValue::"+
			// materialsOrderRequest.getEngineFamilyValue());

			callStatement.setString(37, materialsOrderRequest.getOrderedDate());
			// LOG.info("getOrderedDate::"+
			// materialsOrderRequest.getOrderedDate());

			callStatement.setString(38, materialsOrderRequest.getRequestedDate());
			// LOG.info("getRequestedDate::"+
			// materialsOrderRequest.getRequestedDate());

			callStatement.setString(39, materialsOrderRequest.getAwbNumber());
			// LOG.info("getAwbNumber::"+ materialsOrderRequest.getAwbNumber());

			callStatement.setString(40, materialsOrderRequest.getAwbNumberValue());
			// LOG.info("getAwbNumberValue::"+
			// materialsOrderRequest.getAwbNumberValue());

			callStatement.setString(41, materialsOrderRequest.getDeliveryDate());
			// LOG.info("getDeliveryDate::"+
			// materialsOrderRequest.getDeliveryDate());

			callStatement.setString(42, materialsOrderRequest.getShippmentDate());
			// LOG.info("getShippmentDate::"+
			// materialsOrderRequest.getShippmentDate());

			callStatement.setString(43, materialsOrderRequest.getSellingPrice());
			// LOG.info("getSellingPrice::"+
			// materialsOrderRequest.getSellingPrice());

			callStatement.setString(44, materialsOrderRequest.getSellingPriceValue());
			// LOG.info("getSellingPriceValue::"+
			// materialsOrderRequest.getSellingPriceValue());

			callStatement.setString(45, materialsOrderRequest.getListPrice());
			// LOG.info("getListPrice::"+ materialsOrderRequest.getListPrice());

			callStatement.setString(46, materialsOrderRequest.getListPriceValue());
			// LOG.info("getListPriceValue::"+
			// materialsOrderRequest.getListPriceValue());

			callStatement.setString(47, materialsOrderRequest.getExtendedPrice());
			// LOG.info("getExtendedPrice::"+
			// materialsOrderRequest.getExtendedPrice());

			callStatement.setString(48, materialsOrderRequest.getExtendedPriceValue());
			// LOG.info("getExtendedPriceValue::"+
			// materialsOrderRequest.getExtendedPriceValue());

			callStatement.setString(49, materialsOrderRequest.getEngineModel());
			// LOG.info("getEngineModel::"+
			// materialsOrderRequest.getEngineModel());

			callStatement.setString(50, materialsOrderRequest.getEngineModelValue());
			// LOG.info("getEngineModelValue::"+
			// materialsOrderRequest.getEngineModelValue());

			// LOG.info("materialsOrderRequest.getOrderByColumn()"+materialsOrderRequest.getOrderByColumn());

			// LOG.info("materialsOrderRequest.getSortType"+materialsOrderRequest.getSortType());

			callStatement.setString(51, materialsOrderRequest.getOrderByColumn());
			callStatement.setString(52, materialsOrderRequest.getSortType());

			callStatement.registerOutParameter(53, OracleTypes.ARRAY, "APPS.V_PO_EXPORT_DETAILS_LIST_ARRAY");
			callStatement.registerOutParameter(54, OracleTypes.VARCHAR);
			callStatement.registerOutParameter(55, OracleTypes.VARCHAR);

			callStatement.execute();

			Array materialsOrderssList = (Array) callStatement.getArray(53);
			materialsOrdersList = populateMataerialsOrderListCFM(materialsOrderssList, portalId);
			log.info("materialsOrdersList::" + materialsOrdersList.size());
			String message = (String) callStatement.getObject(54);
			log.info("message::" + message);
			materialsOrdersListResponse.setStatus(message);

			String totalRecords = (String) callStatement.getObject(55);
			log.info("totalRecords::" + totalRecords);
			if (!MaterialsDataUtil.isNullOrEmpty((String) callStatement.getObject(55))) {
				materialsOrdersListResponse.setTotalRecords(Integer.parseInt((String) callStatement.getObject(55)));
			}
			// materialsOrdersListResponse.setTotalRecords(Integer.parseInt("1"));
			materialsOrdersListResponse.setOrdersList(materialsOrdersList);
			log.info("materialsOrdersListDSV2 method - END");
		} catch (SQLException e) {
			log.error("Exception occured while calling materialsOrdersListDSV2 data service : " + e.getMessage());
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return materialsOrdersListResponse;
	}

	private List<MaterialsOrdersCFM> populateMataerialsOrderListCFM(Array array, String portalId) {
		log.info("Inside the method populatematerialsOrdersList : Datalayer");

		List<MaterialsOrdersCFM> materialsOrdersList = null;
		MaterialsOrdersCFM materialsOrders = null;
		try {
			if (null != array) {
				materialsOrdersList = new ArrayList<MaterialsOrdersCFM>();
				Object[] claimsarray = (Object[]) array.getArray();
				for (int i = 0; i < claimsarray.length; i++) {
					Struct struct = (Struct) claimsarray[i];
					Object[] obj = struct.getAttributes();
					String engineFamily = MaterialsDataUtil.getAsString(obj[19]);
					log.info("engineFamily" + engineFamily);
					if (isNotNullandEmpty(engineFamily)
							&& ("LEAP".equalsIgnoreCase(engineFamily) || ("CFM56".equalsIgnoreCase(engineFamily)))) {

						materialsOrders = new MaterialsOrdersCFM();
						materialsOrders.setCustomerNumber(MaterialsDataUtil.getAsString(obj[0]));
						// LOG.info("CustomerNumber"+(MaterialsDataUtil.getAsString(obj[0])));
						materialsOrders.setPurchaseOrderNumber(MaterialsDataUtil.getAsString(obj[1]));
						// LOG.info("Purchase
						// Order"+(MaterialsDataUtil.getAsString(obj[1])));

						// LOG.info("Invoice
						// Number"+(MaterialsDataUtil.getAsString(obj[2])).toString());
						materialsOrders.setCustomerLineNumber((MaterialsDataUtil.getAsString(obj[3])).toString());
						// LOG.info("Customer
						// LineNumber"+(MaterialsDataUtil.getAsString(obj[3])).toString());
						materialsOrders.setPartNumber(MaterialsDataUtil.getAsString(obj[4]));
						// LOG.info("part
						// Number"+(MaterialsDataUtil.getAsString(obj[4])));
						materialsOrders.setOrderStatus(MaterialsDataUtil.getAsString(obj[5]));
						// LOG.info("Status"+(MaterialsDataUtil.getAsString(obj[5])));
						materialsOrders.setRequestedQty((MaterialsDataUtil.getAsString(obj[6])).toString());
						// LOG.info("Rqty"+(MaterialsDataUtil.getAsString(obj[6])).toString());
						materialsOrders.setCancelledQty((MaterialsDataUtil.getAsString(obj[7])).toString());
						// LOG.info("Cqty"+(MaterialsDataUtil.getAsString(obj[7])).toString());
						materialsOrders.setShippedQty((MaterialsDataUtil.getAsString(obj[8])).toString());
						// LOG.info("Sqty"+(MaterialsDataUtil.getAsString(obj[8])).toString());
						materialsOrders.setInvoicedQuantity((MaterialsDataUtil.getAsString(obj[9])).toString());
						// LOG.info("Iqty"+(MaterialsDataUtil.getAsString(obj[9])).toString());
						materialsOrders.setOrderedDate(materialsDataUtil.getFormattedDate(
								(MaterialsDataUtil.getAsString(obj[10]).toString()), DATE_FORMAT1, DATE_FORMAT2));
						// LOG.info("Odate"+(getFormattedDate((MaterialsDataUtil.getAsString(obj[10]).toString()),"dd-MMM-yy","MM/dd/yyyy")));
						materialsOrders.setRequestDate(materialsDataUtil.getFormattedDate(
								(MaterialsDataUtil.getAsString(obj[11]).toString()), DATE_FORMAT1, DATE_FORMAT2));
						// LOG.info("Rdate"+(getFormattedDate((MaterialsDataUtil.getAsString(obj[11]).toString()),"dd-MMM-yy","MM/dd/yyyy")));
						materialsOrders.setDeliveryDate(materialsDataUtil.getFormattedDate(
								(MaterialsDataUtil.getAsString(obj[12]).toString()), DATE_FORMAT1, DATE_FORMAT2));
						// LOG.info("DDate"+(getFormattedDate((MaterialsDataUtil.getAsString(obj[12]).toString()),"dd-MMM-yy","MM/dd/yyyy")));
						materialsOrders.setShipmentDate(materialsDataUtil.getFormattedDate(
								(MaterialsDataUtil.getAsString(obj[13]).toString()), DATE_FORMAT1, DATE_FORMAT2));
						// LOG.info("SDate"+getFormattedDate((MaterialsDataUtil.getAsString(obj[13]).toString()),"dd-MMM-yy","MM/dd/yyyy"));
						materialsOrders.setSellingPrice((MaterialsDataUtil.getAsString(obj[14])).toString());
						// LOG.info("Selling
						// Price"+((MaterialsDataUtil.getAsString(obj[14])).toString()));
						materialsOrders.setListPrice((MaterialsDataUtil.getAsString(obj[15])).toString());
						// LOG.info("ListPRice"+(MaterialsDataUtil.getAsString(obj[15])).toString());
						materialsOrders.setExtendedPrice((MaterialsDataUtil.getAsString(obj[16])).toString());
						// LOG.info("ExtendedPrice"+(MaterialsDataUtil.getAsString(obj[16])).toString());
						materialsOrders.setMsNumber(MaterialsDataUtil.getAsString(obj[17]));
						// LOG.info("MSNumber"+MaterialsDataUtil.getAsString(obj[17]));
						materialsOrders.setOrderLineType(MaterialsDataUtil.getAsString(obj[21]));
						// LOG.info("OrderLinType"+(MaterialsDataUtil.getAsString(obj[21])));
						materialsOrdersList.add(materialsOrders);
					} else {
						break;
					}

				}
			}
		} catch (Exception e) {
			log.error("Exception occured while calling populatematerialsOrdersList" + e.getMessage());
			throw new TechnicalException(e.getMessage(), e.getCause());
		}

		return materialsOrdersList;
	}

	@Override
	public OrderListResponse materialsOrderListDS(MaterialsOrderRequest materialsOrderRequest, String portalId)
			throws TechnicalException {

		OrderListResponse materialsOrdersListResponse = new OrderListResponse();
		List<MaterialsOrders> materialsOrdersList = null;
		Connection connection = null;
		OracleConnection oracleConnection = null;
		CallableStatement callStatement = null;
		log.error("materialsOrdersListDSV2 start");
		
		try {
			String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_NEW_SPARES_EXPT_PO_DTLS_PRC);
			connection = ampsOraDS.getConnection();
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setString(1, materialsOrderRequest.getIcaoCode());
			log.info("icaoCode::" + materialsOrderRequest.getIcaoCode());
			log.info("custCode::" + materialsOrderRequest.getCustCode());

			callStatement.setString(2, materialsOrderRequest.getCustCode());

			callStatement.setString(3, materialsOrderRequest.getRequestDateFrom());
			// LOG.info("custCode::"+
			// materialsOrderRequest.getRequestDateFrom());
			callStatement.setString(4, materialsOrderRequest.getRequestDateTo());
			// LOG.info("requestDateTo::"+
			// materialsOrderRequest.getRequestDateTo());

			callStatement.setString(5, materialsOrderRequest.getOrderedDateFrom());
			// LOG.info("getOrderedDateFrom::"+
			// materialsOrderRequest.getOrderedDateFrom());
			callStatement.setString(6, materialsOrderRequest.getOrderedDateTo());
			// LOG.info("getOrderedDateFrom::"+
			// materialsOrderRequest.getOrderedDateFrom());

			callStatement.setString(7, materialsOrderRequest.getDeliveryDateFrom());
			// LOG.info("getDeliveryDateFrom::"+
			// materialsOrderRequest.getDeliveryDateFrom());

			callStatement.setString(8, materialsOrderRequest.getDeliveryDateTo());
			// LOG.info("getDeliveryDateTo::"+
			// materialsOrderRequest.getDeliveryDateTo());

			callStatement.setString(9, materialsOrderRequest.getShipmentDateFrom());
			// LOG.info("getShipmentDateFrom::"+
			// materialsOrderRequest.getShipmentDateFrom());

			callStatement.setString(10, materialsOrderRequest.getShipmentDateTo());

			// LOG.info("getShipmentDateTo::"+
			// materialsOrderRequest.getShipmentDateTo());

			callStatement.setString(11, materialsOrderRequest.getMsNumber());
			// LOG.info("getMsNumber::"+ materialsOrderRequest.getMsNumber());

			callStatement.setString(12, materialsOrderRequest.getMsNumberValue());
			// LOG.info("getMsNumberValue::"+
			// materialsOrderRequest.getMsNumberValue());

			callStatement.setString(13, materialsOrderRequest.getOrderLineType());
			// LOG.info("getOrderLineType::"+
			// materialsOrderRequest.getOrderLineType());

			callStatement.setString(14, materialsOrderRequest.getOrderLineTypeValue());
			// LOG.info("getOrderLineTypeValue::"+
			// materialsOrderRequest.getOrderLineTypeValue());

			callStatement.setString(15, materialsOrderRequest.getCustomerNumber());
			// LOG.info("getCustomerNumber::"+
			// materialsOrderRequest.getCustomerNumber());

			callStatement.setString(16, materialsOrderRequest.getCustomerNumberValue());
			// LOG.info("getCustomerNumberValue::"+
			// materialsOrderRequest.getCustomerNumberValue());

			callStatement.setString(17, materialsOrderRequest.getPurchaseOrder());
			// LOG.info("getPurchaseOrder::"+
			// materialsOrderRequest.getPurchaseOrder());

			callStatement.setString(18, materialsOrderRequest.getPurchareOrderValue());
			// LOG.info("getPurchareOrderValue::"+
			// materialsOrderRequest.getPurchareOrderValue());

			callStatement.setString(19, materialsOrderRequest.getInvoiceNumber());
			// LOG.info("getInvoiceNumber::"+
			// materialsOrderRequest.getInvoiceNumber());
			callStatement.setString(20, materialsOrderRequest.getInvoiceNumberValue());
			// LOG.info("getInvoiceNumberValue::"+
			// materialsOrderRequest.getInvoiceNumberValue());

			callStatement.setString(21, materialsOrderRequest.getCustomerLineNumber());
			// LOG.info("getCustomerLineNumber::"+
			// materialsOrderRequest.getCustomerLineNumber());

			callStatement.setString(22, materialsOrderRequest.getCustomerLineNumberValue());
			// LOG.info("getCustomerLineNumberValue::"+
			// materialsOrderRequest.getCustomerLineNumberValue());

			callStatement.setString(23, materialsOrderRequest.getOrderStatus());
			// LOG.info("getOrderStatus::"+
			// materialsOrderRequest.getOrderStatus());

			callStatement.setString(24, materialsOrderRequest.getOrderStatusValue());
			// LOG.info("getOrderStatusValue::"+
			// materialsOrderRequest.getOrderStatusValue());

			callStatement.setString(25, materialsOrderRequest.getPartNumber());
			// LOG.info("getPartNumber::"+
			// materialsOrderRequest.getPartNumber());

			callStatement.setString(26, materialsOrderRequest.getPartNumberValue());
			// LOG.info("getPartNumberValue::"+
			// materialsOrderRequest.getPartNumberValue());

			callStatement.setString(27, materialsOrderRequest.getRequestedQty());
			// LOG.info("getRequestedQty::"+
			// materialsOrderRequest.getRequestedQty());

			callStatement.setString(28, materialsOrderRequest.getRequestedQtyValue());
			// LOG.info("getRequestedQtyValue::"+
			// materialsOrderRequest.getRequestedQtyValue());

			callStatement.setString(29, materialsOrderRequest.getCancelledQty());
			// LOG.info("getCancelledQty::"+
			// materialsOrderRequest.getCancelledQty());

			callStatement.setString(30, materialsOrderRequest.getCancelledQtyValue());
			// LOG.info("getCancelledQtyValue::"+
			// materialsOrderRequest.getCancelledQtyValue());

			callStatement.setString(31, materialsOrderRequest.getShippedQty());
			// LOG.info("getShippedQty::"+
			// materialsOrderRequest.getShippedQty());

			callStatement.setString(32, materialsOrderRequest.getShippedQtyValue());
			// LOG.info("getShippedQtyValue::"+
			// materialsOrderRequest.getShippedQtyValue());

			callStatement.setString(33, materialsOrderRequest.getInvoicedQuantity());
			// LOG.info("getInvoicedQuantity::"+
			// materialsOrderRequest.getInvoicedQuantity());

			callStatement.setString(34, materialsOrderRequest.getInvoicedQuantityValue());
			// LOG.info("getInvoicedQuantityValue::"+
			// materialsOrderRequest.getInvoicedQuantityValue());

			callStatement.setString(35, materialsOrderRequest.getEngineFamily());
			// LOG.info("getEngineFamily::"+
			// materialsOrderRequest.getEngineFamily());

			callStatement.setString(36, materialsOrderRequest.getEngineFamilyValue());
			// LOG.info("getEngineFamilyValue::"+
			// materialsOrderRequest.getEngineFamilyValue());

			callStatement.setString(37, materialsOrderRequest.getOrderedDate());
			// LOG.info("getOrderedDate::"+
			// materialsOrderRequest.getOrderedDate());

			callStatement.setString(38, materialsOrderRequest.getRequestedDate());
			// LOG.info("getRequestedDate::"+
			// materialsOrderRequest.getRequestedDate());

			callStatement.setString(39, materialsOrderRequest.getAwbNumber());
			// LOG.info("getAwbNumber::"+ materialsOrderRequest.getAwbNumber());

			callStatement.setString(40, materialsOrderRequest.getAwbNumberValue());
			// LOG.info("getAwbNumberValue::"+
			// materialsOrderRequest.getAwbNumberValue());

			callStatement.setString(41, materialsOrderRequest.getDeliveryDate());
			// LOG.info("getDeliveryDate::"+
			// materialsOrderRequest.getDeliveryDate());

			callStatement.setString(42, materialsOrderRequest.getShippmentDate());
			// LOG.info("getShippmentDate::"+
			// materialsOrderRequest.getShippmentDate());

			callStatement.setString(43, materialsOrderRequest.getSellingPrice());
			// LOG.info("getSellingPrice::"+
			// materialsOrderRequest.getSellingPrice());

			callStatement.setString(44, materialsOrderRequest.getSellingPriceValue());
			// LOG.info("getSellingPriceValue::"+
			// materialsOrderRequest.getSellingPriceValue());

			callStatement.setString(45, materialsOrderRequest.getListPrice());
			// LOG.info("getListPrice::"+ materialsOrderRequest.getListPrice());

			callStatement.setString(46, materialsOrderRequest.getListPriceValue());
			// LOG.info("getListPriceValue::"+
			// materialsOrderRequest.getListPriceValue());

			callStatement.setString(47, materialsOrderRequest.getExtendedPrice());
			// LOG.info("getExtendedPrice::"+
			// materialsOrderRequest.getExtendedPrice());

			callStatement.setString(48, materialsOrderRequest.getExtendedPriceValue());
			// LOG.info("getExtendedPriceValue::"+
			// materialsOrderRequest.getExtendedPriceValue());

			callStatement.setString(49, materialsOrderRequest.getEngineModel());
			// LOG.info("getEngineModel::"+
			// materialsOrderRequest.getEngineModel());

			callStatement.setString(50, materialsOrderRequest.getEngineModelValue());
			// LOG.info("getEngineModelValue::"+
			// materialsOrderRequest.getEngineModelValue());

			// LOG.info("materialsOrderRequest.getOrderByColumn()"+materialsOrderRequest.getOrderByColumn());

			// LOG.info("materialsOrderRequest.getSortType"+materialsOrderRequest.getSortType());

			callStatement.setString(51, materialsOrderRequest.getOrderByColumn());
			callStatement.setString(52, materialsOrderRequest.getSortType());

			callStatement.registerOutParameter(53, OracleTypes.ARRAY, "APPS.V_PO_EXPORT_DETAILS_LIST_ARRAY");
			callStatement.registerOutParameter(54, OracleTypes.VARCHAR);
			callStatement.registerOutParameter(55, OracleTypes.VARCHAR);

			callStatement.execute();

			Array materialsOrderssList = (Array) callStatement.getArray(53);
			materialsOrdersList = populateMataerialsOrderList(materialsOrderssList, portalId);
			log.info("materialsOrdersList::" + materialsOrdersList.size());
			String message = (String) callStatement.getObject(54);
			log.info("message::" + message);
			materialsOrdersListResponse.setStatus(message);

			String totalRecords = (String) callStatement.getObject(55);
			log.info("totalRecords::" + totalRecords);
			if (!MaterialsDataUtil.isNullOrEmpty((String) callStatement.getObject(55))) {
				materialsOrdersListResponse.setTotalRecords(Integer.parseInt((String) callStatement.getObject(55)));
			}
			// materialsOrdersListResponse.setTotalRecords(Integer.parseInt("1"));
			materialsOrdersListResponse.setOrdersList(materialsOrdersList);
			log.info("materialsOrdersListDSV2 method - END");
		} catch (SQLException e) {
			log.error("Exception occured while calling materialsOrdersListDSV2 data service : " + e.getMessage());
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return materialsOrdersListResponse;
	}
	

	private List<MaterialsOrders> populateMataerialsOrderList(Array array, String portalId) {
		log.info("Inside the method populatematerialsOrdersList : Datalayer");
		List<MaterialsOrders> materialsOrdersList = null;
		MaterialsOrders materialsOrders = null;
		try {
			if (null != array) {
				materialsOrdersList = new ArrayList<MaterialsOrders>();
				Object[] claimsarray = (Object[]) array.getArray();
				for (int i = 0; i < claimsarray.length; i++) {
					Struct struct = (Struct) claimsarray[i];
					Object[] obj = struct.getAttributes();
					String engineFamily = MaterialsDataUtil.getAsString(obj[19]);
					if (isNotNullandEmpty(engineFamily)
							&& ("LEAP".equalsIgnoreCase(engineFamily) || ("CFM56".equalsIgnoreCase(engineFamily)))) {
						break;
					} else {
						materialsOrders = new MaterialsOrders();
						materialsOrders.setCustomerNumber(MaterialsDataUtil.getAsString(obj[0]));
						// LOG.info("CustomerNumber"+(MaterialsDataUtil.getAsString(obj[0])));
						materialsOrders.setPurchaseOrderNumber(MaterialsDataUtil.getAsString(obj[1]));
						// LOG.info("Purchase
						// Order"+(MaterialsDataUtil.getAsString(obj[1])));
						materialsOrders.setInvoiceNumber((MaterialsDataUtil.getAsString(obj[2])).toString());
						// LOG.info("Invoice
						// Number"+(MaterialsDataUtil.getAsString(obj[2])).toString());
						materialsOrders.setCustomerLineNumber((MaterialsDataUtil.getAsString(obj[3])).toString());
						// LOG.info("Customer
						// LineNumber"+(MaterialsDataUtil.getAsString(obj[3])).toString());
						materialsOrders.setPartNumber(MaterialsDataUtil.getAsString(obj[4]));
						// LOG.info("part
						// Number"+(MaterialsDataUtil.getAsString(obj[4])));
						materialsOrders.setOrderStatus(MaterialsDataUtil.getAsString(obj[5]));
						// LOG.info("Status"+(MaterialsDataUtil.getAsString(obj[5])));
						materialsOrders.setRequestedQty((MaterialsDataUtil.getAsString(obj[6])).toString());
						// LOG.info("Rqty"+(MaterialsDataUtil.getAsString(obj[6])).toString());
						materialsOrders.setCancelledQty((MaterialsDataUtil.getAsString(obj[7])).toString());
						// LOG.info("Cqty"+(MaterialsDataUtil.getAsString(obj[7])).toString());
						materialsOrders.setShippedQty((MaterialsDataUtil.getAsString(obj[8])).toString());
						// LOG.info("Sqty"+(MaterialsDataUtil.getAsString(obj[8])).toString());
						materialsOrders.setInvoicedQuantity((MaterialsDataUtil.getAsString(obj[9])).toString());
						// LOG.info("Iqty"+(MaterialsDataUtil.getAsString(obj[9])).toString());
						materialsOrders.setOrderedDate(materialsDataUtil.getFormattedDate(
								(MaterialsDataUtil.getAsString(obj[10]).toString()), DATE_FORMAT1, DATE_FORMAT2));
						// LOG.info("Odate"+(getFormattedDate((MaterialsDataUtil.getAsString(obj[10]).toString()),"dd-MMM-yy","MM/dd/yyyy")));
						materialsOrders.setRequestDate(materialsDataUtil.getFormattedDate(
								(MaterialsDataUtil.getAsString(obj[11]).toString()), DATE_FORMAT1, DATE_FORMAT2));
						// LOG.info("Rdate"+(getFormattedDate((MaterialsDataUtil.getAsString(obj[11]).toString()),"dd-MMM-yy","MM/dd/yyyy")));
						materialsOrders.setDeliveryDate(materialsDataUtil.getFormattedDate(
								(MaterialsDataUtil.getAsString(obj[12]).toString()), DATE_FORMAT1, DATE_FORMAT2));
						// LOG.info("DDate"+(getFormattedDate((MaterialsDataUtil.getAsString(obj[12]).toString()),"dd-MMM-yy","MM/dd/yyyy")));
						materialsOrders.setShipmentDate(materialsDataUtil.getFormattedDate(
								(MaterialsDataUtil.getAsString(obj[13]).toString()), DATE_FORMAT1, DATE_FORMAT2));
						// LOG.info("SDate"+getFormattedDate((MaterialsDataUtil.getAsString(obj[13]).toString()),"dd-MMM-yy","MM/dd/yyyy"));
						materialsOrders.setSellingPrice((MaterialsDataUtil.getAsString(obj[14])).toString());
						// LOG.info("Selling
						// Price"+((MaterialsDataUtil.getAsString(obj[14])).toString()));
						materialsOrders.setListPrice((MaterialsDataUtil.getAsString(obj[15])).toString());
						// LOG.info("ListPRice"+(MaterialsDataUtil.getAsString(obj[15])).toString());
						materialsOrders.setExtendedPrice((MaterialsDataUtil.getAsString(obj[16])).toString());
						// LOG.info("ExtendedPrice"+(MaterialsDataUtil.getAsString(obj[16])).toString());
						materialsOrders.setMsNumber(MaterialsDataUtil.getAsString(obj[17]));
						// LOG.info("MSNumber"+MaterialsDataUtil.getAsString(obj[17]));
						materialsOrders.setAwbNumber(MaterialsDataUtil.getAsString(obj[18]));
						// LOG.info("AWbNumber"+(MaterialsDataUtil.getAsString(obj[18])));
						materialsOrders.setEngineFamily(MaterialsDataUtil.getAsString(obj[19]));
						// LOG.info("EngineFamily"+(MaterialsDataUtil.getAsString(obj[19])));
						materialsOrders.setEngineModel(MaterialsDataUtil.getAsString(obj[20]));
						// LOG.info("EngnineModel"+(MaterialsDataUtil.getAsString(obj[20])));

						materialsOrders.setOrderLineType(MaterialsDataUtil.getAsString(obj[21]));
						// LOG.info("OrderLinType"+(MaterialsDataUtil.getAsString(obj[21])));
						materialsOrdersList.add(materialsOrders);
					}

				}
			}
		} catch (Exception e) {
			log.error("Exception occured while calling populatematerialsOrdersList" + e.getMessage());
			throw new TechnicalException(e.getMessage(), e.getCause());
		}

		return materialsOrdersList;
	}
	
	/**
	 * @param sso
	 * @param icao
	 * @param custIdArray
	 * @param role
	 * @param operatingUnitId
	 * @param invoiceId
	 * @return InvoiceDocDO object
	 * @throws TechnicalException
	 **/
	@Override
	public InvoiceDocDO getInvoiceDocDS(String strSSO,String icaoCode,String[] custIdList ,String role,
			String operatingUnitId,String invoiceId) throws TechnicalException {
		String procStr  = null;
		Connection connection = null;
		//Connection delConnection = null;
		CallableStatement callStatement = null;
		InvoiceDocDO invoiceDocDO = null;
		byte[] bytes=null;
		try {
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_INVOICE_FILE_RETURN);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
			oracleConnection = connection.unwrap(OracleConnection.class);
			}
			//delConnection = getDelegatingConnection(connection);
			ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
			ARRAY custArray = new ARRAY(descrip,oracleConnection,custIdList);
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
			callStatement.setString(1, strSSO.toUpperCase());
			callStatement.setString(2, icaoCode);
			callStatement.setArray(3, custArray);
			callStatement.setString(4, role);
			callStatement.setString(5,operatingUnitId);
			callStatement.setInt(6, Integer.parseInt(invoiceId));
			callStatement.registerOutParameter(7, OracleTypes.BLOB);
			callStatement.registerOutParameter(8, OracleTypes.VARCHAR);//file name
			callStatement.registerOutParameter(9, OracleTypes.VARCHAR);//P message
			callStatement.execute();
			String message = (String) callStatement.getObject(9);
			invoiceDocDO = new InvoiceDocDO();
			if(MaterialsDataUtil.isNotNullandEmpty(message)){
				invoiceDocDO.setP_msg(message);
				return invoiceDocDO;
			}
			String fileName = (String) callStatement.getObject(8);
			if(MaterialsDataUtil.isNotNullandEmpty(fileName)){
				invoiceDocDO.setFileName(fileName);
			}
			Blob  fileBlob  = (Blob) callStatement.getObject(7);
			bytes = fileBlob.getBytes(1, (int) fileBlob.length());
			if(bytes.length > 0){
				invoiceDocDO.setFileBlob(bytes);
			}	
		}catch (Exception e) {
			log.info(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return invoiceDocDO;	
	}

	@Override
	public boolean isMSDocRequestExist(String docnumber,String docTypeCd,String emailId)throws TechnicalException {
		Connection connection = null;
		OracleConnection oracleConnection = null;
		PreparedStatement pstmt = null;
		ResultSet results = null;
		try {
			connection = wciOraDS.getConnection();
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			String query =" SELECT * "+
					"FROM wci_email_request "+
					"WHERE lower(doc_number)=lower(?) " +
					"AND doc_type_cd        =? "+
					"AND user_email=? "+
					"AND mail_required_ind  ='Y' "+
					"AND complete_date is null "; 
			pstmt = oracleConnection.prepareStatement(query);
			pstmt.setString(1, docnumber);
			pstmt.setString(2, docTypeCd);
			pstmt.setString(3, emailId);
			results = pstmt.executeQuery();
			if (results.next()) {
				return false;
			} else {
				return true;
			}	
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {
			materialsDataUtil.releaseResources(connection, pstmt, null);
			try {
				results.close();
			} catch (SQLException e) {
				log.error(e);
			}
		}

	}

	@Override
	public int requestEmailMaterialsDocDS(String docType,String docnumber,String docversion,String userId,String userEmail)throws TechnicalException {
		Connection connection = null;
		OracleConnection oracleConnection = null;
		PreparedStatement pstmt = null;
		int results =0;
		int docVersion = 0;
		try {
			if(docversion != null)
			{
				docVersion =  Integer.parseInt(docversion);
			}
			connection = wciOraDS.getConnection();
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			String query = "INSERT INTO WCI_EMAIL_REQUEST"+
					" (EMAIL_REQUEST_SEQ_ID, USER_ID, DOC_TYPE_CD, DOC_NUMBER, DOC_VERSION, " +
					" REQUEST_DATE, USER_EMAIL, COMPLETE_DATE, REQUEST_STATUS, MAIL_SENT_IND," +
					" CREATION_DATE, CREATED_BY, LAST_UPDATE_DATE, LAST_UPDATED_BY, MAIL_REQUIRED_IND, SITE_CD)"+
					" VALUES "+
					" (WCI_EMAIL_REQUEST_SEQ.NEXTVAL," +
					" ?,?,?,?,sysdate,?,null,'N','N',sysdate,?,sysdate,?,'Y','E')";	
			pstmt = oracleConnection.prepareStatement(query);
			pstmt.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
			pstmt.setString(1, userId);
			pstmt.setString(2, docType);
			pstmt.setString(3, docnumber);
			pstmt.setInt(4, docVersion);
			pstmt.setString(5, userEmail);
			pstmt.setString(6, userId);
			pstmt.setString(7, userId);
			results = pstmt.executeUpdate();
			connection.commit();
		} catch (Exception e) {
			log.error(e);
			try {
				connection.rollback();
			} catch (SQLException sqlExce) {
				log.info(sqlExce);
				throw new TechnicalException(sqlExce.getMessage(), sqlExce.getCause());
			}
			throw new TechnicalException(e.getMessage(), e.getCause());
		} finally {
			materialsDataUtil.releaseResources(connection, pstmt, null);
		}
		return results;
	}

	@Override
	public LineDetailDO getLineDetailDS(String strSSO, String icaoCode,	String[] custIdList, String role, String operatingUnitId,
			String msNumber, String deliveryId, String orderHeaderId, String invoiceHeaderId) {
		String procStr  = null;
		Connection connection = null;
		//Connection delConnection = null;
		CallableStatement callStatement = null;
		LineDetailDO lineDetailDO = null;
		List<LineInfoDO> lineInfoDOList = null;
		Array lineInfoArray  = null;

		String message = null;
		try {
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_GET_ORDER_LINE_INFO);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
			oracleConnection = connection.unwrap(OracleConnection.class);
			}
			ArrayDescriptor descrip = ArrayDescriptor.createDescriptor(APPSVCUSTIDARRAY,oracleConnection); 
			ARRAY custArray = new ARRAY(descrip,oracleConnection,custIdList);
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setQueryTimeout(queryTimeOutSecs);
			callStatement.setString(1, strSSO.toUpperCase());
			callStatement.setString(2, icaoCode);
			callStatement.setArray(3, custArray);
			callStatement.setString(4, role);
			callStatement.setString(5, operatingUnitId);
			callStatement.setString(6, msNumber);
			callStatement.setString(7,deliveryId);
			callStatement.setString(8, orderHeaderId);
			callStatement.setString(9, invoiceHeaderId);
			callStatement.registerOutParameter(10, OracleTypes.ARRAY, "APPS.V_ORDER_LINE_INFO_ARRAY");
			callStatement.registerOutParameter(11, OracleTypes.VARCHAR);
			callStatement.execute();
			message = (String) callStatement.getObject(11);
			lineDetailDO = new LineDetailDO();
			if(isNotNullandEmpty(message)){
				lineDetailDO.setMessage(message);
				return lineDetailDO;
			}
			lineInfoDOList = new ArrayList<LineInfoDO>();
			lineInfoArray = (Array) callStatement.getArray(10);
			lineInfoDOList = populateLineDetail(lineInfoArray);
			lineDetailDO.setLineInfoDOList(lineInfoDOList);
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return lineDetailDO;
	}
	
	
	private List<LineInfoDO> populateLineDetail(Array array) {
		List<LineInfoDO> lineInfoDOList = new ArrayList<LineInfoDO>(); 
		LineInfoDO lineInfoDO = null;
		try {
			if (null != array) {
				Object[] returnrecordarray = (Object[]) array.getArray();
				for (int i = 0; i < returnrecordarray.length; i++) {
					Struct struct = (Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					lineInfoDO = new LineInfoDO();

					lineInfoDO.setLineId(MaterialsDataUtil.getAsString(obj[0]));
					lineInfoDO.setOrganisationId(MaterialsDataUtil.getAsString(obj[1]));
					lineInfoDO.setHeaderId(MaterialsDataUtil.getAsString(obj[2]));
					lineInfoDO.setLineNumber(MaterialsDataUtil.getAsString(obj[3]));
					lineInfoDO.setOrderedItem(MaterialsDataUtil.getAsString(obj[4]));
					lineInfoDO.setRequestDateTime((Timestamp)obj[5]);
					lineInfoDO.setPromiseDateTime((Timestamp)obj[6]);
					lineInfoDO.setScheduleArrivalDateTime((Timestamp)obj[7]);
					lineInfoDO.setScheduleShipDateTime((Timestamp)obj[8]);
					lineInfoDO.setOrderQuantityUnitOfMeasure(MaterialsDataUtil.getAsString(obj[9]));

					lineInfoDO.setCanceledQuantity(MaterialsDataUtil.getAsString(obj[10]));
					lineInfoDO.setShippedQuantity(MaterialsDataUtil.getAsString(obj[11]));
					lineInfoDO.setOrderedQuantity(MaterialsDataUtil.getAsString(obj[12]));
					lineInfoDO.setFulfilledQuantity(MaterialsDataUtil.getAsString(obj[13]));
					lineInfoDO.setShippingQuantity(MaterialsDataUtil.getAsString(obj[14]));
					lineInfoDO.setTaxExemptFlag(MaterialsDataUtil.getAsString(obj[15]));
					lineInfoDO.setTaxExemptNumber(MaterialsDataUtil.getAsString(obj[16]));
					lineInfoDO.setTaxExemptReasonCode(MaterialsDataUtil.getAsString(obj[17]));
					lineInfoDO.setCustPONumber(MaterialsDataUtil.getAsString(obj[18]));
					lineInfoDO.setSoldToOrgId(MaterialsDataUtil.getAsString(obj[19]));

					lineInfoDO.setShipFromOrgId(MaterialsDataUtil.getAsString(obj[20]));
					lineInfoDO.setShipToOrgId(MaterialsDataUtil.getAsString(obj[21]));
					lineInfoDO.setDeliverToOrgId(MaterialsDataUtil.getAsString(obj[22]));
					lineInfoDO.setInvoiceToOrgId(MaterialsDataUtil.getAsString(obj[23]));
					lineInfoDO.setInventoryItemId(MaterialsDataUtil.getAsString(obj[24]));
					lineInfoDO.setTaxCode(MaterialsDataUtil.getAsString(obj[25]));
					lineInfoDO.setTaxRate(MaterialsDataUtil.getAsString(obj[26]));
					lineInfoDO.setScheduleStatusCode(MaterialsDataUtil.getAsString(obj[27]));
					lineInfoDO.setPriceListId(MaterialsDataUtil.getAsString(obj[28]));
					lineInfoDO.setPricingDateTime((Timestamp)obj[29]);

					lineInfoDO.setShipmentNumber(MaterialsDataUtil.getAsString(obj[30]));
					lineInfoDO.setShipmentPriorityCode(MaterialsDataUtil.getAsString(obj[31]));
					lineInfoDO.setShippingMethod(MaterialsDataUtil.getAsString(obj[32]));
					lineInfoDO.setFreightTermsCode(MaterialsDataUtil.getAsString(obj[33]));
					lineInfoDO.setFreightCarrierCode(MaterialsDataUtil.getAsString(obj[34]));
					lineInfoDO.setFobPoint(MaterialsDataUtil.getAsString(obj[35]));
					lineInfoDO.setPaymentTermId(MaterialsDataUtil.getAsString(obj[36]));
					lineInfoDO.setReturnContext(MaterialsDataUtil.getAsString(obj[37]));
					lineInfoDO.setCountryOfOriginStr(MaterialsDataUtil.getAsString(obj[38]));
					lineInfoDO.setReturnAttribute1(MaterialsDataUtil.getAsString(obj[39]));

					lineInfoDO.setReturnAttribute2(MaterialsDataUtil.getAsString(obj[40]));
					lineInfoDO.setUnitSellingPrice(MaterialsDataUtil.getAsString(obj[41]));
					lineInfoDO.setUnitListPrice(MaterialsDataUtil.getAsString(obj[42]));
					lineInfoDO.setExternalPrice(MaterialsDataUtil.getAsString(obj[43]));
					lineInfoDO.setTaxValue(MaterialsDataUtil.getAsString(obj[44]));
					lineInfoDO.setCreationDateTime((Timestamp)obj[45]);
					lineInfoDO.setCreatedBy(MaterialsDataUtil.getAsString(obj[46]));
					lineInfoDO.setLastUpdateDateTime((Timestamp)obj[47]);
					lineInfoDO.setLastUpdatedBy(MaterialsDataUtil.getAsString(obj[48]));
					lineInfoDO.setItemTypeCode(MaterialsDataUtil.getAsString(obj[49]));

					lineInfoDO.setComponentNumber(MaterialsDataUtil.getAsString(obj[50]));
					lineInfoDO.setActualShipmentDateTime((Timestamp)obj[51]);
					lineInfoDO.setLineType(MaterialsDataUtil.getAsString(obj[52]));
					lineInfoDO.setPriceList(MaterialsDataUtil.getAsString(obj[53]));
					lineInfoDO.setPaymentTerm(MaterialsDataUtil.getAsString(obj[54]));
					lineInfoDO.setSoldTo(MaterialsDataUtil.getAsString(obj[55]));
					lineInfoDO.setCustomerNumber(MaterialsDataUtil.getAsString(obj[56]));
					lineInfoDO.setShipFrom(MaterialsDataUtil.getAsString(obj[57]));
					lineInfoDO.setShipToLocation(MaterialsDataUtil.getAsString(obj[58]));
					lineInfoDO.setShipToAddress1(MaterialsDataUtil.getAsString(obj[59]));
					lineInfoDO.setShipToAddress2(MaterialsDataUtil.getAsString(obj[60]));

					lineInfoDO.setShipToAddress3(MaterialsDataUtil.getAsString(obj[61]));
					lineInfoDO.setShipToAddress4(MaterialsDataUtil.getAsString(obj[62]));
					lineInfoDO.setShipToAddress5(MaterialsDataUtil.getAsString(obj[63]));
					lineInfoDO.setDeliverToLocation(MaterialsDataUtil.getAsString(obj[64]));
					lineInfoDO.setDeliverToAddress1(MaterialsDataUtil.getAsString(obj[65]));
					lineInfoDO.setDeliverToAddress2(MaterialsDataUtil.getAsString(obj[66]));
					lineInfoDO.setDeliverToAddress3(MaterialsDataUtil.getAsString(obj[67]));
					lineInfoDO.setDeliverToAddress4(MaterialsDataUtil.getAsString(obj[68]));
					lineInfoDO.setDeliverToAddress5(MaterialsDataUtil.getAsString(obj[69]));
					lineInfoDO.setInvoiceToLocation(MaterialsDataUtil.getAsString(obj[70]));

					lineInfoDO.setInvoiceToAddress1(MaterialsDataUtil.getAsString(obj[71]));
					lineInfoDO.setInvoiceToAddress2(MaterialsDataUtil.getAsString(obj[72]));
					lineInfoDO.setInvoiceToAddress3(MaterialsDataUtil.getAsString(obj[73]));
					lineInfoDO.setInvoiceToAddress4(MaterialsDataUtil.getAsString(obj[74]));
					lineInfoDO.setInvoiceToAddress5(MaterialsDataUtil.getAsString(obj[75]));
					lineInfoDO.setOrderNumber(MaterialsDataUtil.getAsString(obj[76]));
					lineInfoDO.setQuoteNumber(MaterialsDataUtil.getAsString(obj[77]));
					lineInfoDO.setOrderTypeId(MaterialsDataUtil.getAsString(obj[78]));
					lineInfoDO.setOrderedDateTime((Timestamp)obj[79]);
					lineInfoDO.setReturnReason(MaterialsDataUtil.getAsString(obj[80]));

					lineInfoDO.setSplitFromLineId(MaterialsDataUtil.getAsString(obj[81]));
					lineInfoDO.setShipSetId(MaterialsDataUtil.getAsString(obj[82]));
					lineInfoDO.setPlanningPriority(MaterialsDataUtil.getAsString(obj[83]));
					lineInfoDO.setShippingInstructions(MaterialsDataUtil.getAsString(obj[84]));
					lineInfoDO.setPackingInstructions(MaterialsDataUtil.getAsString(obj[85]));
					lineInfoDO.setInvoicedQuantity(MaterialsDataUtil.getAsString(obj[86]));
					lineInfoDO.setFlowStatus(MaterialsDataUtil.getAsString(obj[87]));
					lineInfoDO.setCustomerLineNumber(MaterialsDataUtil.getAsString(obj[88]));
					lineInfoDO.setOriginalOrderedItem(MaterialsDataUtil.getAsString(obj[89]));
					lineInfoDO.setOrderSource(MaterialsDataUtil.getAsString(obj[90]));

					lineInfoDO.setKeyword(MaterialsDataUtil.getAsString(obj[91]));
					lineInfoDO.setPartNomenclature(MaterialsDataUtil.getAsString(obj[92]));
					lineInfoDO.setSalesPerson(MaterialsDataUtil.getAsString(obj[93]));
					lineInfoDO.setDeliveryId(MaterialsDataUtil.getAsString(obj[94]));
					lineInfoDO.setInvoiceNumber(MaterialsDataUtil.getAsString(obj[95]));
					lineInfoDO.setDiscountPercent(MaterialsDataUtil.getAsString(obj[96]));
					lineInfoDO.setDiscountAmount(MaterialsDataUtil.getAsString(obj[97]));
					lineInfoDO.setInvoiceDateTime((Timestamp)obj[98]);
					lineInfoDO.setTotalInvoiceValue(MaterialsDataUtil.getAsString(obj[99]));
					lineInfoDO.setOriginalPOForReturn(MaterialsDataUtil.getAsString(obj[100]));

					lineInfoDO.setCancelUpdateAllowedFlag(MaterialsDataUtil.getAsString(obj[101]));
					lineInfoDO.setShipmentDisputeAllowedFlag(MaterialsDataUtil.getAsString(obj[102]));
					lineInfoDO.setMsNumber(MaterialsDataUtil.getAsString(obj[103]));
					lineInfoDO.setShippingStatusStr(MaterialsDataUtil.getAsString(obj[104]));
					lineInfoDO.setShipmentQuantity(MaterialsDataUtil.getAsString(obj[105]));
					lineInfoDO.setDimensions(MaterialsDataUtil.getAsString(obj[106]));
					lineInfoDO.setGrossWeight(MaterialsDataUtil.getAsString(obj[107]));
					lineInfoDO.setSerialNumbers(materialsDataUtil.splitString(MaterialsDataUtil.getAsString(obj[108]),"|"));
					lineInfoDO.setLinkToCarrier(MaterialsDataUtil.getAsString(obj[109]));

					lineInfoDO.setReturnCountryOfOrigin(MaterialsDataUtil.getAsString(obj[110]));
					lineInfoDO.setUpq(MaterialsDataUtil.getAsString(obj[111]));
					lineInfoDO.setInvoiceId(MaterialsDataUtil.getAsString(obj[112]));
					lineInfoDO.setQuantityUpdateAllowedFlag(MaterialsDataUtil.getAsString(obj[113]));
					lineInfoDO.setShipToAddress(MaterialsDataUtil.getAsString(obj[114]));
					lineInfoDO.setDeliverToAddress(MaterialsDataUtil.getAsString(obj[115]));
					lineInfoDO.setInvoiceToAddress(MaterialsDataUtil.getAsString(obj[116]));
					lineInfoDO.setOrderLineESN(MaterialsDataUtil.getAsString(obj[117]));
					lineInfoDO.setDisputeCreated(MaterialsDataUtil.getAsString(obj[118]));
					lineInfoDO.setCriticalPartFlag(MaterialsDataUtil.getAsString(obj[119]));
					lineInfoDOList.add(lineInfoDO);
				}
			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return lineInfoDOList;
	}

	/**
	 * @param array
	 * @return OrderDO
	 */
	private OrderDO populateOrderDetailsValues(Array array) {
		OrderDO custObj = null;
		try {
			if (null != array) {
				Object[] returnrecordarray = (Object[]) array.getArray();
				for (int i = 0; i < returnrecordarray.length; i++) {
					Struct struct = (Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					custObj = new OrderDO();
					custObj.setOrderNumber(MaterialsDataUtil.getAsString(obj[0]));
					custObj.setOrderDate(MaterialsDataUtil.getAsString(obj[1]));
					custObj.setOrderStatus(MaterialsDataUtil.getAsString(obj[2]));
					custObj.setCustCode(MaterialsDataUtil.getAsString(obj[3]));
					custObj.setCustName(MaterialsDataUtil.getAsString(obj[4]));
					custObj.setCustId(MaterialsDataUtil.getAsString(obj[5]));
				}
			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return custObj;
	}
	
	/**
	 * @param sso
	 * @param icao
	 * @param custIds
	 * @param role
	 * @param operatingUnitId
	 * @param headerId
	 * @return OrderDO object
	 * @throws TechnicalException
	 **/
	@Override
	public OrderDO getOrderDetailsDS(String strSSO,String icaoCd,String custIds,String role,String opUid,String headerId) throws TechnicalException{
		OrderDO orderDO = null;
		Connection connection = null;
		CallableStatement callStatement = null;
		String procStr = null;
		try{
			procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_ORDER_DETAILS_DETAILS);
			connection = ampsOraDS.getConnection();
			callStatement = connection.prepareCall(procStr);
			callStatement.setQueryTimeout(queryTimeOutSecs);
			callStatement.setString(1, strSSO.toUpperCase());
			callStatement.setString(2, icaoCd);
			callStatement.setString(3, custIds );
			callStatement.setString(4, role);
			callStatement.setString(5, opUid);
			callStatement.setString(6, headerId);
			callStatement.registerOutParameter(7, OracleTypes.ARRAY, "APPS.V_ORDER_HDR_ARRAY");
			callStatement.registerOutParameter(8, OracleTypes.VARCHAR);
			callStatement.execute();
			String message = (String) callStatement.getObject(8);
			orderDO = new OrderDO();
			if(isNotNullandEmpty(message) ){
				orderDO.setMessage(message);
				return orderDO;
			}
			Array orderDetailsArray = (Array) callStatement.getArray(7);
			orderDO = populateOrderDetailsValues(orderDetailsArray);
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		return orderDO;
	}
}
