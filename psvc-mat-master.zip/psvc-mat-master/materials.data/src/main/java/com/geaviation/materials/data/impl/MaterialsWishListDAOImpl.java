package com.geaviation.materials.data.impl;

import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.EMPTY_STRING;
import static com.geaviation.materials.data.impl.util.MaterialsDataUtil.getAsString;

import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.data.api.IMaterialsWishListDAO;
import com.geaviation.materials.data.impl.util.MaterialsDataConstants;
import com.geaviation.materials.data.impl.util.MaterialsQueryLoader;
import com.geaviation.materials.entity.DeleteWishListBO;
import com.geaviation.materials.entity.InsertWishListResponse;
import com.geaviation.materials.entity.WishListDetailsBO;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

@Component
public class MaterialsWishListDAOImpl implements IMaterialsWishListDAO {

	private static final Log log = LogFactory.getLog(MaterialsWishListDAOImpl.class);
	@Autowired
	private DataSource ampsOraDS;
	
	@Value("${QUERY_TIME_OUT_SECS}")
	private int QUERY_TIME_OUT_SECS;
	
	@Override
	public InsertWishListResponse insertWishListDS(String strSSO,
			String icaoCode, String operatingUnitId, String partNumber) {
		
		Connection connection = null;
		CallableStatement callStatement = null;
		String message;
		InsertWishListResponse response = new InsertWishListResponse();
		
		String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_WISHLT_INSERT);
		
		try {
			connection = ampsOraDS.getConnection();
			callStatement = connection.prepareCall(procStr);
			callStatement.setQueryTimeout(QUERY_TIME_OUT_SECS);//Refer config file for # of secs
			callStatement.setString(1, strSSO.toUpperCase());
			callStatement.setString(2, icaoCode);
			callStatement.setString(3, operatingUnitId);
			callStatement.setString(4, partNumber);
			callStatement.registerOutParameter(5, OracleTypes.VARCHAR);
			callStatement.registerOutParameter(6, OracleTypes.VARCHAR);
			callStatement.execute();
			message = (String) callStatement.getObject(5);
			String p_message = (String) callStatement.getObject(6);
			if(isNotNullandEmpty(message) && isNotNullandEmpty(p_message) ){
				response.setMessage(message);
				response.setP_message(p_message);
				
			}
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			releaseResources(connection, callStatement, null);
		}
		
		return response;
	}

	@Override
	public List<WishListDetailsBO> getWishListDetailsDS(String strSSO,
			String icaoCode, String operatingUnitId,String[] custIdArray,String role) throws TechnicalException {
		
		Array cartDetailsOut  = null;
		String message;
		WishListDetailsBO response = new WishListDetailsBO();
		Connection connection = null;
		List<WishListDetailsBO> wishListDetailsBOList = new ArrayList<WishListDetailsBO>();
		CallableStatement callStatement = null;
		ArrayDescriptor descrip  = null;
		ARRAY custArray = null;
		try{
		    String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_WISHLT_FETCH_DETAILS);
            connection = ampsOraDS.getConnection();
            OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
		    descrip = ArrayDescriptor.createDescriptor("APPS.V_CUST_ID_ARRAY",oracleConnection); 
		    custArray = new ARRAY(descrip,oracleConnection,custIdArray);
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setQueryTimeout(QUERY_TIME_OUT_SECS);//Refer config file for # of secs
			callStatement.setString(1, strSSO.toUpperCase());
			callStatement.setString(2, icaoCode);
			callStatement.setString(3, role);
			callStatement.setString(4, operatingUnitId);
			callStatement.setArray(5, custArray);
		    callStatement.registerOutParameter(6, OracleTypes.ARRAY, "APPS.V_BULK_PART_DETAILS");
			callStatement.registerOutParameter(7, OracleTypes.VARCHAR);
			callStatement.execute();
			message = (String) callStatement.getObject(7);
		
		
				cartDetailsOut = (Array) callStatement.getArray(6);
			
				
				if(!isNotNullandEmpty(message)){
					wishListDetailsBOList = populateWishListDetails(cartDetailsOut);
				} else {
					response.setMessage(message);
					wishListDetailsBOList.add(response);
				}
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			releaseResources(connection, callStatement, null);
		}
		
		
		return wishListDetailsBOList;
	}

	@Override
	public List<DeleteWishListBO>  deleteWishListDS(String strSSO, String portalId,
			String[] partNumberArr,String icaoCode) throws TechnicalException {
		Connection connection = null;
		CallableStatement callStatement = null;
		List<DeleteWishListBO>  deleteWishListBO = null;
	    Array deleteResponse = null;
		
		try{
			String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_WISHLT_DELETE);
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			ArrayDescriptor partNumberArray = ArrayDescriptor.createDescriptor("APPS.V_PART_NUM_LIST_ARRAY", oracleConnection); 
			ARRAY partNoArray = new ARRAY(partNumberArray, oracleConnection, partNumberArr);
			callStatement = oracleConnection.prepareCall(procStr);
			callStatement.setQueryTimeout(QUERY_TIME_OUT_SECS);//Refer config file for # of secs
			callStatement.setString(1, strSSO.toUpperCase());
		    callStatement.setString(2, icaoCode);
	        callStatement.setArray(3,partNoArray);
            callStatement.registerOutParameter(4,OracleTypes.ARRAY, "APPS.V_RESPONSE_ARRAY");
        	callStatement.execute();
        deleteResponse  = (Array) callStatement.getArray(4);
       if (null != deleteResponse) {
       deleteWishListBO = populateDeleteWishList(deleteResponse);
       }
       
      
        	
        	
	}catch (Exception e) {
		log.error(e);
		throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			releaseResources(connection, callStatement, null);
		}
		   return deleteWishListBO;
	}

	private boolean isNotNullandEmpty(final String strData) {
		boolean isValid = false;
		if (strData != null && !strData.trim().equals(EMPTY_STRING)) {
			isValid = true;
		}
		return isValid;
	}
	protected void releaseResources(Connection con, Statement cs,
			ResultSet resultSet) {
		try {
			if (resultSet != null) {
				resultSet.close();
			}
			if (cs != null) {
				cs.close();
			}
			if (con != null) {
				con.close();
			}
		} catch (Exception e) {
			log.info(e);
		}
	}

	private List<WishListDetailsBO> populateWishListDetails(Array array) {
		WishListDetailsBO wishListDetailsDO = null;
		List<WishListDetailsBO> cartMessageDOList = new ArrayList<WishListDetailsBO>();
		try {

				Object[] returnrecordarray = (Object[]) array.getArray();
				for (int i = 0; i < returnrecordarray.length; i++) {
					wishListDetailsDO =  new WishListDetailsBO();
					Struct struct = (Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					wishListDetailsDO.setInventoryItemId(getAsString(obj[0]));
					wishListDetailsDO.setPartNumber(getAsString(obj[1]));
					wishListDetailsDO.setPartDescription(getAsString(obj[2]));
					wishListDetailsDO.setQuantity(getAsString(obj[3]));
					wishListDetailsDO.setUnitPrice(getAsString(obj[4]));
					wishListDetailsDO.setUpq(getAsString(obj[5]));
					wishListDetailsDO.setLeadTime(getAsString(obj[6]));
					wishListDetailsDO.setDiscountPercent(getAsString(obj[7]));
					wishListDetailsDO.setDisplayMessage(getAsString(obj[8]));
					wishListDetailsDO.setPartAvailMsg(getAsString(obj[9]));
					wishListDetailsDO.setPricMessage(getAsString(obj[10]));
					wishListDetailsDO.setDiscountMessage(getAsString(obj[11]));
					wishListDetailsDO.setCriticalPartMessage(getAsString(obj[12]));
					cartMessageDOList.add(wishListDetailsDO);
				
		} 
			}
		catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return cartMessageDOList;
	}

	private List<DeleteWishListBO> populateDeleteWishList(Array array) {
		DeleteWishListBO deleteWishListBO = null;
		List<DeleteWishListBO> deleteWishList = new ArrayList<DeleteWishListBO>();
		try {
				Object[] returnrecordarray = (Object[]) array.getArray();
				for (int i = 0; i < returnrecordarray.length; i++) {
					
					deleteWishListBO =  new DeleteWishListBO();
					Struct struct = (Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					deleteWishListBO.setPartNumber(getAsString(obj[0]));
					deleteWishListBO.setMessage(getAsString(obj[1]));
					deleteWishList.add(deleteWishListBO);
		
	}
		}
		catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return deleteWishList;
	}

}
