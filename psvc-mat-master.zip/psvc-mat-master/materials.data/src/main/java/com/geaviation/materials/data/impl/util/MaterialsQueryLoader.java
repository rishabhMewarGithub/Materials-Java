package com.geaviation.materials.data.impl.util;

import java.util.ResourceBundle;
import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.MATERIALS_QUERY;

public class MaterialsQueryLoader {

	/** The rb query props. */
	private static ResourceBundle rbQueryProps = ResourceBundle
			.getBundle(MATERIALS_QUERY);


	/**
	 * Instantiates a new query loader.
	 */
	private MaterialsQueryLoader(){
		
	}
	/**
	 * Gets the query.
	 * 
	 * @param key the key
	 * 
	 * @return the query
	 */
	public static String getQuery(final String key) {
		return rbQueryProps.getString(key);
	}
	
	
}
