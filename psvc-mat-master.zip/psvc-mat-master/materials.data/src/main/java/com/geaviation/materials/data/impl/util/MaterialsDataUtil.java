/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Feb 24 2016  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE, 
 *                      All rights reserved 
 * Code Review    :     Feb 24, 2016
 * Description    :     MaterialsDataUtil.java
 * 
 * History        :  	Mar 13, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.data.impl.util;


import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.EMPTY_STRING;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Array;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Struct;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.entity.ColumnBO;
import com.geaviation.materials.entity.ColumnGroupBO;
import com.geaviation.materials.entity.CommercialAgreementList;
import com.geaviation.materials.entity.LineMapping;
import com.geaviation.materials.entity.MYGEAGroupBO;
import com.geaviation.materials.entity.OrderHeaderDetails;
import com.geaviation.materials.entity.OrderHeaderInfoBO;
import com.geaviation.materials.entity.WccFileBO;

import oracle.stellent.ridc.IdcClient;
import oracle.stellent.ridc.IdcClientException;
import oracle.stellent.ridc.IdcClientManager;
import oracle.stellent.ridc.IdcContext;
import oracle.stellent.ridc.model.DataBinder;
import oracle.stellent.ridc.model.DataObject;
import oracle.stellent.ridc.model.DataResultSet;
import oracle.stellent.ridc.protocol.ServiceResponse;


@Component
public class MaterialsDataUtil {
	
	private static final Log log = LogFactory.getLog(MaterialsDataUtil.class);
	final static String SIMPLEDATEFORMAT = "yyyy-MM-dd";
	
	@Value("${WCC.IDC.URL}")
	private String idcUrl;
	
	@Value("${WCC.IDC.USER}")
	private String idcUser;
	
	@Value("${WCC.IDC.MSNUM.COLNAME}")
	private String idcMsNumColName;
	
	@Value("${WCC.IDC.DOCTYPE.COLNAME}")
	private String idcDocTypeColName;
	
	/**
	 * @param portalConfigString
	 * @return Portal Config Map
	 */
	public Map<String, String> getPortalConfigAsMap(String portalConfigString)
	{
		List<String> portalIdList = null;
		Map<String,String> portalConfigMap = new HashMap<String,String>();
		portalIdList = new ArrayList<String>(Arrays.asList(portalConfigString.split("\\|")));
		for (String  portalId : portalIdList) {
			String[] parts = portalId.split(":",2);
			portalConfigMap.put(parts[0],  parts[1]);
		}
		return portalConfigMap;
	}
	
	/**
	 * @param portalConfigString
	 * @param portalId
	 * @return Request days to add
	 */
	public String  getPortalRequestedDaysToAdd(String portalConfigString,String portalId)
	{
		String requestedDaysToAdd;
		Map<String,String>  requestedDaysToAddMap;
		requestedDaysToAddMap = getPortalConfigAsMap(portalConfigString);
		requestedDaysToAdd = requestedDaysToAddMap.get(portalId.toUpperCase());
		return requestedDaysToAdd;
	
	}
	
	/**
	 * @param inputDate
	 * @return Formatted date
	 */
	public String convertDate(String inputDate){
		Date date;
		String formattedDate = null;
		DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.S");
		DateFormat outputFormat = new SimpleDateFormat(SIMPLEDATEFORMAT);
		try {
			if(isNotNullandEmpty(inputDate))
			{
				date = inputFormat.parse(inputDate);
				formattedDate = outputFormat.format(date);
			}
		} catch (ParseException e) {
			log.error(e);
		}
		return formattedDate;
	}
	
	
	/**
	 * @param date1
	 * @return Formatted date
	 */
	public  String FormatedDate(String date1)  {
		Date date;
		String formattedDate = null;
		DateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy");
		DateFormat outputFormat = new SimpleDateFormat(SIMPLEDATEFORMAT);
		try {
			if(isNotNullandEmpty(date1))
			{
				date = inputFormat.parse(date1);
				formattedDate = outputFormat.format(date);
			}
		} catch (ParseException e) {
			log.error(e);
		}
		return formattedDate;
	}
	
	/**
	 * @param inputDate
	 * @return Converted date
	 */
	public String convertDateToYYMMMDD(String inputDate){
		Date date;
		String formattedDate = null;
		DateFormat inputFormat = new SimpleDateFormat(SIMPLEDATEFORMAT);
		DateFormat outputFormat = new SimpleDateFormat("yy-MMM-dd");
		try {
			if(isNotNullandEmpty(inputDate))
			{
				date = inputFormat.parse(inputDate);
				formattedDate = outputFormat.format(date);
			}
		} catch (ParseException e) {
			log.error(e);
		}
		return formattedDate;
	}
	/**
	 * Returns true if the given string is not null and not empty
	 * @param strData
	 * @return boolean
	 */	
	public static boolean isNullOrEmpty(final String strData) {
		boolean isValid = false;
		if (strData == null || "".trim().equals(strData)) {
			isValid = true;
		}
		return isValid;
	}
	/**
	 * Returns true if the given string is not null and not empty
	 * @param strData
	 * @return boolean
	 */
	public static boolean isNotNullandEmpty(final String strData) {
		boolean isValid = false;
		if (null!=strData && !"".trim().equals(strData)) {
			isValid = true;
		}
		return isValid;
	}
	
	public static String getAsString(Object obj) {
		if (null != obj) {
			return obj.toString().trim();
		}
		return "";
	}
	
	public static Integer getAsInteger(String obj) {
		if (null != obj && !"".equalsIgnoreCase(obj.trim())) {
			return Integer.parseInt(obj);
		}
		return Integer.parseInt("0");
	}
	public static boolean isCollectionNotEmpty(
			final Collection<? extends Object> list) {
		return (list != null && !list.isEmpty());
	}
	
	/**
	 * @param hdrArray
	 * @param colGrpArray
	 * @param colGEAEGRPArray
	 * @param colArray
	 * @param orderHeaderDetails
	 * @return Order Header details
	 */
	public OrderHeaderDetails getCartHdrDetails(Array hdrArray, Array colGrpArray,Array colGEAEGRPArray,Array colArray, 
			OrderHeaderDetails orderHeaderDetails) {
		OrderHeaderInfoBO headerInfoDO = null;
		List<ColumnGroupBO> columnGroupList = null;
		List<MYGEAGroupBO> colGEAEGroupList=null;
		//String uiColumnName=null;
		List<ColumnBO> colList = null;
		//Map lineMap = null;
		//LineMapping map = null;
		//Added for Snecma
		List<CommercialAgreementList> agreementList = null;
		try {
			if (null != hdrArray) {
				Object[] returnhdrInforecordarray = (Object[]) hdrArray.getArray();
				headerInfoDO = new OrderHeaderInfoBO();
				/*for (int count = 0; count < returnhdrInforecordarray.length;count++) {
					Struct struct = (Struct) returnhdrInforecordarray[count];
					Object[] obj = struct.getAttributes();
					headerInfoDO.setWarehouse(getAsString(obj[1]));
					headerInfoDO.setShipToLocation(getAsString(obj[2]));
					headerInfoDO.setShipToAddress_1(getAsString(obj[3]));
					headerInfoDO.setShipToAddress_2(getAsString(obj[4]));
					headerInfoDO.setShipToAddress_3(getAsString(obj[5]));
					headerInfoDO.setShipToAddress_4(getAsString(obj[6]));
					headerInfoDO.setShipToAddress_5(getAsString(obj[7]));
					headerInfoDO.setDeliverToLocation(getAsString(obj[8]));
					headerInfoDO.setDeliverToAddress_1(getAsString(obj[9]));
					headerInfoDO.setDeliverToAddress_2(getAsString(obj[10]));
					headerInfoDO.setDeliverToAddress_3(getAsString(obj[11]));
					headerInfoDO.setDeliverToAddress_4(getAsString(obj[12]));
					headerInfoDO.setDeliverToAddress_5(getAsString(obj[13]));
					headerInfoDO.setAirWayBillNumber(getAsString(obj[14]));
					headerInfoDO.setInvoiceNumber(getAsString(obj[15]));
					if(!MaterialsDataUtil.isNullOrEmpty(getAsString(obj[16]))) {
						headerInfoDO.setInvoiceDate(convertDate(getAsString(obj[16])));
					}
					else {
						headerInfoDO.setInvoiceDate("");
					}
					headerInfoDO.setInvoiceLink(getAsString(obj[17]));
					headerInfoDO.setInvoiceTotalAmount(getAsString(obj[18]));
					headerInfoDO.setCustomerCode(getAsString(obj[19]));
					headerInfoDO.setCustomerName(getAsString(obj[20]));
					if(!MaterialsDataUtil.isNullOrEmpty(getAsString(obj[21]))) {
						headerInfoDO.setOrderedDate(convertDate(getAsString(obj[21])));
					}
					else {
						headerInfoDO.setOrderedDate("");	
					}
					headerInfoDO.setOrderType(getAsString(obj[22]));
					headerInfoDO.setOrderStatus(getAsString(obj[23]));
					headerInfoDO.setCustomerPONumber(getAsString(obj[24]));
					headerInfoDO.setSupplierCode(getAsString(obj[25]));
					if(!MaterialsDataUtil.isNullOrEmpty(getAsString(obj[26]))) {
						headerInfoDO.setShipmentDate(convertDate(getAsString(obj[26])));
					}
					else {
						headerInfoDO.setShipmentDate("");
					}
					headerInfoDO.setBillOfLadding(getAsString(obj[27]));
					headerInfoDO.setWarehouseCode(getAsString(obj[28]));
					headerInfoDO.setInvoiceToLocation(getAsString(obj[29]));
					headerInfoDO.setInvoiceToAddress_1(getAsString(obj[30]));
					headerInfoDO.setInvoiceToAddress_2(getAsString(obj[31]));
					headerInfoDO.setInvoiceToAddress_3(getAsString(obj[32]));
					headerInfoDO.setInvoiceToAddress_4(getAsString(obj[33]));
					headerInfoDO.setInvoiceToAddress_5(getAsString(obj[34]));
					headerInfoDO.setCustomerId(getAsString(obj[35]));
					headerInfoDO.setInvoiceId(getAsString(obj[37]));
					headerInfoDO.setAwbLink(getAsString(obj[38]));
					headerInfoDO.setTotalOrderValue(getAsString(obj[39]));
					headerInfoDO.setTotalDiscount(getAsString(obj[40]));
				}*/
				headerInfoDO = getHeaderInfo(returnhdrInforecordarray);
				orderHeaderDetails.setOrderHeaderInfoBO(headerInfoDO);
			}	

			if (null != colGrpArray) {
				Object[] returngrpInforecordarray = (Object[]) colGrpArray.getArray();
				columnGroupList = new ArrayList<ColumnGroupBO>(); 
				/*for (int count = 0; count < returngrpInforecordarray.length; count++) {
					Struct struct = (Struct) returngrpInforecordarray[count];
					Object[] obj = struct.getAttributes();
					ColumnGroupBO columnGroupDO = new ColumnGroupBO();
					columnGroupDO.setGroupName(getAsString(obj[0]));
					String columnIds = getAsString(obj[1]);
					String[] columnIdArray = columnIds.split("\\|");
					if(null != columnIdArray){
						List<String> colIds = new ArrayList<String>();
						map = new LineMapping();
						lineMap = map.getColumnNameMap();
						for(int colCount = 0 ;colCount < columnIdArray.length;colCount++){
							if(lineMap.get(columnIdArray[colCount])!=null){
								uiColumnName = lineMap.get(columnIdArray[colCount]).toString();
							}
							else{
								uiColumnName=columnIdArray[colCount];
							}
							colIds.add(uiColumnName.trim());
						}
						columnGroupDO.setColumnIds(colIds);
					}
					columnGroupList.add(columnGroupDO);
				}*/
				columnGroupList = getColumnGroupList(returngrpInforecordarray);
				orderHeaderDetails.setColumnGroupBO(columnGroupList);
			}
			if (null != colGEAEGRPArray) {
				Object[] returngrpInforecordarray = (Object[]) colGEAEGRPArray.getArray();
				colGEAEGroupList = new ArrayList<MYGEAGroupBO>(); 
				/*for (int count = 0; count < returngrpInforecordarray.length; count++) {
					Struct struct = (Struct) returngrpInforecordarray[count];
					Object[] obj = struct.getAttributes();
					MYGEAGroupBO columnGEAEGroupDO = new MYGEAGroupBO();
					columnGEAEGroupDO.setGroupName(getAsString(obj[0]));
					String columnIds = getAsString(obj[1]);
					String[] columnIdArray = columnIds.split("\\|");
					if(null != columnIdArray){
						List<String> colIds = new ArrayList<String>();
						map = new LineMapping();
						lineMap = map.getColumnNameMap();
						for(int colCount = 0 ;colCount < columnIdArray.length;colCount++){
							if(lineMap.get(columnIdArray[colCount])!=null){
								uiColumnName = lineMap.get(columnIdArray[colCount]).toString();
							}
							else{
								uiColumnName=columnIdArray[colCount];
							}
							colIds.add(uiColumnName.trim());
						}
						columnGEAEGroupDO.setColumnIds(colIds);
					}
					colGEAEGroupList.add(columnGEAEGroupDO);
				}*/
				colGEAEGroupList = getGEAEGroupList(returngrpInforecordarray);
				orderHeaderDetails.setColMYGEAGrp(colGEAEGroupList);
			}
			if (null != colArray) {
				Object[] returncolInforecordarray = (Object[]) colArray.getArray();
				colList = new ArrayList<ColumnBO>(); 
				/*for (int count = 0; count < returncolInforecordarray.length;count++) {
					Struct struct = (Struct) returncolInforecordarray[count];
					Object[] obj = struct.getAttributes();
					ColumnBO columnDO = new ColumnBO();
					if(lineMap.get(getAsString(obj[0]))!=null){
						uiColumnName=lineMap.get(getAsString(obj[0])).toString();
					}
					else{
						uiColumnName=getAsString(obj[0]);
					}
					columnDO.setColumnId(uiColumnName.trim());
					columnDO.setColumnName(getAsString(obj[1]));
					colList.add(columnDO);
				}*/
				colList = getColList(returncolInforecordarray);
				orderHeaderDetails.setColumnList(colList);	
			}
			//Added for snecma - START
			agreementList = populateCommercialAgreementValuesForHdrDtl();
			orderHeaderDetails.setCommercialAgreementList(agreementList);
			//Added for snecma - END
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		return orderHeaderDetails;
	}
	
	
	private OrderHeaderInfoBO getHeaderInfo(Object[] returnhdrInforecordarray) throws SQLException {
		OrderHeaderInfoBO headerInfoDO = new OrderHeaderInfoBO();
		for (int count = 0; count < returnhdrInforecordarray.length;count++) {
			Struct struct = (Struct) returnhdrInforecordarray[count];
			Object[] obj = struct.getAttributes();
			headerInfoDO.setWarehouse(getAsString(obj[1]));
			headerInfoDO.setShipToLocation(getAsString(obj[2]));
			headerInfoDO.setShipToAddress_1(getAsString(obj[3]));
			headerInfoDO.setShipToAddress_2(getAsString(obj[4]));
			headerInfoDO.setShipToAddress_3(getAsString(obj[5]));
			headerInfoDO.setShipToAddress_4(getAsString(obj[6]));
			headerInfoDO.setShipToAddress_5(getAsString(obj[7]));
			headerInfoDO.setDeliverToLocation(getAsString(obj[8]));
			headerInfoDO.setDeliverToAddress_1(getAsString(obj[9]));
			headerInfoDO.setDeliverToAddress_2(getAsString(obj[10]));
			headerInfoDO.setDeliverToAddress_3(getAsString(obj[11]));
			headerInfoDO.setDeliverToAddress_4(getAsString(obj[12]));
			headerInfoDO.setDeliverToAddress_5(getAsString(obj[13]));
			headerInfoDO.setAirWayBillNumber(getAsString(obj[14]));
			headerInfoDO.setInvoiceNumber(getAsString(obj[15]));
			if(!MaterialsDataUtil.isNullOrEmpty(getAsString(obj[16]))) {
				headerInfoDO.setInvoiceDate(convertDate(getAsString(obj[16])));
			}
			else {
				headerInfoDO.setInvoiceDate("");
			}
			headerInfoDO.setInvoiceLink(getAsString(obj[17]));
			headerInfoDO.setInvoiceTotalAmount(getAsString(obj[18]));
			headerInfoDO.setCustomerCode(getAsString(obj[19]));
			headerInfoDO.setCustomerName(getAsString(obj[20]));
			if(!MaterialsDataUtil.isNullOrEmpty(getAsString(obj[21]))) {
				headerInfoDO.setOrderedDate(convertDate(getAsString(obj[21])));
			}
			else {
				headerInfoDO.setOrderedDate("");	
			}
			headerInfoDO.setOrderType(getAsString(obj[22]));
			headerInfoDO.setOrderStatus(getAsString(obj[23]));
			headerInfoDO.setCustomerPONumber(getAsString(obj[24]));
			headerInfoDO.setSupplierCode(getAsString(obj[25]));
			if(!MaterialsDataUtil.isNullOrEmpty(getAsString(obj[26]))) {
				headerInfoDO.setShipmentDate(convertDate(getAsString(obj[26])));
			}
			else {
				headerInfoDO.setShipmentDate("");
			}
			headerInfoDO.setBillOfLadding(getAsString(obj[27]));
			headerInfoDO.setWarehouseCode(getAsString(obj[28]));
			headerInfoDO.setInvoiceToLocation(getAsString(obj[29]));
			headerInfoDO.setInvoiceToAddress_1(getAsString(obj[30]));
			headerInfoDO.setInvoiceToAddress_2(getAsString(obj[31]));
			headerInfoDO.setInvoiceToAddress_3(getAsString(obj[32]));
			headerInfoDO.setInvoiceToAddress_4(getAsString(obj[33]));
			headerInfoDO.setInvoiceToAddress_5(getAsString(obj[34]));
			headerInfoDO.setCustomerId(getAsString(obj[35]));
			headerInfoDO.setInvoiceId(getAsString(obj[37]));
			headerInfoDO.setAwbLink(getAsString(obj[38]));
			headerInfoDO.setTotalOrderValue(getAsString(obj[39]));
			headerInfoDO.setTotalDiscount(getAsString(obj[40]));
		}
		return headerInfoDO;
	}
	
	private List<ColumnGroupBO> getColumnGroupList(Object[] returngrpInforecordarray) throws SQLException {
		List<ColumnGroupBO> columnGroupList = new ArrayList<ColumnGroupBO>(); 
		for (int count = 0; count < returngrpInforecordarray.length; count++) {
			Struct struct = (Struct) returngrpInforecordarray[count];
			Object[] obj = struct.getAttributes();
			ColumnGroupBO columnGroupDO = new ColumnGroupBO();
			columnGroupDO.setGroupName(getAsString(obj[0]));
			String columnIds = getAsString(obj[1]);
			String[] columnIdArray = columnIds.split("\\|");
			if(null != columnIdArray){
				List<String> colIds = new ArrayList<String>();
				/*LineMapping map = new LineMapping();
				Map lineMap = map.getColumnNameMap();
				for(int colCount = 0 ;colCount < columnIdArray.length;colCount++){
					if(lineMap.get(columnIdArray[colCount])!=null){
						uiColumnName = lineMap.get(columnIdArray[colCount]).toString();
					}
					else{
						uiColumnName=columnIdArray[colCount];
					}
					colIds.add(uiColumnName.trim());
				}*/
				colIds = getColIds(columnIdArray);
				columnGroupDO.setColumnIds(colIds);
			}
			columnGroupList.add(columnGroupDO);
		}
		return columnGroupList;
	}
	
	
	private List<MYGEAGroupBO> getGEAEGroupList(Object[] returngrpInforecordarray) throws SQLException {
		List<MYGEAGroupBO> colGEAEGroupList = new ArrayList<MYGEAGroupBO>(); 
		for (int count = 0; count < returngrpInforecordarray.length; count++) {
			Struct struct = (Struct) returngrpInforecordarray[count];
			Object[] obj = struct.getAttributes();
			MYGEAGroupBO columnGEAEGroupDO = new MYGEAGroupBO();
			columnGEAEGroupDO.setGroupName(getAsString(obj[0]));
			String columnIds = getAsString(obj[1]);
			String[] columnIdArray = columnIds.split("\\|");
			if(null != columnIdArray){
				List<String> colIds = new ArrayList<String>();
				/*LineMapping map = new LineMapping();
				Map lineMap = map.getColumnNameMap();
				for(int colCount = 0 ;colCount < columnIdArray.length;colCount++){
					if(lineMap.get(columnIdArray[colCount])!=null){
						uiColumnName = lineMap.get(columnIdArray[colCount]).toString();
					}
					else{
						uiColumnName=columnIdArray[colCount];
					}
					colIds.add(uiColumnName.trim());
				}*/
				colIds = getColIds(columnIdArray);
				columnGEAEGroupDO.setColumnIds(colIds);
			}
			colGEAEGroupList.add(columnGEAEGroupDO);
		}
		return colGEAEGroupList;
	}
	

	private List<String> getColIds (String[] columnIdArray) {
		String uiColumnName = null;
		List<String> colIds = new ArrayList<String>();
		LineMapping map = new LineMapping();
		Map<?, ?> lineMap = map.getColumnNameMap();
		for(int colCount = 0 ;colCount < columnIdArray.length;colCount++){
			if(lineMap.get(columnIdArray[colCount])!=null){
				uiColumnName = lineMap.get(columnIdArray[colCount]).toString();
			}
			else{
				uiColumnName=columnIdArray[colCount];
			}
			colIds.add(uiColumnName.trim());
		}
		return 	colIds;
	}
	
	
	private List<ColumnBO> getColList(Object[] returncolInforecordarray) throws SQLException {
		String uiColumnName = null;
		List<ColumnBO> colList = new ArrayList<ColumnBO>(); 
		LineMapping map = new LineMapping();
		Map<?, ?> lineMap = map.getColumnNameMap();
		for (int count = 0; count < returncolInforecordarray.length;count++) {
			Struct struct = (Struct) returncolInforecordarray[count];
			Object[] obj = struct.getAttributes();
			ColumnBO columnDO = new ColumnBO();
			if(lineMap != null && lineMap.get(getAsString(obj[0]))!=null){
				uiColumnName=lineMap.get(getAsString(obj[0])).toString();
			}
			else{
				uiColumnName=getAsString(obj[0]);
			}
			columnDO.setColumnId(uiColumnName.trim());
			columnDO.setColumnName(getAsString(obj[1]));
			colList.add(columnDO);
		}
		return colList;
	}
	
	/**
	 * @return List of CommercialAgreementList objects
	 */
	List<CommercialAgreementList> populateCommercialAgreementValuesForHdrDtl() {
		List<CommercialAgreementList> commercialAgreementList = new ArrayList<CommercialAgreementList>();
		try {
				/*agreementListBO = new CommercialAgreementList();
				agreementListBO.setCommercialAgreementNumber("");
				agreementListBO.setCommercialAgreementName("");
				commercialAgreementList.add(agreementListBO);*/
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(), e.getCause());
		}
		
		return commercialAgreementList;
	}
	
	/**
	 * This method will release the connection
	 * @param con
	 * @param cs
	 * @param resultSet
	 */
	public void releaseResources(Connection con, Statement cs,
			ResultSet resultSet) {
		try {
			if (resultSet != null) {
				resultSet.close();
			}
			if (cs != null) {
				cs.close();
			}
			if (con != null) {
				con.close();
			}
		} catch (Exception e) {
			log.error(e);
		}
	}
	
	public Object encodeForJava(Object object) {
		return object==null ? null : Encode.forJava(object.toString());
	}
	
	public List<Object[]> getAsJavaObject(Array array) {
		List<Object[]> list1 = new ArrayList<Object[]>();
		try {
			if (null != array) {
				//Struct struct ;
				Object[] obj = null;
				//int recordCount = 0;
				Object[] returnrecordarray = (Object[]) array.getArray();
				int recordSize = returnrecordarray.length;
				/*for ( ; recordCount < recordSize; recordCount++) {
					if(returnrecordarray[recordCount] != null)
					{
						struct = (Struct) returnrecordarray[recordCount];
						obj = struct.getAttributes();
						list1.add(obj);
					}
				}*/
				list1 = getObjectList(recordSize, returnrecordarray);
			}
			} catch (Exception e) {
				log.error(e);
				throw new TechnicalException(e.getMessage(), e.getCause());
			}
		return list1;
	}
	
	private List<Object[]> getObjectList(int recordSize, Object[] returnrecordarray) throws SQLException {
		List<Object[]> list = new ArrayList<Object[]>();
		int recordCount = 0;
		Struct struct;
		Object[] obj = null;
		for ( ; recordCount < recordSize; recordCount++) {
			if(returnrecordarray[recordCount] != null)
			{
				struct = (Struct) returnrecordarray[recordCount];
				obj = struct.getAttributes();
				list.add(obj);
			}
		}
		return list;
	}
	
	public static byte[] getBytesFromStream(InputStream is) throws IOException
	{
		byte[] bytes = null;
		try
		{
			bytes = new byte[1024];

			int offset = 0;
			int numRead = 0;
			while ((offset < bytes.length) && ((numRead = is.read(bytes, offset, bytes.length - offset)) >= 0))
			{
				offset += numRead;
			}
			if (offset < bytes.length) { 
				throw new IOException("Could not completely read the stream "); 
			}
		}
		catch(Exception e){
			throw new IOException(e); 
		}
		return bytes;

	}
	public void startLogging(String task, StopWatch watch) {
		watch.start(task);
		log.info("MATL-PERF : <Calling " + task + " method> START ");
	}

	/**
	 * This method will ends a logging task
	 * 
	 * @param task
	 * @param watch
	 */
	public void endLogging(String task, StopWatch watch) {
		watch.stop();
		log.info("MATL-PERF : <Calling " + task + " method> END - " + watch.getLastTaskTimeMillis());
	}
	
	public String getFormattedDate(String date, String inputFormat, String outputFormat) {
		DateFormat outFormat = null;
		DateFormat inFormat = null;
		String formattedDt = EMPTY_STRING;
		try{
			if((null!=date&&!date.isEmpty()) && null!=outputFormat&&!outputFormat.isEmpty()){
				inFormat = new SimpleDateFormat(inputFormat);
				outFormat = new SimpleDateFormat(outputFormat);
				formattedDt = outFormat.format(inFormat.parse(date));
			}
		} catch (Exception e) {
			log.info(e);
			formattedDt = date;
		}
		return formattedDt;
	}
	
	public String[] splitString(final String input,
			final String delimitter) {
		String[] result = null;
		if (isNotNullandEmpty(input)) {
			StringTokenizer stringToken = new StringTokenizer(input, delimitter);
			int count = stringToken.countTokens();
			result = new String[count];
			int index = 0;
			while (stringToken.hasMoreTokens()) {
				result[index] = stringToken.nextToken().trim();
				index++;
			}
		}
		return result;
	}
	
	
	
	/** Creates an IdcClient object that will be used to connect to the given IDC URL
	 * @param url
	 * @return IdcClient object
	 */
	public IdcClient<?, ?, ?> getIdcClient(String url) {
		IdcClientManager idcManager = new IdcClientManager();
        IdcClient<?, ?, ?> idcClient;
        
		try {
			idcClient = idcManager.createClient(url);
		} catch (IdcClientException ice) {
			log.error("Error connecting to IDC URL : " + url);
			log.error(ice);
			throw new TechnicalException(ice.getMessage(), ice.getCause());
		}
        
        return idcClient;
	}
	
	
	/**
	 * Creates an IdcContext object that will contain the user context of the provided user name to be used for accessing IDC
	 * @param user
	 * @return IdcContext object with user context
	 */
	public IdcContext getIdcContext(String user) {
		return (new IdcContext(user));
	}
	
	/**
	 * Creates a DataBinder object that will be used in the IDC request. This object will contain the query parameters sent to the IDC server
	 * @param idcClient
	 * @return DataBinder object 
	 */
	public DataBinder getIdcDataBinder(IdcClient<?, ?, ?> idcClient) {
		return idcClient.createBinder();
	}
}
