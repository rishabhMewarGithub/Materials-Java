
package com.geaviation.materials.data.impl;

import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.EMPTY_STRING;
import static com.geaviation.materials.data.impl.util.MaterialsDataConstants.YES;

import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.data.api.IMaterialsLoginDAO;
import com.geaviation.materials.data.impl.util.MaterialsDataConstants;
import com.geaviation.materials.data.impl.util.MaterialsDataUtil;
import com.geaviation.materials.data.impl.util.MaterialsQueryLoader;
import com.geaviation.materials.entity.CustomerBO;
import com.geaviation.materials.entity.MaterialsUserAccess;
import com.geaviation.materials.entity.MaterialsUserBO;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;


@Component
public class MaterialsLoginDAOImpl implements IMaterialsLoginDAO  {
	
	@Value("${PORTAL_TO_OPERATING_UNIT_MAPPING}")
	private String portalToOperatingUnitIdConfig;
	
	@Value("${PORTAL_TO_OPERATING_UNIT_MAPPING_CWC}")
	private String portalToOperatingUnitIdCwc;
	
	@Value("${QUERY_TIME_OUT_SECS}")
	private int queryTimeOutSecs;
	
	@Autowired
	@Qualifier("ampsOraDS")
	private DataSource ampsOraDS;

	
	
	@Autowired
	private MaterialsDataUtil materialsDataUtil;

	private static final Log log = LogFactory.getLog(MaterialsLoginDAOImpl.class);

	@Override
	public String getPortalOUDS(String portalId, boolean multipleOUID) throws TechnicalException {
		Map<String,String> portalOuIdMap = new HashMap<String,String>();
		if(portalId.equalsIgnoreCase(MaterialsDataConstants.PORTAL_CWC) && multipleOUID){
			portalOuIdMap = materialsDataUtil.getPortalConfigAsMap(portalToOperatingUnitIdCwc);
		}
		else{
			portalOuIdMap = materialsDataUtil.getPortalConfigAsMap(portalToOperatingUnitIdConfig);
		}
		return portalOuIdMap.get(portalId);
	}

	@Override
	public MaterialsUserAccess isHavingAccessDS(String strSSO, String icaoCd, String opUid)
			throws TechnicalException {
		log.info("Entered into isHavingAccessDS() method");
		Connection connection = null;
		CallableStatement callStatement = null;
		MaterialsUserAccess userAccess = null;
		String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_CHECK_LOGIN);
		try {
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null) {
				callStatement = connection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
				callStatement.setString(1, opUid);
				callStatement.setString(2, icaoCd);
				callStatement.setString(3, strSSO.toUpperCase());
				callStatement.registerOutParameter(4, OracleTypes.VARCHAR);
				callStatement.registerOutParameter(5, OracleTypes.VARCHAR);
				callStatement.execute();
				String ouId = (String) callStatement.getObject(4);
				String outErrMsg = (String) callStatement.getObject(5);
				userAccess = new MaterialsUserAccess();
				if(!MaterialsDataUtil.isNullOrEmpty(ouId)){
					userAccess.setSuccess(true);
					userAccess.setOuid(ouId);
				}
				else
				{
					userAccess.setSuccess(false);
					userAccess.setMessage(outErrMsg);
				}
			}			
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
			
		}
		log.info("isHavingAccessDS() method - END");
		return userAccess;
	}

	@Override
	public MaterialsUserBO requestLoginDS(String strSSO, String icaoCd, String opUid, String impersonator)
			throws TechnicalException {
		log.info("Entered into requestLoginDS() method");
		Connection connection = null;
		CallableStatement callStatement = null;
		MaterialsUserBO userBO = null;
		List<CustomerBO> customerBOlist = null;
		StopWatch watch = new StopWatch();
		String task = "";
		String message = "";
		String role = "";
		String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_REQUEST_LOGIN);
		try {
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null) {
				callStatement = connection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
				callStatement.setString(1, opUid);
				callStatement.setString(2, icaoCd);
				callStatement.setString(3, strSSO.toUpperCase());
				callStatement.setString(4, impersonator);
				callStatement.registerOutParameter(5, OracleTypes.VARCHAR);
				callStatement.registerOutParameter(6, OracleTypes.ARRAY, "APPS.V_CUST_ARRAY");
				callStatement.registerOutParameter(7, OracleTypes.VARCHAR);
				callStatement.execute();
				userBO =  new MaterialsUserBO();
				message = (String) materialsDataUtil.encodeForJava(callStatement.getObject(7));
				if(MaterialsDataUtil.isNotNullandEmpty(message)){
					userBO.setMessage(message);
					return userBO;
				}
				role = (String) materialsDataUtil.encodeForJava(callStatement.getObject(5));
				userBO.setRole(role);
				task = "populateCustValues";
				watch.start(task);
				log.info("requestLoginDS method <"+ task +"> - STARTED ");
				Array array =  callStatement.getArray(6);
				customerBOlist = populateCustValues(array);
				watch.stop();
				log.info("requestLoginDS method <"+ task +"> - ENDED and has taken " +watch.getLastTaskTimeMillis() +" msecs.");
				userBO.setCustomerBOList(customerBOlist);
			}			
			//Cache this Obj
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
			
		}
		log.info("requestLoginDS() method - END");
		return userBO;
	}


	public static boolean isMapNotEmpty(
			final Map<? extends Object, ? extends Object> map) {
		return (map != null && !map.isEmpty());
	}

	private List<CustomerBO> populateCustValues(Array array){
		List<CustomerBO> list = new ArrayList<CustomerBO>();
		CustomerBO custObj = null;
		try {
			if(null!=array){
				Object[] returnrecordarray = (Object[])array.getArray();
				for(int i=0;i<returnrecordarray.length;i++){
					Struct struct =(Struct) returnrecordarray[i];
					Object[] obj = struct.getAttributes();
					custObj = new CustomerBO();
					custObj.setCustId(MaterialsDataUtil.getAsString(obj[0]));
					custObj.setCustCode(MaterialsDataUtil.getAsString(obj[1]));
					custObj.setCustName(MaterialsDataUtil.getAsString(obj[2]));
					list.add(custObj);
				}
			}
		} catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}
		return list;
	}

	@Override
	public MaterialsUserBO requestLoginRepairsDS(String sso, String icao,String opUid, String impersonator) throws TechnicalException {
		log.info("Entered into requestLoginDS() method");
		Connection connection = null;
		CallableStatement callStatement = null;
		MaterialsUserBO userBO = null;
		List<CustomerBO> customerBOlist = null;
		StopWatch watch = new StopWatch();
		String task = EMPTY_STRING;
		String message = EMPTY_STRING;
		String role = EMPTY_STRING;
		String procStr = MaterialsQueryLoader.getQuery(MaterialsDataConstants.SP_REQUEST_REPAIR_LOGIN);
		try {
			connection = ampsOraDS.getConnection();
			OracleConnection oracleConnection = null;
			if (connection.isWrapperFor(OracleConnection.class)) {
				oracleConnection = connection.unwrap(OracleConnection.class);
			}
			if(oracleConnection != null) {
				callStatement = connection.prepareCall(procStr);
				callStatement.setQueryTimeout(queryTimeOutSecs);//Refer config file for # of secs
				callStatement.setString(1, opUid);
				callStatement.setString(2, icao);
				callStatement.setString(3, sso.toUpperCase());
				callStatement.setString(4, impersonator);
				callStatement.registerOutParameter(5, OracleTypes.VARCHAR);
				callStatement.registerOutParameter(6, OracleTypes.ARRAY, "APPS.V_CUST_ARRAY");
				callStatement.registerOutParameter(7, OracleTypes.VARCHAR);
				callStatement.execute();
				userBO =  new MaterialsUserBO();
				message = (String) materialsDataUtil.encodeForJava(callStatement.getObject(7));
				if(MaterialsDataUtil.isNotNullandEmpty(message)){
					userBO.setMessage(message);
					return userBO;
				}
				role = (String) materialsDataUtil.encodeForJava(callStatement.getObject(5));
				userBO.setRole(role);
				task = "populateCustValues";
				watch.start(task);
				log.info("requestLoginRepairsDS method <"+ task +"> - STARTED ");
				Array array =  callStatement.getArray(6);
				customerBOlist = populateCustValues(array);
				watch.stop();
				log.info("requestLoginRepairsDS method <"+ task +"> - ENDED and has taken " +watch.getLastTaskTimeMillis() +" msecs.");
				userBO.setCustomerBOList(customerBOlist);
			}			
		}catch (Exception e) {
			log.error(e);
			throw new TechnicalException(e.getMessage(),e.getCause());
		}finally{
			materialsDataUtil.releaseResources(connection, callStatement, null);
		}
		log.info("requestLoginRepairsDS() method - END");
		return userBO;
	}


	
}
