package com.geaviation.materials.data.api;

import java.util.List;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.entity.CustomerBO;
import com.geaviation.materials.entity.ItemConfigHistoryBO;
import com.geaviation.materials.entity.KitStructureBO;
import com.geaviation.materials.entity.PartDetailsBO;

public interface IMaterialsItemDAO {
	
	public PartDetailsBO getItemAvailPricDtlDS(String strSSO,String icaoCode,List<CustomerBO> custId,String role,String operatingUnitId,String invontoryItemId);
	//JIRA 5059
	public PartDetailsBO getItemAvailPricPartDtlDS(String strSSO,String icaoCode,List<CustomerBO> custId,String role,String operatingUnitId,String partNumber);
	public ItemConfigHistoryBO getItemConfigHistoryDS(String strSSO,String icaoCode,List<CustomerBO> customerBOList,String role,String operatingUnitId,String invontoryItemId,String partNumber);
	public KitStructureBO getKitStructureDS(String sso, String icaoCode, String[] custIdList, String role, String operatingUnitId, String inventoryItemId)throws TechnicalException;
	public ItemConfigHistoryBO getRepUsedItemConfigHistory(String strSSO, String icaoCode, String role, String operatingUnitId, String partNumber) throws TechnicalException;
}
