/******************************************************** 
 * Project        :     Materials: CWC Services 
 * Date		      :    	Oct 21, 2014  
 * Created By	  :		720053	
 * Security       :     GE Confidential 
 * Restrictions   :     GE PROPRIETARY INFORMATION, FOR GE USE ONLY. 
 *                      Copyright(C) 2014 GE 
 *                      All rights reserved 
 * Description    :     IMaterialsShipmentDAO.java
 * 
 * History        :  	Oct 21, 2014                
   Date                           
 **********************************************************/
package com.geaviation.materials.data.api;

import com.geaviation.dss.service.common.exception.TechnicalException;
import com.geaviation.materials.entity.CustLoginDetails;
import com.geaviation.materials.entity.DisputeOrderInput;
import com.geaviation.materials.entity.DisputeOrderStatusBO;
import com.geaviation.materials.entity.ReturnLabelDO;

public interface IMaterialsShipmentDAO {
	
	/**
	 * @param custLoginDetails
	 * @param orderHeaderId
	 * @return
	 */
	public ReturnLabelDO getReturnLabelDetailDS(String sso, String orderHeaderId, CustLoginDetails custLoginDetails) throws TechnicalException;
	/**
	 * @param disputeOrderInput
	 * @return
	 */
	public DisputeOrderStatusBO createDisputeOrderDS(DisputeOrderInput disputeOrderInput);
	

}
